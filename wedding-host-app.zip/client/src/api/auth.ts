import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { AppLoginResponse, AppRegisterRequest } from '@shared/api.interface';

const TOKEN_KEY = 'app_auth_token';

// ===== 请求拦截器：自动附加 x-app-auth 头 =====
axiosForBackend.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      // 使用 AxiosHeaders.set 安全地附加自定义头
      if (!config.headers) {
        config.headers = {} as any;
      }
      (config.headers as Record<string, string>)['x-app-auth'] = token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// ===== 响应拦截器：401 自定义 token 失效时清理 =====
axiosForBackend.interceptors.response.use(
  (response) => response,
  (error) => {
    // 平台 SSO 的 401（带 x-login-url 头）不处理，保持现状
    if (error?.response?.status === 401) {
      const loginUrl = error.response.headers?.['x-login-url'];
      if (!loginUrl) {
        // 自定义 token 失效，清掉本地 token
        try {
          localStorage.removeItem(TOKEN_KEY);
        } catch (e) {
          logger.warn('清除 token 失败', e);
        }
      }
    }
    return Promise.reject(error);
  }
);

// ===== 登录 =====
export async function login(username: string, password: string): Promise<AppLoginResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/auth/login',
      method: 'POST',
      data: { username, password },
    });
    const data: AppLoginResponse = response.data;
    if (data?.token) {
      localStorage.setItem(TOKEN_KEY, data.token);
    }
    return data;
  } catch (error) {
    logger.error('登录失败', error);
    throw error;
  }
}

// ===== 注册 =====
export async function register(
  username: string,
  password: string,
  nickname?: string,
): Promise<AppLoginResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/auth/register',
      method: 'POST',
      data: { username, password, nickname } as AppRegisterRequest,
    });
    const data: AppLoginResponse = response.data;
    if (data?.token) {
      localStorage.setItem(TOKEN_KEY, data.token);
    }
    return data;
  } catch (error) {
    logger.error('注册失败', error);
    throw error;
  }
}

// ===== 退出登录 =====
export async function logout(): Promise<{ success: boolean }> {
  try {
    const response = await axiosForBackend({
      url: '/api/auth/logout',
      method: 'POST',
    });
    return response.data;
  } catch (error) {
    logger.error('登出接口调用失败', error);
    throw error;
  } finally {
    // 无论成功失败都清本地 token
    localStorage.removeItem(TOKEN_KEY);
  }
}

// ===== 修改密码 =====
export async function changePassword(oldPassword: string, newPassword: string): Promise<{ success: boolean }> {
  try {
    const response = await axiosForBackend({
      url: '/api/auth/change-password',
      method: 'POST',
      data: { oldPassword, newPassword },
    });
    return response.data;
  } catch (error) {
    logger.error('修改密码失败', error);
    throw error;
  }
}

// ===== 获取当前用户 =====
export async function getCurrentUser() {
  try {
    const response = await axiosForBackend({ url: '/api/auth/me', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取用户信息失败', error);
    throw error;
  }
}

// ===== 获取 AI 额度 =====
export async function getAiQuota() {
  try {
    const response = await axiosForBackend({ url: '/api/auth/quota', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取AI额度失败', error);
    throw error;
  }
}
