import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

export async function getScriptList(params?: {
  category?: string;
  keyword?: string;
  isFavorite?: boolean;
  page?: number;
  pageSize?: number;
}) {
  try {
    const response = await axiosForBackend({ url: '/api/scripts', method: 'GET', params });
    return response.data;
  } catch (error) {
    logger.error('获取台词列表失败', error);
    throw error;
  }
}

export async function getScriptDetail(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/scripts/${id}`, method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取台词详情失败', error);
    throw error;
  }
}

export async function createScript(data: any) {
  try {
    const response = await axiosForBackend({ url: '/api/scripts', method: 'POST', data });
    return response.data;
  } catch (error) {
    logger.error('创建台词失败', error);
    throw error;
  }
}

export async function updateScript(id: string, data: any) {
  try {
    const response = await axiosForBackend({ url: `/api/scripts/${id}`, method: 'PUT', data });
    return response.data;
  } catch (error) {
    logger.error('更新台词失败', error);
    throw error;
  }
}

export async function deleteScript(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/scripts/${id}`, method: 'DELETE' });
    return response.data;
  } catch (error) {
    logger.error('删除台词失败', error);
    throw error;
  }
}

export async function toggleFavorite(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/scripts/${id}/favorite`, method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('切换收藏失败', error);
    throw error;
  }
}

export async function getScriptCategories() {
  try {
    const response = await axiosForBackend({ url: '/api/scripts/categories', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取台词分类失败', error);
    throw error;
  }
}
