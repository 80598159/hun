import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  Quotation,
  QuotationListResponse,
  CreateQuotationRequest,
  UpdateQuotationRequest,
  ExportQuotationResponse,
} from '@shared/api.interface';

export async function getQuotations(params?: {
  page?: number;
  pageSize?: number;
}): Promise<QuotationListResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/quotations',
      method: 'GET',
      params,
    });
    return response.data;
  } catch (error) {
    logger.error('获取报价单列表失败', error);
    throw error;
  }
}

export async function getQuotation(id: string): Promise<Quotation> {
  try {
    const response = await axiosForBackend({
      url: `/api/quotations/${id}`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取报价单详情失败', error);
    throw error;
  }
}

export async function createQuotation(data: CreateQuotationRequest): Promise<Quotation> {
  try {
    const response = await axiosForBackend({
      url: '/api/quotations',
      method: 'POST',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('创建报价单失败', error);
    throw error;
  }
}

export async function updateQuotation(
  id: string,
  data: UpdateQuotationRequest,
): Promise<Quotation> {
  try {
    const response = await axiosForBackend({
      url: `/api/quotations/${id}`,
      method: 'PATCH',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('更新报价单失败', error);
    throw error;
  }
}

export async function deleteQuotation(id: string): Promise<void> {
  try {
    await axiosForBackend({
      url: `/api/quotations/${id}`,
      method: 'DELETE',
    });
  } catch (error) {
    logger.error('删除报价单失败', error);
    throw error;
  }
}

export async function exportQuotation(id: string): Promise<ExportQuotationResponse> {
  try {
    const response = await axiosForBackend({
      url: `/api/quotations/${id}/export`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('导出报价单失败', error);
    throw error;
  }
}

export async function duplicateQuotation(id: string): Promise<Quotation> {
  try {
    const response = await axiosForBackend({
      url: `/api/quotations/${id}/duplicate`,
      method: 'POST',
    });
    return response.data;
  } catch (error) {
    logger.error('复制报价单失败', error);
    throw error;
  }
}
