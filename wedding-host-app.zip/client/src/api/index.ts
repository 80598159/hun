import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

export * as auth from './auth';
export * as wedding from './wedding';
export * as script from './script';
export * as schedule from './schedule';
export * as toolkit from './toolkit';
export * as ai from './ai';
export * as user from './user';
export * as shop from './shop';
export * as admin from './admin';
export * as bgm from './bgm';
export * as quotation from './quotation';
export * as questionnaire from './questionnaire';
