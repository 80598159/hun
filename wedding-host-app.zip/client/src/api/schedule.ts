import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

export async function getSchedules(params?: { startDate?: string; endDate?: string }) {
  try {
    const response = await axiosForBackend({ url: '/api/schedules', method: 'GET', params });
    return response.data;
  } catch (error) {
    logger.error('获取档期列表失败', error);
    throw error;
  }
}

export async function getScheduleDetail(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/schedules/${id}`, method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取档期详情失败', error);
    throw error;
  }
}

export async function createSchedule(data: any) {
  try {
    const response = await axiosForBackend({ url: '/api/schedules', method: 'POST', data });
    return response.data;
  } catch (error) {
    logger.error('创建档期失败', error);
    throw error;
  }
}

export async function updateSchedule(id: string, data: any) {
  try {
    const response = await axiosForBackend({ url: `/api/schedules/${id}`, method: 'PUT', data });
    return response.data;
  } catch (error) {
    logger.error('更新档期失败', error);
    throw error;
  }
}

export async function deleteSchedule(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/schedules/${id}`, method: 'DELETE' });
    return response.data;
  } catch (error) {
    logger.error('删除档期失败', error);
    throw error;
  }
}

export async function checkConflict(date: string, timeType: string) {
  try {
    const response = await axiosForBackend({
      url: '/api/schedules/check-conflict',
      method: 'GET',
      params: { date, timeType },
    });
    return response.data;
  } catch (error) {
    logger.error('检查撞单失败', error);
    throw error;
  }
}
