import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { AiScriptGenerateRequest, RemoveBackgroundRequest, RemoveBackgroundResponse } from '@shared/api.interface';

export async function generateFlow(description: string) {
  try {
    const response = await axiosForBackend({
      url: '/api/ai/generate-flow',
      method: 'POST',
      data: { description },
    });
    return response.data;
  } catch (error) {
    logger.error('AI生成流程失败', error);
    throw error;
  }
}

export async function generateScript(params: AiScriptGenerateRequest) {
  try {
    const response = await axiosForBackend({
      url: '/api/ai/generate-script',
      method: 'POST',
      data: params,
    });
    return response.data;
  } catch (error) {
    logger.error('AI生成台词失败', error);
    throw error;
  }
}

export async function checkScriptQuota() {
  try {
    const response = await axiosForBackend({ url: '/api/ai/check-script-quota', method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('检查台词额度失败', error);
    throw error;
  }
}

export async function consumeScriptQuota() {
  try {
    const response = await axiosForBackend({ url: '/api/ai/consume-script', method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('扣减台词额度失败', error);
    throw error;
  }
}

export async function parseRequirement(text: string) {
  try {
    const response = await axiosForBackend({
      url: '/api/ai/parse-requirement',
      method: 'POST',
      data: { text },
    });
    return response.data;
  } catch (error) {
    logger.error('AI需求解析失败', error);
    throw error;
  }
}

export async function detectRisk(flowList: any[], weddingInfo: any) {
  try {
    const response = await axiosForBackend({
      url: '/api/ai/detect-risk',
      method: 'POST',
      data: { flowList, weddingInfo },
    });
    return response.data;
  } catch (error) {
    logger.error('AI风险检测失败', error);
    throw error;
  }
}

export async function removeBackground(req: RemoveBackgroundRequest): Promise<RemoveBackgroundResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/ai/remove-background',
      method: 'POST',
      data: req,
      timeout: 60000,
    });
    return response.data as RemoveBackgroundResponse;
  } catch (error: any) {
    logger.error('AI云端抠图失败', error);
    const serverMsg = error?.response?.data?.message || error?.response?.data?.error?.message;
    const msg = serverMsg || (error?.message || '网络错误，请稍后重试');
    return {
      success: false,
      message: msg,
    };
  }
}
