import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  QuestionnaireListResponse,
  QuestionnaireDetailResponse,
  QuestionnaireCreateRequest,
  QuestionnaireUpdateFieldsRequest,
  QuestionnaireAnswerListResponse,
  QuestionnaireAnswerSubmitRequest,
  QuestionnaireApplyToProjectRequest,
} from '@shared/api.interface';

const BASE = '/api/questionnaires';

export async function list(): Promise<QuestionnaireListResponse> {
  try {
    const response = await axiosForBackend({
      url: BASE,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取问卷列表失败', error);
    throw error;
  }
}

export async function get(id: string): Promise<QuestionnaireDetailResponse> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/${id}`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取问卷详情失败', error);
    throw error;
  }
}

export async function create(
  data: QuestionnaireCreateRequest,
): Promise<QuestionnaireDetailResponse> {
  try {
    const response = await axiosForBackend({
      url: BASE,
      method: 'POST',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('创建问卷失败', error);
    throw error;
  }
}

export async function updateFields(
  id: string,
  fields: QuestionnaireUpdateFieldsRequest,
): Promise<QuestionnaireDetailResponse> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/${id}/fields`,
      method: 'PATCH',
      data: fields,
    });
    return response.data;
  } catch (error) {
    logger.error('更新问卷字段失败', error);
    throw error;
  }
}

export async function updateStatus(
  id: string,
  status: 'draft' | 'published' | 'closed',
): Promise<{ success: boolean }> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/${id}/status`,
      method: 'PATCH',
      data: { status },
    });
    return response.data;
  } catch (error) {
    logger.error('更新问卷状态失败', error);
    throw error;
  }
}

export async function remove(id: string): Promise<{ success: boolean }> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/${id}`,
      method: 'DELETE',
    });
    return response.data;
  } catch (error) {
    logger.error('删除问卷失败', error);
    throw error;
  }
}

export async function getAnswers(id: string): Promise<QuestionnaireAnswerListResponse> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/${id}/answers`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取问卷答案失败', error);
    throw error;
  }
}

export async function getByShareCode(
  shareCode: string,
): Promise<QuestionnaireDetailResponse> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/by-code/${shareCode}`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取公开问卷失败', error);
    throw error;
  }
}

export async function submitAnswer(
  data: QuestionnaireAnswerSubmitRequest,
): Promise<{ success: boolean }> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/submit`,
      method: 'POST',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('提交问卷答案失败', error);
    throw error;
  }
}

export async function applyToProject(
  data: QuestionnaireApplyToProjectRequest,
): Promise<{ success: boolean }> {
  try {
    const response = await axiosForBackend({
      url: `${BASE}/apply-to-project`,
      method: 'POST',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('写入方案失败', error);
    throw error;
  }
}
