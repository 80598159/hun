import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

export async function getProducts() {
  try {
    const response = await axiosForBackend({ url: '/api/shop/products', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取商品列表失败', error);
    throw error;
  }
}

export async function createOrder(data: any) {
  try {
    const response = await axiosForBackend({ url: '/api/shop/orders', method: 'POST', data });
    return response.data;
  } catch (error) {
    logger.error('创建订单失败', error);
    throw error;
  }
}

export async function payOrder(orderId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/shop/orders/${orderId}/pay`, method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('支付失败', error);
    throw error;
  }
}

export async function getOrder(orderId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/shop/orders/${orderId}`, method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取订单失败', error);
    throw error;
  }
}

export async function getUserProfile() {
  try {
    const response = await axiosForBackend({ url: '/api/user/profile', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取用户资料失败', error);
    throw error;
  }
}

export async function updateUserProfile(data: any) {
  try {
    const response = await axiosForBackend({ url: '/api/user/profile', method: 'PUT', data });
    return response.data;
  } catch (error) {
    logger.error('更新用户资料失败', error);
    throw error;
  }
}

export async function updatePosterPhoto(
  posterPhotoUrl: string,
  projectId?: string,
): Promise<{
  posterPhotoUrl: string;
  remainingUpdates: number;
  totalLimit: number;
}> {
  try {
    const response = await axiosForBackend({
      url: '/api/user/poster-photo',
      method: 'POST',
      data: { posterPhotoUrl, projectId },
    });
    return response.data;
  } catch (error) {
    logger.error('更新海报形象照失败', error);
    throw error;
  }
}

export async function getOrderList(params?: { page?: number; pageSize?: number }) {
  try {
    const response = await axiosForBackend({ url: '/api/user/orders', method: 'GET', params });
    return response.data;
  } catch (error) {
    logger.error('获取订单列表失败', error);
    throw error;
  }
}

export async function getFavoriteList(params?: { page?: number; pageSize?: number }) {
  try {
    const response = await axiosForBackend({ url: '/api/user/favorites', method: 'GET', params });
    return response.data;
  } catch (error) {
    logger.error('获取收藏列表失败', error);
    throw error;
  }
}
