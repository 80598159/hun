import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  AdminLoginRequest,
  AdminLoginResponse,
  AdminDashboardResponse,
  AdminUserListResponse,
  AdminUpdateUserRequest,
  AdminCreateUserRequest,
  AdminAdjustQuotaRequest,
  AdminResetPasswordRequest,
  AdminProjectListResponse,
  AdminScriptListResponse,
  AdminCreateScriptRequest,
  AdminUpdateScriptRequest,
  AdminProductListResponse,
  AdminCreateProductRequest,
  AdminUpdateProductRequest,
  AdminOrderListResponse,
  AdminUpdateOrderStatusRequest,
  AdminMerchantListResponse,
  AdminCreateMerchantRequest,
  AdminUpdateMerchantRequest,
  AdminAuditListResponse,
  AdminUpdateAuditRequest,
  AiApiConfigListResponse,
  AiApiConfigCreateRequest,
  AiApiConfigUpdateRequest,
  AiApiTestResponse,
  SystemConfigListResponse,
  SystemConfigUpdateRequest,
} from '@shared/api.interface';

const ADMIN_TOKEN_KEY = 'admin_session';
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = '123456';

interface AdminSession {
  token: string;
  username: string;
  expiresAt: string;
}

export function getAdminSession(): AdminSession | null {
  try {
    const raw = localStorage.getItem(ADMIN_TOKEN_KEY);
    if (!raw) return null;
    const sess: AdminSession = JSON.parse(raw);
    if (new Date(sess.expiresAt).getTime() < Date.now()) {
      localStorage.removeItem(ADMIN_TOKEN_KEY);
      return null;
    }
    return sess;
  } catch {
    return null;
  }
}

export function setAdminSession(sess: AdminSession): void {
  localStorage.setItem(ADMIN_TOKEN_KEY, JSON.stringify(sess));
}

export function clearAdminSession(): void {
  localStorage.removeItem(ADMIN_TOKEN_KEY);
}

export function isAdminLoggedIn(): boolean {
  return getAdminSession() !== null;
}

export async function adminLogin(
  data: AdminLoginRequest,
): Promise<AdminLoginResponse> {
  const res = await axiosForBackend.post('/api/admin/login', data);
  return res.data;
}

export function getDemoAdminPassword(): { username: string; password: string } {
  return { username: ADMIN_USERNAME, password: ADMIN_PASSWORD };
}

function adminHeaders(): Record<string, string> {
  const sess = getAdminSession();
  return sess ? { 'x-admin-token': sess.token } : {};
}

// Dashboard
export async function getDashboardStats(): Promise<AdminDashboardResponse> {
  const res = await axiosForBackend.get('/api/admin/dashboard', {
    headers: adminHeaders(),
  });
  return res.data;
}

// Users
export interface AdminUserListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  status?: string;
}

export async function getAdminUsers(
  params: AdminUserListParams,
): Promise<AdminUserListResponse> {
  const res = await axiosForBackend.get('/api/admin/users', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateAdminUser(
  userId: string,
  data: AdminUpdateUserRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/users/${userId}`, data, {
    headers: adminHeaders(),
  });
}

export async function adjustUserQuota(
  userId: string,
  data: AdminAdjustQuotaRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/users/${userId}/quota`, data, {
    headers: adminHeaders(),
  });
}

export async function createAdminUser(
  data: AdminCreateUserRequest,
): Promise<{ userId: string }> {
  const res = await axiosForBackend.post('/api/admin/users', data, {
    headers: adminHeaders(),
  });
  return res.data;
}

export async function deleteAdminUser(userId: string): Promise<void> {
  await axiosForBackend.delete(`/api/admin/users/${userId}`, {
    headers: adminHeaders(),
  });
}

export async function resetAdminUserPassword(
  userId: string,
  password: string,
): Promise<void> {
  await axiosForBackend.post(
    `/api/admin/users/${userId}/reset-password`,
    { password } satisfies AdminResetPasswordRequest,
    { headers: adminHeaders() },
  );
}

// Projects
export interface AdminProjectListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  userId?: string;
}

export async function getAdminProjects(
  params: AdminProjectListParams,
): Promise<AdminProjectListResponse> {
  const res = await axiosForBackend.get('/api/admin/projects', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function deleteAdminProject(projectId: string): Promise<void> {
  await axiosForBackend.delete(`/api/admin/projects/${projectId}`, {
    headers: adminHeaders(),
  });
}

// Scripts
export interface AdminScriptListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  category?: string;
  isSystem?: boolean;
}

export async function getAdminScripts(
  params: AdminScriptListParams,
): Promise<AdminScriptListResponse> {
  const res = await axiosForBackend.get('/api/admin/scripts', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function createAdminScript(
  data: AdminCreateScriptRequest,
): Promise<{ id: string }> {
  const res = await axiosForBackend.post('/api/admin/scripts', data, {
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateAdminScript(
  scriptId: string,
  data: AdminUpdateScriptRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/scripts/${scriptId}`, data, {
    headers: adminHeaders(),
  });
}

export async function deleteAdminScript(scriptId: string): Promise<void> {
  await axiosForBackend.delete(`/api/admin/scripts/${scriptId}`, {
    headers: adminHeaders(),
  });
}

// Products
export interface AdminProductListParams {
  type?: string;
  isActive?: boolean;
}

export async function getAdminProducts(
  params: AdminProductListParams = {},
): Promise<AdminProductListResponse> {
  const res = await axiosForBackend.get('/api/admin/products', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function createAdminProduct(
  data: AdminCreateProductRequest,
): Promise<{ id: string }> {
  const res = await axiosForBackend.post('/api/admin/products', data, {
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateAdminProduct(
  productId: string,
  data: AdminUpdateProductRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/products/${productId}`, data, {
    headers: adminHeaders(),
  });
}

export async function deleteAdminProduct(productId: string): Promise<void> {
  await axiosForBackend.delete(`/api/admin/products/${productId}`, {
    headers: adminHeaders(),
  });
}

// Orders
export interface AdminOrderListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  status?: string;
}

export async function getAdminOrders(
  params: AdminOrderListParams,
): Promise<AdminOrderListResponse> {
  const res = await axiosForBackend.get('/api/admin/orders', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateOrderStatus(
  orderId: string,
  data: AdminUpdateOrderStatusRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/orders/${orderId}/status`, data, {
    headers: adminHeaders(),
  });
}

// Merchants
export interface AdminMerchantListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  category?: string;
  isApproved?: boolean;
  isActive?: boolean;
}

export async function getAdminMerchants(
  params: AdminMerchantListParams,
): Promise<AdminMerchantListResponse> {
  const res = await axiosForBackend.get('/api/admin/merchants', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function createAdminMerchant(
  data: AdminCreateMerchantRequest,
): Promise<{ id: string }> {
  const res = await axiosForBackend.post('/api/admin/merchants', data, {
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateAdminMerchant(
  merchantId: string,
  data: AdminUpdateMerchantRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/merchants/${merchantId}`, data, {
    headers: adminHeaders(),
  });
}

export async function deleteAdminMerchant(merchantId: string): Promise<void> {
  await axiosForBackend.delete(`/api/admin/merchants/${merchantId}`, {
    headers: adminHeaders(),
  });
}

// Audit
export interface AdminAuditListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  status?: string;
  riskLevel?: string;
}

export async function getAdminAudits(
  params: AdminAuditListParams,
): Promise<AdminAuditListResponse> {
  const res = await axiosForBackend.get('/api/admin/audits', {
    params,
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateAdminAudit(
  auditId: string,
  data: AdminUpdateAuditRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/audits/${auditId}`, data, {
    headers: adminHeaders(),
  });
}

// ===== AI API 配置 =====

export async function getAiApiConfigs(): Promise<AiApiConfigListResponse> {
  const res = await axiosForBackend.get('/api/admin/ai-api-configs', {
    headers: adminHeaders(),
  });
  return res.data;
}

export async function createAiApiConfig(
  data: AiApiConfigCreateRequest,
): Promise<void> {
  await axiosForBackend.post('/api/admin/ai-api-configs', data, {
    headers: adminHeaders(),
  });
}

export async function updateAiApiConfig(
  id: string,
  data: AiApiConfigUpdateRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/admin/ai-api-configs/${id}`, data, {
    headers: adminHeaders(),
  });
}

export async function deleteAiApiConfig(id: string): Promise<void> {
  await axiosForBackend.delete(`/api/admin/ai-api-configs/${id}`, {
    headers: adminHeaders(),
  });
}

export async function toggleAiApiConfig(
  id: string,
  status: 'active' | 'inactive',
): Promise<void> {
  await axiosForBackend.patch(
    `/api/admin/ai-api-configs/${id}/status`,
    { status },
    { headers: adminHeaders() },
  );
}

export async function testAiApiConfig(id: string): Promise<AiApiTestResponse> {
  const res = await axiosForBackend.post(
    `/api/admin/ai-api-configs/${id}/test`,
    {},
    { headers: adminHeaders() },
  );
  return res.data;
}

// ===== System Configs =====

export async function getSystemConfigs(): Promise<SystemConfigListResponse> {
  const res = await axiosForBackend.get('/api/admin/system-configs', {
    headers: adminHeaders(),
  });
  return res.data;
}

export async function updateSystemConfig(
  configKey: string,
  data: SystemConfigUpdateRequest,
): Promise<{ success: boolean }> {
  const res = await axiosForBackend.patch(
    `/api/admin/system-configs/${configKey}`,
    data,
    { headers: adminHeaders() },
  );
  return res.data;
}

export async function resetProjectPosterPhotoCount(
  projectId: string,
): Promise<{ success: boolean }> {
  const res = await axiosForBackend.post(
    `/api/admin/projects/${projectId}/reset-poster-photo-count`,
    {},
    { headers: adminHeaders() },
  );
  return res.data;
}
