import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

export async function getRehearsalChecklist() {
  try {
    const response = await axiosForBackend({ url: '/api/toolkit/rehearsal-checklist', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取彩排清单失败', error);
    throw error;
  }
}

export async function getEmergencyMemos() {
  try {
    const response = await axiosForBackend({ url: '/api/toolkit/emergency-memos', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取应急备忘失败', error);
    throw error;
  }
}

export async function getContractTemplate() {
  try {
    const response = await axiosForBackend({ url: '/api/toolkit/contract-template', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取合同模板失败', error);
    throw error;
  }
}
