import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  BgmPlaylist,
  BgmPlaylistDetail,
  BgmLibraryListResponse,
  CreatePlaylistRequest,
  UpdatePlaylistRequest,
  AddPlaylistSongsRequest,
  UpdatePlaylistItemRequest,
  ImportPlaylistRequest,
  ExportPlaylistResponse,
} from '@shared/api.interface';

export async function getBgmLibrary(params: {
  category?: string;
  keyword?: string;
  page?: number;
  pageSize?: number;
}): Promise<BgmLibraryListResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/bgm/library',
      method: 'GET',
      params,
    });
    return response.data;
  } catch (error) {
    logger.error('获取BGM曲库失败', error);
    throw error;
  }
}

export async function getPlaylists(): Promise<BgmPlaylist[]> {
  try {
    const response = await axiosForBackend({
      url: '/api/bgm/playlists',
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取歌单列表失败', error);
    throw error;
  }
}

export async function createPlaylist(data: CreatePlaylistRequest): Promise<BgmPlaylist> {
  try {
    const response = await axiosForBackend({
      url: '/api/bgm/playlists',
      method: 'POST',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('创建歌单失败', error);
    throw error;
  }
}

export async function getPlaylist(id: string): Promise<BgmPlaylistDetail> {
  try {
    const response = await axiosForBackend({
      url: `/api/bgm/playlists/${id}`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取歌单详情失败', error);
    throw error;
  }
}

export async function updatePlaylist(
  id: string,
  data: UpdatePlaylistRequest,
): Promise<BgmPlaylist> {
  try {
    const response = await axiosForBackend({
      url: `/api/bgm/playlists/${id}`,
      method: 'PATCH',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('更新歌单失败', error);
    throw error;
  }
}

export async function deletePlaylist(id: string): Promise<void> {
  try {
    await axiosForBackend({
      url: `/api/bgm/playlists/${id}`,
      method: 'DELETE',
    });
  } catch (error) {
    logger.error('删除歌单失败', error);
    throw error;
  }
}

export async function addPlaylistSongs(
  id: string,
  data: AddPlaylistSongsRequest,
): Promise<void> {
  try {
    await axiosForBackend({
      url: `/api/bgm/playlists/${id}/songs`,
      method: 'POST',
      data,
    });
  } catch (error) {
    logger.error('添加歌曲到歌单失败', error);
    throw error;
  }
}

export async function updatePlaylistItem(
  id: string,
  itemId: string,
  data: UpdatePlaylistItemRequest,
): Promise<void> {
  try {
    await axiosForBackend({
      url: `/api/bgm/playlists/${id}/items/${itemId}`,
      method: 'PATCH',
      data,
    });
  } catch (error) {
    logger.error('更新歌单歌曲失败', error);
    throw error;
  }
}

export async function deletePlaylistItem(id: string, itemId: string): Promise<void> {
  try {
    await axiosForBackend({
      url: `/api/bgm/playlists/${id}/items/${itemId}`,
      method: 'DELETE',
    });
  } catch (error) {
    logger.error('删除歌单歌曲失败', error);
    throw error;
  }
}

export async function importPlaylist(
  id: string,
  data: Omit<ImportPlaylistRequest, 'playlistId'>,
): Promise<void> {
  try {
    await axiosForBackend({
      url: `/api/bgm/playlists/${id}/import`,
      method: 'POST',
      data,
    });
  } catch (error) {
    logger.error('导入歌单失败', error);
    throw error;
  }
}

export async function exportPlaylist(id: string): Promise<ExportPlaylistResponse> {
  try {
    const response = await axiosForBackend({
      url: `/api/bgm/playlists/${id}/export`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('导出歌单失败', error);
    throw error;
  }
}
