import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  ShopProductsResponse,
  MallMerchantsResponse,
  CreateOrderRequest,
  Order,
} from '@shared/api.interface';

export async function getProducts(): Promise<ShopProductsResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/shop/products',
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取商品列表失败', error);
    throw error;
  }
}

export async function getMerchants(
  category?: string,
): Promise<MallMerchantsResponse> {
  try {
    const response = await axiosForBackend({
      url: '/api/shop/merchants',
      method: 'GET',
      params: category ? { category } : undefined,
    });
    return response.data;
  } catch (error) {
    logger.error('获取商家列表失败', error);
    throw error;
  }
}

export async function createOrder(data: CreateOrderRequest): Promise<Order> {
  try {
    const response = await axiosForBackend({
      url: '/api/shop/orders',
      method: 'POST',
      data,
    });
    return response.data;
  } catch (error) {
    logger.error('创建订单失败', error);
    throw error;
  }
}

export async function payOrder(orderId: string): Promise<Order> {
  try {
    const response = await axiosForBackend({
      url: `/api/shop/orders/${orderId}/pay`,
      method: 'POST',
    });
    return response.data;
  } catch (error) {
    logger.error('支付失败', error);
    throw error;
  }
}

export async function getOrder(orderId: string): Promise<Order> {
  try {
    const response = await axiosForBackend({
      url: `/api/shop/orders/${orderId}`,
      method: 'GET',
    });
    return response.data;
  } catch (error) {
    logger.error('获取订单失败', error);
    throw error;
  }
}
