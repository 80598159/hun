import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

export async function getProjectList(params?: { status?: string; page?: number; pageSize?: number }) {
  try {
    const response = await axiosForBackend({ url: '/api/wedding/projects', method: 'GET', params });
    return response.data;
  } catch (error) {
    logger.error('获取项目列表失败', error);
    throw error;
  }
}

export async function getProjectDetail(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${id}`, method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取项目详情失败', error);
    throw error;
  }
}

export async function createProject(data?: { title?: string }) {
  try {
    const response = await axiosForBackend({ url: '/api/wedding/projects', method: 'POST', data });
    return response.data;
  } catch (error) {
    logger.error('创建项目失败', error);
    throw error;
  }
}

export async function updateProject(id: string, data: any) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${id}`, method: 'PUT', data });
    return response.data;
  } catch (error) {
    logger.error('更新项目失败', error);
    throw error;
  }
}

export async function deleteProject(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${id}`, method: 'DELETE' });
    return response.data;
  } catch (error) {
    logger.error('删除项目失败', error);
    throw error;
  }
}

export async function copyProject(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${id}/copy`, method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('复制项目失败', error);
    throw error;
  }
}

export async function archiveProject(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${id}/archive`, method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('归档项目失败', error);
    throw error;
  }
}

export async function unarchiveProject(id: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${id}/unarchive`, method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('取消归档失败', error);
    throw error;
  }
}

export async function addStep(projectId: string, data: any) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${projectId}/steps`, method: 'POST', data });
    return response.data;
  } catch (error) {
    logger.error('添加环节失败', error);
    throw error;
  }
}

export async function updateStep(stepId: string, data: any) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/steps/${stepId}`, method: 'PUT', data });
    return response.data;
  } catch (error) {
    logger.error('更新环节失败', error);
    throw error;
  }
}

export async function deleteStep(stepId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/steps/${stepId}`, method: 'DELETE' });
    return response.data;
  } catch (error) {
    logger.error('删除环节失败', error);
    throw error;
  }
}

export async function reorderSteps(projectId: string, stepId: string, targetIndex: number) {
  try {
    const response = await axiosForBackend({
      url: `/api/wedding/projects/${projectId}/steps/reorder`,
      method: 'POST',
      data: { stepId, targetIndex },
    });
    return response.data;
  } catch (error) {
    logger.error('重排环节失败', error);
    throw error;
  }
}

export async function getPresetSteps() {
  try {
    const response = await axiosForBackend({ url: '/api/wedding/preset-steps', method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取预设环节失败', error);
    throw error;
  }
}

export async function getProjectAccessInfo(projectId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${projectId}/access`, method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取项目权限信息失败', error);
    throw error;
  }
}

export async function createShareLink(projectId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${projectId}/share`, method: 'POST' });
    return response.data;
  } catch (error) {
    logger.error('创建分享链接失败', error);
    throw error;
  }
}

export async function getShareLinks(projectId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${projectId}/share`, method: 'GET' });
    return response.data;
  } catch (error) {
    logger.error('获取分享链接失败', error);
    throw error;
  }
}

export async function revokeShareLink(linkId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/share/${linkId}`, method: 'DELETE' });
    return response.data;
  } catch (error) {
    logger.error('撤销分享链接失败', error);
    throw error;
  }
}

export async function joinByShareCode(shareCode: string) {
  try {
    const response = await axiosForBackend({ url: '/api/wedding/share/join', method: 'POST', data: { shareCode } });
    return response.data;
  } catch (error) {
    logger.error('通过分享码加入失败', error);
    throw error;
  }
}

export async function removeCollaborator(projectId: string, collaboratorId: string) {
  try {
    const response = await axiosForBackend({ url: `/api/wedding/projects/${projectId}/collaborators/${collaboratorId}`, method: 'DELETE' });
    return response.data;
  } catch (error) {
    logger.error('移除协作者失败', error);
    throw error;
  }
}
