import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import { ToastProvider } from './components/ToastProvider';
import NotFound from './pages/NotFound/NotFound';

import HomePage from './pages/Home/HomePage';
import AdminLoginPage from './pages/Admin/AdminLoginPage';
import AdminLayout from './pages/Admin/AdminLayout';
import AdminDashboardPage from './pages/Admin/AdminDashboardPage';
import ProtectedAdminRoute from './pages/Admin/ProtectedAdminRoute';
import AdminProductsPage from './pages/Admin/AdminProductsPage';
import AdminOrdersPage from './pages/Admin/AdminOrdersPage';
import WeddingEditorPage from './pages/WeddingEditor/WeddingEditorPage';
import ScriptsPage from './pages/Scripts/ScriptsPage';
import ScriptDetailPage from './pages/Scripts/ScriptDetailPage';
import SchedulePage from './pages/Schedule/SchedulePage';
import ToolkitPage from './pages/Toolkit/ToolkitPage';
import ProfilePage from './pages/Profile/ProfilePage';
import ShopPage from './pages/Shop/ShopPage';
import MallPage from './pages/Mall/MallPage';
import AiFlowPage from './pages/AI/AiFlowPage';
import AiScriptPage from './pages/AI/AiScriptPage';
import AiParsePage from './pages/AI/AiParsePage';
import AiRiskPage from './pages/AI/AiRiskPage';
import OrderListPage from './pages/Profile/OrderListPage';
import FavoriteListPage from './pages/Profile/FavoriteListPage';
import SettingsPage from './pages/Profile/SettingsPage';
import AdminUsersPage from './pages/Admin/AdminUsersPage';
import AdminProjectsPage from './pages/Admin/AdminProjectsPage';
import AdminScriptsPage from './pages/Admin/AdminScriptsPage';
import AdminMerchantsPage from './pages/Admin/AdminMerchantsPage';
import AdminAuditsPage from './pages/Admin/AdminAuditsPage';
import AdminAiApiPage from './pages/Admin/AdminAiApiPage';
import AdminSettingsPage from './pages/Admin/AdminSettingsPage';
import LoginPage from './pages/Login/LoginPage';
import BgmPage from './pages/Bgm/BgmPage';
import BgmPlaylistPage from './pages/Bgm/BgmPlaylistPage';
import QuotationPage from './pages/Quotation/QuotationPage';
import BuisnessCardPage from './pages/Profile/BusinessCardPage';
import QuestionnaireListPage from './pages/Questionnaire/QuestionnaireListPage';
import QuestionnaireDetailPage from './pages/Questionnaire/QuestionnaireDetailPage';
import QuestionnaireFillPage from './pages/Questionnaire/QuestionnaireFillPage';

const RoutesComponent = () => {
  return (
    <ToastProvider>
      <Routes>
        {/* 登录页（不包底部导航布局） */}
        <Route path="/login" element={<LoginPage />} />

        <Route element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="wedding/:id" element={<WeddingEditorPage />} />
          <Route path="scripts" element={<ScriptsPage />} />
          <Route path="scripts/:id" element={<ScriptDetailPage />} />
          <Route path="schedule" element={<SchedulePage />} />
          <Route path="toolkit" element={<ToolkitPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="shop" element={<ShopPage />} />
          <Route path="mall" element={<MallPage />} />
          <Route path="ai/flow" element={<AiFlowPage />} />
          <Route path="ai/script" element={<AiScriptPage />} />
          <Route path="ai/parse" element={<AiParsePage />} />
          <Route path="ai/risk" element={<AiRiskPage />} />
          <Route path="profile/orders" element={<OrderListPage />} />
          <Route path="profile/favorites" element={<FavoriteListPage />} />
          <Route path="profile/settings" element={<SettingsPage />} />
          <Route path="bgm" element={<BgmPage />} />
          <Route path="bgm/:id" element={<BgmPlaylistPage />} />
          <Route path="quotation" element={<QuotationPage />} />
          <Route path="quotation/:id" element={<QuotationPage />} />
          <Route path="profile/card" element={<BuisnessCardPage />} />
          <Route path="questionnaire" element={<QuestionnaireListPage />} />
          <Route path="questionnaire/:id" element={<QuestionnaireDetailPage />} />
        </Route>

        {/* 公开问卷填写页（无需登录） */}
        <Route path="questionnaire/fill/:shareCode" element={<QuestionnaireFillPage />} />

        {/* Admin routes */}
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route
          path="/admin"
          element={
            <ProtectedAdminRoute>
              <AdminLayout />
            </ProtectedAdminRoute>
          }
        >
          <Route index element={<AdminDashboardPage />} />
          <Route path="users" element={<AdminUsersPage />} />
          <Route path="projects" element={<AdminProjectsPage />} />
          <Route path="scripts" element={<AdminScriptsPage />} />
          <Route path="products" element={<AdminProductsPage />} />
          <Route path="orders" element={<AdminOrdersPage />} />
          <Route path="merchants" element={<AdminMerchantsPage />} />
          <Route path="audits" element={<AdminAuditsPage />} />
          <Route path="ai-api" element={<AdminAiApiPage />} />
          <Route path="settings" element={<AdminSettingsPage />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </ToastProvider>
  );
};

export default RoutesComponent;
