interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  color?: 'primary' | 'white' | 'gold';
  className?: string;
}

const LoadingSpinner = ({ size = 'md', color = 'primary', className = '' }: LoadingSpinnerProps) => {
  const sizeClass = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-2',
    lg: 'w-12 h-12 border-3',
  };

  const colorClass = {
    primary: 'border-primary/25 border-t-primary',
    white: 'border-white/30 border-t-white',
    gold: 'border-accent-gold/30 border-t-accent-gold',
  };

  return (
    <div
      className={`${sizeClass[size]} ${colorClass[color]} rounded-full animate-spin ${className}`}
    />
  );
};

export default LoadingSpinner;
