import { X } from 'lucide-react';
import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  height?: 'auto' | 'large' | 'medium' | 'full';
  showHandle?: boolean;
  closeOnBackdrop?: boolean;
}

const BottomSheet = ({
  open,
  onClose,
  title,
  children,
  height = 'auto',
  showHandle = true,
  closeOnBackdrop = true,
}: BottomSheetProps) => {
  const sheetRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  const handleContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  if (!open) return null;

  const heightClass = {
    auto: 'max-h-[85vh]',
    medium: 'h-[60vh]',
    large: 'h-[80vh]',
    full: 'h-[92vh]',
  }[height];

  const sheet = (
    <div className="fixed inset-0 z-[999]" style={{ pointerEvents: 'auto' }}>
      <div
        className="absolute inset-0 bg-foreground/40 backdrop-blur-sm fade-in"
        onClick={closeOnBackdrop ? onClose : undefined}
      />
      <div
        ref={sheetRef}
        onClick={handleContentClick}
        className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-card rounded-t-3xl shadow-2xl ${heightClass} flex flex-col sheet-enter`}
        style={{ animation: 'sheet-enter 0.35s cubic-bezier(0.32,0.72,0,1) both' }}
      >
        {showHandle && (
          <div className="flex justify-center pt-3 pb-1">
            <span className="w-10 h-1 rounded-full bg-border" />
          </div>
        )}
        {title && (
          <div className="flex items-center justify-between px-5 py-3 border-b border-border/60">
            <h3 className="text-lg font-semibold text-foreground">{title}</h3>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              aria-label="关闭"
            >
              <X size={20} />
            </button>
          </div>
        )}
        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );

  if (typeof document === 'undefined') return sheet;
  return createPortal(sheet, document.body);
};

export default BottomSheet;
