interface SkeletonProps {
  variant?: 'text' | 'card' | 'circle' | 'rect';
  width?: string;
  height?: string;
  className?: string;
}

const Skeleton = ({ variant = 'text', width, height, className = '' }: SkeletonProps) => {
  const baseClass = 'skeleton rounded-lg';

  const variantClass = {
    text: 'h-4 w-full',
    card: 'h-32 w-full rounded-2xl',
    circle: 'w-12 h-12 rounded-full',
    rect: '',
  };

  const style: React.CSSProperties = {};
  if (width) style.width = width;
  if (height) style.height = height;

  return (
    <div
      className={`${baseClass} ${variantClass[variant]} ${className}`}
      style={style}
    />
  );
};

export default Skeleton;
