import { InputHTMLAttributes, forwardRef } from 'react';

interface AppInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  containerClassName?: string;
}

const AppInput = forwardRef<HTMLInputElement, AppInputProps>(
  (
    {
      label,
      error,
      leftIcon,
      rightIcon,
      className = '',
      containerClassName = '',
      placeholder,
      value,
      onChange,
      type = 'text',
      ...rest
    },
    ref
  ) => {
    return (
      <div className={containerClassName}>
        {label && (
          <label className="block text-sm font-medium text-foreground/80 mb-2">
            {label}
          </label>
        )}
        <div
          className={`relative flex items-center rounded-xl border transition-all duration-200 bg-secondary/60
            ${
              error
                ? 'border-destructive focus-within:border-destructive focus-within:ring-2 focus-within:ring-destructive/20'
                : 'border-input focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/15 focus-within:bg-card'
            }
            ${leftIcon ? 'pl-3' : 'pl-4'}
            ${rightIcon ? 'pr-3' : 'pr-4'}
          `}
        >
          {leftIcon && (
            <span className="text-muted-foreground mr-2 flex-shrink-0">
              {leftIcon}
            </span>
          )}
          <input
            ref={ref}
            type={type}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className={`w-full py-3 bg-transparent text-foreground placeholder:text-muted-foreground/70 focus:outline-none text-sm ${className}`}
            {...rest}
          />
          {rightIcon && (
            <span className="text-muted-foreground ml-2 flex-shrink-0">
              {rightIcon}
            </span>
          )}
        </div>
        {error && (
          <p className="mt-1.5 text-xs text-destructive">{error}</p>
        )}
      </div>
    );
  }
);

AppInput.displayName = 'AppInput';

export default AppInput;
