import { AlertCircle, CheckCircle2, Info, XCircle, X } from 'lucide-react';
import { useEffect, useState } from 'react';

interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'warning' | 'info';
  visible: boolean;
  onClose: () => void;
  duration?: number;
}

const Toast = ({
  message,
  type = 'info',
  visible,
  onClose,
  duration = 2500,
}: ToastProps) => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (visible) {
      setShow(true);
      const timer = setTimeout(() => {
        setShow(false);
        setTimeout(onClose, 300);
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [visible, duration, onClose]);

  if (!show && !visible) return null;

  const icons = {
    success: <CheckCircle2 size={20} className="text-success" />,
    error: <XCircle size={20} className="text-destructive" />,
    warning: <AlertCircle size={20} className="text-warning" />,
    info: <Info size={20} className="text-info" />,
  };

  const bgColors = {
    success: 'border-success/20 bg-success/5',
    error: 'border-destructive/20 bg-destructive/5',
    warning: 'border-warning/20 bg-warning/5',
    info: 'border-info/20 bg-info/5',
  };

  return (
    <div
      className={`fixed top-6 left-1/2 -translate-x-1/2 z-[100] shadow-lg backdrop-blur-md border rounded-2xl px-5 py-3.5 flex items-center gap-3 max-w-[90%] min-w-[200px] transition-all duration-300 ${bgColors[type]} bg-card/95 ${
        show ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'
      }`}
      style={{ animation: show ? 'fade-up 0.3s cubic-bezier(0.32,0.72,0,1) both' : undefined }}
    >
      {icons[type]}
      <span className="text-sm text-foreground flex-1 font-medium">{message}</span>
      <button
        onClick={onClose}
        className="text-muted-foreground hover:text-foreground transition-colors p-1"
        aria-label="关闭"
      >
        <X size={16} />
      </button>
    </div>
  );
};

export default Toast;
