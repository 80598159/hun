import { TextareaHTMLAttributes, forwardRef } from 'react';

interface AppTextAreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  containerClassName?: string;
}

const AppTextArea = forwardRef<HTMLTextAreaElement, AppTextAreaProps>(
  (
    {
      label,
      error,
      className = '',
      containerClassName = '',
      placeholder,
      value,
      onChange,
      rows = 4,
      ...rest
    },
    ref
  ) => {
    return (
      <div className={containerClassName}>
        {label && (
          <label className="block text-sm font-medium text-foreground/80 mb-2">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          rows={rows}
          className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 bg-secondary/60 text-foreground placeholder:text-muted-foreground/70 focus:outline-none text-sm leading-relaxed resize-y
            ${
              error
                ? 'border-destructive focus:border-destructive focus:ring-2 focus:ring-destructive/20'
                : 'border-input focus:border-primary focus:ring-2 focus:ring-primary/15 focus:bg-card'
            }
            ${className}
          `}
          {...rest}
        />
        {error && <p className="mt-1.5 text-xs text-destructive">{error}</p>}
      </div>
    );
  }
);

AppTextArea.displayName = 'AppTextArea';

export default AppTextArea;
