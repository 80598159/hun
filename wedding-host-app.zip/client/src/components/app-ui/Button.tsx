import { forwardRef, ButtonHTMLAttributes } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'gold';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  fullWidth?: boolean;
  loading?: boolean;
}

const AppButton = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      variant = 'primary',
      size = 'md',
      fullWidth = false,
      loading = false,
      disabled,
      className = '',
      onClick,
      ...rest
    },
    ref
  ) => {
    const baseClass =
      'font-medium rounded-full transition-all duration-200 active:scale-[0.97] disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 flex items-center justify-center gap-2 select-none';

    const variantClass: Record<Variant, string> = {
      primary:
        'bg-primary-gradient text-primary-foreground shadow-md shadow-primary/30 hover:shadow-lg hover:shadow-primary/35',
      secondary:
        'border-2 border-primary text-primary hover:bg-primary/5 active:bg-primary/10 bg-transparent',
      ghost:
        'text-muted-foreground hover:text-foreground hover:bg-secondary active:bg-muted bg-transparent',
      gold: 'bg-gold-gradient text-[hsl(40_50%_22%)] shadow-md shadow-accent-gold/30 hover:shadow-lg hover:shadow-accent-gold/40',
    };

    const sizeClass: Record<Size, string> = {
      sm: 'h-10 px-4 text-sm',
      md: 'h-12 px-6 text-[15px]',
      lg: 'h-14 px-8 text-base',
    };

    return (
      <button
        ref={ref}
        onClick={onClick}
        disabled={disabled || loading}
        className={`${baseClass} ${variantClass[variant]} ${sizeClass[size]} ${
          fullWidth ? 'w-full' : ''
        } ${className}`}
        {...rest}
      >
        {loading && (
          <span className="w-4 h-4 border-2 border-current/30 border-t-current rounded-full animate-spin" />
        )}
        {children}
      </button>
    );
  }
);

AppButton.displayName = 'AppButton';

export default AppButton;
