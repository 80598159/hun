import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { X, User, Lock, MessageCircle } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import Input from '@client/src/components/app-ui/Input';
import Button from '@client/src/components/app-ui/Button';
import { login, register } from '@client/src/api/auth';
import { useToast } from '@client/src/components/ToastProvider';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

type TabType = 'login' | 'register';

const AuthModal = ({ open, onClose, onSuccess }: AuthModalProps) => {
  const { showToast } = useToast();
  const [tab, setTab] = useState<TabType>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      setTab('login');
      setUsername('');
      setPassword('');
      setConfirmPassword('');
      setNickname('');
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      showToast('请输入账号', 'warning');
      return;
    }
    if (!password.trim()) {
      showToast('请输入密码', 'warning');
      return;
    }
    setLoading(true);
    try {
      await login(username.trim(), password);
      showToast('登录成功', 'success');
      onClose();
      onSuccess?.();
    } catch (error) {
      logger.error('登录失败', error);
      const msg =
        (error as any)?.response?.data?.error?.message ||
        '登录失败，请检查账号密码';
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      showToast('请输入账号', 'warning');
      return;
    }
    if (username.trim().length < 3) {
      showToast('账号长度不能少于3位', 'warning');
      return;
    }
    if (!password.trim()) {
      showToast('请输入密码', 'warning');
      return;
    }
    if (password.length < 6) {
      showToast('密码长度不能少于6位', 'warning');
      return;
    }
    if (password !== confirmPassword) {
      showToast('两次输入的密码不一致', 'warning');
      return;
    }
    setLoading(true);
    try {
      await register(username.trim(), password, nickname.trim() || undefined);
      showToast('注册成功', 'success');
      onClose();
      onSuccess?.();
    } catch (error) {
      logger.error('注册失败', error);
      const msg =
        (error as any)?.response?.data?.error?.message || '注册失败，请稍后重试';
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleWechatLogin = () => {
    showToast('微信授权登录即将开放，敬请期待', 'info');
  };

  const handleContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  if (!open) return null;

  const modal = (
    <div className="fixed inset-0 z-[1000] flex items-end sm:items-center justify-center" style={{ pointerEvents: 'auto' }}>
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        onClick={handleContentClick}
        className="relative w-full max-w-[480px] bg-card rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden"
        style={{ animation: 'sheet-enter 0.3s cubic-bezier(0.32,0.72,0,1) both' }}
      >
        <div
          className="px-6 pt-8 pb-5 relative overflow-hidden"
          style={{
            background:
              'linear-gradient(135deg, #2C0A14 0%, #5C1525 50%, #8B1530 100%)',
          }}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/15 flex items-center justify-center text-white hover:bg-white/25 transition-colors"
            aria-label="关闭"
          >
            <X size={18} />
          </button>
          <div className="flex items-center gap-3 mb-2">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                boxShadow: '0 2px 8px rgba(201, 169, 97, 0.4)',
              }}
            >
              <span className="font-serif text-xl font-bold" style={{ color: '#5C4520' }}>
                婚
              </span>
            </div>
            <div>
              <h2 className="font-serif text-2xl font-bold" style={{ color: '#FFFDF8' }}>
                婚序
              </h2>
              <p className="text-xs opacity-70" style={{ color: '#E8D5A3' }}>
                婚礼主持助手
              </p>
            </div>
          </div>
          <p className="text-sm mt-3" style={{ color: 'rgba(255,253,248,0.85)' }}>
            {tab === 'login' ? '欢迎回来，登录继续您的婚礼策划' : '创建账号，开启您的婚礼主持之旅'}
          </p>
        </div>

        <div className="px-6 pb-8 pt-5" style={{ background: '#FBF6F0' }}>
          <div className="flex rounded-xl p-1 mb-6" style={{ background: '#F0E6DE' }}>
            <button
              onClick={() => setTab('login')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                tab === 'login'
                  ? 'bg-white shadow-sm'
                  : 'text-muted-foreground'
              }`}
              style={tab === 'login' ? { color: '#B91C3C' } : {}}
            >
              登录
            </button>
            <button
              onClick={() => setTab('register')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                tab === 'register'
                  ? 'bg-white shadow-sm'
                  : 'text-muted-foreground'
              }`}
              style={tab === 'register' ? { color: '#B91C3C' } : {}}
            >
              注册
            </button>
          </div>

          {tab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                label="账号"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="请输入账号"
                leftIcon={<User size={18} />}
                autoComplete="username"
              />
              <Input
                label="密码"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码"
                type="password"
                leftIcon={<Lock size={18} />}
                autoComplete="current-password"
              />
              <Button type="submit" fullWidth loading={loading} className="!h-12 !mt-2">
                {loading ? '登录中...' : '登 录'}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <Input
                label="账号"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="3-20位字母或数字"
                leftIcon={<User size={18} />}
                autoComplete="username"
              />
              <Input
                label="昵称"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="您的称呼（选填）"
                leftIcon={<MessageCircle size={18} />}
              />
              <Input
                label="密码"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="至少6位"
                type="password"
                leftIcon={<Lock size={18} />}
                autoComplete="new-password"
              />
              <Input
                label="确认密码"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="再次输入密码"
                type="password"
                leftIcon={<Lock size={18} />}
                autoComplete="new-password"
              />
              <Button type="submit" fullWidth loading={loading} className="!h-12 !mt-2">
                {loading ? '注册中...' : '注 册'}
              </Button>
            </form>
          )}

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" style={{ borderColor: '#E8DCD0' }} />
            </div>
            <div className="relative flex justify-center">
              <span
                className="px-4 text-xs"
                style={{ background: '#FBF6F0', color: '#A09090' }}
              >
                其他登录方式
              </span>
            </div>
          </div>

          <button
            onClick={handleWechatLogin}
            className="w-full h-12 rounded-full flex items-center justify-center gap-2 border transition-all hover:opacity-90 active:scale-[0.98]"
            style={{
              borderColor: '#07C160',
              color: '#07C160',
              background: 'rgba(7, 193, 96, 0.05)',
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 0 1 .213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 0 0 .167-.054l1.903-1.114a.864.864 0 0 1 .717-.098 10.16 10.16 0 0 0 2.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178A1.17 1.17 0 0 1 4.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178 1.17 1.17 0 0 1-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 0 1 .598.082l1.584.926a.272.272 0 0 0 .14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177l-.327-1.233a.582.582 0 0 1-.023-.156.49.49 0 0 1 .201-.398C23.024 18.48 24 16.82 24 14.98c0-3.21-2.931-5.837-6.656-6.088V8.89c-.135-.01-.27-.027-.407-.03zm-2.53 3.274c.535 0 .969.44.969.982a.976.976 0 0 1-.969.983.976.976 0 0 1-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 0 1-.969.983.976.976 0 0 1-.969-.983c0-.542.434-.982.969-.982z" />
            </svg>
            <span className="text-sm font-medium">微信授权登录</span>
          </button>

          <div className="mt-5 text-center">
            <p className="text-xs text-muted-foreground">
              演示账号：<span className="font-medium text-foreground/80">demo</span> /{' '}
              <span className="font-medium text-foreground/80">123456</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  if (typeof document === 'undefined') return modal;
  return createPortal(modal, document.body);
};

export default AuthModal;
