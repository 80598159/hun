import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  Home,
  BookOpen,
  Calendar,
  Wrench,
  User,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import AuthModal from '@client/src/components/AuthModal';
import { getCurrentUser } from '@client/src/api/auth';

const tabs = [
  { path: '/', icon: Home, label: '首页' },
  { path: '/scripts', icon: BookOpen, label: '台词库' },
  { path: '/schedule', icon: Calendar, label: '档期' },
  { path: '/toolkit', icon: Wrench, label: '工具箱' },
  { path: '/profile', icon: User, label: '我的' },
];

const TOKEN_KEY = 'app_auth_token';

const Layout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [pageKey, setPageKey] = useState(0);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [hasChecked, setHasChecked] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    setPageKey(prev => prev + 1);
  }, [location.pathname]);

  useEffect(() => {
    const checkAuth = async () => {
      let token: string | null = null;
      try {
        token = localStorage.getItem(TOKEN_KEY);
      } catch (e) {
        logger.warn('读取本地存储失败', e);
      }
      if (!token) {
        setHasChecked(true);
        setIsLoggedIn(false);
        setShowAuthModal(true);
        return;
      }
      try {
        await getCurrentUser();
        setIsLoggedIn(true);
      } catch (error) {
        logger.warn('登录态已失效', error);
        try {
          localStorage.removeItem(TOKEN_KEY);
        } catch (e) {
          logger.warn('清除本地 token 失败', e);
        }
        setIsLoggedIn(false);
        setShowAuthModal(true);
      } finally {
        setHasChecked(true);
      }
    };
    checkAuth();
  }, []);

  const handleAuthSuccess = () => {
    setIsLoggedIn(true);
  };

  const handleCloseAuth = () => {
    setShowAuthModal(false);
  };

  const isTabPage = tabs.some((tab: { path: string }) => {
    if (tab.path === '/') return location.pathname === '/';
    return location.pathname.startsWith(tab.path);
  });

  if (!hasChecked) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
          <span className="text-sm text-muted-foreground">加载中...</span>
        </div>
      </div>
    );
  }

  if (!isTabPage) {
    return (
      <div className="min-h-screen bg-background">
        <div key={pageKey} className="page-enter">
          <Outlet />
        </div>
        <AuthModal
          open={showAuthModal}
          onClose={handleCloseAuth}
          onSuccess={handleAuthSuccess}
        />
      </div>
    );
  }

  const activeIndex = tabs.findIndex((tab) => {
    if (tab.path === '/') return location.pathname === '/';
    return location.pathname.startsWith(tab.path);
  });

  return (
    <div className="min-h-screen bg-background pb-24 max-w-[480px] mx-auto relative">
      <main className="px-5 pt-4 pb-6">
        <div key={pageKey} className="page-enter">
          <Outlet />
        </div>
      </main>
      <nav
        className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] min-h-20 bg-card/95 backdrop-blur-xl border-t border-border flex items-start justify-around z-50 shadow-[0_-4px_20px_rgba(139_21_48_0.06)]"
        style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0) + 8px)', paddingTop: '8px' }}
      >
        {tabs.map((tab, index) => {
          const Icon = tab.icon;
          const isActive = activeIndex === index;
          const distance = Math.abs(index - activeIndex);
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
                className={`relative flex flex-col items-center justify-center gap-1 flex-1 transition-all duration-300 ${
                isActive
                  ? 'text-primary'
                  : distance === 1
                  ? 'text-foreground/50'
                  : 'text-foreground/35'
              }`}
              aria-label={tab.label}
            >
              <div className="relative">
                <Icon
                  size={24}
                  strokeWidth={isActive ? 2.5 : 2}
                  className={isActive ? 'scale-110 transition-transform duration-300' : 'transition-transform duration-300'}
                />
                {isActive && (
                  <span
                    className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"
                    style={{ animation: 'pulse-dot 2s ease-in-out infinite' }}
                  />
                )}
              </div>
              <span
                className={`text-[11px] font-medium transition-all duration-300 ${
                  isActive ? 'font-semibold' : ''
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
        <span
          className="absolute top-0 h-0.5 bg-primary rounded-full transition-all duration-500 ease-out"
          style={{
            width: '20%',
            left: `${activeIndex * 20}%`,
            opacity: activeIndex >= 0 ? 1 : 0,
          }}
        />
      </nav>
      <AuthModal
        open={showAuthModal}
        onClose={handleCloseAuth}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
};

export default Layout;
