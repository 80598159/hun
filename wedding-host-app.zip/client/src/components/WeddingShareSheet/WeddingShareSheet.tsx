import { useState, useEffect, useCallback } from 'react';
import {
  Share2,
  Copy,
  Users,
  Crown,
  UserPlus,
  Link as LinkIcon,
  X,
  Check,
} from 'lucide-react';
import type {
  WeddingProject,
  WeddingShareLink,
  WeddingCollaborator,
  ProjectAccessInfo,
} from '@shared/api.interface';
import {
  getProjectAccessInfo,
  createShareLink,
  getShareLinks,
  revokeShareLink,
  removeCollaborator,
} from '@client/src/api/wedding';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import Button from '@client/src/components/app-ui/Button';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';

interface WeddingShareSheetProps {
  open: boolean;
  onClose: () => void;
  projectId: string;
  project?: WeddingProject | null;
}

function formatUserId(userId: string): string {
  if (!userId) return '主持人';
  const tail = userId.slice(-4);
  return `主持人 ${tail}`;
}

function getShareText(
  project: WeddingProject | null | undefined,
  code: string,
): string {
  const title = project?.title || '婚礼方案';
  const date = project?.weddingDate || '待定';
  const hotel = project?.hotelName || '待定';
  const groom = project?.groomName || '新郎';
  const bride = project?.brideName || '新娘';
  return `【婚礼共创邀请】婚礼：${title}，日期：${date}，酒店：${hotel}，新人：${groom} & ${bride}。打开婚序APP，输入分享码 ${code} 加入方案共创。`;
}

const WeddingShareSheet = ({
  open,
  onClose,
  projectId,
  project,
}: WeddingShareSheetProps) => {
  const { showToast } = useToast();
  const [accessInfo, setAccessInfo] = useState<ProjectAccessInfo | null>(null);
  const [activeLink, setActiveLink] = useState<WeddingShareLink | null>(null);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [revoking, setRevoking] = useState(false);
  const [copying, setCopying] = useState<string | null>(null);
  const [removingId, setRemovingId] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    try {
      const [access, links] = await Promise.all([
        getProjectAccessInfo(projectId),
        getShareLinks(projectId),
      ]);
      setAccessInfo(access);
      const active = (Array.isArray(links) ? links : links.items || []).find(
        (l: WeddingShareLink) => l.isActive,
      );
      setActiveLink(active || null);
    } catch {
      showToast('加载分享信息失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [projectId, showToast]);

  useEffect(() => {
    if (open && projectId) {
      void loadData();
    }
  }, [open, projectId, loadData]);

  const handleCreateShare = async () => {
    setCreating(true);
    try {
      const link = await createShareLink(projectId);
      setActiveLink(link);
      showToast('分享链接已生成', 'success');
    } catch {
      showToast('生成分享链接失败', 'error');
    } finally {
      setCreating(false);
    }
  };

  const handleRevokeShare = async () => {
    if (!activeLink) return;
    setRevoking(true);
    try {
      await revokeShareLink(activeLink.id);
      setActiveLink(null);
      showToast('已撤销分享链接', 'success');
    } catch {
      showToast('撤销失败', 'error');
    } finally {
      setRevoking(false);
    }
  };

  const handleCopyCode = async () => {
    if (!activeLink) return;
    setCopying('code');
    try {
      await navigator.clipboard.writeText(activeLink.shareCode);
      showToast('分享码已复制', 'success');
    } catch {
      showToast('复制失败', 'error');
    } finally {
      setTimeout(() => setCopying(null), 1200);
    }
  };

  const handleCopyShareText = async () => {
    if (!activeLink) return;
    setCopying('text');
    try {
      const text = getShareText(project, activeLink.shareCode);
      await navigator.clipboard.writeText(text);
      showToast('分享文案已复制', 'success');
    } catch {
      showToast('复制失败', 'error');
    } finally {
      setTimeout(() => setCopying(null), 1200);
    }
  };

  const handleCopyLink = async () => {
    if (!activeLink) return;
    setCopying('link');
    try {
      const link = `${window.location.origin}/wedding/${projectId}?code=${activeLink.shareCode}`;
      await navigator.clipboard.writeText(link);
      showToast('链接已复制', 'success');
    } catch {
      showToast('复制失败', 'error');
    } finally {
      setTimeout(() => setCopying(null), 1200);
    }
  };

  const handleRemoveCollaborator = async (collaboratorId: string) => {
    setRemovingId(collaboratorId);
    try {
      await removeCollaborator(projectId, collaboratorId);
      setAccessInfo((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          collaborators: prev.collaborators.filter(
            (c: WeddingCollaborator) => c.id !== collaboratorId,
          ),
        };
      });
      showToast('已移除协作者', 'success');
    } catch {
      showToast('移除失败', 'error');
    } finally {
      setRemovingId(null);
    }
  };

  const isOwner = accessInfo?.role === 'owner';
  const collaborators = accessInfo?.collaborators || [];
  const owner = collaborators.find((c: WeddingCollaborator) => c.role === 'owner');
  const collaboratorList = collaborators.filter(
    (c: WeddingCollaborator) => c.role === 'collaborator',
  );

  const groom = project?.groomName || '新郎';
  const bride = project?.brideName || '新娘';
  const date = project?.weddingDate || '日期待定';
  const hotel = project?.hotelName || '酒店待定';
  const timeType = project?.timeType === 'lunch' ? '午宴' : '晚宴';

  return (
    <BottomSheet open={open} onClose={onClose} title="方案共创" height="large">
      <div className="px-5 py-4 space-y-5 pb-6">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <LoadingSpinner size="lg" />
          </div>
        ) : (
          <>
            {/* 微信分享卡片预览 */}
            <div>
              <p className="text-xs text-muted-foreground mb-2 font-medium">
                分享预览
              </p>
              <div
                className="rounded-2xl overflow-hidden shadow-md"
                style={{
                  background:
                    'linear-gradient(135deg, #B91C3C 0%, #8B1530 100%)',
                }}
              >
                {/* 卡片顶部装饰 */}
                <div className="relative px-5 pt-5 pb-4">
                  <div
                    className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none"
                    style={{
                      backgroundImage:
                        'radial-gradient(circle at 20% 20%, #E8D5A3 0%, transparent 40%), radial-gradient(circle at 80% 80%, #E8D5A3 0%, transparent 40%)',
                    }}
                  />
                  <div className="relative">
                    <div className="text-[10px] tracking-[0.3em] mb-2" style={{ color: '#E8D5A3' }}>
                      囍 · WEDDING · 囍
                    </div>
                    <h3 className="font-serif text-xl font-bold text-white tracking-tight mb-1">
                      {project?.title || '婚礼方案'}
                    </h3>
                    <div className="flex items-center gap-2 mb-3">
                      <span
                        className="text-sm font-serif font-medium"
                        style={{ color: '#E8D5A3' }}
                      >
                        {groom}
                      </span>
                      <span className="text-white/40 text-sm">&</span>
                      <span
                        className="text-sm font-serif font-medium"
                        style={{ color: '#E8D5A3' }}
                      >
                        {bride}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-white/70">
                      <span>{date}</span>
                      <span className="w-1 h-1 rounded-full bg-white/30" />
                      <span>{timeType}</span>
                      <span className="w-1 h-1 rounded-full bg-white/30" />
                      <span className="truncate">{hotel}</span>
                    </div>
                  </div>
                </div>
                {/* 底部标签 */}
                <div
                  className="px-5 py-2.5 flex items-center justify-between"
                  style={{ background: 'rgba(0,0,0,0.15)' }}
                >
                  <div className="flex items-center gap-1.5">
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center"
                      style={{ background: 'linear-gradient(135deg, #E8D5A3, #C9A961)' }}
                    >
                      <span className="text-[8px] font-bold" style={{ color: '#5C4520' }}>
                        婚
                      </span>
                    </div>
                    <span className="text-xs text-white/80">婚序 · 婚礼主持助手</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: 'rgba(232,213,163,0.2)', color: '#E8D5A3' }}>
                    主持人方案
                  </span>
                </div>
              </div>

              {/* 卡片下方两个按钮 */}
              <div className="grid grid-cols-2 gap-2 mt-3">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleCopyShareText}
                  disabled={!activeLink}
                  loading={copying === 'text'}
                >
                  {copying === 'text' ? (
                    <>
                      <Check size={14} />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy size={14} />
                      复制文案
                    </>
                  )}
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleCopyLink}
                  disabled={!activeLink}
                  loading={copying === 'link'}
                >
                  {copying === 'link' ? (
                    <>
                      <Check size={14} />
                      已复制
                    </>
                  ) : (
                    <>
                      <LinkIcon size={14} />
                      复制链接
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* 分享码区域 */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-muted-foreground font-medium">
                  分享码
                </p>
                {activeLink && (
                  <span className="text-xs text-accent-gold-dark flex items-center gap-1">
                    <UserPlus size={12} />
                    已有 {activeLink.joinCount} 人加入
                  </span>
                )}
              </div>
              {activeLink ? (
                <div className="bg-card rounded-2xl p-4 border border-border/60 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div
                        className="text-3xl font-bold font-mono tracking-[0.2em]"
                        style={{
                          background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                          WebkitBackgroundClip: 'text',
                          WebkitTextFillColor: 'transparent',
                        }}
                      >
                        {activeLink.shareCode}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1.5">
                        把分享码发给搭档，对方在APP内「加入协作」输入即可加入
                      </p>
                    </div>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={handleCopyCode}
                      loading={copying === 'code'}
                      className="flex-shrink-0"
                    >
                      {copying === 'code' ? (
                        <>
                          <Check size={14} />
                          已复制
                        </>
                      ) : (
                        <>
                          <Copy size={14} />
                          复制
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              ) : (
                <div
                  className="rounded-2xl p-5 text-center border-2 border-dashed"
                  style={{ borderColor: '#E0D4C8', background: '#FDF9F5' }}
                >
                  <div className="flex justify-center mb-2">
                    <Share2 size={24} className="text-muted-foreground/50" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    暂无有效分享链接
                  </p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    点击下方按钮生成分享码
                  </p>
                </div>
              )}
            </div>

            {/* 参与成员列表 */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs text-muted-foreground font-medium">
                  参与成员（{collaborators.length}人）
                </p>
              </div>
              <div className="bg-card rounded-2xl border border-border/60 shadow-sm overflow-hidden">
                {/* 创建者 */}
                {owner && (
                  <div className="flex items-center gap-3 px-4 py-3 border-b border-border/40">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{
                        background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                        boxShadow: '0 2px 8px rgba(201, 169, 97, 0.3)',
                      }}
                    >
                      <Crown size={16} style={{ color: '#5C4520' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground flex items-center gap-2">
                        {formatUserId(owner.userId)}
                        <span
                          className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                          style={{
                            background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                            color: '#5C4520',
                          }}
                        >
                          创建者
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        方案创建人，拥有全部权限
                      </div>
                    </div>
                  </div>
                )}

                {/* 协作者列表 */}
                {collaboratorList.length === 0 ? (
                  <div className="px-4 py-6 text-center">
                    <Users size={20} className="mx-auto text-muted-foreground/40 mb-2" />
                    <p className="text-xs text-muted-foreground">
                      暂无协作者，分享方案邀请搭档加入
                    </p>
                  </div>
                ) : (
                  collaboratorList.map((c: WeddingCollaborator) => (
                    <div
                      key={c.id}
                      className="flex items-center gap-3 px-4 py-3 border-b border-border/40 last:border-b-0"
                    >
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                        <Users size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-foreground flex items-center gap-2">
                          {formatUserId(c.userId)}
                          <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-primary/10 text-primary">
                            协作者
                          </span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          加入于 {c.joinedAt?.split('T')[0] || ''}
                        </div>
                      </div>
                      {isOwner && (
                        <button
                          onClick={() => handleRemoveCollaborator(c.id)}
                          disabled={removingId === c.id}
                          className="text-xs text-destructive hover:text-destructive/80 px-3 py-1.5 rounded-full hover:bg-destructive/5 transition-colors flex-shrink-0 disabled:opacity-50"
                          aria-label={`移除 ${formatUserId(c.userId)}`}
                        >
                          {removingId === c.id ? '移除中...' : '移除'}
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* 底部操作按钮 */}
            <div className="pt-2">
              {activeLink ? (
                <Button
                  variant="ghost"
                  size="md"
                  fullWidth
                  onClick={handleRevokeShare}
                  loading={revoking}
                  className="text-destructive hover:text-destructive hover:bg-destructive/5"
                >
                  <X size={16} />
                  撤销此分享
                </Button>
              ) : (
                <Button
                  variant="primary"
                  size="md"
                  fullWidth
                  onClick={handleCreateShare}
                  loading={creating}
                >
                  <Share2 size={16} />
                  生成新分享链接
                </Button>
              )}
            </div>
          </>
        )}
      </div>
    </BottomSheet>
  );
};

export default WeddingShareSheet;
