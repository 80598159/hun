interface PageHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'transparent' | 'dark';
  className?: string;
}

const PageHeader = ({
  title,
  subtitle,
  onBack,
  rightAction,
  variant = 'default',
  className = '',
}: PageHeaderProps) => {
  const bgClass = {
    default: 'bg-background',
    transparent: 'bg-transparent',
    dark: 'bg-wedding-gradient text-primary-foreground',
  };

  return (
    <div
      className={`sticky top-0 z-40 -mx-5 px-5 py-4 ${bgClass[variant]} backdrop-blur-md ${
        variant === 'default' ? 'border-b border-border/40' : ''
      } ${className}`}
    >
      <div className="flex items-center justify-between min-h-10">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {onBack && (
            <button
              onClick={onBack}
              className={`p-2 -ml-2 rounded-full transition-colors ${
                variant === 'dark'
                  ? 'hover:bg-white/10 text-primary-foreground'
                  : 'hover:bg-muted text-foreground'
              }`}
              aria-label="返回"
            >
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6" />
              </svg>
            </button>
          )}
          <div className="flex-1 min-w-0">
            <h1
              className={`text-lg font-bold truncate ${
                variant === 'dark' ? 'text-primary-foreground' : 'text-foreground'
              }`}
            >
              {title}
            </h1>
            {subtitle && (
              <p
                className={`text-xs mt-0.5 truncate ${
                  variant === 'dark' ? 'text-primary-foreground/70' : 'text-muted-foreground'
                }`}
              >
                {subtitle}
              </p>
            )}
          </div>
        </div>
        {rightAction && <div className="flex-shrink-0 ml-3">{rightAction}</div>}
      </div>
    </div>
  );
};

export default PageHeader;
