import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield,
  AlertTriangle,
  AlertCircle,
  Info,
  ChevronDown,
  AlertOctagon,
  Lightbulb,
} from 'lucide-react';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import { useToast } from '@client/src/components/ToastProvider';
import { detectRisk } from '@client/src/api/ai';
import { getProjectList, getProjectDetail } from '@client/src/api/wedding';
import type { AiRiskDetectResponse, WeddingProject, WeddingStep } from '@shared/api.interface';

const DISCLAMER = 'AI生成内容仅为初稿，请主持人人工审核修改，本工具不承担现场使用责任';

interface RiskItem {
  level: string;
  content: string;
  suggestion: string;
}

const getLevelInfo = (level: string) => {
  switch (level) {
    case 'high':
    case '高':
      return {
        label: '高风险',
        bgColor: 'bg-destructive/10',
        textColor: 'text-destructive',
        borderColor: 'border-destructive/30',
        icon: <AlertOctagon size={16} />,
      };
    case 'medium':
    case '中':
      return {
        label: '中风险',
        bgColor: 'bg-warning/10',
        textColor: 'text-warning',
        borderColor: 'border-warning/30',
        icon: <AlertTriangle size={16} />,
      };
    case 'low':
    case '低':
      return {
        label: '低风险',
        bgColor: 'bg-info/10',
        textColor: 'text-info',
        borderColor: 'border-info/30',
        icon: <Info size={16} />,
      };
    default:
      return {
        label: level || '风险',
        bgColor: 'bg-muted',
        textColor: 'text-muted-foreground',
        borderColor: 'border-border',
        icon: <AlertCircle size={16} />,
      };
  }
};

const AiRiskPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [projects, setProjects] = useState<WeddingProject[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [showProjectPicker, setShowProjectPicker] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AiRiskDetectResponse | null>(null);
  const [remaining, setRemaining] = useState(3);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const data = await getProjectList({ pageSize: 50 });
      setProjects(data.items || []);
    } catch {
      showToast('加载项目列表失败', 'error');
    } finally {
      setLoadingProjects(false);
    }
  };

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  const handleDetect = async () => {
    if (!selectedProjectId) {
      showToast('请先选择要检测的婚礼项目', 'warning');
      return;
    }
    if (remaining <= 0) {
      showToast('本月AI风险检测额度已用完，请到商店充值', 'warning');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // 加载项目流程
      const detail = await getProjectDetail(selectedProjectId);
      const steps: WeddingStep[] = detail.steps || [];

      if (steps.length === 0) {
        setError('该方案暂无流程环节，无法进行风险检测');
        showToast('该方案暂无流程环节', 'warning');
        setLoading(false);
        return;
      }

      const flowList = steps.map((s: WeddingStep) => ({
        stepName: s.stepName,
        duration: s.duration,
        hostTip: s.hostTip,
      }));

      const weddingInfo = {
        timeType: detail.timeType || 'dinner',
        totalMinutes: steps.reduce((sum: number, s: WeddingStep) => sum + (s.duration || 0), 0),
      };

      const data: AiRiskDetectResponse = await detectRisk(flowList, weddingInfo);
      setResult(data);
      setRemaining(prev => Math.max(0, prev - 1));
      showToast('检测完成', 'success');
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || '检测失败，请稍后重试';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const riskLevels =
    result?.risks?.reduce(
      (acc, r) => {
        if (r.level === '高' || r.level === 'high') acc.high += 1;
        else if (r.level === '中' || r.level === 'medium') acc.medium += 1;
        else acc.low += 1;
        return acc;
      },
      { high: 0, medium: 0, low: 0 }
    ) || { high: 0, medium: 0, low: 0 };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-[480px] mx-auto px-5">
        <PageHeader title="AI流程风险检测" onBack={() => navigate(-1)} />

        {/* 顶部说明卡片 */}
        <div className="bg-card rounded-2xl shadow-md p-5 mb-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Shield size={24} className="text-primary" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold font-serif text-foreground mb-1.5">
                智能风险检测
              </h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                AI智能分析婚礼流程，识别潜在风险并给出优化建议，帮您提前规避现场问题。
              </p>
            </div>
          </div>
        </div>

        {/* 选择方案卡片 */}
        <div className="bg-card rounded-2xl shadow-md p-5 mb-4">
          <label className="block text-sm font-medium text-foreground mb-3">
            选择要检测的婚礼项目
          </label>
          <button
            onClick={() => setShowProjectPicker(true)}
            className="w-full flex items-center justify-between px-4 py-3.5 border border-border rounded-xl text-left bg-secondary/40 hover:border-primary/40 transition-colors"
          >
            <span className={selectedProject ? 'text-foreground text-sm font-medium' : 'text-muted-foreground text-sm'}>
              {selectedProject ? selectedProject.title : '请选择婚礼项目'}
            </span>
            <ChevronDown size={18} className="text-muted-foreground" />
          </button>
        </div>

        {/* 额度提示行 */}
        <div className="flex items-center justify-between mb-4 px-1">
          <span className="text-sm text-muted-foreground">
            本月剩余 <span className="text-primary font-semibold">{remaining}</span> 次AI风险检测
          </span>
          <button
            onClick={() => navigate('/shop')}
            className="text-sm text-primary font-medium"
          >
            去充值
          </button>
        </div>

        {/* 检测按钮 */}
        <Button fullWidth onClick={handleDetect} loading={loading} disabled={!selectedProjectId}>
          <Shield size={18} />
          {loading ? 'AI检测中...' : '开始检测'}
        </Button>

        {/* 加载状态 */}
        {loading && (
          <div className="bg-card rounded-2xl shadow-md p-8 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">AI正在为您检测</p>
            <p className="text-xs text-muted-foreground">请稍候，正在全面分析流程风险...</p>
          </div>
        )}

        {/* 错误状态 */}
        {error && !loading && (
          <div className="bg-card rounded-2xl shadow-md p-6 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
              <AlertCircle size={28} className="text-destructive" />
            </div>
            <p className="text-base font-semibold text-foreground mb-2">检测失败</p>
            <p className="text-sm text-muted-foreground mb-4">{error}</p>
            <Button variant="secondary" onClick={handleDetect}>
              重新检测
            </Button>
          </div>
        )}

        {/* 结果区 */}
        {result && !loading && (
          <div className="mt-4 space-y-4">
            {/* 风险概览 */}
            <div className="bg-card rounded-2xl shadow-md p-5">
              <h3 className="text-lg font-semibold font-serif text-foreground mb-4">检测概览</h3>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-4 bg-destructive/10 rounded-xl">
                  <p className="text-2xl font-bold text-destructive font-serif">
                    {riskLevels.high}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">高风险</p>
                </div>
                <div className="text-center p-4 bg-warning/10 rounded-xl">
                  <p className="text-2xl font-bold text-warning font-serif">
                    {riskLevels.medium}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">中风险</p>
                </div>
                <div className="text-center p-4 bg-info/10 rounded-xl">
                  <p className="text-2xl font-bold text-info font-serif">
                    {riskLevels.low}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">低风险</p>
                </div>
              </div>
            </div>

            {/* 风险列表 */}
            <div className="bg-card rounded-2xl shadow-md p-5">
              <h3 className="text-lg font-semibold font-serif text-foreground mb-4">
                风险详情
                <span className="text-sm font-normal text-muted-foreground ml-2">
                  共{result.risks.length}项
                </span>
              </h3>
              {result.risks.length === 0 ? (
                <EmptyState
                  icon={<Shield size={24} />}
                  title="未检测到风险"
                  description="流程设计合理，继续保持"
                />
              ) : (
                <div className="space-y-3">
                  {result.risks.map((risk: RiskItem, index: number) => {
                    const info = getLevelInfo(risk.level);
                    return (
                      <div
                        key={index}
                        className={`border ${info.borderColor} rounded-xl p-4 ${info.bgColor}`}
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`${info.textColor}`}>{info.icon}</span>
                          <span
                            className={`text-xs font-semibold ${info.textColor} px-2 py-0.5 rounded-full bg-white/60`}
                          >
                            {info.label}
                          </span>
                        </div>
                        <p className="text-sm text-foreground mb-3 leading-relaxed">
                          {risk.content}
                        </p>
                        <div className="bg-card rounded-xl p-3 border border-border/50">
                          <div className="flex items-start gap-2">
                            <Lightbulb
                              size={14}
                              className="text-accent-gold flex-shrink-0 mt-0.5"
                            />
                            <p className="text-xs text-muted-foreground leading-relaxed">
                              <span className="font-medium text-foreground/70">优化建议：</span>
                              {risk.suggestion}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 底部免责声明 */}
        <p className="text-xs text-muted-foreground text-center mt-8 mb-4 px-4">
          {DISCLAMER}
        </p>
      </div>

      {/* 方案选择弹窗 - BottomSheet */}
      <BottomSheet
        open={showProjectPicker}
        onClose={() => setShowProjectPicker(false)}
        title="选择婚礼项目"
        height="large"
      >
        <div className="flex flex-col h-full">
          <div className="flex-1 overflow-y-auto p-5">
            {loadingProjects ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
              </div>
            ) : projects.length === 0 ? (
              <EmptyState
                icon={<Shield size={24} />}
                title="暂无婚礼项目"
                description="请先创建婚礼项目"
              />
            ) : (
              <div className="space-y-2">
                {projects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => {
                      setSelectedProjectId(project.id);
                      setShowProjectPicker(false);
                    }}
                    className={`w-full text-left p-4 rounded-xl border transition-all ${
                      selectedProjectId === project.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/30 bg-card'
                    }`}
                  >
                    <p className="text-sm font-semibold text-foreground">{project.title}</p>
                    <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
                      {project.groomName} & {project.brideName}
                      {project.hotelName ? ` · ${project.hotelName}` : ''}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="p-5 border-t border-border/60">
            <Button variant="secondary" fullWidth onClick={() => setShowProjectPicker(false)}>
              取消
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default AiRiskPage;
