import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Copy, Save, RotateCcw, AlertCircle, FileText } from 'lucide-react';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import { useToast } from '@client/src/components/ToastProvider';
import {
  generateScript as apiGenerateScript,
  checkScriptQuota,
  consumeScriptQuota,
} from '@client/src/api/ai';
import { createScript, getScriptCategories } from '@client/src/api/script';
import type { ScriptCategory } from '@shared/api.interface';

const DISCLAMER = 'AI生成内容仅为初稿，请主持人人工审核修改，本工具不承担现场使用责任';

const OPERATION_TYPES = [
  { key: 'generate', label: '生成新台词' },
  { key: 'rewrite', label: '改写现有' },
  { key: 'polish', label: '润色优化' },
];

const SPEECH_TYPES = [
  { key: 'opening', label: '开场词' },
  { key: 'oath', label: '誓言' },
  { key: 'parents', label: '父母致辞' },
  { key: 'witness', label: '证婚词' },
  { key: 'toast', label: '敬酒词' },
  { key: 'ending', label: '结束语' },
];

const SPEECH_STYLES = [
  { key: 'warm', label: '温馨感人' },
  { key: 'humorous', label: '幽默风趣' },
  { key: 'traditional', label: '中式传统' },
  { key: 'modern', label: '简约现代' },
  { key: 'grand', label: '庄重典雅' },
];

const LENGTH_OPTIONS = [
  { key: 'short', label: '简短开场白（约200字）' },
  { key: 'medium', label: '500字左右' },
  { key: 'long', label: '3分钟以内（约800字）' },
];

const AiScriptPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [operationType, setOperationType] = useState('generate');
  const [speechType, setSpeechType] = useState('opening');
  const [speechStyle, setSpeechStyle] = useState('warm');
  const [lengthRequirement, setLengthRequirement] = useState('medium');
  const [keyInformation, setKeyInformation] = useState('');
  const [originalContent, setOriginalContent] = useState('');
  const [additionalRequirements, setAdditionalRequirements] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedText, setGeneratedText] = useState('');
  const [generatedTitle, setGeneratedTitle] = useState('');
  const [remainingScript, setRemainingScript] = useState(10);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveTitle, setSaveTitle] = useState('');
  const [saveCategory, setSaveCategory] = useState('');
  const [saveTags, setSaveTags] = useState('');
  const [categories, setCategories] = useState<ScriptCategory[]>([]);
  const [saving, setSaving] = useState(false);

  const handleGenerate = async () => {
    if (operationType !== 'polish') {
      if (!keyInformation.trim()) {
        showToast('请填写关键信息', 'warning');
        return;
      }
    }
    if (operationType === 'rewrite' && !originalContent.trim()) {
      showToast('请输入原始台词', 'warning');
      return;
    }

    try {
      const quota = await checkScriptQuota();
      if (quota.remainingScript <= 0) {
        showToast('本月AI台词生成额度已用完，请到商店充值', 'warning');
        return;
      }
      setRemainingScript(quota.remainingScript);
    } catch {
      // 额度检查失败，继续
    }

    setLoading(true);
    setError(null);
    setGeneratedText('');
    setGeneratedTitle('');

    try {
      const data = await apiGenerateScript({
        speechType: SPEECH_TYPES.find(s => s.key === speechType)?.label || speechType,
        speechStyle: SPEECH_STYLES.find(s => s.key === speechStyle)?.label || speechStyle,
        operationType: OPERATION_TYPES.find(o => o.key === operationType)?.label || operationType,
        keyInformation,
        lengthRequirement: LENGTH_OPTIONS.find(l => l.key === lengthRequirement)?.label || lengthRequirement,
        originalContent,
        additionalRequirements,
      });

      setGeneratedText(data.content || '');
      setGeneratedTitle(data.title || '');

      try {
        await consumeScriptQuota();
        setRemainingScript(prev => Math.max(0, prev - 1));
      } catch {
        // 静默处理
      }

      showToast('生成完成', 'success');
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || err?.message || '生成失败，请稍后重试';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!generatedText) return;
    try {
      await navigator.clipboard.writeText(generatedText);
      showToast('已复制到剪贴板', 'success');
    } catch {
      showToast('复制失败', 'error');
    }
  };

  const handleSave = async () => {
    if (!generatedText) return;
    try {
      const cats = await getScriptCategories();
      setCategories(cats.items || []);
      if (cats.items?.[0]) setSaveCategory(cats.items[0].key);
    } catch {
      setCategories([]);
    }
    const baseTitle = generatedTitle
      ? generatedTitle
      : `${SPEECH_TYPES.find(s => s.key === speechType)?.label || '台词'}`;
    setSaveTitle(`${baseTitle}-${Date.now()}`);
    setSaveTags(SPEECH_STYLES.find(s => s.key === speechStyle)?.label || '');
    setShowSaveDialog(true);
  };

  const handleConfirmSave = async () => {
    if (!saveTitle.trim()) {
      showToast('请输入标题', 'warning');
      return;
    }
    if (!saveCategory) {
      showToast('请选择分类', 'warning');
      return;
    }
    setSaving(true);
    try {
      await createScript({
        title: saveTitle,
        category: saveCategory,
        content: generatedText,
        styleTags: saveTags,
      });
      showToast('已保存到台词库', 'success');
      setShowSaveDialog(false);
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || '保存失败';
      showToast(msg, 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleRegenerate = () => {
    handleGenerate();
  };

  const getButtonText = () => {
    if (loading) return 'AI生成中...';
    if (operationType === 'generate') return '生成台词';
    if (operationType === 'rewrite') return '改写台词';
    return '开始润色';
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-[480px] mx-auto px-5">
        <PageHeader title="AI台词生成" onBack={() => navigate(-1)} />

        {/* 顶部说明卡片 */}
        <div className="bg-card rounded-2xl shadow-md p-5 mb-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <FileText size={24} className="text-primary" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold font-serif text-foreground mb-1.5">
                智能台词创作
              </h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                根据新人信息和场景需求，AI一键生成专属婚礼台词，支持改写、润色多种模式。
              </p>
            </div>
          </div>
        </div>

        {/* 操作类型分段控件 */}
        <div className="bg-muted p-1 rounded-full mb-4 flex">
          {OPERATION_TYPES.map((op) => (
            <button
              key={op.key}
              onClick={() => {
                setOperationType(op.key);
                setGeneratedText('');
                setError(null);
              }}
              className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all ${
                operationType === op.key
                  ? 'bg-primary text-white shadow-md shadow-primary/20'
                  : 'text-muted-foreground'
              }`}
            >
              {op.label}
            </button>
          ))}
        </div>

        {/* 表单区 */}
        <div className="bg-card rounded-2xl shadow-md p-5 mb-4 space-y-5">
          {/* 台词类型 */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">台词类型</label>
            <div className="flex flex-wrap gap-2">
              {SPEECH_TYPES.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setSpeechType(s.key)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    speechType === s.key
                      ? 'bg-primary text-white'
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* 风格 */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">风格</label>
            <div className="flex flex-wrap gap-2">
              {SPEECH_STYLES.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setSpeechStyle(s.key)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    speechStyle === s.key
                      ? 'bg-primary text-white'
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* 长度 */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">长度要求</label>
            <div className="flex flex-wrap gap-2">
              {LENGTH_OPTIONS.map((l) => (
                <button
                  key={l.key}
                  onClick={() => setLengthRequirement(l.key)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    lengthRequirement === l.key
                      ? 'bg-primary text-white'
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* 关键信息 */}
          {operationType !== 'polish' && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">关键信息</label>
              <TextArea
                value={keyInformation}
                onChange={(e) => setKeyInformation(e.target.value)}
                placeholder="新人姓名、爱情故事、特别的记忆点等"
                rows={3}
              />
            </div>
          )}

          {/* 改写模式：原始台词 */}
          {operationType === 'rewrite' && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">原始台词</label>
              <TextArea
                value={originalContent}
                onChange={(e) => setOriginalContent(e.target.value)}
                placeholder="粘贴需要改写的原始台词"
                rows={5}
              />
            </div>
          )}

          {/* 润色模式：待润色内容 */}
          {operationType === 'polish' && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">待润色内容</label>
              <TextArea
                value={originalContent}
                onChange={(e) => setOriginalContent(e.target.value)}
                placeholder="粘贴需要润色优化的台词内容"
                rows={5}
              />
            </div>
          )}

          {/* 附加要求 */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              附加要求（选填）
            </label>
            <Input
              value={additionalRequirements}
              onChange={(e) => setAdditionalRequirements(e.target.value)}
              placeholder="如：需要包含古诗词、加入互动环节等"
            />
          </div>
        </div>

        {/* 额度提示行 */}
        <div className="flex items-center justify-between mb-4 px-1">
          <span className="text-sm text-muted-foreground">
            本月剩余 <span className="text-primary font-semibold">{remainingScript}</span> 次AI台词生成
          </span>
          <button
            onClick={() => navigate('/shop')}
            className="text-sm text-primary font-medium"
          >
            去充值
          </button>
        </div>

        {/* 生成按钮 */}
        <Button fullWidth onClick={handleGenerate} loading={loading}>
          <Sparkles size={18} />
          {getButtonText()}
        </Button>

        {/* 加载状态（流式时也展示） */}
        {loading && !generatedText && (
          <div className="bg-card rounded-2xl shadow-md p-8 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">AI正在为您生成</p>
            <p className="text-xs text-muted-foreground">请稍候，正在精心创作专属台词...</p>
          </div>
        )}

        {/* 错误状态 */}
        {error && !loading && (
          <div className="bg-card rounded-2xl shadow-md p-6 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
              <AlertCircle size={28} className="text-destructive" />
            </div>
            <p className="text-base font-semibold text-foreground mb-2">生成失败</p>
            <p className="text-sm text-muted-foreground mb-4">{error}</p>
            <Button variant="secondary" onClick={handleRegenerate}>
              重新生成
            </Button>
          </div>
        )}

        {/* 结果区 */}
        {generatedText && (
          <div className="bg-card rounded-2xl shadow-md p-5 mt-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold font-serif text-foreground">
                {generatedTitle || '生成结果'}
              </h3>
              {loading && (
                <span className="text-xs text-primary font-medium flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  生成中...
                </span>
              )}
            </div>
            <div className="bg-muted rounded-xl p-4 text-sm text-foreground leading-relaxed whitespace-pre-wrap min-h-[160px]">
              {generatedText}
              {loading && (
                <span className="inline-block w-0.5 h-4 bg-primary align-middle ml-0.5 animate-pulse" />
              )}
            </div>
            <div className="grid grid-cols-3 gap-2 mt-4">
              <Button variant="secondary" onClick={handleCopy}>
                <Copy size={16} />
                复制
              </Button>
              <Button variant="secondary" onClick={handleSave}>
                <Save size={16} />
                保存
              </Button>
              <Button variant="secondary" onClick={handleRegenerate} disabled={loading}>
                <RotateCcw size={16} />
                重新生成
              </Button>
            </div>
          </div>
        )}

        {/* 底部免责声明 */}
        <p className="text-xs text-muted-foreground text-center mt-8 mb-4 px-4">
          {DISCLAMER}
        </p>
      </div>

      {/* 保存弹窗 - BottomSheet */}
       <BottomSheet
        open={showSaveDialog}
        onClose={() => setShowSaveDialog(false)}
        title="保存到台词库"
        height="medium"
      >
        <div className="p-5 space-y-5">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">标题</label>
            <Input
              value={saveTitle}
              onChange={(e) => setSaveTitle(e.target.value)}
              placeholder="请输入台词标题"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">分类</label>
            <div className="flex flex-wrap gap-2">
              {categories.length > 0 ? (
                categories.map(c => (
                  <button
                    key={c.key}
                    onClick={() => setSaveCategory(c.key)}
                    className="px-4 py-1.5 rounded-full text-sm font-medium transition-all"
                    style={
                      saveCategory === c.key
                        ? {
                            background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                            color: '#FFFDF8',
                            boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                          }
                        : {
                            background: '#FDF9F5',
                            color: '#6B5C5C',
                            border: '1px solid #E8DCD0',
                          }
                    }
                  >
                    {c.name}
                  </button>
                ))
              ) : (
                <div className="text-sm text-muted-foreground">加载中...</div>
              )}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              标签（选填，多个用逗号分隔）
            </label>
            <Input
              value={saveTags}
              onChange={(e) => setSaveTags(e.target.value)}
              placeholder="如：温馨感人, 户外婚礼, 轻松自然"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" fullWidth onClick={() => setShowSaveDialog(false)}>
              取消
            </Button>
            <Button fullWidth onClick={handleConfirmSave} disabled={saving}>
              {saving ? '保存中...' : '确认保存'}
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default AiScriptPage;
