import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Copy,
  Download,
  AlertCircle,
  CheckCircle,
  Music,
  Mic,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  Edit3,
  Check,
  X,
  GripVertical,
  Save,
  FileText,
  Image as ImageIcon,
  Clock,
} from 'lucide-react';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import TextArea from '@client/src/components/app-ui/TextArea';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import { useToast } from '@client/src/components/ToastProvider';
import { generateFlow } from '@client/src/api/ai';
import { getProjectList, addStep, updateProject } from '@client/src/api/wedding';
import type { AiFlowGenerateResponse } from '@shared/api.interface';
import { logger } from '@lark-apaas/client-toolkit/logger';

const DISCLAMER = 'AI生成内容仅为初稿，请主持人人工审核修改，本工具不承担现场使用责任';
const DRAFT_KEY = 'ai_flow_edit_draft';

interface EditableStep {
  id: string;
  stepName: string;
  duration: number;
  bgmSuggest: string;
  hostTip: string;
  enabled: boolean;
}

function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

const AiFlowPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [steps, setSteps] = useState<EditableStep[]>([]);
  const [weddingInfo, setWeddingInfo] = useState<{
    timeType: string;
    totalMinutes: number;
    specialTip: string;
  } | null>(null);
  const [remainingFlow, setRemainingFlow] = useState(5);
  const [showImport, setShowImport] = useState(false);
  const [projects, setProjects] = useState<{ id: string; title: string }[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [importMode, setImportMode] = useState<'append' | 'overwrite'>('append');
  const [importing, setImporting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [hasUnsavedEdit, setHasUnsavedEdit] = useState(false);
  const [showAddSheet, setShowAddSheet] = useState(false);
  const [newStep, setNewStep] = useState({
    stepName: '',
    duration: 3,
    bgmSuggest: '',
    hostTip: '',
  });

  const charCount = description.length;

  useEffect(() => {
    getProjectList({ pageSize: 50 })
      .then((res) => {
        if (res?.items) {
          setProjects(res.items.map((p: any) => ({ id: p.id, title: p.title })));
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const draft = JSON.parse(raw);
        if (draft?.steps?.length > 0) {
          setSteps(draft.steps);
          setWeddingInfo(draft.weddingInfo);
          setDescription(draft.description || '');
          setHasUnsavedEdit(true);
        }
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (steps.length > 0) {
      try {
        localStorage.setItem(
          DRAFT_KEY,
          JSON.stringify({ steps, weddingInfo, description }),
        );
      } catch {
        /* ignore */
      }
    }
  }, [steps, weddingInfo, description]);

  const enabledSteps = useMemo(() => steps.filter((s) => s.enabled), [steps]);
  const totalMinutes = useMemo(
    () => enabledSteps.reduce((sum, s) => sum + s.duration, 0),
    [enabledSteps],
  );

  const handleGenerate = async () => {
    if (!description.trim()) {
      showToast('请先输入婚礼需求描述', 'warning');
      return;
    }
    if (remainingFlow <= 0) {
      showToast('本月AI流程生成额度已用完，请到商店充值', 'warning');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data: AiFlowGenerateResponse = await generateFlow(description);
      const editable: EditableStep[] = (data.flowList || []).map((s) => ({
        id: uid(),
        stepName: s.stepName,
        duration: s.duration,
        bgmSuggest: s.bgmSuggest,
        hostTip: s.hostTip,
        enabled: true,
      }));
      setSteps(editable);
      setWeddingInfo(data.weddingInfo);
      setRemainingFlow((prev) => Math.max(0, prev - 1));
      setHasUnsavedEdit(true);
      showToast('生成成功，可直接编辑环节', 'success');
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || '生成失败，请稍后重试';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (enabledSteps.length === 0) return;
    const text = enabledSteps
      .map(
        (s, i) =>
          `${i + 1}. ${s.stepName}（${s.duration}分钟）\nBGM：${s.bgmSuggest || '无'}\n备注：${s.hostTip || '无'}`,
      )
      .join('\n\n');
    try {
      await navigator.clipboard.writeText(text);
      showToast('已复制到剪贴板', 'success');
    } catch {
      showToast('复制失败', 'error');
    }
  };

  const moveStep = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= steps.length) return;
    const next = [...steps];
    [next[index], next[target]] = [next[target], next[index]];
    setSteps(next);
    setHasUnsavedEdit(true);
  };

  const deleteStep = (index: number) => {
    const next = steps.filter((_, i) => i !== index);
    setSteps(next);
    setHasUnsavedEdit(true);
  };

  const toggleStep = (index: number) => {
    const next = [...steps];
    next[index] = { ...next[index], enabled: !next[index].enabled };
    setSteps(next);
    setHasUnsavedEdit(true);
  };

  const updateStepField = (index: number, field: keyof EditableStep, value: string | number | boolean) => {
    const next = [...steps];
    next[index] = { ...next[index], [field]: value };
    setSteps(next);
    setHasUnsavedEdit(true);
  };

  const handleAddStep = () => {
    if (!newStep.stepName.trim()) {
      showToast('请输入环节名称', 'warning');
      return;
    }
    const step: EditableStep = {
      id: uid(),
      stepName: newStep.stepName.trim(),
      duration: Number(newStep.duration) || 3,
      bgmSuggest: newStep.bgmSuggest.trim(),
      hostTip: newStep.hostTip.trim(),
      enabled: true,
    };
    setSteps([...steps, step]);
    setShowAddSheet(false);
    setNewStep({ stepName: '', duration: 3, bgmSuggest: '', hostTip: '' });
    setHasUnsavedEdit(true);
    showToast('已添加环节', 'success');
  };

  const handleImport = async () => {
    if (!selectedProjectId) {
      showToast('请选择目标方案', 'warning');
      return;
    }
    if (enabledSteps.length === 0) {
      showToast('没有可导入的环节', 'warning');
      return;
    }
    setImporting(true);
    try {
      if (importMode === 'overwrite') {
        await updateProject(selectedProjectId, { title: undefined });
      }
      const promises = enabledSteps.map((s) =>
        addStep(selectedProjectId, {
          stepName: s.stepName,
          duration: s.duration,
          bgmSuggest: s.bgmSuggest,
          hostTip: s.hostTip,
        }),
      );
      await Promise.all(promises);
      showToast(`已${importMode === 'append' ? '追加' : '覆盖'}导入${enabledSteps.length}个环节`, 'success');
      setShowImport(false);
      localStorage.removeItem(DRAFT_KEY);
      setHasUnsavedEdit(false);
    } catch (err) {
      logger.error('导入流程失败', err);
      showToast('导入失败，请稍后重试', 'error');
    } finally {
      setImporting(false);
    }
  };

  const timeTypeLabel = (t: string) => (t === 'lunch' ? '午宴' : t === 'dinner' ? '晚宴' : t);

  const clearDraft = () => {
    setSteps([]);
    setWeddingInfo(null);
    setDescription('');
    localStorage.removeItem(DRAFT_KEY);
    setHasUnsavedEdit(false);
  };

  return (
    <div className="min-h-screen bg-background pb-28">
      <div className="max-w-[480px] mx-auto px-5">
        <PageHeader title="AI一键生成流程" onBack={() => navigate(-1)} />

        <div className="bg-card rounded-2xl shadow-md p-5 mb-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Sparkles size={24} className="text-primary" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold font-serif text-foreground mb-1.5">
                智能流程生成
              </h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                输入婚礼需求，AI自动生成完整流程，生成后可直接编辑每个环节再导入方案。
              </p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-2xl shadow-md p-5 mb-4 space-y-5">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-foreground">描述婚礼需求</label>
              <span className="text-xs text-muted-foreground">{charCount}字</span>
            </div>
            <TextArea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="中式午宴，仪式约40分钟，新人喜欢轻松氛围，有父母敬茶环节，不抛手捧花，室内五星酒店"
              rows={6}
            />
          </div>
        </div>

        <div className="flex items-center justify-between mb-4 px-1">
          <span className="text-sm text-muted-foreground">
            本月剩余 <span className="text-primary font-semibold">{remainingFlow}</span> 次AI流程生成
          </span>
          <button
            onClick={() => navigate('/shop')}
            className="text-sm text-primary font-medium"
          >
            去充值
          </button>
        </div>

        <Button fullWidth onClick={handleGenerate} loading={loading}>
          <Sparkles size={18} />
          {loading ? 'AI生成中...' : '一键生成流程'}
        </Button>

        {hasUnsavedEdit && steps.length > 0 && !loading && (
          <div className="flex items-center justify-between mt-3 px-1">
            <span className="text-xs text-accent-gold flex items-center gap-1">
              <Save size={12} />
              已自动保存编辑草稿
            </span>
            <button
              onClick={clearDraft}
              className="text-xs text-muted-foreground hover:text-destructive"
            >
              清空草稿
            </button>
          </div>
        )}

        {loading && (
          <div className="bg-card rounded-2xl shadow-md p-8 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">AI正在为您生成</p>
            <p className="text-xs text-muted-foreground">请稍候，正在为您定制婚礼流程...</p>
          </div>
        )}

        {error && !loading && (
          <div className="bg-card rounded-2xl shadow-md p-6 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
              <AlertCircle size={28} className="text-destructive" />
            </div>
            <p className="text-base font-semibold text-foreground mb-2">生成失败</p>
            <p className="text-sm text-muted-foreground mb-4">{error}</p>
            <Button
              variant="secondary"
              onClick={() => {
                setError(null);
                setDescription((d) => d.slice(0, Math.max(50, d.length / 2)));
              }}
            >
              简化描述重试
            </Button>
          </div>
        )}

        {steps.length > 0 && !loading && (
          <div className="mt-4 space-y-4">
            <div className="bg-card rounded-2xl shadow-md p-5">
              <h3 className="text-lg font-semibold font-serif text-foreground mb-4 flex items-center gap-2">
                <CheckCircle size={20} className="text-success" />
                婚礼信息
              </h3>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground mb-1">时段</p>
                  <p className="text-sm font-semibold text-foreground">
                    {weddingInfo ? timeTypeLabel(weddingInfo.timeType) : '-'}
                  </p>
                </div>
                <div className="text-center p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground mb-1">总时长</p>
                  <p className="text-sm font-semibold text-foreground">
                    {totalMinutes}分钟
                  </p>
                </div>
                <div className="text-center p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground mb-1">环节数</p>
                  <p className="text-sm font-semibold text-primary">
                    {enabledSteps.length}/{steps.length}
                  </p>
                </div>
              </div>
              {weddingInfo?.specialTip && (
                <div className="mt-3 p-3 bg-accent-gold/10 rounded-xl">
                  <p className="text-xs text-accent-gold font-medium">{weddingInfo.specialTip}</p>
                </div>
              )}
            </div>

            <div className="bg-card rounded-2xl shadow-md p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold font-serif text-foreground">
                  流程列表
                  <span className="text-sm font-normal text-muted-foreground ml-2">
                    共{steps.length}个环节
                  </span>
                </h3>
                <button
                  onClick={() => setShowAddSheet(true)}
                  className="text-xs text-primary font-medium flex items-center gap-1"
                >
                  <Plus size={14} />
                  添加环节
                </button>
              </div>

              <div className="space-y-3">
                {steps.map((step, index) => (
                  <div
                    key={step.id}
                    className={`border rounded-xl p-4 transition-all ${
                      step.enabled
                        ? 'border-border bg-white hover:border-primary/30'
                        : 'border-border/50 bg-muted/40 opacity-60'
                    }`}
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <button
                        onClick={() => toggleStep(index)}
                        className={`w-6 h-6 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${
                          step.enabled
                            ? 'border-primary bg-primary'
                            : 'border-border bg-white'
                        }`}
                        aria-label={step.enabled ? '取消勾选' : '勾选环节'}
                      >
                        {step.enabled && <Check size={14} className="text-white" />}
                      </button>

                      <div className="flex-1 min-w-0">
                        {editingId === step.id ? (
                          <input
                            value={step.stepName}
                            onChange={(e) => updateStepField(index, 'stepName', e.target.value)}
                            className="w-full px-2 py-1.5 text-sm font-semibold border border-primary rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            autoFocus
                          />
                        ) : (
                          <p className={`text-sm font-semibold ${step.enabled ? 'text-foreground' : 'text-muted-foreground line-through'}`}>
                            {index + 1}. {step.stepName}
                          </p>
                        )}
                      </div>

                      {editingId === step.id ? (
                        <button
                          onClick={() => setEditingId(null)}
                          className="text-primary p-1"
                          aria-label="完成编辑"
                        >
                          <Check size={16} />
                        </button>
                      ) : (
                        <button
                          onClick={() => setEditingId(step.id)}
                          className="text-muted-foreground p-1 hover:text-primary"
                          aria-label="编辑环节"
                        >
                          <Edit3 size={16} />
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mb-3 pl-9">
                      <span className="text-xs text-muted-foreground">时长</span>
                      <div className="flex items-center border border-border rounded-lg overflow-hidden">
                        <button
                          onClick={() =>
                            updateStepField(
                              index,
                              'duration',
                              Math.max(1, step.duration - 1),
                            )
                          }
                          className="px-2 py-1 text-xs text-foreground hover:bg-muted"
                          aria-label="减少时长"
                        >
                          −
                        </button>
                        <span className="px-2 text-xs font-semibold text-foreground min-w-[32px] text-center">
                          {step.duration}分
                        </span>
                        <button
                          onClick={() =>
                            updateStepField(
                              index,
                              'duration',
                              Math.min(60, step.duration + 1),
                            )
                          }
                          className="px-2 py-1 text-xs text-foreground hover:bg-muted"
                          aria-label="增加时长"
                        >
                          +
                        </button>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        <Clock size={12} className="inline" /> {step.duration}分钟
                      </span>
                    </div>

                    <div className="space-y-2 pl-9">
                      <div className="flex items-start gap-2 text-xs">
                        <Music size={14} className="text-accent-gold flex-shrink-0 mt-0.5" />
                        {editingId === step.id ? (
                          <input
                            value={step.bgmSuggest}
                            onChange={(e) => updateStepField(index, 'bgmSuggest', e.target.value)}
                            placeholder="背景音乐建议"
                            className="flex-1 px-2 py-1 text-xs border border-border rounded-lg focus:border-primary focus:outline-none"
                          />
                        ) : (
                          <span className="text-muted-foreground leading-relaxed">
                            <span className="font-medium text-foreground/70">BGM：</span>
                            {step.bgmSuggest || '无'}
                          </span>
                        )}
                      </div>
                      <div className="flex items-start gap-2 text-xs">
                        <Mic size={14} className="text-primary flex-shrink-0 mt-0.5" />
                        {editingId === step.id ? (
                          <textarea
                            value={step.hostTip}
                            onChange={(e) => updateStepField(index, 'hostTip', e.target.value)}
                            placeholder="主持人备注提示"
                            rows={2}
                            className="flex-1 px-2 py-1 text-xs border border-border rounded-lg focus:border-primary focus:outline-none resize-none"
                          />
                        ) : (
                          <span className="text-muted-foreground leading-relaxed">
                            <span className="font-medium text-foreground/70">主持备注：</span>
                            {step.hostTip || '无'}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-1 mt-3 pt-3 border-t border-border/50">
                      <button
                        onClick={() => moveStep(index, -1)}
                        disabled={index === 0}
                        className="p-1.5 text-muted-foreground hover:text-primary disabled:opacity-30"
                        aria-label="上移"
                      >
                        <ChevronUp size={16} />
                      </button>
                      <button
                        onClick={() => moveStep(index, 1)}
                        disabled={index === steps.length - 1}
                        className="p-1.5 text-muted-foreground hover:text-primary disabled:opacity-30"
                        aria-label="下移"
                      >
                        <ChevronDown size={16} />
                      </button>
                      <div className="w-px h-4 bg-border mx-1" />
                      <button
                        onClick={() => deleteStep(index)}
                        className="p-1.5 text-muted-foreground hover:text-destructive"
                        aria-label="删除环节"
                      >
                        <Trash2 size={16} />
                      </button>
                      <div className="p-1.5 text-muted-foreground/40 cursor-grab" aria-label="拖拽排序">
                        <GripVertical size={16} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setShowAddSheet(true)}
                className="w-full mt-4 py-3 border-2 border-dashed border-border rounded-xl text-sm text-muted-foreground hover:text-primary hover:border-primary/50 transition-colors flex items-center justify-center gap-2"
              >
                <Plus size={16} />
                添加自定义环节
              </button>
            </div>

            <div className="flex gap-3">
              <Button variant="secondary" fullWidth onClick={() => setShowImport(true)}>
                <FileText size={16} />
                导入方案
              </Button>
              <Button variant="secondary" fullWidth onClick={handleCopy}>
                <Copy size={16} />
                复制全部
              </Button>
            </div>

            <Button fullWidth onClick={() => setShowImport(true)}>
              <ImageIcon size={18} />
              生成海报 / 导出流程单
            </Button>
          </div>
        )}

        <p className="text-xs text-muted-foreground text-center mt-8 mb-4 px-4">
          {DISCLAMER}
        </p>
      </div>

      <BottomSheet
        open={showImport}
        onClose={() => setShowImport(false)}
        title="导入到方案"
        height="medium"
      >
        <div className="p-5 space-y-5">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">选择目标方案</label>
            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              className="w-full px-4 py-3 border border-input rounded-xl bg-secondary/60 focus:border-primary focus:outline-none text-sm text-foreground"
            >
              <option value="">请选择方案</option>
              {projects.length > 0 ? (
                projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title}
                  </option>
                ))
              ) : (
                <option value="" disabled>
                  暂无方案，请先创建
                </option>
              )}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">导入方式</label>
            <div className="flex gap-3">
              <button
                onClick={() => setImportMode('append')}
                className={`flex-1 py-3 rounded-xl border text-sm font-medium transition-all ${
                  importMode === 'append'
                    ? 'border-primary bg-primary/5 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                追加到末尾
              </button>
              <button
                onClick={() => setImportMode('overwrite')}
                className={`flex-1 py-3 rounded-xl border text-sm font-medium transition-all ${
                  importMode === 'overwrite'
                    ? 'border-primary bg-primary/5 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                覆盖现有流程
              </button>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            将导入 <span className="text-primary font-semibold">{enabledSteps.length}</span> 个已启用的环节
          </p>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" fullWidth onClick={() => setShowImport(false)}>
              取消
            </Button>
            <Button fullWidth onClick={handleImport} disabled={importing || !selectedProjectId}>
              {importing ? '导入中...' : '确认导入'}
            </Button>
          </div>
        </div>
      </BottomSheet>

      <BottomSheet
        open={showAddSheet}
        onClose={() => setShowAddSheet(false)}
        title="添加环节"
        height="medium"
      >
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              环节名称 <span className="text-destructive">*</span>
            </label>
            <input
              value={newStep.stepName}
              onChange={(e) => setNewStep({ ...newStep, stepName: e.target.value })}
              placeholder="如：跨火盆、敬烟、放飞气球"
              className="w-full px-4 py-3 border border-input rounded-xl bg-secondary/60 focus:border-primary focus:outline-none text-sm text-foreground"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">预计时长（分钟）</label>
            <input
              type="number"
              min={1}
              max={60}
              value={newStep.duration}
              onChange={(e) => setNewStep({ ...newStep, duration: Number(e.target.value) })}
              className="w-full px-4 py-3 border border-input rounded-xl bg-secondary/60 focus:border-primary focus:outline-none text-sm text-foreground"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">背景音乐建议</label>
            <input
              value={newStep.bgmSuggest}
              onChange={(e) => setNewStep({ ...newStep, bgmSuggest: e.target.value })}
              placeholder="可选，输入推荐曲目名称"
              className="w-full px-4 py-3 border border-input rounded-xl bg-secondary/60 focus:border-primary focus:outline-none text-sm text-foreground"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">主持人备注</label>
            <textarea
              value={newStep.hostTip}
              onChange={(e) => setNewStep({ ...newStep, hostTip: e.target.value })}
              placeholder="可选，输入该环节的主持要点"
              rows={3}
              className="w-full px-4 py-3 border border-input rounded-xl bg-secondary/60 focus:border-primary focus:outline-none text-sm text-foreground resize-none"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" fullWidth onClick={() => setShowAddSheet(false)}>
              取消
            </Button>
            <Button fullWidth onClick={handleAddStep}>
              <Plus size={16} />
              添加
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default AiFlowPage;
