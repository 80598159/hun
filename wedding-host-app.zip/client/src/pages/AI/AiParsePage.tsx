import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  AlertCircle,
  User,
  Calendar,
  Clock,
  Building,
  Palette,
  AlertTriangle,
  Users,
  Ban,
  FileSearch,
  ArrowRight,
} from 'lucide-react';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import TextArea from '@client/src/components/app-ui/TextArea';
import { useToast } from '@client/src/components/ToastProvider';
import { parseRequirement } from '@client/src/api/ai';
import type { AiRequirementParseResponse } from '@shared/api.interface';

const DISCLAMER = 'AI生成内容仅为初稿，请主持人人工审核修改，本工具不承担现场使用责任';

interface ParseField {
  label: string;
  value: string;
  icon: React.ReactNode;
  bgClass: string;
  textClass: string;
}

const AiParsePage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AiRequirementParseResponse | null>(null);
  const [remaining, setRemaining] = useState(5);

  const charCount = text.length;

  const handleParse = async () => {
    if (!text.trim()) {
      showToast('请先粘贴需求文本', 'warning');
      return;
    }
    if (remaining <= 0) {
      showToast('本月AI需求解析额度已用完，请到商店充值', 'warning');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data: AiRequirementParseResponse = await parseRequirement(text);
      setResult(data);
      setRemaining(prev => Math.max(0, prev - 1));
      showToast('解析成功', 'success');
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || '解析失败，请稍后重试';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleImport = () => {
    showToast('已导入到方案信息', 'success');
    navigate(-1);
  };

  const getFields = (r: AiRequirementParseResponse): ParseField[] => [
    {
      label: '新郎姓名',
      value: r.groomName || '未识别',
      icon: <User size={16} />,
      bgClass: 'bg-info/10',
      textClass: 'text-info',
    },
    {
      label: '新娘姓名',
      value: r.brideName || '未识别',
      icon: <User size={16} />,
      bgClass: 'bg-primary/10',
      textClass: 'text-primary',
    },
    {
      label: '婚礼日期',
      value: r.weddingDate || '未识别',
      icon: <Calendar size={16} />,
      bgClass: 'bg-accent-gold/15',
      textClass: 'text-accent-gold',
    },
    {
      label: '时段',
      value: r.timeType === 'lunch' ? '午宴' : r.timeType === 'dinner' ? '晚宴' : (r.timeType || '未识别'),
      icon: <Clock size={16} />,
      bgClass: 'bg-warning/10',
      textClass: 'text-warning',
    },
    {
      label: '酒店名称',
      value: r.hotelName || '未识别',
      icon: <Building size={16} />,
      bgClass: 'bg-info/10',
      textClass: 'text-info',
    },
    {
      label: '婚礼风格',
      value: r.style || '未识别',
      icon: <Palette size={16} />,
      bgClass: 'bg-primary/10',
      textClass: 'text-primary',
    },
    {
      label: '特殊要求',
      value: r.specialRequirements || '无',
      icon: <AlertTriangle size={16} />,
      bgClass: 'bg-warning/10',
      textClass: 'text-warning',
    },
    {
      label: '父母是否上台',
      value: r.parentsOnStage ? '是' : '否',
      icon: <Users size={16} />,
      bgClass: 'bg-success/10',
      textClass: 'text-success',
    },
    {
      label: '禁忌环节',
      value: r.tabooLinks?.length > 0 ? r.tabooLinks.join('、') : '无',
      icon: <Ban size={16} />,
      bgClass: 'bg-destructive/10',
      textClass: 'text-destructive',
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="max-w-[480px] mx-auto px-5">
        <PageHeader title="AI需求解析" onBack={() => navigate(-1)} />

        {/* 顶部说明卡片 */}
        <div className="bg-card rounded-2xl shadow-md p-5 mb-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <FileSearch size={24} className="text-primary" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold font-serif text-foreground mb-1.5">
                智能需求解析
              </h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                粘贴新人想法或需求描述，AI自动提取关键信息，一键回填到婚礼方案中。
              </p>
            </div>
          </div>
        </div>

        {/* 输入表单卡片 */}
        <div className="bg-card rounded-2xl shadow-md p-5 mb-4 space-y-5">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-foreground">需求文本</label>
              <span className="text-xs text-muted-foreground">{charCount}字</span>
            </div>
            <TextArea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="粘贴新人需求文本，如：我们想办一场中式婚礼，新郎叫张三，新娘叫李四，日期定在2025年10月1日，午宴..."
              rows={8}
            />
          </div>
        </div>

        {/* 额度提示行 */}
        <div className="flex items-center justify-between mb-4 px-1">
          <span className="text-sm text-muted-foreground">
            本月剩余 <span className="text-primary font-semibold">{remaining}</span> 次AI需求解析
          </span>
          <button
            onClick={() => navigate('/shop')}
            className="text-sm text-primary font-medium"
          >
            去充值
          </button>
        </div>

        {/* 主操作按钮 */}
        <Button fullWidth onClick={handleParse} loading={loading}>
          <Sparkles size={18} />
          {loading ? 'AI解析中...' : '开始解析'}
        </Button>

        {/* 加载状态 */}
        {loading && (
          <div className="bg-card rounded-2xl shadow-md p-8 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">AI正在为您解析</p>
            <p className="text-xs text-muted-foreground">请稍候，正在提取需求关键信息...</p>
          </div>
        )}

        {/* 错误状态 */}
        {error && !loading && (
          <div className="bg-card rounded-2xl shadow-md p-6 mt-4 text-center">
            <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
              <AlertCircle size={28} className="text-destructive" />
            </div>
            <p className="text-base font-semibold text-foreground mb-2">解析失败</p>
            <p className="text-sm text-muted-foreground mb-4">{error}</p>
            <Button variant="secondary" onClick={handleParse}>
              重新解析
            </Button>
          </div>
        )}

        {/* 结果区 */}
        {result && !loading && (
          <div className="mt-4 space-y-4">
            <div className="bg-card rounded-2xl shadow-md p-5">
              <h3 className="text-lg font-semibold font-serif text-foreground mb-4">
                解析结果
              </h3>
              <div className="space-y-1">
                {getFields(result).map((field, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 py-3 border-b border-border/60 last:border-b-0"
                  >
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${field.bgClass} ${field.textClass}`}
                    >
                      {field.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-0.5">{field.label}</p>
                      <p className="text-sm font-medium text-foreground break-words leading-relaxed">
                        {field.value}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Button fullWidth onClick={handleImport}>
              导入到方案信息
              <ArrowRight size={18} />
            </Button>
          </div>
        )}

        {/* 底部免责声明 */}
        <p className="text-xs text-muted-foreground text-center mt-8 mb-4 px-4">
          {DISCLAMER}
        </p>
      </div>
    </div>
  );
};

export default AiParsePage;
