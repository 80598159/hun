import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Lock } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { login } from '@client/src/api/auth';
import Input from '@client/src/components/app-ui/Input';
import Button from '@client/src/components/app-ui/Button';
import { useToast } from '@client/src/components/ToastProvider';

const LoginPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      showToast('请输入账号', 'warning');
      return;
    }
    if (!password.trim()) {
      showToast('请输入密码', 'warning');
      return;
    }

    setLoading(true);
    try {
      await login(username.trim(), password);
      showToast('登录成功', 'success');
      setTimeout(() => {
        navigate('/', { replace: true });
      }, 500);
    } catch (error) {
      logger.error('登录失败', error);
      const msg =
        (error as any)?.response?.data?.error?.message ||
        '登录失败，请检查账号密码';
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex flex-col relative overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #2C0A14 0%, #5C1525 45%, #8B1530 100%)' }}
    >
      {/* 顶部品牌区 */}
      <div className="flex-1 flex flex-col items-center justify-center pt-16 pb-10 px-5">
        {/* Logo 圆环 */}
        <div className="relative mb-6">
          <div
            className="absolute -inset-2 rounded-full opacity-40 blur-md"
            style={{ background: 'linear-gradient(135deg, #E8D5A3, #C9A961)' }}
          />
          <div
            className="relative w-20 h-20 rounded-full flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
              boxShadow: '0 4px 20px rgba(201, 169, 97, 0.4)',
            }}
          >
            <span
              className="font-serif text-3xl font-bold"
              style={{ color: '#5C4520' }}
            >
              婚
            </span>
          </div>
        </div>

        {/* 品牌名 */}
        <h1
          className="font-serif text-4xl font-bold tracking-widest mb-2"
          style={{ color: '#FFFDF8' }}
        >
          婚序
        </h1>
        <p className="text-sm opacity-70 tracking-widest" style={{ color: '#E8D5A3' }}>
          婚礼主持助手
        </p>
      </div>

      {/* 底部登录卡片 */}
      <div
        className="rounded-t-[2rem] px-6 pt-8 pb-10 w-full max-w-[480px] mx-auto relative z-10"
        style={{
          background: '#FBF6F0',
          boxShadow: '0 -8px 32px rgba(0, 0, 0, 0.15)',
        }}
      >
        <h2 className="text-xl font-semibold text-foreground mb-6 text-center tracking-tight">
          账号登录
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="账号"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="请输入账号"
            leftIcon={<User size={18} />}
            autoComplete="username"
          />
          <Input
            label="密码"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="请输入密码"
            type="password"
            leftIcon={<Lock size={18} />}
            autoComplete="current-password"
          />

          <Button type="submit" fullWidth loading={loading} className="!h-12 !mt-6">
            {loading ? '登录中...' : '登 录'}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground">
            演示账号：<span className="font-medium text-foreground/80">demo</span> /{' '}
            <span className="font-medium text-foreground/80">123456</span>
          </p>
        </div>

        {/* 底部版权 */}
        <div className="mt-10 text-center">
          <p className="font-serif text-sm text-primary font-bold mb-1 tracking-wider">
            婚序 · 婚礼主持助手
          </p>
          <p className="text-xs text-muted-foreground">
            © 2025 婚序 v1.0.0
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
