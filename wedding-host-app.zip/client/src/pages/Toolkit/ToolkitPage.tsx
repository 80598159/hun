import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ClipboardList,
  AlertTriangle,
  FileText,
  ClipboardCheck,
  ChevronDown,
  ChevronUp,
  Copy,
  ArrowRight,
  Sparkles,
  FileEdit,
  Search,
  ShieldAlert,
  Store,
  Check,
  Music,
  Receipt,
} from 'lucide-react';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import PageHeader from '@client/src/components/PageHeader';
import { useToast } from '@client/src/components/ToastProvider';
import {
  getRehearsalChecklist,
  getEmergencyMemos,
  getContractTemplate,
} from '@client/src/api/toolkit';

interface ChecklistCategory {
  category: string;
  icon?: string;
  items: string[];
}

interface EmergencyMemo {
  title: string;
  content: string;
}

interface ContractTemplate {
  title: string;
  content: string;
}

type ToolKey = 'rehearsal' | 'emergency' | 'contract' | 'questionnaire' | 'bgm' | 'quotation' | null;

const ToolkitPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [activeTool, setActiveTool] = useState<ToolKey>(null);

  // 彩排清单
  const [checklist, setChecklist] = useState<ChecklistCategory[]>([]);
  const [checklistLoading, setChecklistLoading] = useState(false);
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());

  // 应急备忘
  const [memos, setMemos] = useState<EmergencyMemo[]>([]);
  const [memosLoading, setMemosLoading] = useState(false);
  const [expandedMemo, setExpandedMemo] = useState<number | null>(null);

  // 合同模板
  const [contract, setContract] = useState<ContractTemplate | null>(null);
  const [contractLoading, setContractLoading] = useState(false);

  const toolCards = [
    {
      key: 'rehearsal' as const,
      title: '彩排核对',
      desc: '逐项确认，万无一失',
      icon: ClipboardList,
      bgColor: 'bg-primary/10',
      iconColor: 'text-primary',
    },
    {
      key: 'emergency' as const,
      title: '应急备忘',
      desc: '突发状况从容应对',
      icon: AlertTriangle,
      bgColor: 'bg-[hsl(42_65%_53%)]/10',
      iconColor: 'text-[hsl(42_65%_53%)]',
    },
    {
      key: 'contract' as const,
      title: '合同模板',
      desc: '规范合作保障权益',
      icon: FileText,
      bgColor: 'bg-[hsl(205_38%_46%)]/10',
      iconColor: 'text-[hsl(205_38%_46%)]',
    },
    {
      key: 'questionnaire' as const,
      title: '新人问卷',
      desc: '一键生成问卷链接',
      icon: ClipboardCheck,
      bgColor: 'bg-[hsl(130_38%_45%)]/10',
      iconColor: 'text-[hsl(130_38%_45%)]',
    },
    {
      key: 'bgm' as const,
      title: '音乐歌单',
      desc: '精选婚礼BGM库',
      icon: Music,
      bgColor: 'bg-[hsl(330_50%_45%)]/10',
      iconColor: 'text-[hsl(330_50%_45%)]',
    },
    {
      key: 'quotation' as const,
      title: '报价单',
      desc: '专业报价一键生成',
      icon: Receipt,
      bgColor: 'bg-[hsl(32_60%_50%)]/10',
      iconColor: 'text-[hsl(32_60%_50%)]',
    },
  ];

  const aiTools = [
    {
      key: 'flow',
      title: 'AI流程生成',
      desc: '智能生成完整婚礼流程',
      icon: Sparkles,
      path: '/ai/flow',
    },
    {
      key: 'script',
      title: 'AI台词生成',
      desc: '多风格台词一键创作',
      icon: FileEdit,
      path: '/ai/script',
    },
    {
      key: 'parse',
      title: 'AI需求解析',
      desc: '文字提取婚礼信息',
      icon: Search,
      path: '/ai/parse',
    },
    {
      key: 'risk',
      title: 'AI风险检测',
      desc: '智能识别流程风险点',
      icon: ShieldAlert,
      path: '/ai/risk',
    },
  ];

  const loadRehearsal = async () => {
    if (checklist.length > 0) return;
    setChecklistLoading(true);
    try {
      const data = await getRehearsalChecklist();
      setChecklist(data || []);
    } catch {
      showToast('加载彩排清单失败', 'error');
    } finally {
      setChecklistLoading(false);
    }
  };

  const loadEmergency = async () => {
    if (memos.length > 0) return;
    setMemosLoading(true);
    try {
      const data = await getEmergencyMemos();
      setMemos(data || []);
    } catch {
      showToast('加载应急备忘失败', 'error');
    } finally {
      setMemosLoading(false);
    }
  };

  const loadContract = async () => {
    if (contract) return;
    setContractLoading(true);
    try {
      const data = await getContractTemplate();
      setContract(data);
    } catch {
      showToast('加载合同模板失败', 'error');
    } finally {
      setContractLoading(false);
    }
  };

  const handleToolClick = (key: ToolKey) => {
    if (key === 'bgm') {
      navigate('/bgm');
      return;
    }
    if (key === 'quotation') {
      navigate('/quotation');
      return;
    }
    if (key === 'questionnaire') {
      navigate('/questionnaire');
      return;
    }
    setActiveTool(key);
    if (key === 'rehearsal') void loadRehearsal();
    if (key === 'emergency') void loadEmergency();
    if (key === 'contract') void loadContract();
  };

  const toggleCheck = (category: string, item: string) => {
    const key = `${category}::${item}`;
    setCheckedItems(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const totalItems = checklist.reduce((sum, cat) => sum + cat.items.length, 0);
  const checkedCount = Array.from(checkedItems).filter(key => {
    const [cat] = key.split('::');
    return checklist.some(c => c.category === cat);
  }).length;
  const progressPercent = totalItems > 0 ? Math.round((checkedCount / totalItems) * 100) : 0;

  const handleCopyContract = async () => {
    if (!contract) return;
    try {
      await navigator.clipboard.writeText(contract.content);
      showToast('已复制全文', 'success');
    } catch {
      showToast('复制失败，请手动复制', 'error');
    }
  };

  const handleGenerateQuestionnaire = () => {
    navigate('/questionnaire');
  };

  const getToolTitle = (): string => {
    const map: Record<string, string> = {
      rehearsal: '彩排核对',
      emergency: '应急备忘',
      contract: '合同模板',
      questionnaire: '新人问卷',
    };
    return map[activeTool as string] ?? '';
  };


  const sheetHeight = activeTool === 'rehearsal' ? 'full' : activeTool === 'contract' ? 'large' : 'medium';

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="工具箱" onBack={() => navigate(-1)} />

      {/* 常用工具 2x2 卡片网格 */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-7">
        {toolCards.map(tool => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.key}
              onClick={() => handleToolClick(tool.key)}
              className="bg-card rounded-2xl shadow-md p-5 text-left transition-all duration-200 active:scale-[0.97] hover:shadow-lg"
            >
              <div className={`w-12 h-12 rounded-xl ${tool.bgColor} ${tool.iconColor} flex items-center justify-center mb-3`}>
                <Icon size={24} />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-1">
                {tool.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{tool.desc}</p>
            </button>
          );
        })}
      </div>

      {/* AI 工具专区 */}
      <div className="mb-7">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles size={20} className="text-primary" />
          <h2 className="font-serif text-xl font-semibold text-foreground tracking-tight">
            AI 智能工具
          </h2>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {aiTools.map(tool => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.key}
                onClick={() => navigate(tool.path)}
                className="relative rounded-2xl p-5 text-left transition-all duration-200 active:scale-[0.97] overflow-hidden border border-primary/10"
                style={{ background: 'linear-gradient(135deg, hsl(348 74% 42% / 0.08) 0%, hsl(43 44% 55% / 0.12) 100%)' }}
              >
                <div className="w-10 h-10 rounded-xl bg-card shadow-sm flex items-center justify-center mb-3 text-primary">
                  <Icon size={20} />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-0.5">
                  {tool.title}
                </h3>
                <p className="text-xs text-muted-foreground mb-3 leading-relaxed">{tool.desc}</p>
                <div className="flex items-center text-primary text-xs font-medium">
                  去使用 <ArrowRight size={14} className="ml-1" />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 商圈入口 Banner */}
      <button
        onClick={() => navigate('/mall')}
        className="w-full bg-card rounded-2xl shadow-md p-5 flex items-center justify-between transition-all duration-200 active:scale-[0.98] hover:shadow-lg"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-accent-gold/10 text-accent-gold flex items-center justify-center">
            <Store size={24} />
          </div>
          <div className="text-left">
            <h3 className="text-lg font-semibold text-foreground">婚庆商圈</h3>
            <p className="text-sm text-muted-foreground mt-0.5">优质商家推荐</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-accent-gold font-medium text-sm">
          进入商圈
          <ArrowRight size={18} />
        </div>
      </button>

      {/* 工具详情 BottomSheet */}
      <BottomSheet
        open={activeTool !== null}
        onClose={() => setActiveTool(null)}
        title={getToolTitle()}
        height={sheetHeight}
      >
        <div className="p-5">
          {/* 彩排核对清单 */}
          {activeTool === 'rehearsal' && (
            <>
              {checklistLoading ? (
                <div className="flex justify-center py-12">
                  <LoadingSpinner />
                </div>
              ) : checklist.length === 0 ? (
                <EmptyState
                  icon={<ClipboardList size={28} />}
                  title="暂无清单"
                />
              ) : (
                <>
                  {/* 进度条卡片 */}
                  <div className="bg-card rounded-2xl shadow-sm p-5 mb-5 flex items-center justify-between border border-border/40">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">完成进度</p>
                      <p className="text-2xl font-bold text-foreground font-serif">
                        {checkedCount}
                        <span className="text-sm font-normal text-muted-foreground"> / {totalItems}</span>
                      </p>
                    </div>
                    <div className="relative w-16 h-16">
                      <svg className="w-16 h-16 -rotate-90" viewBox="0 0 64 64">
                        <circle
                          cx="32" cy="32" r="28"
                          fill="none"
                          stroke="hsl(30 25% 88%)"
                          strokeWidth="5"
                        />
                        <circle
                          cx="32" cy="32" r="28"
                          fill="none"
                          stroke="hsl(348 74% 42%)"
                          strokeWidth="5"
                          strokeLinecap="round"
                          strokeDasharray={`${2 * Math.PI * 28}`}
                          strokeDashoffset={`${2 * Math.PI * 28 * (1 - progressPercent / 100)}`}
                          style={{ transition: 'stroke-dashoffset 0.4s ease' }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-sm font-bold text-primary">{progressPercent}%</span>
                      </div>
                    </div>
                  </div>

                  {/* 分组列表 */}
                  <div className="space-y-4">
                    {checklist.map((cat, catIdx) => {
                      const catChecked = cat.items.filter(item =>
                        checkedItems.has(`${cat.category}::${item}`)
                      ).length;
                      return (
                        <div key={catIdx} className="bg-card rounded-2xl shadow-sm p-5 border border-border/40">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="text-base font-semibold text-foreground">
                              {cat.category}
                            </h4>
                            <span className="text-xs text-muted-foreground font-medium">
                              {catChecked}/{cat.items.length}
                            </span>
                          </div>
                          <div className="space-y-2.5">
                            {cat.items.map((item, itemIdx) => {
                              const isChecked = checkedItems.has(`${cat.category}::${item}`);
                              return (
                                <button
                                  key={itemIdx}
                                  onClick={() => toggleCheck(cat.category, item)}
                                  className="w-full flex items-start gap-3 text-left py-1 transition-colors"
                                  aria-checked={isChecked}
                                  role="checkbox"
                                  aria-label={item}
                                >
                                  <div
                                    className={`
                                      w-5 h-5 rounded-md border-2 flex-shrink-0 mt-0.5 flex items-center justify-center transition-all
                                      ${isChecked
                                        ? 'bg-primary border-primary'
                                        : 'border-border'}
                                    `}
                                  >
                                    {isChecked && <Check size={14} className="text-primary-foreground" strokeWidth={3} />}
                                  </div>
                                  <span
                                    className={`text-sm flex-1 leading-relaxed ${
                                      isChecked
                                        ? 'text-muted-foreground line-through'
                                        : 'text-foreground/80'
                                    }`}
                                  >
                                    {item}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </>
          )}

          {/* 应急备忘录 */}
          {activeTool === 'emergency' && (
            <>
              {memosLoading ? (
                <div className="flex justify-center py-12">
                  <LoadingSpinner />
                </div>
              ) : memos.length === 0 ? (
                <EmptyState
                  icon={<AlertTriangle size={28} />}
                  title="暂无备忘"
                />
              ) : (
                <div className="space-y-3">
                  {memos.map((memo, idx) => (
                    <div
                      key={idx}
                      className="bg-card rounded-2xl shadow-sm overflow-hidden border border-border/40"
                    >
                      <button
                        onClick={() =>
                          setExpandedMemo(expandedMemo === idx ? null : idx)
                        }
                        className="w-full flex items-center justify-between p-4 text-left"
                        aria-expanded={expandedMemo === idx}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-accent-gold/10 text-accent-gold flex items-center justify-center">
                            <AlertTriangle size={20} />
                          </div>
                          <h4 className="text-base font-medium text-foreground">
                            {memo.title}
                          </h4>
                        </div>
                        {expandedMemo === idx ? (
                          <ChevronUp size={20} className="text-muted-foreground" />
                        ) : (
                          <ChevronDown size={20} className="text-muted-foreground" />
                        )}
                      </button>
                      {expandedMemo === idx && (
                        <div className="px-5 pb-4 border-t border-border/40">
                          <p className="text-sm text-muted-foreground leading-relaxed pt-3 whitespace-pre-wrap">
                            {memo.content}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {/* 合同模板 */}
          {activeTool === 'contract' && (
            <>
              {contractLoading ? (
                <div className="flex justify-center py-12">
                  <LoadingSpinner />
                </div>
              ) : !contract ? (
                <EmptyState
                  icon={<FileText size={28} />}
                  title="暂无合同模板"
                />
              ) : (
                <>
                  <div className="mb-4">
                    <Button
                      variant="gold"
                      fullWidth
                      onClick={handleCopyContract}
                    >
                      <Copy size={18} />
                      复制全文
                    </Button>
                  </div>
                  <div className="bg-card rounded-2xl shadow-sm p-6 border border-border/40">
                    <h3 className="text-lg font-bold text-center text-foreground mb-5 font-serif">
                      {contract.title}
                    </h3>
                    <div className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
                      {contract.content}
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {/* 新人问卷 */}
          {activeTool === 'questionnaire' && (
            <div className="py-6">
              <div className="bg-card rounded-2xl shadow-sm p-8 border border-border/40 text-center mb-5">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mx-auto mb-5">
                  <ClipboardCheck size={36} />
                </div>
                <h3 className="text-lg font-semibold text-foreground font-serif mb-2">
                  新人问卷
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-6">
                  生成专属问卷链接或二维码，<br />快速收集新人婚礼信息
                </p>
                <div className="bg-secondary/60 rounded-xl p-5 mb-6">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    💍 问卷功能开发中<br />
                    即将支持：新人信息收集、婚礼偏好调研、流程需求问卷等
                  </p>
                </div>
              </div>
              <Button
                variant="primary"
                fullWidth
                size="lg"
                onClick={handleGenerateQuestionnaire}
              >
                生成新人问卷
              </Button>
            </div>
          )}
        </div>
      </BottomSheet>
    </div>
  );
};

export default ToolkitPage;
