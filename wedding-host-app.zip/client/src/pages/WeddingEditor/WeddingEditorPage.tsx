import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import html2canvas from 'html2canvas';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  MoreHorizontal,
  Plus,
  ChevronUp,
  ChevronDown,
  Trash2,
  Edit3,
  Music,
  Clock,
  FileText,
  Copy,
  Check,
  X,
  Settings,
  Sparkles,
  Heart,
  GripVertical,
  AlertTriangle,
  Share2,
  Users,
  Calendar as CalendarIcon,
  Building2,
  Mic2,
  Video,
  Camera,
  Volume2,
  UserCog,
  User,
  MessageSquare,

  ChevronDown as ChevronDownIcon,
  ChevronRight,
  Image as ImageIcon,
  ImagePlus,
  RotateCw,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Crown,
  Palette,
  Upload,
  UserPlus,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';
import { capabilityClient } from '@lark-apaas/client-toolkit';
import { removeBackground } from '@client/src/api/ai';
import defaultPosterBg from '@client/src/assets/poster/default-bg.jpg';
import type { WeddingProject, WeddingStep, PresetStep, ProjectAccessInfo } from '@shared/api.interface';
import {
  getProjectDetail,
  updateProject,
  addStep,
  updateStep,
  deleteStep,
  reorderSteps,
  getPresetSteps,
  copyProject,
  archiveProject,
  getProjectAccessInfo,
  joinByShareCode,
} from '@client/src/api/wedding';
import { getUserProfile, updatePosterPhoto } from '@client/src/api/user';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import PhotoEditor from './components/PhotoEditor';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import WeddingShareSheet from '@client/src/components/WeddingShareSheet/WeddingShareSheet';
import { useToast } from '@client/src/components/ToastProvider';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Image } from '@client/src/components/ui/image';
import type {
  HostImageGenerationOneOutput,
  HostPhotoBackgroundMattingOneOutput,
} from '@shared/plugin-types';

type StepCategory = '暖场类' | '仪式类' | '互动类';

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

const PRESET_CATEGORIES = [
  { key: '暖场类', name: '暖场类' },
  { key: '仪式类', name: '仪式类' },
  { key: '互动类', name: '互动类' },
];

const CATEGORY_COLORS: Record<StepCategory, { bar: string; badge: string; text: string; bg: string }> = {
  '暖场类': {
    bar: 'bg-accent-gold',
    badge: 'bg-accent-gold/15 text-accent-gold-dark',
    text: 'text-accent-gold-dark',
    bg: 'bg-accent-gold/10',
  },
  '仪式类': {
    bar: 'bg-primary',
    badge: 'bg-primary/10 text-primary',
    text: 'text-primary',
    bg: 'bg-primary/5',
  },
  '互动类': {
    bar: 'bg-info',
    badge: 'bg-info/15 text-info',
    text: 'text-info',
    bg: 'bg-info/10',
  },
};

function getStepCategory(step: WeddingStep | PresetStep): StepCategory {
  const preset = step as PresetStep;
  if (preset.category) {
    const cat = preset.category;
    if (cat === '暖场类' || cat === '暖场') return '暖场类';
    if (cat === '互动类' || cat === '互动') return '互动类';
    if (cat === '仪式类' || cat === '仪式') return '仪式类';
  }
  const name = step.stepName;
  if (/暖场|迎宾|签到|等候|开场前|候场|入场前|宾客/.test(name)) return '暖场类';
  if (/互动|游戏|抽奖|抛捧花|合影|敬酒|送客|红包|手捧花/.test(name)) return '互动类';
  return '仪式类';
}

const WeddingEditorPage = () => {
  const { id = '' } = useParams<{ id: string }>();
  const isNewProject = id === 'new';
  const navigate = useNavigate();
  const { showToast } = useToast();
  const posterExportRef = useRef<HTMLDivElement>(null);

  const [loading, setLoading] = useState(!isNewProject);
  const [project, setProject] = useState<WeddingProject | null>(
    isNewProject
      ? {
          id: 'new',
          title: '新婚礼方案',
          groomName: '',
          brideName: '',
          weddingDate: null,
          timeType: 'lunch',
          hotelName: '',
          planner: '',
          supervisor: '',
          videographer: '',
          photographer: '',
          soundController: '',
          specialNotes: '',
          status: 'draft',
          isArchived: false,
          posterTemplate: 'classic',
          scheduleId: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }
      : null,
  );
  const [steps, setSteps] = useState<WeddingStep[]>([]);

  // 拖拽排序
  const dragStateRef = useRef({
    isDragging: false,
    longPressTimer: null as ReturnType<typeof setTimeout> | null,
    dragIndex: -1,
    startY: 0,
    currentY: 0,
    itemHeight: 0,
    listTop: 0,
  });
  const [draggingIndex, setDraggingIndex] = useState<number>(-1);
  const [dragOffset, setDragOffset] = useState(0);
  const [targetIndex, setTargetIndex] = useState<number>(-1);
  const stepListRef = useRef<HTMLDivElement>(null);
  const stepItemRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  // 标题编辑
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft, setTitleDraft] = useState('');

  // 更多操作（底部面板）
  const [showMoreSheet, setShowMoreSheet] = useState(false);

  // 加入协作
  const [joinSheetOpen, setJoinSheetOpen] = useState(false);
  const [shareCode, setShareCode] = useState('');
  const [joinLoading, setJoinLoading] = useState(false);

  // 分享面板
  const [showShareSheet, setShowShareSheet] = useState(false);
  const [accessInfo, setAccessInfo] = useState<ProjectAccessInfo | null>(null);

  // 新人信息表单
  const [formData, setFormData] = useState<Partial<WeddingProject>>({});
  const [savingInfo, setSavingInfo] = useState(false);

  // 预设环节
  const [presetSteps, setPresetSteps] = useState<PresetStep[]>([]);
  const [presetLoading, setPresetLoading] = useState(false);

  // 预设环节面板（保留批量添加功能）
  const [showPresetPanel, setShowPresetPanel] = useState(false);
  const [selectedPresets, setSelectedPresets] = useState<Set<number>>(new Set());

  // 环节编辑弹窗
  const [showStepModal, setShowStepModal] = useState(false);
  const [editingStep, setEditingStep] = useState<WeddingStep | null>(null);
  const [stepForm, setStepForm] = useState({
    stepName: '',
    duration: 5,
    bgmSuggest: '',
    hostTip: '',
    category: '仪式类' as StepCategory,
  });
  const [stepSaving, setStepSaving] = useState(false);

  // 自定义环节输入
  const [customStepName, setCustomStepName] = useState('');
  const [customAdding, setCustomAdding] = useState(false);

  // 海报背景
  const [posterBackgroundUrl, setPosterBackgroundUrl] = useState(defaultPosterBg);
  const [showPosterBgSheet, setShowPosterBgSheet] = useState(false);
  const [posterBgUploading, setPosterBgUploading] = useState(false);

  // 主持人形象替换
  const [showHostImageSheet, setShowHostImageSheet] = useState(false);
  const [hostImageMode, setHostImageMode] = useState<'upload' | 'ai'>('upload');
  const [hostImageUploading, setHostImageUploading] = useState(false);
  const [hostImageGenerating, setHostImageGenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [originalBgUrl, setOriginalBgUrl] = useState(defaultPosterBg);
  const [hasCustomHostImage, setHasCustomHostImage] = useState(false);
  const hostPhotoInputRef = useRef<HTMLInputElement>(null);

  const bgUploadInputRef = useRef<HTMLInputElement>(null);
  const posterPhotoUploadRef = useRef<HTMLInputElement>(null);
  const [posterPhotoUploading, setPosterPhotoUploading] = useState(false);
  const [posterPhotoLoading, setPosterPhotoLoading] = useState(false);

  const PRESET_BACKGROUNDS = [
    { key: 'classic-red', name: '中式红金', url: '/spark/app/app_17g5xv7rp0y/runtime/api/v1/storage/object/bucket_aadk2i3qeriiu_static/static%2Faadk2jnv76gio_ve_miaoda' },
    { key: 'minimal-gold', name: '极简香槟', url: '/spark/app/app_17g5xv7rp0y/runtime/api/v1/storage/object/bucket_aadk2i3qeriiu_static/static%2Faadk2jnzrsqoy_ve_miaoda' },
    { key: 'forest-green', name: '森系复古', url: '/spark/app/app_17g5xv7rp0y/runtime/api/v1/storage/object/bucket_aadk2i3qeriiu_static/static%2Faadk2jodwvshg_ve_miaoda' },
    { key: 'starry-purple', name: '梦幻星空', url: '/spark/app/app_17g5xv7rp0y/runtime/api/v1/storage/object/bucket_aadk2i3qeriiu_static/static%2Faadk2jptvwmio_ve_miaoda' },
  ];

  const handleExportPng = async () => {
    if (!posterExportRef.current) return;
    showToast('正在生成海报...', 'info');
    try {
      const canvas = await html2canvas(posterExportRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: null,
      });
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      const groom = formData.groomName || '新郎';
      const bride = formData.brideName || '新娘';
      link.download = `${groom}&${bride}婚礼流程海报.png`;
      link.href = dataUrl;
      link.click();
      showToast('海报已保存', 'success');
    } catch {
      showToast('导出失败，请重试', 'error');
    }
  };

  // 海报形象照 & 主持人昵称
  const [posterPhotoUrl, setPosterPhotoUrl] = useState('');
  const [hostNickname, setHostNickname] = useState('婚礼主持人');
  const [posterPhotoRemaining, setPosterPhotoRemaining] = useState<number>(-1);
  const [posterPhotoLimit, setPosterPhotoLimit] = useState<number>(0);
  const [showPhotoEditor, setShowPhotoEditor] = useState(false);
  const [editorImageSrc, setEditorImageSrc] = useState('');
  const editorEditedImageRef = useRef<string>('');

  // 加载项目详情
  const loadProject = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const data = await getProjectDetail(id);
      setProject(data);
      setSteps(data.steps || []);
      setFormData(data);
      setTitleDraft(data.title);
      if (typeof data.posterPhotoUpdateCount === 'number' && typeof data.posterPhotoUpdateLimit === 'number') {
        const remaining = data.posterPhotoUpdateLimit > 0
          ? data.posterPhotoUpdateLimit - data.posterPhotoUpdateCount
          : -1;
        setPosterPhotoRemaining(remaining);
        setPosterPhotoLimit(data.posterPhotoUpdateLimit);
      }

    } catch (err) {
      showToast('加载项目失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [id, showToast]);

  // 加载预设环节
  const loadPresets = useCallback(async () => {
    if (presetSteps.length > 0) return;
    setPresetLoading(true);
    try {
      const data = await getPresetSteps();
      setPresetSteps(Array.isArray(data) ? data : data.items || []);
    } catch {
      showToast('加载预设失败', 'error');
    } finally {
      setPresetLoading(false);
    }
  }, [presetSteps.length, showToast]);

  // 加载项目权限信息
  const loadAccessInfo = useCallback(async () => {
    if (!id) return;
    try {
      const info = await getProjectAccessInfo(id);
      setAccessInfo(info);
    } catch {
      // 静默失败，不影响主流程
    }
  }, [id]);

  useEffect(() => {
    loadProject();
    loadPresets();
    loadAccessInfo();
  }, [loadProject, loadPresets, loadAccessInfo]);

  // 加载用户海报形象照 & 昵称
  useEffect(() => {
    const loadProfile = async () => {
      try {
        const profile = await getUserProfile();
        if (profile?.posterPhotoUrl) {
          setPosterPhotoUrl(profile.posterPhotoUrl);
        }
        if (profile?.nickname) {
          setHostNickname(profile.nickname);
        }
      } catch {
        // 静默失败，不影响主流程
      }
    };
    void loadProfile();
  }, []);

  // 校验图片文件
  const validateImageFile = (file: File): string | null => {
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      return '仅支持 JPG、PNG、WebP 格式';
    }
    if (file.size > MAX_IMAGE_SIZE_BYTES) {
      return '图片大小不能超过 5MB';
    }
    return null;
  };

  // 处理背景图选择并上传
  const handleBgFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const error = validateImageFile(file);
    if (error) {
      showToast(error, 'error');
      e.target.value = '';
      return;
    }
    setPosterBgUploading(true);
    try {
      const dataloom = await getDataloom();
      const { data, error: uploadErr } = await dataloom
        .storage
        .from(getDefaultBucketId())
        .uploadFile(file);
      if (uploadErr || !data) {
        const errMsg =
          (uploadErr as { message?: string; error_msg?: string })?.message ||
          (uploadErr as { message?: string; error_msg?: string })?.error_msg ||
          '上传失败';
        throw new Error(errMsg);
      }
      setPosterBackgroundUrl(data.download_url);
      setOriginalBgUrl(data.download_url);
      setHasCustomHostImage(false);
      showToast('背景已更换', 'success');
      setShowPosterBgSheet(false);
    } catch (err) {
      const msg =
        (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message ||
        (err as { message?: string })?.message ||
        '背景上传失败，请稍后重试';
      showToast(msg, 'error');
    } finally {
      setPosterBgUploading(false);
      e.target.value = '';
    }
  };

  // 选择预设背景
  const handlePresetBgSelect = (url: string) => {
    setPosterBackgroundUrl(url);
    setOriginalBgUrl(url);
    setHasCustomHostImage(false);
    setShowPosterBgSheet(false);
    showToast('背景已更换', 'success');
  };

  // 恢复默认背景
  const handleResetBg = () => {
    setPosterBackgroundUrl(defaultPosterBg);
    setOriginalBgUrl(defaultPosterBg);
    setHasCustomHostImage(false);
    setShowPosterBgSheet(false);
    showToast('已恢复默认背景', 'success');
  };

  // 主持人形象上传替换 - 直接作为透明背景人物放置
  const handleHostPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const error = validateImageFile(file);
    if (error) {
      showToast(error, 'error');
      e.target.value = '';
      return;
    }
    setHostImageUploading(true);
    try {
      const reader = new FileReader();
      const dataUrl: string = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = () => reject(new Error('读取图片失败'));
        reader.readAsDataURL(file);
      });
      const cutoutUrl = await runCloudCutout(dataUrl);
      const finalUrl = cutoutUrl || dataUrl;

      const dataloom = await getDataloom();
      const blob = await (await fetch(finalUrl)).blob();
      const uploadFile = new File([blob], `host-photo-${Date.now()}.png`, { type: 'image/png' });
      const { data, error: uploadErr } = await dataloom
        .storage
        .from(getDefaultBucketId())
        .uploadFile(uploadFile);
      if (uploadErr || !data) {
        const errMsg =
          (uploadErr as { message?: string; error_msg?: string })?.message ||
          (uploadErr as { message?: string; error_msg?: string })?.error_msg ||
          '上传失败';
        throw new Error(errMsg);
      }
      const uploadedUrl = data.download_url;
      const timestampedUrl = uploadedUrl + (uploadedUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`;

      setPosterPhotoUrl(timestampedUrl);
      setHasCustomHostImage(true);

      if (!isNewProject) {
        try {
          const result = await updatePosterPhoto(uploadedUrl, id);
          const savedUrl = result.posterPhotoUrl || uploadedUrl;
          setPosterPhotoUrl(savedUrl + (savedUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`);
          if (typeof result.remainingUpdates === 'number') {
            setPosterPhotoRemaining(result.remainingUpdates);
          }
          if (typeof result.totalLimit === 'number') {
            setPosterPhotoLimit(result.totalLimit);
          }
        } catch {
          // 保存失败不阻断展示
        }
      }

      showToast('形象已更新', 'success');
      setShowHostImageSheet(false);
    } catch (err) {
      logger.error('主持人形象上传替换失败', err);
      let msg = '形象替换失败，请稍后重试';
      if (err && typeof err === 'object') {
        const e = err as Record<string, unknown>;
        const resp = e.response as Record<string, unknown> | undefined;
        const respData = resp?.data as Record<string, unknown> | undefined;
        const respError = respData?.error as Record<string, unknown> | undefined;
        if (respError?.message && typeof respError.message === 'string') {
          msg = respError.message;
        } else if (e.message && typeof e.message === 'string' && e.message.length < 100) {
          msg = e.message;
        }
      }
      showToast(msg, 'error');
    } finally {
      setHostImageUploading(false);
      e.target.value = '';
    }
  };

  // AI生成主持人形象 - 直接作为透明背景人物放置
  const handleAIGenerateHost = async () => {
    if (!aiPrompt.trim()) {
      showToast('请描述一下你想要的形象', 'error');
      return;
    }
    setHostImageGenerating(true);
    try {
      const result = await capabilityClient
        .load('host_image_generation_1')
        .call<HostImageGenerationOneOutput>('textToImage', {
          host_description: aiPrompt.trim(),
        });
      if (result?.images?.[0]) {
        const generatedUrl = result.images[0];
        const cutoutUrl = await runCloudCutout(generatedUrl);
        const finalUrl = cutoutUrl || generatedUrl;

        const dataloom = await getDataloom();
        const blob = await (await fetch(finalUrl)).blob();
        const uploadFile = new File([blob], `host-photo-${Date.now()}.png`, { type: 'image/png' });
        const { data, error: uploadErr } = await dataloom
          .storage
          .from(getDefaultBucketId())
          .uploadFile(uploadFile);
        if (uploadErr || !data) {
          const errMsg =
            (uploadErr as { message?: string; error_msg?: string })?.message ||
            (uploadErr as { message?: string; error_msg?: string })?.error_msg ||
            '上传失败';
          throw new Error(errMsg);
        }
        const uploadedUrl = data.download_url;
        const timestampedUrl = uploadedUrl + (uploadedUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`;

        setPosterPhotoUrl(timestampedUrl);
        setHasCustomHostImage(true);

        if (!isNewProject) {
          try {
            const saveResult = await updatePosterPhoto(uploadedUrl, id);
            const savedUrl = saveResult.posterPhotoUrl || uploadedUrl;
            setPosterPhotoUrl(savedUrl + (savedUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`);
            if (typeof saveResult.remainingUpdates === 'number') {
              setPosterPhotoRemaining(saveResult.remainingUpdates);
            }
            if (typeof saveResult.totalLimit === 'number') {
              setPosterPhotoLimit(saveResult.totalLimit);
            }
          } catch {
            // 保存失败不阻断展示
          }
        }

        showToast('AI形象生成成功', 'success');
        setShowHostImageSheet(false);
      } else {
        throw new Error('生成结果为空');
      }
    } catch (err) {
      logger.error('AI生成主持人形象失败', err);
      const msg =
        (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message ||
        (err as { message?: string })?.message ||
        '生成失败，请稍后重试';
      showToast(msg, 'error');
    } finally {
      setHostImageGenerating(false);
    }
  };

  // 恢复默认主持人形象
  const handleResetHostImage = () => {
    setPosterPhotoUrl('');
    setHasCustomHostImage(false);
    showToast('已恢复默认形象', 'success');
  };

  // 处理主持人形象照上传选择 - 打开编辑器
  const handlePosterPhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const error = validateImageFile(file);
    if (error) {
      showToast(error, 'error');
      e.target.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setEditorImageSrc(result);
      editorEditedImageRef.current = '';
      setShowPhotoEditor(true);
    };
    reader.onerror = () => {
      showToast('读取图片失败', 'error');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleEditorReupload = (file: File) => {
    const error = validateImageFile(file);
    if (error) {
      showToast(error, 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setEditorImageSrc(result);
      editorEditedImageRef.current = '';
    };
    reader.onerror = () => {
      showToast('读取图片失败', 'error');
    };
    reader.readAsDataURL(file);
  };

  const dataUrlToFile = (dataUrl: string, filename: string): File => {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1] ?? 'image/png';
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  };

  const applyEditedPhotoAndSave = async (editedDataUrl: string) => {
    setShowPhotoEditor(false);

    try {
      const file = dataUrlToFile(editedDataUrl, `host-photo-${Date.now()}.png`);
      const dataloom = await getDataloom();
      const { data, error: uploadErr } = await dataloom
        .storage
        .from(getDefaultBucketId())
        .uploadFile(file);
      if (uploadErr || !data) {
        const errMsg =
          (uploadErr as { message?: string; error_msg?: string })?.message ||
          (uploadErr as { message?: string; error_msg?: string })?.error_msg ||
          '上传失败';
        throw new Error(errMsg);
      }
      const uploadedUrl = data.download_url;
      const finalUrl: string = uploadedUrl;
      const timestampedUrl = finalUrl + (finalUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`;

      setPosterPhotoUrl(timestampedUrl);

      if (isNewProject) {
        showToast('形象已更新', 'success');
      } else {
        try {
          const result = await updatePosterPhoto(finalUrl, id);
          const savedUrl = result.posterPhotoUrl || finalUrl;
          setPosterPhotoUrl(savedUrl + (savedUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`);
          if (typeof result.remainingUpdates === 'number') {
            setPosterPhotoRemaining(result.remainingUpdates);
          }
          if (typeof result.totalLimit === 'number') {
            setPosterPhotoLimit(result.totalLimit);
          }
          showToast('形象已更新', 'success');
        } catch (saveErr) {
          const saveMsg =
            (saveErr as { response?: { data?: { error?: { message?: string } }, status?: number } })?.response?.data?.error?.message ||
            (saveErr as { message?: string })?.message ||
            '保存失败';
          const status = (saveErr as { response?: { status?: number } })?.response?.status;
          if (status === 409 && saveMsg.includes('本方案已达到形象照更换次数上限')) {
            showToast(saveMsg, 'error');
            setShowPhotoEditor(true);
          } else {
            showToast(saveMsg, 'error');
          }
        }
      }
    } catch (err) {
      logger.error('主持人形象保存失败', err);
      let msg = '形象照保存失败，请稍后重试';
      if (err && typeof err === 'object') {
        const e = err as Record<string, unknown>;
        const resp = e.response as Record<string, unknown> | undefined;
        const respData = resp?.data as Record<string, unknown> | undefined;
        const respError = respData?.error as Record<string, unknown> | undefined;
        if (respError?.message && typeof respError.message === 'string') {
          msg = respError.message;
        } else if (e.message && typeof e.message === 'string') {
          if (e.message.includes("'json' on 'Response'") || e.message.includes('JSON input')) {
            msg = '图片上传服务暂时不可用，请稍后重试';
          } else if (e.message.length < 100) {
            msg = e.message;
          }
        } else if (e.error_msg && typeof e.error_msg === 'string') {
          msg = e.error_msg;
        }
      }
      showToast(msg, 'error');
    }
  };
  const compressImageToSize = (dataUrl: string, maxBytes: number): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas not supported'));
          return;
        }
        let quality = 0.9;
        let scale = 1;
        const tryCompress = () => {
          const w = Math.max(1, Math.round(img.naturalWidth * scale));
          const h = Math.max(1, Math.round(img.naturalHeight * scale));
          canvas.width = w;
          canvas.height = h;
          ctx.clearRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          const result = canvas.toDataURL('image/jpeg', quality);
          const match = result.match(/^data:image\/[^;]+;base64,(.+)$/);
          const size = match ? Math.round((match[1].length * 3) / 4) : result.length;
          if (size <= maxBytes || quality <= 0.2) {
            resolve(result);
            return;
          }
          if (quality > 0.3) {
            quality -= 0.2;
          } else {
            scale *= 0.8;
            if (scale < 0.2) {
              resolve(result);
              return;
            }
          }
          requestAnimationFrame(tryCompress);
        };
        tryCompress();
      };
      img.onerror = () => reject(new Error('图片加载失败'));
      img.src = dataUrl;
    });
  };

  const runCloudCutout = async (imageUrl: string): Promise<string> => {
    try {
      let sourceImage = imageUrl;
      if (!sourceImage.startsWith('data:image/')) {
        const resp = await fetch(imageUrl);
        const blob = await resp.blob();
        const reader = new FileReader();
        sourceImage = await new Promise((resolve, reject) => {
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = () => reject(new Error('读取图片失败'));
          reader.readAsDataURL(blob);
        });
      }

      const sizeMatch = sourceImage.match(/^data:image\/([a-zA-Z0-9.+-]+);base64,(.+)$/);
      const rawSizeBytes = sizeMatch
        ? Math.round((sizeMatch[2].length * 3) / 4)
        : sourceImage.length;
      let uploadImage = sourceImage;
      const MAX_BYTES = 1024 * 1024;
      if (rawSizeBytes > MAX_BYTES) {
        uploadImage = await compressImageToSize(sourceImage, MAX_BYTES);
      }

      const result = await removeBackground({
        imageDataUrl: uploadImage,
        scene: 'portrait',
        outputMode: 'transparent',
      });
      if (result.success && result.imageDataUrl) {
        return result.imageDataUrl;
      }
      throw new Error(result.message || '云端抠图失败');
    } catch (err) {
      logger.error('云端AI抠图失败', err);
      showToast('抠图失败，使用原图', 'warning');
      return imageUrl;
    }
  };

  const handleSaveTitle = async () => {
    if (!titleDraft.trim()) {
      showToast('标题不能为空', 'warning');
      return;
    }
    try {
      const result = await updateProject(id, { title: titleDraft.trim(), autoLinkSchedule: false });
      setProject((prev) => (prev ? { ...prev, title: result.project.title } : prev));
      setEditingTitle(false);
      showToast('标题已更新', 'success');
    } catch {
      showToast('保存失败', 'error');
    }
  };

  // 保存新人信息
  const handleSaveInfo = async () => {
    setSavingInfo(true);
    try {
      const result = await updateProject(id, formData);
      setProject((prev) => (prev ? { ...prev, ...result.project } : prev));
      if (result.linkAction === 'created') {
        showToast('已自动为您创建档期记录', 'success');
      } else if (result.linkAction === 'linked') {
        showToast('该日期已有档期，已自动关联', 'success');
      } else if (result.linkAction === 'conflict') {
        showToast('该日期已有其他方案档期，请注意撞单', 'warning');
      } else {
        showToast('保存成功', 'success');
      }
    } catch {
      showToast('保存失败', 'error');
    } finally {
      setSavingInfo(false);
    }
  };

  // 上移环节
  const handleMoveUp = async (index: number) => {
    if (index === 0) return;
    const step = steps[index];
    try {
      await reorderSteps(id, step.id, index - 1);
      const newSteps = [...steps];
      [newSteps[index - 1], newSteps[index]] = [newSteps[index], newSteps[index - 1]];
      setSteps(newSteps);
    } catch {
      showToast('移动失败', 'error');
    }
  };

  // 下移环节
  const handleMoveDown = async (index: number) => {
    if (index === steps.length - 1) return;
    const step = steps[index];
    try {
      await reorderSteps(id, step.id, index + 1);
      const newSteps = [...steps];
      [newSteps[index], newSteps[index + 1]] = [newSteps[index + 1], newSteps[index]];
      setSteps(newSteps);
    } catch {
      showToast('移动失败', 'error');
    }
  };

  // 长按拖拽开始
  const handleDragTouchStart = (index: number, e: React.TouchEvent) => {
    const ds = dragStateRef.current;
    ds.dragIndex = index;
    ds.startY = e.touches[0].clientY;
    ds.currentY = e.touches[0].clientY;

    // 计算列表顶部和每项高度
    if (stepListRef.current) {
      ds.listTop = stepListRef.current.getBoundingClientRect().top;
    }
    const el = stepItemRefs.current.get(steps[index].id);
    if (el) {
      ds.itemHeight = el.offsetHeight + 8; // 含 space-y-2 的间距
    }

    ds.longPressTimer = setTimeout(() => {
      ds.isDragging = true;
      setDraggingIndex(index);
      setTargetIndex(index);
      document.body.style.overflow = 'hidden';
      // 触觉反馈
      if (navigator.vibrate) navigator.vibrate(10);
    }, 500);
  };

  const handleDragTouchMove = (e: React.TouchEvent) => {
    const ds = dragStateRef.current;
    ds.currentY = e.touches[0].clientY;

    if (!ds.isDragging) return;
    e.preventDefault();

    const offset = ds.currentY - ds.startY;
    setDragOffset(offset);

    // 计算目标位置
    if (ds.itemHeight > 0) {
      const rawTarget = ds.dragIndex + Math.round(offset / ds.itemHeight);
      const clamped = Math.max(0, Math.min(steps.length - 1, rawTarget));
      setTargetIndex(clamped);
    }
  };

  const handleDragTouchEnd = async () => {
    const ds = dragStateRef.current;

    if (ds.longPressTimer) {
      clearTimeout(ds.longPressTimer);
      ds.longPressTimer = null;
    }

    if (!ds.isDragging) return;

    const fromIdx = ds.dragIndex;
    const toIdx = targetIndex;

    ds.isDragging = false;
    document.body.style.overflow = '';
    setDraggingIndex(-1);
    setDragOffset(0);
    setTargetIndex(-1);

    if (fromIdx === toIdx || toIdx < 0) return;

    const step = steps[fromIdx];
    // 先更新本地状态，保证视觉流畅
    const newSteps = [...steps];
    const [removed] = newSteps.splice(fromIdx, 1);
    newSteps.splice(toIdx, 0, removed);
    setSteps(newSteps);

    try {
      await reorderSteps(id, step.id, toIdx);
    } catch {
      // 失败回滚
      setSteps(steps);
      showToast('移动失败', 'error');
    }
  };

  const handleDragTouchCancel = () => {
    const ds = dragStateRef.current;
    if (ds.longPressTimer) {
      clearTimeout(ds.longPressTimer);
      ds.longPressTimer = null;
    }
    if (ds.isDragging) {
      ds.isDragging = false;
      document.body.style.overflow = '';
      setDraggingIndex(-1);
      setDragOffset(0);
      setTargetIndex(-1);
    }
  };

  // 删除环节
  const handleDeleteStep = async (stepId: string) => {
    try {
      await deleteStep(stepId);
      setSteps((prev) => prev.filter((s: WeddingStep) => s.id !== stepId));
      showToast('已删除', 'success');
    } catch {
      showToast('删除失败', 'error');
    }
  };

  // 判断预设是否已添加（按名称匹配）
  const isPresetAdded = (presetName: string): boolean => {
    return steps.some((s: WeddingStep) => s.stepName === presetName);
  };

  // 切换预设环节（色块点击）
  const togglePresetStep = async (preset: PresetStep) => {
    const existing = steps.find((s: WeddingStep) => s.stepName === preset.stepName);
    if (existing) {
      // 已存在 → 删除
      try {
        await deleteStep(existing.id);
        setSteps((prev) => prev.filter((s: WeddingStep) => s.id !== existing.id));
        showToast(`已移除「${preset.stepName}」`, 'success');
      } catch {
        showToast('移除失败', 'error');
      }
    } else {
      // 不存在 → 添加
      try {
        const newStep = await addStep(id, {
          stepName: preset.stepName,
          duration: preset.duration,
          bgmSuggest: preset.bgmSuggest,
          hostTip: preset.hostTip,
          isCustom: false,
        });
        setSteps((prev) => [...prev, newStep]);
        showToast(`已添加「${preset.stepName}」`, 'success');
      } catch {
        showToast('添加失败', 'error');
      }
    }
  };

  // 添加自定义环节（色块区）
  const handleAddCustomStepInline = async () => {
    if (!customStepName.trim()) {
      showToast('请输入环节名称', 'warning');
      return;
    }
    setCustomAdding(true);
    try {
      const newStep = await addStep(id, {
        stepName: customStepName.trim(),
        duration: 5,
        bgmSuggest: '',
        hostTip: '',
        isCustom: true,
      });
      setSteps((prev) => [...prev, newStep]);
      setCustomStepName('');
      showToast('已添加', 'success');
    } catch {
      showToast('添加失败', 'error');
    } finally {
      setCustomAdding(false);
    }
  };

  // 打开预设环节面板（批量添加）
  const openPresetPanel = async () => {
    setShowPresetPanel(true);
    setSelectedPresets(new Set());
    if (presetSteps.length === 0) {
      setPresetLoading(true);
      try {
        const data = await getPresetSteps();
        setPresetSteps(Array.isArray(data) ? data : data.items || []);
      } catch {
        showToast('加载预设失败', 'error');
      } finally {
        setPresetLoading(false);
      }
    }
  };

  // 切换预设选中（面板内）
  const togglePreset = (index: number) => {
    const next = new Set(selectedPresets);
    if (next.has(index)) {
      next.delete(index);
    } else {
      next.add(index);
    }
    setSelectedPresets(next);
  };

  // 确认添加预设环节（面板批量）
  const handleAddPresets = async () => {
    const selectedList = Array.from(selectedPresets)
      .sort((a: number, b: number) => a - b)
      .map((i: number) => presetSteps[i])
      .filter(Boolean);
    if (selectedList.length === 0) {
      showToast('请选择要添加的环节', 'warning');
      return;
    }
    try {
      for (const preset of selectedList) {
        await addStep(id, {
          stepName: preset.stepName,
          duration: preset.duration,
          bgmSuggest: preset.bgmSuggest,
          hostTip: preset.hostTip,
          isCustom: false,
        });
      }
      const data = await getProjectDetail(id);
      setSteps(data.steps || []);
      setShowPresetPanel(false);
      showToast(`已添加 ${selectedList.length} 个环节`, 'success');
    } catch {
      showToast('添加失败', 'error');
    }
  };

  // 打开新增自定义环节
  const openAddCustomStep = () => {
    setEditingStep(null);
    setStepForm({ stepName: '', duration: 5, bgmSuggest: '', hostTip: '', category: '仪式类' });
    setShowStepModal(true);
    setShowPresetPanel(false);
  };

  // 打开编辑环节
  const openEditStep = (step: WeddingStep) => {
    setEditingStep(step);
    const cat = getStepCategory(step);
    setStepForm({
      stepName: step.stepName,
      duration: step.duration,
      bgmSuggest: step.bgmSuggest,
      hostTip: step.hostTip,
      category: cat,
    });
    setShowStepModal(true);
  };

  // 保存环节
  const handleSaveStep = async () => {
    if (!stepForm.stepName.trim()) {
      showToast('请输入环节名称', 'warning');
      return;
    }
    setStepSaving(true);
    try {
      const payload = {
        stepName: stepForm.stepName.trim(),
        duration: stepForm.duration,
        bgmSuggest: stepForm.bgmSuggest,
        hostTip: stepForm.hostTip,
      };
      if (editingStep) {
        await updateStep(editingStep.id, payload);
        setSteps((prev) =>
          prev.map((s: WeddingStep) =>
            s.id === editingStep.id ? { ...s, ...payload } : s,
          ),
        );
        showToast('已更新', 'success');
      } else {
        const newStep = await addStep(id, { ...payload, isCustom: true });
        setSteps((prev) => [...prev, newStep]);
        showToast('已添加', 'success');
      }
      setShowStepModal(false);
    } catch {
      showToast('保存失败', 'error');
    } finally {
      setStepSaving(false);
    }
  };

  // 加入协作
  const handleJoin = async () => {
    const code = shareCode.trim().toUpperCase();
    if (!code) {
      showToast('请输入分享码', 'warning');
      return;
    }
    setJoinLoading(true);
    try {
      const result = await joinByShareCode(code);
      showToast('加入成功', 'success');
      setJoinSheetOpen(false);
      setShareCode('');
      navigate(`/wedding/${result.projectId}`);
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: { message?: string } } } };
      const msg = error.response?.data?.error?.message || '加入失败，请检查分享码';
      showToast(msg, 'error');
    } finally {
      setJoinLoading(false);
    }
  };

  // 复制项目
  const handleCopyProject = async () => {
    setShowMoreSheet(false);
    try {
      const data = await copyProject(id);
      showToast('已复制项目', 'success');
      navigate(`/wedding/${data.id || data.project?.id}`);
    } catch {
      showToast('复制失败', 'error');
    }
  };

  // 归档项目
  const handleArchiveProject = async () => {
    setShowMoreSheet(false);
    try {
      await archiveProject(id);
      showToast('已归档', 'success');
      navigate(-1);
    } catch {
      showToast('归档失败', 'error');
    }
  };

  // 复制流程文本
  const handleCopyFlowText = async () => {
    if (!project) return;
    const lines: string[] = [];
    lines.push('━━━━━━━━━━━━━━━━━━━━━━━');
    lines.push(`  ${project.groomName || '新郎'} & ${project.brideName || '新娘'} 婚礼流程`);
    lines.push('━━━━━━━━━━━━━━━━━━━━━━━');
    if (project.weddingDate) {
      const dateStr = project.weddingDate;
      const timeStr = project.timeType === 'lunch' ? '午宴' : '晚宴';
      lines.push(`📅 ${dateStr}  ${timeStr}`);
    }
    if (project.hotelName) lines.push(`🏛️ ${project.hotelName}`);
    lines.push('');
    lines.push(`⏱️  总时长：${totalDuration} 分钟  |  共 ${steps.length} 个环节`);
    lines.push('');
    lines.push('——— 婚礼流程 ———');
    steps.forEach((s: WeddingStep, i: number) => {
      lines.push(`${i + 1}. ${s.stepName}  （${s.duration}分钟）`);
      if (s.bgmSuggest) lines.push(`   🎵 BGM：${s.bgmSuggest}`);
      if (s.hostTip) lines.push(`   💡 备注：${s.hostTip}`);
    });
    lines.push('');
    lines.push('—— 婚序 · 婚礼主持助手 ——');
    const text = lines.join('\n');
    try {
      await navigator.clipboard.writeText(text);
      showToast('流程文本已复制', 'success');
    } catch {
      showToast('复制失败', 'error');
    }
  };

  // 复制音乐清单
  const handleCopyMusicList = async () => {
    if (!project) return;
    const bgmSteps = steps.filter((s: WeddingStep) => s.bgmSuggest && s.bgmSuggest.trim());
    if (bgmSteps.length === 0) {
      showToast('暂无BGM信息', 'warning');
      return;
    }
    const lines: string[] = [];
    lines.push('━━━━━━━━━━━━━━━━━━━━━━━');
    lines.push(`  ${project.groomName || '新郎'} & ${project.brideName || '新娘'} 婚礼音乐清单`);
    lines.push('━━━━━━━━━━━━━━━━━━━━━━━');
    lines.push('');
    bgmSteps.forEach((s: WeddingStep, i: number) => {
      lines.push(`${String(i + 1).padStart(2, '0')}. ${s.stepName}`);
      lines.push(`    🎵 ${s.bgmSuggest}`);
    });
    lines.push('');
    lines.push('—— 婚序 · 婚礼主持助手 ——');
    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      showToast('音乐清单已复制', 'success');
    } catch {
      showToast('复制失败', 'error');
    }
  };


  const totalDuration = useMemo(
    () => steps.reduce((sum: number, s: WeddingStep) => sum + (s.duration || 0), 0),
    [steps],
  );

  // 音乐清单数据
  const musicList = useMemo(
    () => steps.filter((s: WeddingStep) => s.bgmSuggest && s.bgmSuggest.trim()),
    [steps],
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-[480px] mx-auto px-5">
          <PageHeader title="加载中..." onBack={() => navigate(-1)} />
          <div className="flex items-center justify-center pt-32">
            <LoadingSpinner size="lg" />
          </div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-[480px] mx-auto px-5">
          <PageHeader title="项目不存在" onBack={() => navigate(-1)} />
          <EmptyState title="项目不存在或已删除" description="请返回列表重新选择" />
        </div>
      </div>
    );
  }

  const groupedPresets: Record<string, PresetStep[]> = {};
  for (const p of presetSteps) {
    const cat = p.category || 'other';
    if (!groupedPresets[cat]) groupedPresets[cat] = [];
    groupedPresets[cat].push(p);
  }

  const getPresetGlobalIndex = (category: string, idxInCat: number): number => {
    let globalIdx = 0;
    for (const cat of Object.keys(groupedPresets)) {
      if (cat === category) {
        return globalIdx + idxInCat;
      }
      globalIdx += groupedPresets[cat].length;
    }
    return -1;
  };

  // 区块标题装饰组件
  const SectionTitle = ({ title, subtitle }: { title: string; subtitle?: string }) => (
    <div className="flex items-center gap-3 mb-5">
      <div className="w-1 h-5 bg-primary rounded-full flex-shrink-0" />
      <h3 className="font-serif text-lg font-bold text-foreground tracking-tight">
        {title}
      </h3>
      {subtitle && (
        <span className="text-xs text-muted-foreground font-sans font-normal">
          {subtitle}
        </span>
      )}
      <div className="flex-1 h-px bg-gradient-to-r from-border/60 to-transparent" />
    </div>
  );

  return (
    <div className="min-h-screen pb-20" style={{ background: '#FBF6F0' }}>
      <div className="max-w-[480px] mx-auto relative">
        {/* ===== 大幅海报主视觉 ===== */}
        <div
          ref={posterExportRef}
          className="relative w-full overflow-hidden"
          style={{
            background:
              'linear-gradient(160deg, #1E060D 0%, #5C1525 40%, #8B1530 75%, #A02040 100%)',
            minHeight: '500px',
          }}
        >
          {/* 顶部金色装饰线 */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E8D5A3]/60 to-transparent" />

          {/* 右侧人物形象照 - 透明背景直接放置，柔和投影 */}
          <div
            className="absolute top-0 right-0 z-0 pointer-events-none"
            style={{
              left: '50%',
              right: 0,
              width: '50%',
              height: '100%',
              backgroundColor: 'transparent',
            }}
          >
            {posterPhotoUrl ? (
              <div
                className="relative h-full w-full flex justify-end items-start"
                style={{ backgroundColor: 'transparent' }}
              >
                <Image
                  src={posterPhotoUrl}
                  alt="页面人物形象"
                  className="w-full h-auto max-h-full relative z-10 !bg-transparent !bg-none"
                  style={{
                    objectFit: 'contain',
                    objectPosition: 'top right',
                    filter: 'drop-shadow(-4px 8px 12px rgba(0, 0, 0, 0.25))',
                  }}
                  crossOrigin="anonymous"
                />
              </div>
            ) : (
              <div
                className="w-full h-full flex flex-col items-center justify-start pt-16 gap-2"
                style={{
                  background: 'linear-gradient(180deg, rgba(232,213,163,0.06) 0%, rgba(232,213,163,0.02) 60%, transparent 100%)',
                  borderLeft: '1px solid rgba(232, 213, 163, 0.15)',
                }}
              >
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(180deg, rgba(232,213,163,0.2) 0%, rgba(232,213,163,0.05) 100%)',
                    border: '1px dashed rgba(232, 213, 163, 0.3)',
                  }}
                >
                  <User size={22} style={{ color: 'rgba(232, 213, 163, 0.4)' }} />
                </div>
                <span className="text-[11px] font-medium text-center" style={{ color: 'rgba(232, 213, 163, 0.5)' }}>
                  人物形象区
                </span>
                <span className="text-[9px] text-center" style={{ color: 'rgba(232, 213, 163, 0.35)' }}>
                  点击「···」上传
                </span>
              </div>
            )}

          </div>

          {/* 左上角返回按钮 */}
          <button
            onClick={() => navigate(-1)}
            className="absolute top-4 left-4 w-10 h-10 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/25 transition-colors z-20"
            aria-label="返回"
          >
            <ArrowLeft size={20} />
          </button>

          {/* 右上角更多按钮 */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMoreSheet(true);
            }}
            className="absolute top-3 right-3 w-11 h-11 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/25 transition-colors z-30 active:scale-95"
            style={{ minWidth: '44px', minHeight: '44px', touchAction: 'manipulation' }}
            aria-label="更多操作"
            type="button"
          >
            <MoreHorizontal size={22} strokeWidth={2.2} />
          </button>

          {/* 右上角分享按钮 */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowShareSheet(true);
            }}
            className="absolute top-3 right-16 w-11 h-11 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/25 transition-colors z-30 active:scale-95"
            aria-label="分享"
            type="button"
          >
            <Share2 size={20} />
          </button>

          {/* 海报内容：文字内容 + 下方全宽环节区（叠在形象层之上） */}
          <div className="relative z-10 w-full">
            {/* 顶部文字区 */}
            <div className="relative z-10 pt-16 px-5" style={{ width: '55%' }}>
              {/* 英文副标题 */}
              <div
                className="text-[10px] tracking-[0.25em] mb-2 font-serif"
                style={{ color: '#E8D5A3' }}
              >
                WEDDING CEREMONY
              </div>

              {/* 金色分隔装饰 */}
              <div className="flex items-center gap-2 mb-3 w-full">
                <div className="h-px w-6" style={{ background: 'linear-gradient(to right, transparent, #C9A961)' }} />
                <span style={{ color: '#E8D5A3', fontSize: '10px' }}>❖</span>
                <div className="h-px flex-1" style={{ background: 'linear-gradient(to left, transparent, #C9A961)' }} />
              </div>

              {/* 新人主标题 */}
              <div className="mb-2">
                <h2 className="font-serif text-xl font-bold tracking-tight whitespace-nowrap overflow-hidden text-ellipsis" style={{ color: '#FFFDF8' }}>
                  {formData.groomName || '新郎'} &amp; {formData.brideName || '新娘'}
                </h2>
                <p className="text-sm font-serif mt-0.5" style={{ color: '#E8D5A3' }}>
                  婚礼大典
                </p>
              </div>

              {/* 日期时间酒店 */}
              <div className="text-xs font-serif" style={{ color: '#E8D5A3' }}>
                {(() => {
                  const dateStr = formData.weddingDate || '选择日期';
                  const weekDay = formData.weddingDate
                    ? (() => {
                        const d = new Date(formData.weddingDate);
                        const days = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
                        return isNaN(d.getTime()) ? '' : days[d.getDay()];
                      })()
                    : '';
                  const timeStr = formData.timeType === 'lunch' ? '午宴' : '晚宴';
                  const hotel = formData.hotelName || '酒店名称';
                  return (
                    <>
                      <div className="whitespace-nowrap overflow-hidden text-ellipsis">{dateStr}{weekDay ? ` · ${weekDay}` : ''} · {timeStr}</div>
                      <div className="mt-0.5 whitespace-nowrap overflow-hidden text-ellipsis">{hotel}</div>
                    </>
                  );
                })()}
              </div>
            </div>

            {/* 环节区 - 全宽，高度自适应，与照片区上下衔接不重叠 */}
            <div className="relative z-10 px-5 pt-5 pb-6">
              <div
                className="w-full rounded-xl"
                style={{
                  border: '1px solid rgba(232, 213, 163, 0.3)',
                  background: 'rgba(255, 255, 255, 0.05)',
                  padding: '12px 14px',
                  backdropFilter: 'blur(2px)',
                }}
              >
                {steps.length === 0 ? (
                  <div className="text-center py-4 text-xs" style={{ color: 'rgba(232, 213, 163, 0.5)' }}>
                    暂无环节，请先添加
                  </div>
                ) : (
                  <div className="space-y-0">
                    {steps.map((step: WeddingStep, index: number) => (
                      <div key={step.id} className="flex items-center gap-2 py-1.5">
                        <div
                          className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold"
                          style={{
                            background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                            color: '#5C4520',
                          }}
                        >
                          {String(index + 1).padStart(2, '0')}
                        </div>
                        <div className="flex-1 min-w-0 text-xs font-medium truncate" style={{ color: 'rgba(255, 253, 248, 0.95)' }}>
                          {step.stepName}
                        </div>
                        <div
                          className="text-[10px] truncate flex-shrink-0 max-w-[80px]"
                          style={{ color: 'rgba(232, 213, 163, 0.75)' }}
                          title={step.bgmSuggest || ''}
                        >
                          {step.bgmSuggest || '—'}
                        </div>
                        <div
                          className="text-[10px] font-medium flex-shrink-0 text-right w-10"
                          style={{ color: '#E8D5A3' }}
                        >
                          {step.duration ? `${step.duration}min` : '—'}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ===== 白色内容区（圆角上翘） ===== */}
        <div className="bg-white rounded-t-3xl -mt-4 relative z-10 px-5 pt-6 pb-6">
          {/* 协作者身份横幅 */}
          {accessInfo?.role === 'collaborator' && (
            <div
              className="rounded-2xl px-4 py-3 flex items-center gap-3 shadow-md mb-6"
              style={{
                background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                color: '#5C4520',
              }}
            >
              <div className="w-9 h-9 rounded-full bg-white/30 flex items-center justify-center flex-shrink-0">
                <Users size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">
                  你正在以协作者身份参与此方案共创
                </p>
                <p className="text-xs opacity-70 mt-0.5">
                  创建者：主持人 {accessInfo.collaborators.find(c => c.role === 'owner')?.userId?.slice(-4) || '未知'}
                </p>
              </div>
            </div>
          )}

          {/* ===== 区块一：基础信息 ===== */}
          <div className="mb-8">
            <SectionTitle title="基础信息" />
            <div className="space-y-3">
              {/* 第一行：新郎、新娘、时段 */}
              <div className="grid grid-cols-3 gap-2.5">
                <Input
                  label="新郎"
                  value={formData.groomName || ''}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, groomName: e.target.value }))
                  }
                  placeholder="新郎"
                />
                <Input
                  label="新娘"
                  value={formData.brideName || ''}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, brideName: e.target.value }))
                  }
                  placeholder="新娘"
                />
                <div>
                  <label className="block text-xs font-medium text-foreground/80 mb-1.5">
                    时段
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {[
                      { value: 'lunch', label: '午宴' },
                      { value: 'dinner', label: '晚宴' },
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() =>
                          setFormData((prev) => ({
                            ...prev,
                            timeType: opt.value as 'lunch' | 'dinner',
                          }))
                        }
                        className={`h-10 rounded-lg border-2 transition-all duration-200 font-medium text-xs ${
                          formData.timeType === opt.value
                            ? 'border-primary bg-primary text-white'
                            : 'border-border bg-secondary/60 text-muted-foreground hover:border-primary/50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* 第二行：日期、酒店 */}
              <div className="grid grid-cols-3 gap-2.5">
                <div className="col-span-1">
                  <label className="block text-xs font-medium text-foreground/80 mb-1.5">
                    日期
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <button
                        type="button"
                        className="w-full h-12 px-3 rounded-xl flex items-center justify-between text-left transition-all border"
                        style={{
                          borderColor: '#E0D4C8',
                          background: '#FDF9F5',
                        }}
                      >
                        <span className="text-sm" style={{ color: formData.weddingDate ? '#1A1414' : '#A09090' }}>
                          {formData.weddingDate || '选择日期'}
                        </span>
                        <CalendarIcon size={14} style={{ color: '#A09090' }} />
                      </button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={formData.weddingDate ? new Date(formData.weddingDate) : undefined}
                        onSelect={(date: Date | undefined) => {
                          if (date) {
                            const y = date.getFullYear();
                            const m = String(date.getMonth() + 1).padStart(2, '0');
                            const d = String(date.getDate()).padStart(2, '0');
                            setFormData((prev) => ({ ...prev, weddingDate: `${y}-${m}-${d}` }));
                          }
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="col-span-2">
                  <Input
                    label="酒店"
                    value={formData.hotelName || ''}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, hotelName: e.target.value }))
                    }
                    placeholder="请输入酒店名称"
                    leftIcon={<Building2 size={14} />}
                  />
                </div>
              </div>

              <Button
                fullWidth
                size="sm"
                variant="secondary"
                onClick={handleSaveInfo}
                loading={savingInfo}
              >
                保存基础信息
              </Button>

              {project?.scheduleId && (
                <div
                  className="flex items-center justify-between px-4 py-3 rounded-xl mt-3"
                  style={{ background: 'linear-gradient(135deg, rgba(185, 28, 60, 0.06), rgba(201, 169, 97, 0.08))', border: '1px solid rgba(201, 169, 97, 0.25)' }}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #D4354F, #B91C3C)' }}>
                      <CalendarIcon size={14} style={{ color: '#FFFDF8' }} />
                    </div>
                    <div>
                      <p className="text-sm font-medium" style={{ color: '#B91C3C' }}>已登记档期</p>
                      <p className="text-xs" style={{ color: '#6B5C5C' }}>
                        {project.weddingDate || ''} · {project.timeType === 'lunch' ? '午宴' : '晚宴'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => navigate('/schedule')}
                    className="text-xs font-medium px-3 py-1.5 rounded-full transition-all"
                    style={{ color: '#C9A961', border: '1px solid #C9A961' }}
                  >
                    查看档期
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* ===== 区块二：仪式环节 ===== */}
          <div className="mb-8">
            <SectionTitle title="仪式环节" subtitle={`已选${steps.length}个`} />

            {presetLoading ? (
              <div className="flex items-center justify-center py-8">
                <LoadingSpinner size="sm" />
              </div>
            ) : (
              <div className="space-y-5">
                {PRESET_CATEGORIES.map((cat) => {
                  const catSteps = groupedPresets[cat.key] || [];
                  if (catSteps.length === 0) return null;
                  return (
                    <div key={cat.key}>
                      <h4 className="text-xs font-semibold text-muted-foreground mb-2.5 flex items-center gap-2">
                        <span className={`w-1 h-3 rounded-full ${CATEGORY_COLORS[cat.key as StepCategory].bar}`} />
                        {cat.name}
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {catSteps.map((preset) => {
                          const added = isPresetAdded(preset.stepName);
                          return (
                            <button
                              key={preset.stepName}
                              onClick={() => togglePresetStep(preset)}
                              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                                added
                                  ? 'bg-primary text-white shadow-sm'
                                  : 'bg-secondary/70 text-muted-foreground hover:bg-secondary'
                              }`}
                            >
                              {added && <Check size={12} className="flex-shrink-0" />}
                              {preset.stepName}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* 自定义添加 */}
            <div className="mt-4 flex gap-2">
              <input
                value={customStepName}
                onChange={(e) => setCustomStepName(e.target.value)}
                placeholder="自定义环节名称"
                className="flex-1 px-4 py-2.5 rounded-xl border border-input bg-secondary/60 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 focus:bg-card transition-all"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddCustomStepInline();
                }}
              />
              <Button
                size="sm"
                onClick={handleAddCustomStepInline}
                loading={customAdding}
              >
                <Plus size={16} />
                添加
              </Button>
            </div>

            {/* 从预设批量添加入口 */}
            <button
              onClick={openPresetPanel}
              className="mt-3 w-full flex items-center justify-center gap-2 py-2 text-xs text-muted-foreground hover:text-primary transition-colors"
            >
              <Sparkles size={14} />
              从预设批量添加
            </button>

            {/* 已选环节列表（可排序） */}
            {steps.length > 0 && (
              <div className="mt-5 pt-5 border-t border-border/40">
                <h4 className="text-xs font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-3 rounded-full bg-primary" />
                  已选环节排序
                  <span className="ml-auto flex items-center gap-1 font-normal">
                    <Clock size={10} />
                    共 {totalDuration} 分钟
                  </span>
                </h4>
                <div className="space-y-2" ref={stepListRef}>
                  {steps.map((step: WeddingStep, index: number) => {
                    const cat = getStepCategory(step);
                    const colors = CATEGORY_COLORS[cat];
                    const isDragging = draggingIndex === index;
                    const isAboveTarget = targetIndex === index && draggingIndex > targetIndex;
                    const isBelowTarget = targetIndex === index && draggingIndex < targetIndex;

                    return (
                      <div key={step.id} className="relative">
                        {/* 上方插入指示线 */}
                        {isAboveTarget && draggingIndex !== -1 && (
                          <div className="absolute -top-1.5 left-3 right-3 h-1 bg-primary rounded-full z-20 shadow-md shadow-primary/40" />
                        )}
                        <div
                          ref={(el) => {
                            if (el) stepItemRefs.current.set(step.id, el);
                            else stepItemRefs.current.delete(step.id);
                          }}
                          onTouchStart={(e) => handleDragTouchStart(index, e)}
                          onTouchMove={handleDragTouchMove}
                          onTouchEnd={handleDragTouchEnd}
                          onTouchCancel={handleDragTouchCancel}
                          className={`flex items-center gap-3 p-3 rounded-xl bg-card border border-border/50 shadow-sm select-none ${
                            isDragging
                              ? 'opacity-85 scale-[1.03] shadow-lg border-primary/40 z-10 relative ring-2 ring-primary/20'
                              : ''
                          }`}
                          style={isDragging ? { transform: `translateY(${dragOffset}px) scale(1.03)` } : undefined}
                        >
                        <div
                          className={`w-6 h-6 rounded-full ${colors.bg} ${colors.text} flex items-center justify-center text-[10px] font-bold flex-shrink-0`}
                        >
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h5 className="text-sm font-medium text-foreground truncate">
                            {step.stepName}
                          </h5>
                          <div className="flex items-center gap-2 mt-0.5 text-[10px] text-muted-foreground">
                            <span className="flex items-center gap-0.5">
                              <Clock size={10} />
                              {step.duration}分钟
                            </span>
                            {step.bgmSuggest && (
                              <span className="flex items-center gap-0.5 truncate">
                                <Music size={10} className="text-accent-gold flex-shrink-0" />
                                <span className="truncate">{step.bgmSuggest}</span>
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-0.5 flex-shrink-0">
                          <button
                            onClick={() => handleMoveUp(index)}
                            disabled={index === 0}
                            className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-primary disabled:opacity-30 disabled:hover:text-muted-foreground transition-all"
                            aria-label="上移"
                          >
                            <ChevronUp size={14} />
                          </button>
                          <button
                            onClick={() => handleMoveDown(index)}
                            disabled={index === steps.length - 1}
                            className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-primary disabled:opacity-30 disabled:hover:text-muted-foreground transition-all"
                            aria-label="下移"
                          >
                            <ChevronDown size={14} />
                          </button>
                          <button
                            onClick={() => openEditStep(step)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-primary transition-all"
                            aria-label="编辑"
                          >
                            <Edit3 size={14} />
                          </button>
                          <button
                            onClick={() => handleDeleteStep(step.id)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all"
                            aria-label="删除"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                       {/* 下方插入指示线 */}
                       {isBelowTarget && draggingIndex !== -1 && (
                         <div className="absolute -bottom-1.5 left-3 right-3 h-1 bg-primary rounded-full z-20 shadow-md shadow-primary/40" />
                       )}
                     </div>
                    );
                  })}
                </div>
              </div>
            )}

            {steps.length === 0 && (
              <div className="mt-4 p-5 rounded-2xl border border-dashed border-border bg-secondary/30">
                <EmptyState
                  icon={<FileText size={24} />}
                  title="暂无环节"
                  description="点击上方色块添加仪式环节"
                />
              </div>
            )}
          </div>

          {/* ===== 区块三：环节备注 ===== */}
          <div className="mb-8">
            <SectionTitle title="环节备注" />

            {steps.length === 0 ? (
              <div className="p-5 rounded-2xl border border-dashed border-border bg-secondary/30">
                <EmptyState
                  icon={<MessageSquare size={24} />}
                  title="暂无环节"
                  description="先添加环节再编辑备注"
                />
              </div>
            ) : (
              <div className="space-y-3">
                {steps.map((step: WeddingStep, index: number) => (
                  <div
                    key={step.id}
                    className="p-4 rounded-2xl border border-border/60 bg-card shadow-sm"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <span className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center text-[10px] font-bold">
                        {index + 1}
                      </span>
                      <h5 className="text-sm font-semibold text-foreground flex-1">
                        {step.stepName}
                      </h5>
                      <button
                        onClick={() => openEditStep(step)}
                        className="text-xs text-primary hover:underline flex items-center gap-1"
                      >
                        <Edit3 size={12} />
                        编辑
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1">
                          <Clock size={11} className="text-muted-foreground/60" />
                          时长：{step.duration} 分钟
                        </label>
                      </div>

                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1">
                          <Music size={11} className="text-accent-gold" />
                          BGM推荐
                        </label>
                        <p className="text-xs text-foreground/80 leading-relaxed">
                          {step.bgmSuggest || <span className="text-muted-foreground/50">暂未设置</span>}
                        </p>
                      </div>

                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1">
                          <Mic2 size={11} className="text-primary/60" />
                          主持人备注
                        </label>
                        <p className="text-xs text-foreground/80 leading-relaxed">
                          {step.hostTip || <span className="text-muted-foreground/50">暂未设置</span>}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ===== 音乐清单区块 ===== */}
          <div className="mb-8">
            <SectionTitle title="音乐清单" subtitle={`${musicList.length}首BGM`} />

            <div className="mb-4">
              <Button
                variant="gold"
                fullWidth
                size="sm"
                onClick={handleCopyMusicList}
                disabled={musicList.length === 0}
              >
                <Copy size={16} />
                一键复制音乐清单
              </Button>
            </div>

            {musicList.length === 0 ? (
              <div className="p-5 rounded-2xl border border-dashed border-border bg-secondary/30">
                <EmptyState
                  icon={<Music size={24} />}
                  title="暂无BGM信息"
                  description="添加环节时设置BGM，这里会自动汇总"
                />
              </div>
            ) : (
              <div className="rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
                {musicList.map((step: WeddingStep, idx: number) => (
                  <div
                    key={step.id}
                    className={`flex items-center gap-4 px-4 py-3 ${
                      idx !== musicList.length - 1 ? 'border-b border-border/40' : ''
                    }`}
                  >
                    <div className="w-7 h-7 rounded-full bg-accent-gold/15 flex items-center justify-center flex-shrink-0">
                      <span className="text-[10px] font-bold text-accent-gold-dark">
                        {idx + 1}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground truncate mb-0.5">
                        {step.stepName}
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Music size={11} className="text-accent-gold flex-shrink-0" />
                        <span className="truncate">{step.bgmSuggest}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ===== 区块四：温馨提示 ===== */}
          <div className="mb-8">
            <SectionTitle title="给新人的温馨提示" />
            <TextArea
              value={formData.specialNotes || ''}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, specialNotes: e.target.value }))
              }
              placeholder="请输入温馨提示内容..."
              rows={5}
            />
            <div className="mt-3">
              <Button
                fullWidth
                size="sm"
                variant="secondary"
                onClick={handleSaveInfo}
                loading={savingInfo}
              >
                保存温馨提示
              </Button>
            </div>
          </div>


        </div>
      </div>



      {/* 分享共创面板 */}
      <WeddingShareSheet
        open={showShareSheet}
        onClose={() => setShowShareSheet(false)}
        projectId={id}
        project={project}
      />

      {/* 更多操作底部面板 */}
      <BottomSheet
        open={showMoreSheet}
        onClose={() => setShowMoreSheet(false)}
        title="更多操作"
        height="auto"
      >
        <div className="px-5 py-4 space-y-2">
          <button
            onClick={() => {
              const input = posterPhotoUploadRef.current ||
                document.querySelector('input[type="file"][accept="image/*"]') as HTMLInputElement | null;
              if (input) {
                input.click();
              } else {
                logger.error('上传页面人物形象：找不到 file input');
              }
              setShowMoreSheet(false);
            }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-accent-gold/15 flex items-center justify-center text-accent-gold-dark">
              <ImagePlus size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">上传页面人物形象</div>
              <div className="text-xs text-muted-foreground">AI自动抠图修图，替换海报人物形象</div>
            </div>
          </button>

          <button
            onClick={() => {
              setShowMoreSheet(false);
              setJoinSheetOpen(true);
            }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <UserPlus size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">加入协作</div>
              <div className="text-xs text-muted-foreground">输入分享码加入方案共创</div>
            </div>
          </button>

          <button
            onClick={() => {
              setShowMoreSheet(false);
              setShowShareSheet(true);
            }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-info/10 flex items-center justify-center text-info">
              <Share2 size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">分享</div>
              <div className="text-xs text-muted-foreground">生成分享码邀请协作</div>
            </div>
          </button>

          <button
            onClick={handleCopyProject}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <Copy size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">复制项目</div>
              <div className="text-xs text-muted-foreground">创建一个副本</div>
            </div>
          </button>

          <button
            onClick={handleArchiveProject}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center text-muted-foreground">
              <FileText size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">归档项目</div>
              <div className="text-xs text-muted-foreground">移至归档列表</div>
            </div>
          </button>

          <button
            onClick={handleCopyFlowText}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-accent-gold/15 flex items-center justify-center text-accent-gold-dark">
              <Mic2 size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">复制流程文本</div>
              <div className="text-xs text-muted-foreground">精美格式一键复制</div>
            </div>
          </button>

          <button
            onClick={() => {
              setShowMoreSheet(false);
              openPresetPanel();
            }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-secondary transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-info/10 flex items-center justify-center text-info">
              <Sparkles size={18} />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium text-foreground">从预设批量添加</div>
              <div className="text-xs text-muted-foreground">快速添加多个环节</div>
            </div>
          </button>

          <div className="pt-2">
            <button
              onClick={() => setShowMoreSheet(false)}
              className="w-full h-12 rounded-full bg-secondary text-foreground font-medium hover:bg-muted transition-colors"
            >
              取消
            </button>
          </div>
        </div>
      </BottomSheet>

      {/* 加入协作面板 */}
      <BottomSheet
        open={joinSheetOpen}
        onClose={() => setJoinSheetOpen(false)}
        title="加入协作"
        height="auto"
      >
        <div className="px-5 py-5 space-y-5">
          <div className="text-center">
            <div
              className="w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
              }}
            >
              <UserPlus size={28} style={{ color: '#5C4520' }} />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">
              加入婚礼方案共创
            </h3>
            <p className="text-sm text-muted-foreground">
              输入搭档分享的8位分享码，即可参与方案协作
            </p>
          </div>

          <div>
            <Input
              label="分享码"
              value={shareCode}
              onChange={(e) => setShareCode(e.target.value.toUpperCase())}
              placeholder="请输入8位分享码"
              maxLength={8}
              className="text-center text-xl font-mono tracking-[0.3em]"
            />
          </div>

          <Button fullWidth onClick={handleJoin} loading={joinLoading}>
            <UserPlus size={18} />
            加入协作
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            加入后可查看和编辑婚礼方案流程
          </p>
        </div>
      </BottomSheet>

      {/* 预设环节选择面板（批量添加） */}
      <BottomSheet
        open={showPresetPanel}
        onClose={() => setShowPresetPanel(false)}
        title="从预设批量添加"
        height="large"
      >
        <div className="px-5 py-4">
          {presetLoading ? (
            <div className="flex items-center justify-center py-12">
              <LoadingSpinner size="lg" />
            </div>
          ) : presetSteps.length === 0 ? (
            <EmptyState
              icon={<Sparkles size={28} />}
              title="暂无预设环节"
              description="可手动添加自定义环节"
            />
          ) : (
            <div className="space-y-5 pb-4">
              {PRESET_CATEGORIES.map((cat) => {
                const catSteps = groupedPresets[cat.key] || [];
                if (catSteps.length === 0) return null;
                const colors = CATEGORY_COLORS[cat.key as StepCategory];
                return (
                  <div key={cat.key}>
                    <div className="flex items-center gap-2 mb-2.5">
                      <div className={`w-1 h-4 rounded-full ${colors.bar}`} />
                      <h4 className="text-sm font-semibold text-foreground">{cat.name}</h4>
                      <span className="text-xs text-muted-foreground">
                        ({catSteps.length})
                      </span>
                    </div>
                    <div className="space-y-2">
                      {catSteps.map((preset, idxInCat) => {
                        const globalIdx = getPresetGlobalIndex(cat.key, idxInCat);
                        const isSelected = selectedPresets.has(globalIdx);
                        return (
                          <div
                            key={`${cat.key}-${idxInCat}`}
                            onClick={() => togglePreset(globalIdx)}
                            className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                              isSelected
                                ? 'border-primary bg-primary/5 shadow-sm'
                                : 'border-border bg-card hover:border-primary/40 hover:bg-secondary/50'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${colors.badge}`}
                                  >
                                    {cat.name}
                                  </span>
                                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                    <Clock size={10} />
                                    {preset.duration}分钟
                                  </span>
                                </div>
                                <div className="font-medium text-sm text-foreground">
                                  {preset.stepName}
                                </div>
                                {preset.bgmSuggest && (
                                  <div className="flex items-center gap-1 mt-1.5 text-xs text-muted-foreground">
                                    <Music size={11} className="text-accent-gold" />
                                    <span className="truncate">{preset.bgmSuggest}</span>
                                  </div>
                                )}
                                {preset.hostTip && (
                                  <p className="mt-1 text-xs text-muted-foreground/80 line-clamp-1">
                                    💡 {preset.hostTip}
                                  </p>
                                )}
                              </div>
                              <div
                                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all ${
                                  isSelected
                                    ? 'border-primary bg-primary'
                                    : 'border-border'
                                }`}
                              >
                                {isSelected && (
                                  <Check size={13} className="text-primary-foreground" />
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* 底部按钮 */}
        <div className="px-5 pb-5 pt-3 border-t border-border/40 space-y-2.5">
          <Button
            fullWidth
            onClick={handleAddPresets}
            disabled={selectedPresets.size === 0}
          >
            确认添加 ({selectedPresets.size})
          </Button>
          <Button fullWidth variant="secondary" onClick={openAddCustomStep}>
            <Plus size={16} />
            新增自定义环节
          </Button>
        </div>
      </BottomSheet>

      {/* 环节编辑底部面板 */}
      <BottomSheet
        open={showStepModal}
        onClose={() => setShowStepModal(false)}
        title={editingStep ? '编辑环节' : '新增自定义环节'}
        height="large"
      >
        <div className="px-5 py-4 space-y-4">
          <div>
            <Input
              label="环节名称"
              value={stepForm.stepName}
              onChange={(e) =>
                setStepForm((prev) => ({ ...prev, stepName: e.target.value }))
              }
              placeholder="如：新人入场"
            />
          </div>

          <div>
            <Input
              label="时长（分钟）"
              type="number"
              value={stepForm.duration}
              onChange={(e) =>
                setStepForm((prev) => ({
                  ...prev,
                  duration: Number(e.target.value) || 0,
                }))
              }
              leftIcon={<Clock size={16} />}
              min={0}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              环节分类
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['暖场类', '仪式类', '互动类'] as StepCategory[]).map((cat) => {
                const colors = CATEGORY_COLORS[cat];
                const isActive = stepForm.category === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setStepForm((prev) => ({ ...prev, category: cat }))}
                    className={`py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? `${colors.bg} ${colors.text} ring-1 ring-current/30`
                        : 'bg-secondary/60 text-muted-foreground hover:bg-secondary'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <Input
              label="BGM 推荐"
              value={stepForm.bgmSuggest}
              onChange={(e) =>
                setStepForm((prev) => ({ ...prev, bgmSuggest: e.target.value }))
              }
              placeholder="选填，如：婚礼进行曲"
              leftIcon={<Music size={16} />}
            />
          </div>

          <div>
            <TextArea
              label="主持人备注"
              value={stepForm.hostTip}
              onChange={(e) =>
                setStepForm((prev) => ({ ...prev, hostTip: e.target.value }))
              }
              placeholder="选填，主持要点、注意事项等"
              rows={4}
            />
          </div>
        </div>

        <div className="px-5 pb-5 pt-3 border-t border-border/40">
          <Button fullWidth onClick={handleSaveStep} loading={stepSaving}>
            {editingStep ? '保存修改' : '添加环节'}
          </Button>
        </div>
       </BottomSheet>

      {/* 海报背景选择面板 */}
      <BottomSheet open={showPosterBgSheet} onClose={() => setShowPosterBgSheet(false)} title="海报背景">
        <div className="space-y-5 pb-2">
          <div>
            <div className="text-sm font-medium text-foreground mb-3">预设背景</div>
            <div className="grid grid-cols-4 gap-3">
              <button
                onClick={handleResetBg}
                className={`relative aspect-[3/4] rounded-xl overflow-hidden transition-all ${
                  posterBackgroundUrl === defaultPosterBg
                    ? 'ring-2 ring-primary ring-offset-2'
                    : 'opacity-80 hover:opacity-100'
                }`}
              >
                <Image src={defaultPosterBg} alt="默认背景" className="w-full h-full object-cover" />
                <span className="absolute bottom-0 inset-x-0 py-1 text-[10px] text-white text-center bg-black/40">
                  默认
                </span>
              </button>
              {PRESET_BACKGROUNDS.map((bg) => (
                <button
                  key={bg.key}
                  onClick={() => handlePresetBgSelect(bg.url)}
                  className={`relative aspect-[3/4] rounded-xl overflow-hidden transition-all ${
                    posterBackgroundUrl === bg.url
                      ? 'ring-2 ring-primary ring-offset-2'
                      : 'opacity-80 hover:opacity-100'
                  }`}
                >
                  <Image src={bg.url} alt={bg.name} className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 inset-x-0 py-1 text-[10px] text-white text-center bg-black/40">
                    {bg.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-sm font-medium text-foreground mb-3">自定义背景</div>
            <button
              onClick={() => bgUploadInputRef.current?.click()}
              disabled={posterBgUploading}
              className="w-full h-12 rounded-xl border border-dashed border-border flex items-center justify-center gap-2 text-sm text-muted-foreground active:bg-muted disabled:opacity-60"
            >
              {posterBgUploading ? (
                <>
                  <LoadingSpinner size="sm" />
                  上传中...
                </>
              ) : (
                <>
                  <Upload size={16} />
                  上传自定义背景图
                </>
              )}
            </button>
            <p className="text-xs text-muted-foreground mt-2">
              建议使用 3:4 竖版图片，支持 JPG / PNG / WebP，不超过 5MB
            </p>
          </div>

          <input
            ref={bgUploadInputRef}
            type="file"
            accept="image/*"
            onChange={handleBgFileSelect}
            className="hidden"
          />
          <input
            ref={hostPhotoInputRef}
            type="file"
            accept="image/*"
            onChange={handleHostPhotoUpload}
            className="hidden"
          />
        </div>
      </BottomSheet>

      <BottomSheet
        open={showHostImageSheet}
        onClose={() => setShowHostImageSheet(false)}
        title="人物形象"
        height="auto"
      >
        <div className="px-5 py-5 space-y-5">
          <div className="flex gap-2 p-1 bg-secondary rounded-xl">
            <button
              onClick={() => setHostImageMode('upload')}
              className={`flex-1 h-9 rounded-lg text-sm font-medium transition-all ${
                hostImageMode === 'upload'
                  ? 'bg-white text-foreground shadow-sm'
                  : 'text-muted-foreground'
              }`}
            >
              上传照片
            </button>
            <button
              onClick={() => setHostImageMode('ai')}
              className={`flex-1 h-9 rounded-lg text-sm font-medium transition-all ${
                hostImageMode === 'ai'
                  ? 'bg-white text-foreground shadow-sm'
                  : 'text-muted-foreground'
              }`}
            >
              AI 生成
            </button>
          </div>

          {hostImageMode === 'upload' ? (
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                 上传人物形象照，AI 自动抠图后放在海报右侧，打造专属海报。
              </div>
              {posterPhotoLimit > 0 && !isNewProject && (
                <div
                  className="text-xs px-3 py-2 rounded-xl flex items-center justify-between"
                  style={{
                    background: 'rgba(201, 169, 97, 0.08)',
                    color: '#A08040',
                  }}
                >
                  <span>本方案更新次数</span>
                  <span className="font-semibold">
                    {posterPhotoRemaining >= 0 ? posterPhotoRemaining : '—'} / {posterPhotoLimit}
                  </span>
                </div>
              )}
              <button
                onClick={() => hostPhotoInputRef.current?.click()}
                disabled={hostImageUploading}
                className="w-full h-32 rounded-2xl border-2 border-dashed border-accent-gold/40 flex flex-col items-center justify-center gap-2 text-accent-gold-dark active:bg-accent-gold/5 disabled:opacity-60 transition-all"
                style={{ background: 'linear-gradient(135deg, rgba(232,213,163,0.08) 0%, rgba(201,169,97,0.05) 100%)' }}
              >
                {hostImageUploading ? (
                  <>
                    <LoadingSpinner size="lg" />
                    <span className="text-sm font-medium">处理中，请稍候...</span>
                  </>
                ) : (
                  <>
                    <Camera size={28} />
                    <span className="text-sm font-medium">上传人物形象照</span>
                    <span className="text-xs opacity-60">JPG / PNG / WebP，不超过 5MB</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                用文字描述你想要的形象，AI 为你生成专属人物形象。
              </div>
              <TextArea
                value={aiPrompt}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setAiPrompt(e.target.value)}
                placeholder="例如：成熟稳重的男士主持人，35岁左右，穿深蓝色西装，气质儒雅大气，专业商业摄影风格..."
                rows={4}
              />
              <div className="flex flex-wrap gap-2">
                {['专业商务 西装革履', '儒雅绅士 成熟稳重', '时尚前卫 年轻活力', '优雅端庄 女主持人'].map((tag: string) => (
                  <button
                    key={tag}
                    onClick={() => setAiPrompt(tag)}
                    className="px-3 py-1.5 rounded-full text-xs bg-accent-gold/10 text-accent-gold-dark hover:bg-accent-gold/20 transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>
              <button
                onClick={handleAIGenerateHost}
                disabled={hostImageGenerating || !aiPrompt.trim()}
                className="w-full h-12 rounded-full font-medium text-white disabled:opacity-60 transition-all flex items-center justify-center gap-2"
                style={{
                  background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                  color: '#5C4520',
                  boxShadow: '0 4px 12px rgba(201, 169, 97, 0.3)',
                }}
              >
                {hostImageGenerating ? (
                  <>
                    <LoadingSpinner size="sm" />
                    AI生成中，请稍候...
                  </>
                ) : (
                  <>
                    <Sparkles size={18} />
                    AI 生成形象
                  </>
                )}
              </button>
            </div>
          )}

          {hasCustomHostImage && (
            <button
              onClick={handleResetHostImage}
              className="w-full h-12 rounded-full border border-border text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
            >
              <RotateCcw size={16} />
              恢复默认形象
            </button>
          )}
        </div>
      </BottomSheet>

      <PhotoEditor
        open={showPhotoEditor}
        onClose={() => setShowPhotoEditor(false)}
        imageSrc={editorImageSrc}
        onApply={applyEditedPhotoAndSave}
        onReupload={handleEditorReupload}
      />

      <input
        ref={posterPhotoUploadRef}
        type="file"
        accept="image/*"
        onChange={handlePosterPhotoSelect}
        className="hidden"
      />
    </div>
  );
};
export default WeddingEditorPage;
