import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  RotateCw,
  RotateCcw,
  Crop,
  SlidersHorizontal,
  Sparkles,
  Check,
  X,
  RefreshCw,
  ArrowLeft,
  Upload,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import { removeBackground as cloudRemoveBackground } from '@client/src/api/ai';
import { Slider } from '@client/src/components/ui/slider';
import { Image as UIImage } from '@client/src/components/ui/image';
import { useToast } from '@client/src/components/ToastProvider';

interface PhotoEditorProps {
  open: boolean;
  onClose: () => void;
  imageSrc: string;
  onApply: (editedImageDataUrl: string) => void;
  onReupload?: (file: File) => void;
}

interface Adjustments {
  brightness: number;
  contrast: number;
  rotation: number;
}

interface CropState {
  active: boolean;
  x: number;
  y: number;
  w: number;
  h: number;
}

type Step = 'crop' | 'adjust';

const PhotoEditor: React.FC<PhotoEditorProps> = ({
  open,
  onClose,
  imageSrc,
  onApply,
  onReupload,
}) => {
  const [step, setStep] = useState<Step>('crop');
  const [squareCrop, setSquareCrop] = useState<boolean>(true);
  const [originalImage, setOriginalImage] = useState<string>('');
  const [currentImage, setCurrentImage] = useState<string>('');
  const [adj, setAdj] = useState<Adjustments>({ brightness: 0, contrast: 0, rotation: 0 });
  const [crop, setCrop] = useState<CropState>({ active: false, x: 0, y: 0, w: 100, h: 100 });
  const [naturalSize, setNaturalSize] = useState({ w: 0, h: 0 });
  const [displayRect, setDisplayRect] = useState({ x: 0, y: 0, w: 0, h: 0 });
  const [dragging, setDragging] = useState<'move' | 'nw' | 'ne' | 'sw' | 'se' | null>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0, crop: { x: 0, y: 0, w: 0, h: 0 } });
  const [confirming, setConfirming] = useState(false);
  const [aiCutoutLoading, setAiCutoutLoading] = useState(false);
  const [aiCutoutProgressText, setAiCutoutProgressText] = useState('AI抠图中...');
  const { showToast } = useToast();

  const imgRef = useRef<HTMLImageElement>(null);
  const previewWrapRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setOriginalImage(imageSrc);
    setCurrentImage(imageSrc);
    setAdj({ brightness: 0, contrast: 0, rotation: 0 });
    setCrop({ active: false, x: 0, y: 0, w: 100, h: 100 });
    setSquareCrop(true);
    setNaturalSize({ w: 0, h: 0 });
    setDisplayRect({ x: 0, y: 0, w: 0, h: 0 });
    setStep('crop');
  }, [open, imageSrc]);

  const computeDisplayRect = useCallback(() => {
    const wrap = previewWrapRef.current;
    const img = imgRef.current;
    if (!wrap || !img || !naturalSize.w) return null;
    const wrapRect = wrap.getBoundingClientRect();
    const wrapW = wrapRect.width;
    const wrapH = wrapRect.height;
    if (!wrapW || !wrapH) return null;

    const imgRatio = naturalSize.w / naturalSize.h;
    const wrapRatio = wrapW / wrapH;

    let dispW: number;
    let dispH: number;
    if (imgRatio > wrapRatio) {
      dispW = wrapW;
      dispH = wrapW / imgRatio;
    } else {
      dispH = wrapH;
      dispW = wrapH * imgRatio;
    }
    const dispX = (wrapW - dispW) / 2;
    const dispY = (wrapH - dispH) / 2;
    return { x: dispX, y: dispY, w: dispW, h: dispH, wrapW, wrapH };
  }, [naturalSize]);

  const handleImgLoad = useCallback((e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    const nw = img.naturalWidth;
    const nh = img.naturalHeight;
    setNaturalSize({ w: nw, h: nh });
    if (!crop.active) {
      requestAnimationFrame(() => {
        const wrap = previewWrapRef.current;
        if (!wrap) return;
        const wrapRect = wrap.getBoundingClientRect();
        const wrapW = wrapRect.width;
        const wrapH = wrapRect.height;
        if (!wrapW || !wrapH) return;
        const imgRatio = nw / nh;
        const wrapRatio = wrapW / wrapH;
        let dispW: number;
        let dispH: number;
        if (imgRatio > wrapRatio) {
          dispW = wrapW;
          dispH = wrapW / imgRatio;
        } else {
          dispH = wrapH;
          dispW = wrapH * imgRatio;
        }
        const dispX = (wrapW - dispW) / 2;
        const dispY = (wrapH - dispH) / 2;
        setDisplayRect({ x: dispX, y: dispY, w: dispW, h: dispH });

        if (squareCrop) {
          const aspectRatio = wrapW / wrapH;
          const side = Math.min(dispW, dispH);
          const wPct = (side / wrapW) * 100;
          const hPct = wPct * aspectRatio;
          let cropX: number;
          let cropY: number;
          if (dispW >= dispH) {
            cropX = ((dispX + (dispW - side) / 2) / wrapW) * 100;
            cropY = (dispY / wrapH) * 100;
          } else {
            cropX = (dispX / wrapW) * 100;
            cropY = ((dispY + (dispH - side) / 2) / wrapH) * 100;
          }
          setDisplayRect({ x: dispX, y: dispY, w: dispW, h: dispH });
          setCrop({ active: true, x: cropX, y: cropY, w: wPct, h: hPct });
        } else {
          const cropX = (dispX / wrapW) * 100;
          const cropY = (dispY / wrapH) * 100;
          const cropW = (dispW / wrapW) * 100;
          const cropH = (dispH / wrapH) * 100;
          setCrop({ active: true, x: cropX, y: cropY, w: cropW, h: cropH });
        }
      });
    }
  }, [crop.active, squareCrop]);

  const applyCssFilter = `brightness(${100 + adj.brightness}%) contrast(${100 + adj.contrast}%)`;

  const clampCropToImage = useCallback((nc: CropState): CropState => {
    const wrap = previewWrapRef.current;
    if (!wrap || !displayRect.w) return nc;
    const wrapRect = wrap.getBoundingClientRect();
    const wrapW = wrapRect.width;
    const wrapH = wrapRect.height;
    if (!wrapW || !wrapH) return nc;

    const imgX = (displayRect.x / wrapW) * 100;
    const imgY = (displayRect.y / wrapH) * 100;
    const imgW = (displayRect.w / wrapW) * 100;
    const imgH = (displayRect.h / wrapH) * 100;

    let { x, y, w, h } = nc;
    w = Math.max(5, Math.min(imgW, w));
    h = Math.max(5, Math.min(imgH, h));
    x = Math.max(imgX, Math.min(imgX + imgW - w, x));
    y = Math.max(imgY, Math.min(imgY + imgH - h, y));
    return { ...nc, x, y, w, h };
  }, [displayRect]);

  const handlePointerDown = (
    e: React.PointerEvent<HTMLDivElement>,
    mode: 'move' | 'nw' | 'ne' | 'sw' | 'se',
  ) => {
    if (!crop.active || step !== 'crop') return;
    e.preventDefault();
    e.stopPropagation();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    setDragging(mode);
    setDragStart({ x: e.clientX, y: e.clientY, crop: { ...crop } });
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragging || !previewWrapRef.current) return;
    const rect = previewWrapRef.current.getBoundingClientRect();
    const dxPct = ((e.clientX - dragStart.x) / rect.width) * 100;
    const dyPct = ((e.clientY - dragStart.y) / rect.height) * 100;
    const aspectRatio = rect.width / rect.height;

    const s = dragStart.crop;
    let nx = s.x;
    let ny = s.y;
    let nw = s.w;
    let nh = s.h;

    if (dragging === 'move') {
      nx = s.x + dxPct;
      ny = s.y + dyPct;
    } else if (squareCrop) {
      const dxSign = dxPct >= 0 ? 1 : -1;
      const dySign = dyPct >= 0 ? 1 : -1;
      const dxAbs = Math.abs(dxPct);
      const dyAbsEquiv = Math.abs(dyPct) * aspectRatio;
      const deltaWPct = Math.max(dxAbs, dyAbsEquiv);
      const deltaHPct = deltaWPct * aspectRatio;
      if (dragging === 'se') {
        nw = s.w + deltaWPct * dxSign;
        nh = s.h + deltaHPct * dySign;
      } else if (dragging === 'sw') {
        nw = s.w - deltaWPct * dxSign;
        nx = s.x + (s.w - nw);
        nh = s.h + deltaHPct * dySign;
      } else if (dragging === 'ne') {
        nw = s.w + deltaWPct * dxSign;
        nh = s.h - deltaHPct * dySign;
        ny = s.y + (s.h - nh);
      } else if (dragging === 'nw') {
        nw = s.w - deltaWPct * dxSign;
        nx = s.x + (s.w - nw);
        nh = s.h - deltaHPct * dySign;
        ny = s.y + (s.h - nh);
      }
    } else {
      if (dragging === 'se') {
        nw = s.w + dxPct;
        nh = s.h + dyPct;
      } else if (dragging === 'sw') {
        nw = s.w - dxPct;
        nx = s.x + (s.w - nw);
        nh = s.h + dyPct;
      } else if (dragging === 'ne') {
        nw = s.w + dxPct;
        nh = s.h - dyPct;
        ny = s.y + (s.h - nh);
      } else if (dragging === 'nw') {
        nw = s.w - dxPct;
        nx = s.x + (s.w - nw);
        nh = s.h - dyPct;
        ny = s.y + (s.h - nh);
      }
    }

      const next = clampCropToImage({ active: true, x: nx, y: ny, w: nw, h: nh });
      setCrop(next);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragging) {
      (e.target as Element).releasePointerCapture?.(e.pointerId);
      setDragging(null);
    }
  };

  const generateCroppedImage = useCallback((): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const wrap = previewWrapRef.current;
          if (!wrap) {
            resolve(img.src);
            return;
          }
          const wrapRect = wrap.getBoundingClientRect();
          const wrapW = wrapRect.width;
          const wrapH = wrapRect.height;

          const imgRatio = img.naturalWidth / img.naturalHeight;
          const wrapRatio = wrapW / wrapH;
          let dispW: number;
          let dispH: number;
          if (imgRatio > wrapRatio) {
            dispW = wrapW;
            dispH = wrapW / imgRatio;
          } else {
            dispH = wrapH;
            dispW = wrapH * imgRatio;
          }
          const dispX = (wrapW - dispW) / 2;
          const dispY = (wrapH - dispH) / 2;

          const cropXpx = (crop.x / 100) * wrapW;
          const cropYpx = (crop.y / 100) * wrapH;
          const cropWpx = (crop.w / 100) * wrapW;
          const cropHpx = (crop.h / 100) * wrapH;

          const sx = ((cropXpx - dispX) / dispW) * img.naturalWidth;
          const sy = ((cropYpx - dispY) / dispH) * img.naturalHeight;
          const sw = (cropWpx / dispW) * img.naturalWidth;
          const sh = (cropHpx / dispH) * img.naturalHeight;

          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(sw));
          canvas.height = Math.max(1, Math.round(sh));
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Canvas not supported'));
            return;
          }
          ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/png'));
        } catch (err) {
          reject(err);
        }
      };
      img.onerror = () => reject(new Error('图片加载失败'));
      img.src = originalImage;
    });
  }, [originalImage, crop]);

  const generateAdjustedImage = useCallback((): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const rad = (adj.rotation * Math.PI) / 180;
          const cos = Math.abs(Math.cos(rad));
          const sin = Math.abs(Math.sin(rad));
          const sw = img.naturalWidth;
          const sh = img.naturalHeight;
          const cw = Math.round(sw * cos + sh * sin);
          const ch = Math.round(sw * sin + sh * cos);

          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, cw);
          canvas.height = Math.max(1, ch);
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Canvas not supported'));
            return;
          }

          ctx.filter = `brightness(${100 + adj.brightness}%) contrast(${100 + adj.contrast}%)`;
          ctx.save();
          ctx.translate(cw / 2, ch / 2);
          ctx.rotate(rad);
          ctx.drawImage(img, -sw / 2, -sh / 2);
          ctx.restore();

          resolve(canvas.toDataURL('image/png'));
        } catch (err) {
          reject(err);
        }
      };
      img.onerror = () => reject(new Error('图片加载失败'));
      img.src = currentImage;
    });
  }, [currentImage, adj]);

  const compressImageToSize = useCallback(
    (dataUrl: string, maxBytes: number): Promise<string> => {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
          try {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
              reject(new Error('Canvas not supported'));
              return;
            }
            let quality = 0.9;
            let scale = 1;
            const tryCompress = () => {
              const w = Math.max(1, Math.round(img.naturalWidth * scale));
              const h = Math.max(1, Math.round(img.naturalHeight * scale));
              canvas.width = w;
              canvas.height = h;
              ctx.clearRect(0, 0, w, h);
              ctx.drawImage(img, 0, 0, w, h);
              const result = canvas.toDataURL('image/jpeg', quality);
              const match = result.match(/^data:image\/[^;]+;base64,(.+)$/);
              const size = match ? Math.round((match[1].length * 3) / 4) : result.length;
              if (size <= maxBytes || quality <= 0.2) {
                resolve(result);
                return;
              }
              if (quality > 0.3) {
                quality -= 0.2;
              } else {
                scale *= 0.8;
                if (scale < 0.2) {
                  resolve(result);
                  return;
                }
              }
              requestAnimationFrame(tryCompress);
            };
            tryCompress();
          } catch (err) {
            reject(err);
          }
        };
        img.onerror = () => reject(new Error('图片加载失败'));
        img.src = dataUrl;
      });
    },
    [],
  );

  const handleConfirmCrop = async () => {
    if (!crop.active || step !== 'crop') return;
    try {
      setConfirming(true);
      const cropped = await generateCroppedImage();
      setCurrentImage(cropped);
      setAdj({ brightness: 0, contrast: 0, rotation: 0 });
      setStep('adjust');
    } catch (err) {
      logger.error('裁剪生成失败', err);
      setStep('adjust');
    } finally {
      setConfirming(false);
    }
  };

  const handleBackToCrop = () => {
    setCurrentImage(originalImage);
    setAdj({ brightness: 0, contrast: 0, rotation: 0 });
    setStep('crop');
  };

  const handleApply = async () => {
    try {
      const dataUrl = await generateAdjustedImage();
      onApply(dataUrl);
    } catch (err) {
      logger.error('图片编辑导出失败', err);
      onApply(currentImage);
    }
  };

  const applySquareCrop = useCallback(() => {
    const wrap = previewWrapRef.current;
    if (!wrap || !displayRect.w || !naturalSize.w) return;
    const wrapRect = wrap.getBoundingClientRect();
    const wrapW = wrapRect.width;
    const wrapH = wrapRect.height;
    const aspectRatio = wrapW / wrapH;

    const dispW = displayRect.w;
    const dispH = displayRect.h;
    const side = Math.min(dispW, dispH);

    const wPct = (side / wrapW) * 100;
    const hPct = wPct * aspectRatio;

    let cropX: number;
    let cropY: number;
    if (dispW >= dispH) {
      cropX = ((displayRect.x + (dispW - side) / 2) / wrapW) * 100;
      cropY = (displayRect.y / wrapH) * 100;
    } else {
      cropX = (displayRect.x / wrapW) * 100;
      cropY = ((displayRect.y + (dispH - side) / 2) / wrapH) * 100;
    }

    setCrop({ active: true, x: cropX, y: cropY, w: wPct, h: hPct });
  }, [displayRect, naturalSize]);

  const handleResetCrop = () => {
    const wrap = previewWrapRef.current;
    if (!wrap || !displayRect.w || !naturalSize.w) {
      setCrop({ active: true, x: 0, y: 0, w: 100, h: 100 });
      return;
    }
    if (squareCrop) {
      applySquareCrop();
      return;
    }
    const wrapRect = wrap.getBoundingClientRect();
    const wrapW = wrapRect.width;
    const wrapH = wrapRect.height;
    const cropX = (displayRect.x / wrapW) * 100;
    const cropY = (displayRect.y / wrapH) * 100;
    const cropW = (displayRect.w / wrapW) * 100;
    const cropH = (displayRect.h / wrapH) * 100;
    setCrop({ active: true, x: cropX, y: cropY, w: cropW, h: cropH });
  };

  const handleSquareCropToggle = (checked: boolean) => {
    setSquareCrop(checked);
    if (checked && crop.active) {
      applySquareCrop();
    }
  };

  const handleResetAdjust = () => {
    setAdj({ brightness: 0, contrast: 0, rotation: 0 });
  };

  const handleReuploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !onReupload) return;
    if (!file.type.startsWith('image/')) return;
    onReupload(file);
  };

  const handleAICutout = async () => {
    logger.info('[AI抠图调试] 点击AI智能抠图按钮');
    logger.info('[AI抠图调试] 当前状态 - 有图:', { arg0: !!currentImage, arg1: ', 步骤:', step: step, arg3: ', 亮度:', arg4: adj.brightness, arg5: ', 对比度:', arg6: adj.contrast, arg7: ', 旋转:', arg8: adj.rotation });

    if (!currentImage || aiCutoutLoading) return;
    setAiCutoutLoading(true);

    try {
      setAiCutoutProgressText('云端AI抠图处理中...');

      let sourceImage = currentImage;
      if (step === 'adjust' && (adj.brightness !== 0 || adj.contrast !== 0 || adj.rotation !== 0)) {
        logger.info('[AI抠图调试] 开始从Canvas导出图片...');
        try {
          sourceImage = await generateAdjustedImage();
          const match = sourceImage.match(/^data:image\/([a-zA-Z0-9.+-]+);base64,(.+)$/);
          const size = match ? Math.round((match[2].length * 3) / 4) : sourceImage.length;
          const type = match ? `image/${match[1]}` : 'unknown';
          logger.info('[AI抠图调试] 画布导出成功，文件大小：', { size: size, arg1: 'bytes，类型：', type: type });
        } catch (err) {
          logger.info('[AI抠图调试] 画布导出失败', String(err));
          logger.warn('生成调整后图片失败，使用原图', err);
        }
      } else {
        logger.info('[AI抠图调试] 无调整参数，直接使用当前图片');
      }

      logger.info('[AI抠图调试] 开始组装请求参数...');
      logger.info('[AI抠图调试] 参数：imageDataUrl长度=', { arg0: sourceImage.length, arg1: ', scene=portrait, outputMode=transparent' });

      const sizeMatch = sourceImage.match(/^data:image\/([a-zA-Z0-9.+-]+);base64,(.+)$/);
      const rawSizeBytes = sizeMatch
        ? Math.round((sizeMatch[2].length * 3) / 4)
        : sourceImage.length;
      let uploadImage = sourceImage;
      const MAX_CLOUD_BYTES = 1024 * 1024;
      if (rawSizeBytes > MAX_CLOUD_BYTES) {
        logger.info('[AI抠图调试] 图片过大（', {
          size: rawSizeBytes,
          arg1: ' bytes），开始压缩到 ',
          max: MAX_CLOUD_BYTES,
          arg2: ' bytes 以内',
        });
        try {
          uploadImage = await compressImageToSize(sourceImage, MAX_CLOUD_BYTES);
          const cm = uploadImage.match(/^data:image\/[^;]+;base64,(.+)$/);
          const cs = cm ? Math.round((cm[1].length * 3) / 4) : uploadImage.length;
          logger.info('[AI抠图调试] 压缩完成，压缩后大小：', {
            size: cs,
            arg1: ' bytes (',
            ratio: ((cs / rawSizeBytes) * 100).toFixed(1),
            arg2: '%)',
          });
        } catch (compressErr: any) {
          logger.warn('[AI抠图调试] 图片压缩失败，使用原图', compressErr?.message || compressErr);
        }
      }

      logger.info('[AI抠图调试] 开始发起请求，接口地址：/api/ai/remove-background，超时：30秒');

      const result = await cloudRemoveBackground({
        imageDataUrl: uploadImage,
        scene: 'portrait',
        outputMode: 'transparent',
      });

      logger.info('[AI抠图调试] 请求成功！响应：', String(JSON.stringify(result).slice(0, 300)));

      if (result.success && result.imageDataUrl) {
        logger.info('[AI抠图调试] 开始更新海报预览');
        setCurrentImage(result.imageDataUrl);
        setOriginalImage(result.imageDataUrl);
        setAdj({ brightness: 0, contrast: 0, rotation: 0 });
        showToast('AI抠图完成', 'success');
        logger.info('[AI抠图调试] 抠图完成！最终图片URL长度：', { arg0: result.imageDataUrl.length, arg1: '，已更新到海报' });
        return;
      }

      const failMsg = result.message || '云端服务不可用';
      logger.info('[AI抠图调试] 请求失败！success=false，错误信息：', String(failMsg));
      logger.info('[AI抠图调试] 抠图完成！最终结果：云端抠图失败');
      showToast(`抠图失败：${failMsg}`, 'error');
    } catch (err: any) {
      logger.info('[AI抠图调试] 请求失败！异常：', String(err?.message || err));
      logger.info('[AI抠图调试] 错误详情：', String(err));
      logger.error('AI抠图失败', err);
      showToast('抠图失败，请换一张照片重试', 'error');
    } finally {
      setAiCutoutLoading(false);
      setAiCutoutProgressText('AI抠图中...');
    }
  };

  const stepIndicator = (
    <div className="flex items-center justify-center gap-3">
      <div className="flex items-center gap-1.5">
        <div
          className="w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold"
          style={{
            background: step === 'crop'
              ? 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)'
              : 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
            color: step === 'crop' ? '#fff' : '#5C4520',
          }}
        >
          {step === 'adjust' ? <Check size={12} /> : '1'}
        </div>
        <span
          className="text-sm font-medium"
          style={{ color: step === 'crop' ? '#B91C3C' : '#C9A961' }}
        >
          裁剪
        </span>
      </div>
      <div
        className="w-6 h-px"
        style={{
          background: step === 'adjust' ? '#C9A961' : '#E5E0DC',
        }}
      />
      <div className="flex items-center gap-1.5">
        <div
          className="w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold"
          style={{
            background: step === 'adjust'
              ? 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)'
              : '#E5E0DC',
            color: step === 'adjust' ? '#fff' : '#A09090',
          }}
        >
          2
        </div>
        <span
          className="text-sm font-medium"
          style={{ color: step === 'adjust' ? '#B91C3C' : '#A09090' }}
        >
          调整
        </span>
      </div>
    </div>
  );

  const previewImageSrc = step === 'crop' ? originalImage : currentImage;

  return (
    <BottomSheet open={open} onClose={onClose} title="编辑形象照" height="auto">
      <div className="px-5 pt-3 pb-6 space-y-4">
        {stepIndicator}

        <div
          ref={previewWrapRef}
          className="relative w-full rounded-xl overflow-hidden select-none"
          style={{
            aspectRatio: '3 / 4',
            background:
              'linear-gradient(135deg, #2C0A14 0%, #5C1525 50%, #8B1530 100%)',
            touchAction: 'none',
          }}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
        >
          <div
            className="absolute inset-0 flex items-center justify-center"
            style={{
              transform: step === 'adjust' ? `rotate(${adj.rotation}deg)` : 'none',
              filter: step === 'adjust' ? applyCssFilter : 'none',
              transition: dragging ? 'none' : 'filter 0.15s ease-out',
            }}
          >
            <UIImage
              ref={imgRef}
              src={previewImageSrc}
              alt="预览"
              onLoad={handleImgLoad}
              className="max-w-full max-h-full object-contain"
              draggable={false}
              key={previewImageSrc}
            />
          </div>

          {step === 'crop' && crop.active && (
            <>
              <div
                className="absolute inset-0 pointer-events-none"
                style={{ background: 'rgba(0,0,0,0.45)' }}
              />
              <div
                className="absolute pointer-events-none"
                style={{
                  left: `${crop.x}%`,
                  top: `${crop.y}%`,
                  width: `${crop.w}%`,
                  height: `${crop.h}%`,
                  boxShadow: '0 0 0 9999px rgba(0,0,0,0) inset',
                  border: '2px solid #E8D5A3',
                  background: 'transparent',
                }}
              >
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute left-1/3 top-0 bottom-0 w-px bg-white/30" />
                  <div className="absolute left-2/3 top-0 bottom-0 w-px bg-white/30" />
                  <div className="absolute top-1/3 left-0 right-0 h-px bg-white/30" />
                  <div className="absolute top-2/3 left-0 right-0 h-px bg-white/30" />
                </div>
                <div
                  className="absolute -left-1.5 -top-1.5 w-4 h-4 border-2 border-[#E8D5A3] bg-white rounded-full cursor-nw-resize touch-none"
                  onPointerDown={(e) => handlePointerDown(e, 'nw')}
                  style={{ pointerEvents: 'auto' }}
                />
                <div
                  className="absolute -right-1.5 -top-1.5 w-4 h-4 border-2 border-[#E8D5A3] bg-white rounded-full cursor-ne-resize touch-none"
                  onPointerDown={(e) => handlePointerDown(e, 'ne')}
                  style={{ pointerEvents: 'auto' }}
                />
                <div
                  className="absolute -left-1.5 -bottom-1.5 w-4 h-4 border-2 border-[#E8D5A3] bg-white rounded-full cursor-sw-resize touch-none"
                  onPointerDown={(e) => handlePointerDown(e, 'sw')}
                  style={{ pointerEvents: 'auto' }}
                />
                <div
                  className="absolute -right-1.5 -bottom-1.5 w-4 h-4 border-2 border-[#E8D5A3] bg-white rounded-full cursor-se-resize touch-none"
                  onPointerDown={(e) => handlePointerDown(e, 'se')}
                  style={{ pointerEvents: 'auto' }}
                />
                <div
                  className="absolute inset-2 cursor-move"
                  onPointerDown={(e) => handlePointerDown(e, 'move')}
                  style={{ pointerEvents: 'auto' }}
                />
              </div>
            </>
          )}

          {(aiCutoutLoading || (confirming && step === 'crop')) && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/40 z-10 rounded-xl">
              <div className="w-8 h-8 border-2 border-[#E8D5A3]/30 border-t-[#E8D5A3] rounded-full animate-spin" />
              <span className="text-sm font-medium text-[#E8D5A3]">
                {aiCutoutLoading ? aiCutoutProgressText : '裁剪处理中...'}
              </span>
            </div>
          )}
        </div>

        {step === 'crop' && (
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <Crop size={16} className="flex-shrink-0 mt-0.5" style={{ color: '#B91C3C' }} />
              <div>
                <p className="text-sm font-medium text-foreground">第一步 · 裁剪构图</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  拖动四角手柄调整裁剪区域，拖动中间移动位置。
                </p>
              </div>
            </div>
            <label className="flex items-center gap-3 px-3 py-3 rounded-xl bg-secondary cursor-pointer select-none">
              <input
                type="checkbox"
                checked={squareCrop}
                onChange={(e) => handleSquareCropToggle(e.target.checked)}
                className="w-4 h-4 rounded accent-[#B91C3C] cursor-pointer"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-foreground">正方形裁剪</div>
                <div className="text-xs text-muted-foreground">裁剪框锁定 1:1 比例</div>
              </div>
            </label>
            <div className="flex gap-2">
              <button
                onClick={handleResetCrop}
                className="flex-1 h-11 rounded-xl bg-secondary text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
              >
                <RefreshCw size={16} />
                重置
              </button>
              {onReupload && (
                <button
                  onClick={handleReuploadClick}
                  className="flex-1 h-11 rounded-xl bg-secondary text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
                >
                  <Upload size={16} />
                  重新上传
                </button>
              )}
            </div>
          </div>
        )}

        {step === 'adjust' && (
          <div className="space-y-4 pt-1">
            <div className="flex items-start gap-2">
              <SlidersHorizontal size={16} className="flex-shrink-0 mt-0.5" style={{ color: '#B91C3C' }} />
              <div>
                <p className="text-sm font-medium text-foreground">第二步 · 微调与AI抠图</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  调整亮度、对比度、旋转角度，或使用AI智能抠图去除背景。
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">亮度</span>
                <span className="text-xs text-muted-foreground">{adj.brightness > 0 ? '+' : ''}{adj.brightness}%</span>
              </div>
              <Slider
                value={[adj.brightness]}
                min={-50}
                max={50}
                step={1}
                onValueChange={([v]) => setAdj((p) => ({ ...p, brightness: v }))}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">对比度</span>
                <span className="text-xs text-muted-foreground">{adj.contrast > 0 ? '+' : ''}{adj.contrast}%</span>
              </div>
              <Slider
                value={[adj.contrast]}
                min={-50}
                max={50}
                step={1}
                onValueChange={([v]) => setAdj((p) => ({ ...p, contrast: v }))}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">旋转</span>
                <span className="text-xs text-muted-foreground">{adj.rotation}°</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setAdj((p) => ({ ...p, rotation: Math.max(-180, p.rotation - 90) }))}
                  className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-foreground hover:bg-muted transition-colors flex-shrink-0"
                  aria-label="向左旋转"
                >
                  <RotateCcw size={18} />
                </button>
                <Slider
                  value={[adj.rotation]}
                  min={-180}
                  max={180}
                  step={1}
                  onValueChange={([v]) => setAdj((p) => ({ ...p, rotation: v }))}
                  className="flex-1"
                />
                <button
                  onClick={() => setAdj((p) => ({ ...p, rotation: Math.min(180, p.rotation + 90) }))}
                  className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-foreground hover:bg-muted transition-colors flex-shrink-0"
                  aria-label="向右旋转"
                >
                  <RotateCw size={18} />
                </button>
              </div>
            </div>


            <button
              onClick={handleAICutout}
              disabled={aiCutoutLoading}
              className="w-full h-12 rounded-full font-medium flex items-center justify-center gap-2 disabled:opacity-60 transition-all active:scale-[0.98]"
              style={{
                background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                color: '#5C4520',
                boxShadow: '0 2px 8px rgba(201, 169, 97, 0.4)',
              }}
            >
              <Sparkles size={18} />
              {aiCutoutLoading ? 'AI抠图处理中...' : 'AI智能抠图'}
            </button>

            <div className="flex gap-2">
              <button
                onClick={handleResetAdjust}
                className="flex-1 h-11 rounded-xl bg-secondary text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
              >
                <RefreshCw size={16} />
                重置调整
              </button>
              {onReupload && (
                <button
                  onClick={handleReuploadClick}
                  className="flex-1 h-11 rounded-xl bg-secondary text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
                >
                  <Upload size={16} />
                  重新上传
                </button>
              )}
            </div>
          </div>
        )}

        <div className="flex gap-3 pt-2">
          {step === 'crop' ? (
            <>
              <button
                onClick={onClose}
                className="flex-1 h-12 rounded-full bg-secondary text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
              >
                <X size={18} />
                取消
              </button>
              <button
                onClick={handleConfirmCrop}
                disabled={confirming}
                className="flex-[1.5] h-12 rounded-full text-white font-medium flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-60"
                style={{
                  background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                  boxShadow: '0 4px 12px rgba(185, 28, 60, 0.30)',
                }}
              >
                <Check size={18} />
                确认裁剪
              </button>
            </>
          ) : (
            <>
              <button
                onClick={handleBackToCrop}
                className="flex-1 h-12 rounded-full bg-secondary text-foreground font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2"
              >
                <ArrowLeft size={18} />
                重选裁剪
              </button>
              <button
                onClick={handleApply}
                className="flex-[1.5] h-12 rounded-full text-white font-medium flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                style={{
                  background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                  boxShadow: '0 4px 12px rgba(185, 28, 60, 0.30)',
                }}
              >
                <Check size={18} />
                应用到海报
              </button>
            </>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
    </BottomSheet>
  );
};

export default PhotoEditor;
