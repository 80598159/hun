import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  CreditCard,
  Smartphone,
  Sparkles,
  Image as ImageIcon,
  Check,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { createOrder, payOrder } from '@client/src/api/shop';
import Button from '@client/src/components/app-ui/Button';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import type {
  ShopProduct,
  CreateOrderRequest,
} from '@shared/api.interface';

type ProductDisplayType = 'ai_flow' | 'ai_script' | 'poster';

interface Product {
  id: string;
  name: string;
  price: number;
  flowQuota: number;
  scriptQuota: number;
  type: ProductDisplayType;
  description: string;
  posterTemplate: string | null;
}

function mapProductType(type: string): ProductDisplayType {
  if (type === 'ai_package') {
    // 后台的 ai_package 统一当作 AI 充值包；按 flowQuota/scriptQuota 区分具体子类
    return 'ai_flow';
  }
  if (type === 'poster_template') {
    return 'poster';
  }
  return 'ai_flow';
}

function toProduct(p: ShopProduct): Product {
  const displayType = mapProductType(p.type);
  return {
    id: p.id,
    name: p.name,
    price: Number(p.price),
    flowQuota: p.flowQuota ?? 0,
    scriptQuota: p.scriptQuota ?? 0,
    type: displayType,
    description: p.description || '',
    posterTemplate: p.posterTemplate,
  };
}

const ShopPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [paying, setPaying] = useState(false);
  const [payMethod, setPayMethod] = useState<'wechat' | 'alipay'>('wechat');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [aiProducts, setAiProducts] = useState<Product[]>([]);
  const [posterProducts, setPosterProducts] = useState<Product[]>([]);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const { items } = await import('@client/src/api/shop').then(
          (m) => m.getProducts(),
        );
        if (cancelled) return;
        const all = items.map(toProduct);
        setAiProducts(all.filter((p) => p.type !== 'poster'));
        setPosterProducts(all.filter((p) => p.type === 'poster'));
      } catch (err) {
        if (cancelled) return;
        logger.error('加载商品失败', err);
        setError('商品加载失败，请稍后重试');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleBuy = (product: Product) => {
    setSelectedProduct(product);
    setPayMethod('wechat');
  };

  const handleCloseSheet = () => {
    if (paying) return;
    setSelectedProduct(null);
  };

  const handlePay = async () => {
    if (!selectedProduct) return;
    setPaying(true);
    try {
      const orderData: CreateOrderRequest = {
        productType: selectedProduct.type,
        productName: selectedProduct.name,
        amount: selectedProduct.price,
        flowQuota: selectedProduct.flowQuota,
        scriptQuota: selectedProduct.scriptQuota,
      };
      const order = await createOrder(orderData);
      await payOrder(order.id);
      showToast('支付成功！', 'success');
      setSelectedProduct(null);
      setTimeout(() => {
        navigate(-1);
      }, 800);
    } catch (err) {
      logger.error('支付失败', err);
      const msg =
        (err as { response?: { data?: { error?: { message?: string } } } })
          .response?.data?.error?.message || '支付失败，请稍后重试';
      showToast(msg, 'error');
    } finally {
      setPaying(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5">
        <p className="text-foreground font-medium mb-2">加载失败</p>
        <p className="text-sm text-muted-foreground mb-4 text-center">{error}</p>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => window.location.reload()}
        >
          重新加载
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      {/* 顶部标题 */}
      <div className="pt-10 pb-6">
        <h1 className="text-2xl font-serif font-bold text-foreground tracking-tight">
          增值商店
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          解锁更多 AI 能力与高级模板
        </p>
      </div>

      {/* AI 次数充值包 */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Sparkles size={18} className="text-primary" />
            <h2 className="text-lg font-semibold text-foreground">AI 次数充值包</h2>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mb-4">永久有效，可叠加使用</p>

        {aiProducts.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground text-sm">
            暂无可购买的 AI 充值包
          </div>
        ) : (
          <div className="space-y-3">
            {aiProducts.map((product) => (
              <div
                key={product.id}
                className="relative bg-card rounded-2xl shadow-md p-5 flex items-center justify-between"
              >
                <div className="flex-1 pr-3">
                  <h3 className="text-lg font-semibold text-foreground">
                    {product.name}
                  </h3>
                  {product.description && (
                    <p className="text-sm text-muted-foreground mt-1">
                      {product.description}
                    </p>
                  )}
                  <p className="text-2xl font-bold text-primary mt-2">
                    ¥{product.price.toFixed(1)}
                  </p>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleBuy(product)}
                  className="flex-shrink-0"
                >
                  立即购买
                </Button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 高级海报模板 */}
      <section className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <ImageIcon size={18} className="text-primary" />
          <h2 className="text-lg font-semibold text-foreground">高级海报模板</h2>
        </div>

        {posterProducts.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground text-sm">
            暂无可购买的海报模板
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {posterProducts.map((product) => (
              <div
                key={product.id}
                className="bg-card rounded-2xl shadow-md overflow-hidden"
              >
                <div
                  className="aspect-[3/4] relative flex items-center justify-center overflow-hidden"
                  style={{
                    background:
                      product.posterTemplate === 'minimal'
                        ? 'linear-gradient(180deg, #1A1414 0%, #2C2020 60%, #3D2A2A 100%)'
                        : product.posterTemplate === 'cinema'
                          ? 'linear-gradient(180deg, #0A0A0A 0%, #1A1A2E 50%, #16213E 100%)'
                          : 'linear-gradient(135deg, #8B1530 0%, #B91C3C 50%, #D4354F 100%)',
                  }}
                >
                  {product.posterTemplate === 'minimal' ? (
                    <div className="text-center">
                      <p
                        className="font-serif text-2xl font-bold tracking-[0.3em] mb-2"
                        style={{ color: '#E8D5A3' }}
                      >
                        WEDDING
                      </p>
                      <div
                        className="w-12 h-px mx-auto mb-2"
                        style={{ background: '#C9A961' }}
                      />
                      <p className="text-xs tracking-widest text-white/60">
                        极简电影风
                      </p>
                    </div>
                  ) : product.posterTemplate === 'cinema' ? (
                    <div className="text-center w-full px-4">
                      <div className="w-full h-px bg-white/30 mb-2" />
                      <p
                        className="font-serif text-base italic"
                        style={{ color: '#C9A961' }}
                      >
                        A Love Story
                      </p>
                      <p className="text-2xl font-bold text-white mt-1 tracking-wide">
                        婚礼电影
                      </p>
                      <div className="w-full h-px bg-white/30 mt-2 mb-2" />
                      <p className="text-[10px] tracking-[0.3em] text-white/40">
                        CINEMATIC WEDDING
                      </p>
                    </div>
                  ) : (
                    <>
                      <div
                        className="absolute inset-0 flex items-center justify-center opacity-20"
                        style={{
                          fontFamily: 'serif',
                          fontSize: '120px',
                          color: '#E8D5A3',
                          fontWeight: 'bold',
                        }}
                      >
                        囍
                      </div>
                      <div
                        className="relative z-10 text-center"
                        style={{ color: '#FFFDF8' }}
                      >
                        <p className="font-serif text-lg font-bold tracking-wider">
                          中式古典
                        </p>
                        <p className="text-xs opacity-70 mt-1">传统典雅</p>
                      </div>
                      <div
                        className="absolute inset-3 border rounded-lg opacity-30"
                        style={{ borderColor: '#E8D5A3' }}
                      />
                    </>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="text-base font-semibold text-foreground truncate">
                    {product.name}
                  </h3>
                  {product.description && (
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">
                      {product.description}
                    </p>
                  )}
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-primary font-bold">
                      ¥{product.price.toFixed(1)}
                    </span>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => handleBuy(product)}
                      className="!h-8 !px-4 !text-xs"
                    >
                      购买
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 支付确认 BottomSheet */}
      <BottomSheet
        open={selectedProduct !== null}
        onClose={handleCloseSheet}
        title="确认订单"
        height="auto"
      >
        <div className="px-5 pt-2 pb-6">
          {/* 商品信息 */}
          <div className="py-4 border-b border-border/60">
            <div className="flex items-center justify-between">
              <div className="flex-1 pr-4">
                <p className="text-base font-medium text-foreground">
                  {selectedProduct?.name}
                </p>
                {selectedProduct?.description && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {selectedProduct.description}
                  </p>
                )}
              </div>
              <p className="text-xl font-bold text-primary">
                ¥{selectedProduct?.price.toFixed(1)}
              </p>
            </div>
          </div>

          {/* 支付方式 */}
          <div className="py-4">
            <p className="text-sm font-medium text-foreground mb-3">选择支付方式</p>
            <div className="space-y-3">
              <button
                onClick={() => setPayMethod('wechat')}
                disabled={paying}
                className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all ${
                  payMethod === 'wechat'
                    ? 'border-primary bg-primary/5'
                    : 'border-border bg-card'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white flex-shrink-0">
                  <Smartphone size={20} />
                </div>
                <span className="flex-1 text-left text-base text-foreground">
                  微信支付
                </span>
                <div
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    payMethod === 'wechat'
                      ? 'border-primary'
                      : 'border-border'
                  }`}
                >
                  {payMethod === 'wechat' && (
                    <Check size={14} className="text-primary" strokeWidth={3} />
                  )}
                </div>
              </button>

              <button
                onClick={() => setPayMethod('alipay')}
                disabled={paying}
                className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all ${
                  payMethod === 'alipay'
                    ? 'border-primary bg-primary/5'
                    : 'border-border bg-card'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white flex-shrink-0">
                  <CreditCard size={20} />
                </div>
                <span className="flex-1 text-left text-base text-foreground">
                  支付宝
                </span>
                <div
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    payMethod === 'alipay'
                      ? 'border-primary'
                      : 'border-border'
                  }`}
                >
                  {payMethod === 'alipay' && (
                    <Check size={14} className="text-primary" strokeWidth={3} />
                  )}
                </div>
              </button>
            </div>
          </div>

          {/* 支付按钮 */}
          <div className="pt-4">
            <Button
              fullWidth
              size="lg"
              onClick={handlePay}
              loading={paying}
              disabled={paying}
            >
              {paying ? '支付中...' : `立即支付 ¥${selectedProduct?.price.toFixed(1)}`}
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default ShopPage;
