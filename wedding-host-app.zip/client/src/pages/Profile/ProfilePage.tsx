import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  User,
  Settings,
  Heart,
  ShoppingBag,
  Wrench,
  Store,
  Headphones,
  ChevronRight,
  Sparkles,
  CreditCard,
  UserPlus,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getAiQuota } from '@client/src/api/auth';
import { getUserProfile } from '@client/src/api/user';
import { joinByShareCode } from '@client/src/api/wedding';
import type { AiQuota } from '@shared/api.interface';
import type { UserProfileData } from '@shared/api.interface';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import { useToast } from '@client/src/components/ToastProvider';
import { Image } from '@client/src/components/ui/image';

interface MenuItem {
  icon: React.ReactNode;
  label: string;
  to?: string;
  onClick?: string;
  badge?: string;
  disabled?: boolean;
}

const menuGroups: { title: string; items: MenuItem[] }[] = [
  {
    title: '我的内容',
    items: [
      { icon: <Heart size={20} />, label: '我的收藏', to: '/profile/favorites' },
      { icon: <ShoppingBag size={20} />, label: '我的订单', to: '/profile/orders' },
      { icon: <CreditCard size={20} />, label: '电子名片', to: '/profile/card' },
      { icon: <UserPlus size={20} />, label: '加入协作', onClick: 'join' },
      { icon: <Wrench size={20} />, label: '婚礼工具', to: '/toolkit' },
      { icon: <User size={20} />, label: '账号设置', to: '/profile/settings' },
    ],
  },
  {
    title: '更多',
    items: [
      { icon: <Store size={20} />, label: '婚庆商圈', to: '/mall' },
      {
        icon: <Headphones size={20} />,
        label: '联系客服',
        to: '',
        badge: '敬请期待',
        disabled: true,
      },
      { icon: <Settings size={20} />, label: '账号与安全', to: '/profile/settings' },
    ],
  },
];

const ProfilePage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [quota, setQuota] = useState<AiQuota | null>(null);
  const [profile, setProfile] = useState<UserProfileData | null>(null);

  // 加入协作弹窗
  const [joinSheetOpen, setJoinSheetOpen] = useState(false);
  const [shareCode, setShareCode] = useState('');
  const [joinLoading, setJoinLoading] = useState(false);

  useEffect(() => {
    void loadData();
  }, [location.pathname]);

  const handleJoin = async () => {
    const code = shareCode.trim().toUpperCase();
    if (!code) {
      showToast('请输入分享码', 'warning');
      return;
    }
    setJoinLoading(true);
    try {
      const result = await joinByShareCode(code);
      showToast('加入成功', 'success');
      setJoinSheetOpen(false);
      setShareCode('');
      navigate(`/wedding/${result.projectId}`);
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: { message?: string } } } };
      const msg = error.response?.data?.error?.message || '加入失败，请检查分享码';
      showToast(msg, 'error');
    } finally {
      setJoinLoading(false);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [quotaRes, profileRes] = await Promise.all([
        getAiQuota(),
        getUserProfile(),
      ]);
      setQuota(quotaRes);
      setProfile(profileRes);
    } catch (error) {
      logger.error('加载个人中心失败', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-24 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  const renderMenuItem = (item: MenuItem, index: number, total: number) => {
    const hasDivider = index < total - 1;
    const content = (
      <div
        className={`flex items-center gap-3 px-5 py-4 ${
          hasDivider ? 'border-b border-border/50' : ''
        } ${item.disabled ? 'opacity-60' : 'active:bg-muted'}`}
      >
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
          {item.icon}
        </div>
        <span className="flex-1 text-base text-foreground">{item.label}</span>
        {item.badge && (
          <span className="text-xs text-muted-foreground">{item.badge}</span>
        )}
        {!item.disabled && (
          <ChevronRight size={18} className="text-muted-foreground/50 flex-shrink-0" />
        )}
      </div>
    );

    if (item.disabled) {
      return (
        <div key={item.label} className="cursor-default">
          {content}
        </div>
      );
    }

    if (item.onClick === 'join') {
      return (
        <button
          key={item.label}
          onClick={() => setJoinSheetOpen(true)}
          className="block w-full text-left"
        >
          {content}
        </button>
      );
    }

    return (
      <Link key={item.label} to={item.to || ''} className="block">
        {content}
      </Link>
    );
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* 深色品牌头部 */}
      <div
        className="relative h-[220px] rounded-b-[2rem] px-5 pt-12"
        style={{
          background:
            'linear-gradient(135deg, #2C0A14 0%, #5C1525 50%, #8B1530 100%)',
        }}
      >
        {/* 设置按钮 */}
        <button
          onClick={() => navigate('/profile/settings')}
          className="absolute top-12 right-5 w-10 h-10 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center text-white/90 flex-shrink-0 hover:bg-white/20 transition-colors"
          aria-label="设置"
        >
          <Settings size={20} />
        </button>

        {/* 用户信息 */}
        <div className="flex items-center gap-4 h-full">
          <div className="relative flex-shrink-0">
            {/* 金色光晕外圈 */}
            <div
              className="absolute -inset-1 rounded-full opacity-50 blur-sm"
              style={{ background: 'linear-gradient(135deg, #E8D5A3, #C9A961)' }}
            />
            {/* 头像 */}
            <div
              className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-white"
              style={{ borderColor: '#FFFDF8' }}
            >
              {profile?.avatarUrl ? (
                <Image
                  src={profile.avatarUrl}
                  alt={profile.nickname}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div
                  className="w-full h-full flex items-center justify-center"
                  style={{
                    background:
                      'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                  }}
                >
                  <User size={36} style={{ color: '#5C4520' }} />
                </div>
              )}
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-serif font-bold text-white tracking-tight truncate">
              {profile?.nickname || '婚礼主持人'}
            </h1>
            <div className="flex items-center gap-2 mt-1.5">
              <span
                className="px-2.5 py-0.5 rounded-full text-xs font-medium"
                style={{
                  background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                  color: '#5C4520',
                }}
              >
                婚礼主持人
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* AI 额度金卡（负 margin 叠在头部上） */}
      <div className="px-5 -mt-8 relative z-10">
        <div
          className="rounded-2xl p-5 shadow-lg"
          style={{
            background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
            boxShadow: '0 8px 24px rgba(201, 169, 97, 0.30)',
            color: '#5C4520',
          }}
        >
          {/* 标题行 */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Sparkles size={20} />
              <h2 className="text-base font-semibold">我的AI额度</h2>
            </div>
            <button
              onClick={() => navigate('/shop')}
              className="h-8 px-4 rounded-full text-xs font-medium text-white transition-all active:scale-[0.97]"
              style={{ background: '#5C4520' }}
            >
              去充值
            </button>
          </div>

          {/* 双列数据 */}
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div
              className="rounded-xl p-3"
              style={{ background: 'rgba(92, 69, 32, 0.12)' }}
            >
              <p className="text-xs opacity-70 mb-1">流程生成剩余</p>
              <p className="text-2xl font-bold">{quota?.remainingFlow ?? 0}</p>
              <p className="text-xs opacity-60 mt-1">
                本月免费 {quota?.monthlyFlowQuota ?? 0} 次
              </p>
            </div>
            <div
              className="rounded-xl p-3"
              style={{ background: 'rgba(92, 69, 32, 0.12)' }}
            >
              <p className="text-xs opacity-70 mb-1">台词生成剩余</p>
              <p className="text-2xl font-bold">{quota?.remainingScript ?? 0}</p>
              <p className="text-xs opacity-60 mt-1">
                本月免费 {quota?.monthlyScriptQuota ?? 0} 次
              </p>
            </div>
          </div>

          {/* 底部小字 */}
          <p className="text-xs opacity-60 text-center">
            额度将在 {quota?.resetDate || '每月1日'} 重置
          </p>
        </div>
      </div>

      {/* 功能菜单分组 */}
      <div className="px-5 mt-6 space-y-5">
        {menuGroups.map((group) => (
          <div key={group.title}>
            <p className="text-sm text-muted-foreground mb-3 px-1 font-medium">
              {group.title}
            </p>
            <div className="bg-card rounded-2xl shadow-md overflow-hidden">
              {group.items.map((item, index) =>
                renderMenuItem(item, index, group.items.length)
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 底部版本信息 */}
      <div className="mt-10 text-center px-5">
        <p className="font-serif text-xl text-primary font-bold mb-2 tracking-tight">
          婚序
        </p>
        <p className="text-xs text-muted-foreground mb-3">
          婚礼主持助手 v1.0.0
        </p>
        <div className="flex items-center justify-center gap-3 text-xs text-muted-foreground">
          <span className="cursor-pointer hover:text-foreground transition-colors">
            用户协议
          </span>
          <span className="text-border">|</span>
          <span className="cursor-pointer hover:text-foreground transition-colors">
            隐私政策
          </span>
        </div>
      </div>

      {/* 加入协作弹窗 */}
      <BottomSheet
        open={joinSheetOpen}
        onClose={() => setJoinSheetOpen(false)}
        title="加入协作"
        height="auto"
      >
        <div className="px-5 py-5 space-y-5">
          <div className="text-center">
            <div
              className="w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
              }}
            >
              <UserPlus size={28} style={{ color: '#5C4520' }} />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">
              加入婚礼方案共创
            </h3>
            <p className="text-sm text-muted-foreground">
              输入搭档分享的8位分享码，即可参与方案协作
            </p>
          </div>

          <div>
            <Input
              label="分享码"
              value={shareCode}
              onChange={(e) => setShareCode(e.target.value.toUpperCase())}
              placeholder="请输入8位分享码"
              maxLength={8}
              className="text-center text-xl font-mono tracking-[0.3em]"
            />
          </div>

          <Button fullWidth onClick={handleJoin} loading={joinLoading}>
            <UserPlus size={18} />
            加入协作
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            加入后可查看和编辑婚礼方案流程
          </p>
        </div>
      </BottomSheet>
    </div>
  );
};

export default ProfilePage;
