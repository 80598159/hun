import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingBag, Clock, CheckCircle } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getOrderList, payOrder } from '@client/src/api/user';
import type { Order } from '@shared/api.interface';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';

const OrderListPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState<Order[]>([]);
  const [payingId, setPayingId] = useState<string | null>(null);

  useEffect(() => {
    void loadOrders();
  }, []);

  const loadOrders = async () => {
    setLoading(true);
    try {
      const res = await getOrderList({ page: 1, pageSize: 20 });
      setOrders(res.items || []);
    } catch (error) {
      logger.error('获取订单列表失败', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePay = async (order: Order) => {
    setPayingId(order.id);
    try {
      await payOrder(order.id);
      showToast('支付成功！', 'success');
      void loadOrders();
    } catch (error) {
      logger.error('支付失败', error);
      showToast('支付失败，请稍后重试', 'error');
    } finally {
      setPayingId(null);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] px-4 pb-20 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="我的订单" onBack={() => navigate(-1)} />

      {orders.length === 0 ? (
        <EmptyState
          icon={<ShoppingBag size={32} />}
          title="暂无订单"
          description="快去商店看看吧"
        />
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-xl shadow-sm p-4"
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="text-base font-semibold text-gray-900 flex-1 pr-2">
                  {order.productName}
                </h3>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {order.status === 'pending' ? (
                    <>
                      <Clock size={14} className="text-[#FAAD14]" />
                      <span className="text-sm text-[#FAAD14] font-medium">
                        待支付
                      </span>
                    </>
                  ) : (
                    <>
                      <CheckCircle size={14} className="text-[#52C41A]" />
                      <span className="text-sm text-[#52C41A] font-medium">
                        已完成
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-500">
                  {formatDate(order.createdAt)}
                </p>
                <p className="text-lg font-bold text-[#C41E3A]">
                  ¥{order.amount.toFixed(1)}
                </p>
              </div>

              {order.status === 'pending' && (
                <div className="mt-3 pt-3 border-t border-gray-50 flex justify-end">
                  <Button
                    size="sm"
                    onClick={() => handlePay(order)}
                    disabled={payingId === order.id}
                    className="!h-8 !px-4 !text-sm"
                  >
                    {payingId === order.id ? '支付中...' : '去支付'}
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrderListPage;
