import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, FileText } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getFavoriteList } from '@client/src/api/user';
import type { Script } from '@shared/api.interface';
import PageHeader from '@client/src/components/PageHeader';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';

const FavoriteListPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [scripts, setScripts] = useState<Script[]>([]);

  useEffect(() => {
    void loadFavorites();
  }, []);

  const loadFavorites = async () => {
    setLoading(true);
    try {
      const res = await getFavoriteList({ page: 1, pageSize: 50 });
      setScripts(res.items || []);
    } catch (error) {
      logger.error('获取收藏列表失败', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] px-4 pb-20 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="我的收藏" onBack={() => navigate(-1)} />

      {scripts.length === 0 ? (
        <EmptyState
          icon={<Heart size={32} />}
          title="暂无收藏"
          description="去台词库收藏喜欢的台词吧"
        />
      ) : (
        <div className="space-y-3">
          {scripts.map((script) => (
            <div
              key={script.id}
              onClick={() => navigate(`/scripts/${script.id}`)}
              className="bg-white rounded-xl shadow-sm p-4 cursor-pointer active:bg-gray-50 transition-colors"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#C41E3A]/10 flex items-center justify-center text-[#C41E3A] flex-shrink-0">
                  <FileText size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-semibold text-gray-900 truncate">
                    {script.title}
                  </h3>
                  <p className="text-xs text-[#C41E3A] mt-1 inline-block bg-[#C41E3A]/10 px-2 py-0.5 rounded-full">
                    {script.category}
                  </p>
                  <p className="text-sm text-gray-500 mt-2 line-clamp-2">
                    {script.content}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FavoriteListPage;
