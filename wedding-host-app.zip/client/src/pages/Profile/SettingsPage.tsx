import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  X,
  Lock,
  Camera,
  Image as ImageIcon,
  Trash2,
  RotateCw,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  User,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';
import { getUserProfile, updateUserProfile } from '@client/src/api/user';
import { changePassword, logout } from '@client/src/api/auth';
import type { UserProfileData } from '@shared/api.interface';
import PageHeader from '@client/src/components/PageHeader';
import Input from '@client/src/components/app-ui/Input';
import Button from '@client/src/components/app-ui/Button';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import { Image } from '@client/src/components/ui/image';

const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
const CROP_VIEWPORT = 240; // px
const CROP_OUTPUT = 512; // px

const SettingsPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showPwdDialog, setShowPwdDialog] = useState(false);
  const [form, setForm] = useState({
    nickname: '',
    avatarUrl: '',
    phone: '',
    city: '',
    experienceYears: '',
    bio: '',
    styleTags: '',
  });

  // 头像相关 state
  const [showAvatarSheet, setShowAvatarSheet] = useState(false);
  const [showCropper, setShowCropper] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [cropImageSrc, setCropImageSrc] = useState<string | null>(null);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    void loadProfile();
  }, []);

  const loadProfile = async () => {
    setLoading(true);
    try {
      const profile: UserProfileData = await getUserProfile();
      setForm({
        nickname: profile.nickname || '',
        avatarUrl: profile.avatarUrl || '',
        phone: profile.phone || '',
        city: profile.city || '',
        experienceYears: profile.experienceYears
          ? String(profile.experienceYears)
          : '',
        bio: profile.bio || '',
        styleTags: profile.styleTags || '',
      });
    } catch (error) {
      logger.error('获取用户资料失败', error);
    } finally {
      setLoading(false);
    }
  };

  const validateFile = (file: File): string | null => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return '仅支持 JPG、PNG、WebP 格式';
    }
    if (file.size > MAX_SIZE_BYTES) {
      return '图片大小不能超过 5MB';
    }
    return null;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const error = validateFile(file);
    if (error) {
      showToast(error, 'error');
      e.target.value = '';
      return;
    }

    setShowAvatarSheet(false);
    const reader = new FileReader();
    reader.onload = () => {
      setCropImageSrc(reader.result as string);
      setShowCropper(true);
    };
    reader.onerror = () => {
      showToast('读取图片失败', 'error');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleCropConfirm = useCallback(
    async (croppedBlob: Blob) => {
      setShowCropper(false);
      setAvatarUploading(true);
      try {
        const file = new File([croppedBlob], 'avatar.jpg', {
          type: 'image/jpeg',
        });

        const dataloom = await getDataloom();
        const { data, error } = await dataloom
          .storage
          .from(getDefaultBucketId())
          .uploadFile(file);

        if (error || !data) {
          throw new Error(
            error?.message ?? (error as { error_msg?: string })?.error_msg ?? '上传失败',
          );
        }

        const downloadUrl = data.download_url;
        await updateUserProfile({ avatarUrl: downloadUrl });
        setForm((prev) => ({ ...prev, avatarUrl: downloadUrl }));
        showToast('头像更新成功', 'success');
      } catch (error) {
        logger.error('头像上传失败', error);
        const msg =
          (error as { message?: string })?.message || '头像上传失败，请稍后重试';
        showToast(msg, 'error');
      } finally {
        setAvatarUploading(false);
        setCropImageSrc(null);
      }
    },
    [showToast],
  );

  const handleDeleteAvatar = async () => {
    setShowDeleteConfirm(false);
    setAvatarUploading(true);
    try {
      await updateUserProfile({ avatarUrl: '' });
      setForm((prev) => ({ ...prev, avatarUrl: '' }));
      showToast('头像已删除', 'success');
    } catch (error) {
      logger.error('删除头像失败', error);
      showToast('删除失败，请稍后重试', 'error');
    } finally {
      setAvatarUploading(false);
    }
  };

  const handleSave = async () => {
    if (!form.nickname.trim()) {
      showToast('请输入昵称', 'warning');
      return;
    }

    setSaving(true);
    try {
      await updateUserProfile({
        nickname: form.nickname.trim(),
        avatarUrl: form.avatarUrl.trim(),
        phone: form.phone.trim(),
        city: form.city.trim(),
        experienceYears: form.experienceYears
          ? Number(form.experienceYears)
          : 0,
        bio: form.bio.trim(),
        styleTags: form.styleTags.trim(),
      });
      showToast('保存成功', 'success');
      setTimeout(() => {
        navigate(-1);
      }, 800);
    } catch (error) {
      logger.error('保存资料失败', error);
      showToast('保存失败，请稍后重试', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      logger.error('退出登录失败', error);
    } finally {
      showToast('已退出登录', 'info');
      setTimeout(() => {
        navigate('/login', { replace: true });
      }, 300);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background px-5 pb-20 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="账号与安全" onBack={() => navigate(-1)} />

      {/* 头像设置 */}
      <div className="flex flex-col items-center py-6 mb-2">
        <button
          onClick={() => setShowAvatarSheet(true)}
          disabled={avatarUploading}
          className="relative group"
          aria-label="更换头像"
        >
          <div
            className="w-24 h-24 rounded-full overflow-hidden flex items-center justify-center"
            style={{
              border: '2px solid #C9A961',
              boxShadow: '0 2px 12px rgba(201, 169, 97, 0.25)',
            }}
          >
            {form.avatarUrl ? (
              <Image
                src={form.avatarUrl}
                alt="头像"
                className="w-full h-full object-cover"
              />
            ) : (
              <div
                className="w-full h-full flex items-center justify-center"
                style={{
                  background:
                    'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                }}
              >
                <User size={40} style={{ color: '#5C4520' }} />
              </div>
            )}
          </div>
          {avatarUploading && (
            <div className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center">
              <LoadingSpinner size="sm" color="white" />
            </div>
          )}
        </button>
        <p className="text-xs text-muted-foreground mt-2 text-center">
          点击头像更换
        </p>
      </div>

      <div className="space-y-4 mb-6">
        <Input
          label="昵称"
          value={form.nickname}
          onChange={(e) => setForm((prev) => ({ ...prev, nickname: e.target.value }))}
          placeholder="请输入昵称"
        />
        <Input
          label="手机号"
          value={form.phone}
          onChange={(e) => setForm((prev) => ({ ...prev, phone: e.target.value }))}
          placeholder="请输入手机号"
          type="tel"
        />
        <Input
          label="所在城市"
          value={form.city}
          onChange={(e) => setForm((prev) => ({ ...prev, city: e.target.value }))}
          placeholder="请输入所在城市"
        />
        <Input
          label="从业年限"
          value={form.experienceYears}
          onChange={(e) =>
            setForm((prev) => ({
              ...prev,
              experienceYears: e.target.value.replace(/[^0-9]/g, ''),
            }))
          }
          placeholder="请输入从业年限"
          type="text"
        />
        <div>
          <label className="block text-sm font-medium text-foreground/80 mb-2">
            个人简介
          </label>
          <textarea
            value={form.bio}
            onChange={(e) => setForm((prev) => ({ ...prev, bio: e.target.value }))}
            placeholder="介绍一下你自己..."
            rows={4}
            className="w-full px-4 py-3 rounded-xl border border-input bg-secondary/60 text-foreground placeholder:text-muted-foreground/70 text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 focus:bg-card transition-all duration-200 resize-none"
          />
        </div>
        <Input
          label="主持风格标签"
          value={form.styleTags}
          onChange={(e) => setForm((prev) => ({ ...prev, styleTags: e.target.value }))}
          placeholder="中式,西式,文艺（用逗号分隔）"
        />
      </div>

      <Button fullWidth onClick={handleSave} disabled={saving} className="!h-12 mb-8">
        {saving ? '保存中...' : '保存'}
      </Button>

      {/* 账号安全操作 */}
      <div className="space-y-3">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <button
            onClick={() => setShowPwdDialog(true)}
            className="w-full px-5 py-4 text-left text-base text-foreground active:bg-muted flex items-center justify-between"
          >
            <span className="flex items-center gap-3">
              <Lock size={18} className="text-primary" />
              修改密码
            </span>
            <span className="text-muted-foreground/50">›</span>
          </button>
        </div>

        <button
          onClick={handleLogout}
          className="w-full bg-white rounded-xl shadow-md py-4 text-base text-primary font-medium active:bg-muted"
        >
          退出登录
        </button>

        <div className="bg-white rounded-xl shadow-md overflow-hidden mt-3">
          <button className="w-full px-5 py-4 text-left text-base text-foreground active:bg-muted border-b border-border/50">
            用户协议
          </button>
          <button className="w-full px-5 py-4 text-left text-base text-foreground active:bg-muted">
            隐私政策
          </button>
        </div>
      </div>

      {/* 修改密码弹窗 */}
      {showPwdDialog && (
        <ChangePasswordDialog
          onClose={() => setShowPwdDialog(false)}
          onSuccess={() => {
            setShowPwdDialog(false);
            showToast('密码修改成功，请重新登录', 'success');
            setTimeout(() => {
              localStorage.removeItem('app_auth_token');
              navigate('/login', { replace: true });
            }, 1000);
          }}
        />
      )}

      {/* 头像选择底部菜单 */}
      {showAvatarSheet && (
        <AvatarActionSheet
          hasAvatar={!!form.avatarUrl}
          onCamera={() => cameraInputRef.current?.click()}
          onGallery={() => galleryInputRef.current?.click()}
          onDelete={() => {
            setShowAvatarSheet(false);
            setShowDeleteConfirm(true);
          }}
          onClose={() => setShowAvatarSheet(false)}
        />
      )}

      {/* 隐藏的文件输入 */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        className="hidden"
      />
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* 图片裁剪器 */}
      {showCropper && cropImageSrc && (
        <ImageCropper
          imageSrc={cropImageSrc}
          onCancel={() => {
            setShowCropper(false);
            setCropImageSrc(null);
          }}
          onConfirm={handleCropConfirm}
        />
      )}

      {/* 删除头像确认弹窗 */}
      {showDeleteConfirm && (
        <DeleteConfirmDialog
          onCancel={() => setShowDeleteConfirm(false)}
          onConfirm={handleDeleteAvatar}
        />
      )}
    </div>
  );
};

// ===== 修改密码弹窗 =====
interface ChangePasswordDialogProps {
  onClose: () => void;
  onSuccess: () => void;
}

const ChangePasswordDialog = ({ onClose, onSuccess }: ChangePasswordDialogProps) => {
  const { showToast } = useToast();
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oldPassword) {
      showToast('请输入原密码', 'warning');
      return;
    }
    if (!newPassword || newPassword.length < 6) {
      showToast('新密码至少6位', 'warning');
      return;
    }
    if (newPassword !== confirmPassword) {
      showToast('两次输入的新密码不一致', 'warning');
      return;
    }

    setSubmitting(true);
    try {
      await changePassword(oldPassword, newPassword);
      onSuccess();
    } catch (error) {
      logger.error('修改密码失败', error);
      const msg =
        (error as any)?.response?.data?.error?.message || '修改密码失败，请稍后重试';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* 背景遮罩 */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
        style={{ animation: 'fade-in 0.2s ease-out' }}
      />
      {/* 弹窗内容 */}
      <div
        className="relative w-full max-w-[480px] bg-card rounded-t-3xl sm:rounded-2xl p-6 shadow-xl"
        style={{ animation: 'slide-up 0.3s cubic-bezier(0.32, 0.72, 0, 1)' }}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground">修改密码</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            aria-label="关闭"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="原密码"
            type="password"
            value={oldPassword}
            onChange={(e) => setOldPassword(e.target.value)}
            placeholder="请输入原密码"
          />
          <Input
            label="新密码"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="请输入新密码（至少6位）"
          />
          <Input
            label="确认新密码"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="请再次输入新密码"
          />

          <Button
            type="submit"
            fullWidth
            loading={submitting}
            className="!h-12 !mt-2"
          >
            {submitting ? '提交中...' : '确认修改'}
          </Button>
        </form>
      </div>
    </div>
  );
};

// ===== 头像操作底部菜单 =====
interface AvatarActionSheetProps {
  hasAvatar: boolean;
  onCamera: () => void;
  onGallery: () => void;
  onDelete: () => void;
  onClose: () => void;
}

const AvatarActionSheet = ({
  hasAvatar,
  onCamera,
  onGallery,
  onDelete,
  onClose,
}: AvatarActionSheetProps) => {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
        style={{ animation: 'fade-in 0.2s ease-out' }}
      />
      <div
        className="relative w-full max-w-[480px] bg-card rounded-t-3xl sm:rounded-2xl p-4 pb-6 shadow-xl"
        style={{ animation: 'slide-up 0.3s cubic-bezier(0.32, 0.72, 0, 1)' }}
      >
        {/* 顶部指示条 */}
        <div className="w-10 h-1 bg-border/60 rounded-full mx-auto mb-4" />

        <div className="space-y-1">
          <button
            onClick={onCamera}
            className="w-full px-4 py-4 text-base text-foreground rounded-xl active:bg-muted flex items-center gap-3"
          >
            <Camera size={20} className="text-primary" />
            拍照
          </button>
          <button
            onClick={onGallery}
            className="w-full px-4 py-4 text-base text-foreground rounded-xl active:bg-muted flex items-center gap-3"
          >
            <ImageIcon size={20} className="text-primary" />
            从相册选择
          </button>
          {hasAvatar && (
            <button
              onClick={onDelete}
              className="w-full px-4 py-4 text-base rounded-xl active:bg-muted flex items-center gap-3"
              style={{ color: '#C93030' }}
            >
              <Trash2 size={20} />
              删除头像
            </button>
          )}
        </div>

        <div className="mt-3 pt-3 border-t border-border/50">
          <button
            onClick={onClose}
            className="w-full py-3 text-base text-foreground font-medium rounded-xl active:bg-muted"
          >
            取消
          </button>
        </div>
      </div>
    </div>
  );
};

// ===== 图片裁剪器 =====
interface ImageCropperProps {
  imageSrc: string;
  onCancel: () => void;
  onConfirm: (blob: Blob) => void;
}

const ImageCropper = ({ imageSrc, onCancel, onConfirm }: ImageCropperProps) => {
  const imgRef = useRef<HTMLImageElement | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const dragState = useRef({
    isDragging: false,
    startX: 0,
    startY: 0,
    startOffsetX: 0,
    startOffsetY: 0,
  });
  const [confirming, setConfirming] = useState(false);

  const handleImageLoad = () => {
    const img = imgRef.current;
    if (!img) return;

    const nw = img.naturalWidth;
    const nh = img.naturalHeight;
    // 默认 cover：填满裁剪框
    const initialScale = Math.max(CROP_VIEWPORT / nw, CROP_VIEWPORT / nh);
    setScale(initialScale);
    setOffset({ x: 0, y: 0 });
    setImgLoaded(true);
  };

  const handleDragStart = (clientX: number, clientY: number) => {
    dragState.current = {
      isDragging: true,
      startX: clientX,
      startY: clientY,
      startOffsetX: offset.x,
      startOffsetY: offset.y,
    };
  };

  const handleDragMove = (clientX: number, clientY: number) => {
    if (!dragState.current.isDragging) return;
    const dx = clientX - dragState.current.startX;
    const dy = clientY - dragState.current.startY;
    setOffset({
      x: dragState.current.startOffsetX + dx,
      y: dragState.current.startOffsetY + dy,
    });
  };

  const handleDragEnd = () => {
    dragState.current.isDragging = false;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    handleDragStart(e.clientX, e.clientY);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    handleDragMove(e.clientX, e.clientY);
  };

  const handleMouseUp = () => {
    handleDragEnd();
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      handleDragStart(t.clientX, t.clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      handleDragMove(t.clientX, t.clientY);
    }
  };

  const handleTouchEnd = () => {
    handleDragEnd();
  };

  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev * 1.2, 3.0));
  };

  const handleZoomOut = () => {
    setScale((prev) => Math.max(prev / 1.2, 0.5));
  };

  const handleRotateLeft = () => {
    setRotation((prev) => (prev - 90 + 360) % 360);
  };

  const handleRotateRight = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const handleConfirm = () => {
    const img = imgRef.current;
    if (!img || confirming) return;

    setConfirming(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = CROP_OUTPUT;
      canvas.height = CROP_OUTPUT;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas not supported');

      // 白色背景（JPEG 不支持透明）
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, CROP_OUTPUT, CROP_OUTPUT);

      const scaleRatio = CROP_OUTPUT / CROP_VIEWPORT;

      ctx.save();
      ctx.translate(CROP_OUTPUT / 2, CROP_OUTPUT / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(scale * scaleRatio, scale * scaleRatio);
      ctx.translate(offset.x / scale, offset.y / scale);
      ctx.drawImage(
        img,
        -img.naturalWidth / 2,
        -img.naturalHeight / 2,
      );
      ctx.restore();

      canvas.toBlob(
        (blob) => {
          setConfirming(false);
          if (blob) {
            onConfirm(blob);
          } else {
            // fallback
            const fallback = canvas.toDataURL('image/jpeg', 0.85);
            const byteString = atob(fallback.split(',')[1]);
            const ab = new ArrayBuffer(byteString.length);
            const ia = new Uint8Array(ab);
            for (let i = 0; i < byteString.length; i++) {
              ia[i] = byteString.charCodeAt(i);
            }
            onConfirm(new Blob([ab], { type: 'image/jpeg' }));
          }
        },
        'image/jpeg',
        0.85,
      );
    } catch (err) {
      setConfirming(false);
      logger.error('裁剪图片失败', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black">
      {/* 图片裁剪区 */}
      <div
        className="flex-1 relative overflow-hidden select-none"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 图片 */}
        <div
          ref={viewportRef}
          className="absolute top-1/2 left-1/2 rounded-full overflow-hidden cursor-grab active:cursor-grabbing"
          style={{
            width: CROP_VIEWPORT,
            height: CROP_VIEWPORT,
            transform: 'translate(-50%, -50%)',
          }}
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
        >
          <Image
            ref={imgRef}
            src={imageSrc}
            alt="裁剪预览"
            onLoad={handleImageLoad}
            draggable={false}
            className="absolute top-1/2 left-1/2 max-w-none"
            style={{
              transform: `translate(-50%, -50%) translate(${offset.x}px, ${offset.y}px) scale(${scale}) rotate(${rotation}deg)`,
              transformOrigin: 'center center',
              opacity: imgLoaded ? 1 : 0,
              transition: dragState.current.isDragging ? 'none' : 'opacity 0.2s',
            }}
          />
        </div>

        {/* 圆形外的暗层（用 box-shadow 实现镂空效果） */}
        <div
          className="absolute top-1/2 left-1/2 rounded-full pointer-events-none"
          style={{
            width: CROP_VIEWPORT,
            height: CROP_VIEWPORT,
            transform: 'translate(-50%, -50%)',
            boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.7)',
          }}
        />

        {/* 顶部工具栏 */}
        <div className="absolute top-0 left-0 right-0 flex items-center justify-between px-4 pt-4">
          <button
            onClick={onCancel}
            className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white"
            aria-label="取消"
          >
            <X size={20} />
          </button>
          <p className="text-white text-sm font-medium">移动和缩放图片</p>
          <div className="w-10" />
        </div>

        {!imgLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <LoadingSpinner color="white" />
          </div>
        )}
      </div>

      {/* 底部控制栏 */}
      <div className="bg-black/90 px-6 pt-4 pb-8">
        {/* 缩放 + 旋转控制 */}
        <div className="flex items-center justify-center gap-6 mb-5">
          <button
            onClick={handleZoomOut}
            className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-white active:bg-white/20 transition-colors"
            aria-label="缩小"
          >
            <ZoomOut size={20} />
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={handleRotateLeft}
              className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-white active:bg-white/20 transition-colors"
              aria-label="向左旋转"
            >
              <RotateCcw size={20} />
            </button>
            <button
              onClick={handleRotateRight}
              className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-white active:bg-white/20 transition-colors"
              aria-label="向右旋转"
            >
              <RotateCw size={20} />
            </button>
          </div>
          <button
            onClick={handleZoomIn}
            className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-white active:bg-white/20 transition-colors"
            aria-label="放大"
          >
            <ZoomIn size={20} />
          </button>
        </div>

        {/* 取消 + 确认按钮 */}
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 h-12 rounded-full bg-white/10 text-white text-base font-medium active:bg-white/20 transition-colors"
          >
            取消
          </button>
          <button
            onClick={handleConfirm}
            disabled={!imgLoaded || confirming}
            className="flex-1 h-12 rounded-full text-base font-medium text-white disabled:opacity-50"
            style={{
              background:
                'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
              boxShadow: '0 4px 12px rgba(185, 28, 60, 0.30)',
            }}
          >
            {confirming ? '处理中...' : '确认'}
          </button>
        </div>
      </div>
    </div>
  );
};

// ===== 删除头像确认弹窗 =====
interface DeleteConfirmDialogProps {
  onCancel: () => void;
  onConfirm: () => void;
}

const DeleteConfirmDialog = ({ onCancel, onConfirm }: DeleteConfirmDialogProps) => {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onCancel}
        style={{ animation: 'fade-in 0.2s ease-out' }}
      />
      <div
        className="relative w-full max-w-[360px] bg-card rounded-2xl p-6 shadow-xl mx-5"
        style={{ animation: 'slide-up 0.3s cubic-bezier(0.32, 0.72, 0, 1)' }}
      >
        <h3 className="text-lg font-semibold text-foreground text-center mb-2">
          删除头像
        </h3>
        <p className="text-sm text-muted-foreground text-center mb-6">
          确定要删除头像吗？删除后将显示默认头像。
        </p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 h-11 rounded-full border border-input text-foreground text-base font-medium active:bg-muted transition-colors"
          >
            取消
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 h-11 rounded-full text-base font-medium text-white"
            style={{
              background:
                'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
              boxShadow: '0 4px 12px rgba(185, 28, 60, 0.30)',
            }}
          >
            确定删除
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
