import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  User,
  Copy,
  Sparkles,
  Calendar,
  Share2,
  Image as ImageIcon,
} from 'lucide-react';
import { useToast } from '@client/src/components/ToastProvider';
import Button from '@client/src/components/app-ui/Button';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import { Image } from '@client/src/components/ui/image';
import type { UserProfileData } from '@shared/api.interface';
import { getUserProfile } from '@client/src/api/user';

type TemplateType = 'classic' | 'minimal' | 'luxury';
type ScheduleStatus = 'available' | 'busy';

const BusinessCardPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [profile, setProfile] = useState<UserProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTemplate, setActiveTemplate] = useState<TemplateType>('classic');
  const [scheduleStatus, setScheduleStatus] = useState<ScheduleStatus>('available');
  const cardRef = useRef<HTMLDivElement>(null);

  // 分享文案对话框
  const [showShareText, setShowShareText] = useState(false);
  const [shareText, setShareText] = useState('');

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const data = await getUserProfile();
      setProfile(data);
    } catch {
      showToast('加载个人资料失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchProfile();
  }, []);

  const styleTagsList = profile?.styleTags
    ? profile.styleTags.split(/[,，]/).map(t => t.trim()).filter(Boolean)
    : [];

  const nickname = profile?.nickname || '未设置昵称';
  const bio = profile?.bio || '';
  const hasBio = !!bio && bio.trim().length > 0;
  const hasTags = styleTagsList.length > 0;
  const hasAvatar = !!profile?.avatarUrl;

  // 生成分享文案
  const generateShareText = (): string => {
    const name = profile?.nickname || '婚礼主持人';
    const tags = styleTagsList.length > 0 ? styleTagsList.join(' / ') : '专业婚礼主持';
    const status = scheduleStatus === 'available' ? '近期有空档' : '档期紧张，请提前预约';
    const bioText = bio || '用心主持每一场婚礼';
    return `【${name}】专业婚礼主持人\n` +
      `风格：${tags}\n` +
      `理念：${bioText}\n` +
      `档期：${status}\n` +
      `—— 让每一场婚礼都有完美的节奏 ——`;
  };

  const handleShareText = () => {
    setShareText(generateShareText());
    setShowShareText(true);
  };

  const handleCopyShare = async () => {
    try {
      await navigator.clipboard.writeText(shareText);
      showToast('已复制分享文案', 'success');
    } catch {
      showToast('复制失败，请手动复制', 'error');
    }
  };

  const handleSaveImage = () => {
    showToast('请长按名片图片保存到相册', 'info');
  };

  const templates: { key: TemplateType; label: string; desc: string }[] = [
    { key: 'classic', label: '中式经典', desc: '红金配色' },
    { key: 'minimal', label: '现代简约', desc: '黑白金' },
    { key: 'luxury', label: '高端质感', desc: '深色金' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  // 判断是否有未完善的字段
  const incompleteFields: string[] = [];
  if (!profile?.nickname) incompleteFields.push('昵称');
  if (!profile?.avatarUrl) incompleteFields.push('头像');
  if (!profile?.bio) incompleteFields.push('个人简介');
  if (!profile?.styleTags) incompleteFields.push('风格标签');

  return (
    <div className="min-h-screen bg-background pb-24 page-enter">
      {/* 顶部导航 */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm px-5 pt-3 pb-3 flex items-center justify-between border-b border-border/50">
        <Link
          to="/profile"
          className="w-10 h-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground transition-colors"
          aria-label="返回"
        >
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-base font-semibold text-foreground">
          电子名片海报
        </h1>
        <div className="w-10" />
      </div>

      {/* 未完善提示 */}
      {incompleteFields.length > 0 && (
        <div className="px-5 pt-4">
          <div className="bg-accent-gold/10 border border-accent-gold/30 rounded-2xl p-4 flex items-start gap-3">
            <Sparkles size={18} className="text-accent-gold-dark flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-medium text-accent-gold-dark mb-1">
                完善资料让名片更完整
              </p>
              <p className="text-xs text-accent-gold-dark/80 leading-relaxed mb-2">
                还未设置：{incompleteFields.join('、')}
              </p>
              <button
                onClick={() => navigate('/profile/settings')}
                className="text-xs text-primary font-medium"
              >
                去完善 →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 模板选择 */}
      <div className="px-5 pt-5">
        <h3 className="text-sm font-medium text-foreground/80 mb-3">选择模板</h3>
        <div className="grid grid-cols-3 gap-2">
          {templates.map(template => (
            <button
              key={template.key}
              onClick={() => setActiveTemplate(template.key)}
              className={`rounded-xl p-3 text-center transition-all duration-200 ${
                activeTemplate === template.key
                  ? 'bg-primary/10 border-2 border-primary'
                  : 'bg-card border border-border/60 hover:border-primary/30'
              }`}
            >
              <div
                className={`w-full h-12 rounded-lg mb-2 ${
                  template.key === 'classic'
                    ? 'bg-gradient-to-br from-[#B91C3C] to-[#C9A961]'
                    : template.key === 'minimal'
                    ? 'bg-gradient-to-br from-[#1A1414] to-[#6B5C5C]'
                    : 'bg-gradient-to-br from-[#1A0A10] to-[#2C1520]'
                }`}
              />
              <p className={`text-xs font-medium ${
                activeTemplate === template.key ? 'text-primary' : 'text-foreground'
              }`}>
                {template.label}
              </p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                {template.desc}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* 名片预览区 */}
      <div className="px-5 pt-6 pb-6">
        <div className="flex justify-center">
          <div
            ref={cardRef}
            className="w-full max-w-[320px] rounded-3xl overflow-hidden shadow-xl"
            style={{
              aspectRatio: '3/4',
              ...(activeTemplate === 'classic'
                ? {
                    background: 'linear-gradient(160deg, #2C0A14 0%, #8B1530 40%, #B91C3C 70%, #C9A961 100%)',
                  }
                : activeTemplate === 'minimal'
                ? {
                    background: 'linear-gradient(160deg, #1A1414 0%, #2D2828 50%, #6B5C5C 100%)',
                  }
                : {
                    background: 'linear-gradient(160deg, #0D0508 0%, #1A0A10 30%, #2C1520 60%, #4A2030 100%)',
                  }),
            }}
          >
            <div className="h-full flex flex-col items-center justify-center p-8 relative">
              {/* 装饰元素 */}
              {activeTemplate === 'classic' && (
                <>
                  <div className="absolute top-6 left-6 w-16 h-16 border-t-2 border-l-2 border-accent-gold/40 rounded-tl-2xl" />
                  <div className="absolute top-6 right-6 w-16 h-16 border-t-2 border-r-2 border-accent-gold/40 rounded-tr-2xl" />
                  <div className="absolute bottom-6 left-6 w-16 h-16 border-b-2 border-l-2 border-accent-gold/40 rounded-bl-2xl" />
                  <div className="absolute bottom-6 right-6 w-16 h-16 border-b-2 border-r-2 border-accent-gold/40 rounded-br-2xl" />
                </>
              )}

              {activeTemplate === 'luxury' && (
                <>
                  <div className="absolute top-8 left-1/2 -translate-x-1/2 w-20 h-px bg-gradient-to-r from-transparent via-accent-gold/60 to-transparent" />
                  <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-20 h-px bg-gradient-to-r from-transparent via-accent-gold/60 to-transparent" />
                </>
              )}

              {/* 头像 */}
              <div className="relative mb-5">
                {activeTemplate === 'classic' && (
                  <div
                    className="absolute -inset-1.5 rounded-full opacity-60 blur-sm"
                    style={{ background: 'linear-gradient(135deg, #E8D5A3, #C9A961)' }}
                  />
                )}
                {activeTemplate === 'luxury' && (
                  <div
                    className="absolute -inset-2 rounded-full opacity-50"
                    style={{ background: 'linear-gradient(135deg, #E8D5A3, #C9A961)' }}
                  />
                )}
                {activeTemplate === 'minimal' && (
                  <div className="absolute -inset-1 rounded-full border-2 border-accent-gold/60" />
                )}
                <div className="relative w-20 h-20 rounded-full overflow-hidden bg-white/10 flex items-center justify-center">
                  {hasAvatar ? (
                    <Image
                      src={profile?.avatarUrl || ''}
                      alt={nickname}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User size={32} className="text-white/60" />
                  )}
                </div>
              </div>

              {/* 姓名 */}
              <h2
                className={`font-serif text-2xl font-bold mb-2 tracking-tight text-center ${
                  activeTemplate === 'classic' || activeTemplate === 'luxury'
                    ? 'text-gradient-gold'
                    : 'text-white'
                }`}
                style={activeTemplate === 'classic' || activeTemplate === 'luxury' ? {
                  background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 50%, #A08040 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                } : undefined}
              >
                {nickname}
              </h2>

              {/* 职业标签 */}
              <div className="mb-4">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    activeTemplate === 'minimal'
                      ? 'bg-white/10 text-white/80 border border-white/20'
                      : 'bg-accent-gold/20 text-accent-gold-light border border-accent-gold/30'
                  }`}
                >
                  婚礼主持人
                </span>
              </div>

              {/* 风格标签 */}
              {hasTags && (
                <div className="flex flex-wrap justify-center gap-1.5 mb-4">
                  {styleTagsList.slice(0, 3).map((tag, idx) => (
                    <span
                      key={idx}
                      className={`px-2.5 py-1 rounded-full text-[11px] ${
                        activeTemplate === 'minimal'
                          ? 'bg-white/5 text-white/60 border border-white/10'
                          : 'bg-white/10 text-white/70 border border-white/15'
                      }`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Slogan / 简介 */}
              <p className="text-sm text-white/70 text-center leading-relaxed mb-5 max-w-[240px]">
                {hasBio ? bio : '用心主持每一场婚礼'}
              </p>

              {/* 分隔线 */}
              <div className="w-12 h-px bg-white/20 mb-4" />

              {/* 档期状态 */}
              <div className="flex items-center gap-2">
                <Calendar
                  size={14}
                  className={
                    scheduleStatus === 'available'
                      ? 'text-emerald-400'
                      : activeTemplate === 'minimal'
                      ? 'text-amber-300'
                      : 'text-accent-gold'
                  }
                />
                <span
                  className={`text-xs font-medium ${
                    scheduleStatus === 'available'
                      ? 'text-emerald-400'
                      : activeTemplate === 'minimal'
                      ? 'text-amber-300'
                      : 'text-accent-gold-light'
                  }`}
                >
                  {scheduleStatus === 'available' ? '近期有空档' : '档期紧张'}
                </span>
              </div>

              {/* 底部品牌 */}
              <div className="absolute bottom-5 left-0 right-0 text-center">
                <p className="text-[10px] text-white/30 tracking-widest">
                  WEDDING HOST ASSISTANT
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 档期状态切换 */}
      <div className="px-5 mb-5">
        <div className="bg-card rounded-2xl shadow-sm p-4 border border-border/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-gold/10 text-accent-gold flex items-center justify-center">
              <Calendar size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">档期状态</p>
              <p className="text-xs text-muted-foreground">
                展示在名片上，让客户了解档期情况
              </p>
            </div>
          </div>
          <div className="flex items-center bg-secondary/70 rounded-full p-0.5">
            <button
              onClick={() => setScheduleStatus('available')}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                scheduleStatus === 'available'
                  ? 'bg-emerald-500 text-white shadow-sm'
                  : 'text-muted-foreground'
              }`}
            >
              有空档
            </button>
            <button
              onClick={() => setScheduleStatus('busy')}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                scheduleStatus === 'busy'
                  ? 'bg-amber-500 text-white shadow-sm'
                  : 'text-muted-foreground'
              }`}
            >
              紧张
            </button>
          </div>
        </div>
      </div>

      {/* 底部操作按钮 */}
      <div className="px-5 space-y-3">
        <Button variant="primary" fullWidth onClick={handleShareText}>
          <Share2 size={18} />
          分享文案
        </Button>
        <Button variant="gold" fullWidth onClick={handleSaveImage}>
          <ImageIcon size={18} />
          保存图片
        </Button>
        <p className="text-xs text-muted-foreground text-center leading-relaxed">
          长按名片图片可保存到手机相册
        </p>
      </div>

      {/* 分享文案对话框 */}
      <BottomSheet
        open={showShareText}
        onClose={() => setShowShareText(false)}
        title="分享文案"
        height="medium"
      >
        <div className="p-5">
          <div className="bg-secondary/60 rounded-xl p-4 mb-4 border border-border/50">
            <pre className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap font-sans">
              {shareText}
            </pre>
          </div>
          <Button variant="primary" fullWidth onClick={() => void handleCopyShare()}>
            <Copy size={16} />
            一键复制
          </Button>
        </div>
      </BottomSheet>
    </div>
  );
};

export default BusinessCardPage;
