import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Music,
  Plus,
  Search,
  ChevronRight,
  Music2,
  ListMusic,
  X,
  PlusCircle,
} from 'lucide-react';
import { useToast } from '@client/src/components/ToastProvider';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import Input from '@client/src/components/app-ui/Input';
import type {
  BgmSong,
  BgmPlaylist,
  BgmCategory,
} from '@shared/api.interface';
import {
  getBgmLibrary,
  getPlaylists,
  createPlaylist,
  addPlaylistSongs,
} from '@client/src/api/bgm';

type TabType = 'library' | 'my';

const categoryLabels: { key: BgmCategory | 'all'; label: string }[] = [
  { key: 'all', label: '全部' },
  { key: 'prelude', label: '暖场迎宾' },
  { key: 'entrance', label: '新人入场' },
  { key: 'vows', label: '誓言' },
  { key: 'rings', label: '交换戒指' },
  { key: 'tea', label: '敬茶' },
  { key: 'speech', label: '致辞' },
  { key: 'exit', label: '退场' },
  { key: 'climax', label: '高潮' },
  { key: 'other', label: '其他' },
];

const BgmPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<TabType>('library');

  // 曲库
  const [songs, setSongs] = useState<BgmSong[]>([]);
  const [songsLoading, setSongsLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<BgmCategory | 'all'>('all');
  const [searchKeyword, setSearchKeyword] = useState('');

  // 我的歌单
  const [playlists, setPlaylists] = useState<BgmPlaylist[]>([]);
  const [playlistsLoading, setPlaylistsLoading] = useState(false);

  // 加入歌单对话框
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedSong, setSelectedSong] = useState<BgmSong | null>(null);
  const [showNewPlaylist, setShowNewPlaylist] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [addingSong, setAddingSong] = useState(false);
  const [creatingPlaylist, setCreatingPlaylist] = useState(false);

  const fetchSongs = async () => {
    setSongsLoading(true);
    try {
      const data = await getBgmLibrary({
        category: selectedCategory === 'all' ? undefined : selectedCategory,
        keyword: searchKeyword || undefined,
        pageSize: 50,
      });
      setSongs(data.items || []);
    } catch {
      showToast('加载曲库失败', 'error');
    } finally {
      setSongsLoading(false);
    }
  };

  const fetchPlaylists = async () => {
    setPlaylistsLoading(true);
    try {
      const data = await getPlaylists();
      setPlaylists(data || []);
    } catch {
      showToast('加载歌单失败', 'error');
    } finally {
      setPlaylistsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'library') {
      void fetchSongs();
    } else {
      void fetchPlaylists();
    }
  }, [activeTab, selectedCategory]);

  const handleSearch = () => {
    void fetchSongs();
  };

  const handleAddToPlaylist = (song: BgmSong) => {
    setSelectedSong(song);
    setShowAddDialog(true);
    setShowNewPlaylist(false);
    setNewPlaylistName('');
    void fetchPlaylists();
  };

  const handleConfirmAdd = async (playlistId: string) => {
    if (!selectedSong) return;
    setAddingSong(true);
    try {
      await addPlaylistSongs(playlistId, {
        songs: [
          {
            songId: selectedSong.id,
            title: selectedSong.title,
            artist: selectedSong.artist,
          },
        ],
      });
      showToast('已加入歌单', 'success');
      setShowAddDialog(false);
      setSelectedSong(null);
    } catch {
      showToast('添加失败，请重试', 'error');
    } finally {
      setAddingSong(false);
    }
  };

  const handleCreatePlaylist = async () => {
    if (!newPlaylistName.trim()) {
      showToast('请输入歌单名称', 'warning');
      return;
    }
    setCreatingPlaylist(true);
    try {
      const data = await createPlaylist({ name: newPlaylistName.trim() });
      showToast('歌单创建成功', 'success');
      void fetchPlaylists();
      setShowNewPlaylist(false);
      setNewPlaylistName('');
      if (selectedSong) {
        void handleConfirmAdd(data.id);
      }
    } catch {
      showToast('创建失败，请重试', 'error');
    } finally {
      setCreatingPlaylist(false);
    }
  };

  const getCategoryLabel = (cat: string): string => {
    const found = categoryLabels.find(c => c.key === cat);
    return found ? found.label : cat;
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background pb-24 page-enter">
      {/* 顶部标题 */}
      <div className="pt-6 pb-4 px-5">
        <h1 className="font-serif text-2xl font-bold text-foreground tracking-tight">
          音乐歌单
        </h1>
        <p className="text-sm text-muted-foreground mt-1.5">
          精选婚礼BGM，打造专属仪式音乐
        </p>
      </div>

      {/* Tab 切换 */}
      <div className="px-5 mb-4">
        <div className="bg-secondary/70 rounded-full p-1 flex">
          <button
            onClick={() => setActiveTab('library')}
            className={`flex-1 h-10 rounded-full text-sm font-medium transition-all duration-200 ${
              activeTab === 'library'
                ? 'bg-primary-gradient text-primary-foreground shadow-md shadow-primary/25'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <span className="flex items-center justify-center gap-1.5">
              <Music2 size={16} />
              推荐库
            </span>
          </button>
          <button
            onClick={() => setActiveTab('my')}
            className={`flex-1 h-10 rounded-full text-sm font-medium transition-all duration-200 ${
              activeTab === 'my'
                ? 'bg-primary-gradient text-primary-foreground shadow-md shadow-primary/25'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <span className="flex items-center justify-center gap-1.5">
              <ListMusic size={16} />
              我的歌单
            </span>
          </button>
        </div>
      </div>

      {/* 推荐库 Tab */}
      {activeTab === 'library' && (
        <>
          {/* 分类横向滚动 */}
          <div className="px-5 mb-4">
            <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
              {categoryLabels.map(cat => (
                <button
                  key={cat.key}
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-medium transition-all duration-200 ${
                    selectedCategory === cat.key
                      ? 'bg-primary text-primary-foreground shadow-md shadow-primary/25'
                      : 'bg-card text-muted-foreground border border-border/60 hover:border-primary/30 hover:text-foreground'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* 搜索框 */}
          <div className="px-5 mb-4">
            <Input
              placeholder="搜索歌曲名或歌手"
              value={searchKeyword}
              onChange={e => setSearchKeyword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
              leftIcon={<Search size={18} />}
              rightIcon={
                searchKeyword ? (
                  <button
                    onClick={() => {
                      setSearchKeyword('');
                      void fetchSongs();
                    }}
                    aria-label="清除搜索"
                  >
                    <X size={16} className="text-muted-foreground" />
                  </button>
                ) : undefined
              }
            />
          </div>

          {/* 歌曲列表 */}
          <div className="px-5">
            {songsLoading ? (
              <div className="flex justify-center py-12">
                <LoadingSpinner />
              </div>
            ) : songs.length === 0 ? (
              <EmptyState
                icon={<Music2 size={28} />}
                title="暂无歌曲"
                description="试试其他分类或关键词"
              />
            ) : (
              <div className="space-y-2">
                {songs.map((song, idx) => (
                  <div
                    key={song.id}
                    className="bg-card rounded-2xl shadow-sm p-4 flex items-center gap-3 border border-border/40"
                    style={{ animationDelay: `${idx * 30}ms` }}
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
                      <Music size={18} />
                    </div>
                    <div className="flex-1 min-w-0 relative">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-medium text-foreground truncate">
                          {song.title}
                        </h4>
                        {song.isSystem && (
                          <span className="flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium bg-accent-gold/15 text-accent-gold-dark">
                            推荐
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">
                        {song.artist}
                      </p>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] bg-secondary text-muted-foreground">
                        {getCategoryLabel(song.category)}
                      </span>
                    </div>
                    <button
                      onClick={() => handleAddToPlaylist(song)}
                      className="flex-shrink-0 w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center hover:bg-primary/20 active:scale-[0.92] transition-all"
                      aria-label={`加入歌单: ${song.title}`}
                    >
                      <Plus size={18} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* 我的歌单 Tab */}
      {activeTab === 'my' && (
        <div className="px-5">
          {/* 新建按钮 */}
          <div className="mb-4">
            <Button
              variant="primary"
              fullWidth
              onClick={() => {
                setSelectedSong(null);
                setShowAddDialog(true);
                setShowNewPlaylist(true);
                setNewPlaylistName('');
              }}
            >
              <Plus size={18} />
              新建歌单
            </Button>
          </div>

          {playlistsLoading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner />
            </div>
          ) : playlists.length === 0 ? (
            <EmptyState
              icon={<ListMusic size={28} />}
              title="还没有歌单"
              description="创建专属歌单，收藏你喜欢的婚礼音乐"
              action={
                <Button
                  variant="primary"
                  onClick={() => {
                    setShowAddDialog(true);
                    setShowNewPlaylist(true);
                  }}
                >
                  <Plus size={16} />
                  新建歌单
                </Button>
              }
            />
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {playlists.map(playlist => (
                <button
                  key={playlist.id}
                  onClick={() => navigate(`/bgm/playlist/${playlist.id}`)}
                  className="w-full bg-card rounded-2xl shadow-md p-5 flex items-center gap-4 text-left transition-all duration-200 active:scale-[0.98] hover:shadow-lg border border-border/40"
                >
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center text-white flex-shrink-0"
                    style={{
                      background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                    }}
                  >
                    <ListMusic size={22} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-base font-semibold text-foreground truncate">
                      {playlist.name}
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {playlist.songCount || 0} 首歌曲
                    </p>
                    <p className="text-xs text-muted-foreground/70 mt-0.5">
                      创建于 {formatDate(playlist.createdAt)}
                    </p>
                  </div>
                  <ChevronRight size={20} className="text-muted-foreground/50 flex-shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 加入歌单 / 新建歌单 对话框 */}
      <BottomSheet
        open={showAddDialog}
        onClose={() => {
          setShowAddDialog(false);
          setSelectedSong(null);
          setShowNewPlaylist(false);
          setNewPlaylistName('');
        }}
        title={selectedSong ? '加入歌单' : '新建歌单'}
        height="medium"
      >
        <div className="p-5">
          {selectedSong && (
            <div className="bg-secondary/60 rounded-xl p-4 mb-5 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
                <Music size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {selectedSong.title}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {selectedSong.artist}
                </p>
              </div>
            </div>
          )}

          {/* 新建歌单表单 */}
          {showNewPlaylist ? (
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-3">
                新建歌单
              </h4>
              <Input
                placeholder="请输入歌单名称"
                value={newPlaylistName}
                onChange={e => setNewPlaylistName(e.target.value)}
                containerClassName="mb-4"
              />
              <div className="flex gap-3">
                <Button
                  variant="secondary"
                  fullWidth
                  onClick={() => {
                    if (selectedSong) {
                      setShowNewPlaylist(false);
                    } else {
                      setShowAddDialog(false);
                    }
                  }}
                >
                  取消
                </Button>
                <Button
                  variant="primary"
                  fullWidth
                  onClick={() => void handleCreatePlaylist()}
                  loading={creatingPlaylist}
                >
                  <PlusCircle size={16} />
                  创建
                </Button>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-semibold text-foreground">
                  选择歌单
                </h4>
                <button
                  onClick={() => setShowNewPlaylist(true)}
                  className="text-xs text-primary font-medium flex items-center gap-1"
                >
                  <Plus size={14} />
                  新建歌单
                </button>
              </div>
              <div className="space-y-2 max-h-[40vh] overflow-y-auto">
                {playlists.length === 0 ? (
                  <EmptyState
                    icon={<ListMusic size={24} />}
                    title="还没有歌单"
                    description="点击上方新建歌单"
                  />
                ) : (
                  playlists.map(playlist => (
                    <button
                      key={playlist.id}
                      onClick={() => void handleConfirmAdd(playlist.id)}
                      disabled={addingSong}
                      className="w-full bg-card rounded-xl p-4 flex items-center gap-3 border border-border/50 hover:border-primary/30 hover:bg-secondary/30 transition-all active:scale-[0.98]"
                    >
                      <div className="w-9 h-9 rounded-lg bg-accent-gold/15 text-accent-gold flex items-center justify-center flex-shrink-0">
                        <ListMusic size={16} />
                      </div>
                      <div className="flex-1 min-w-0 text-left">
                        <p className="text-sm font-medium text-foreground truncate">
                          {playlist.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {playlist.songCount || 0} 首
                        </p>
                      </div>
                      <Plus size={16} className="text-primary flex-shrink-0" />
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </BottomSheet>
    </div>
  );
};

export default BgmPage;
