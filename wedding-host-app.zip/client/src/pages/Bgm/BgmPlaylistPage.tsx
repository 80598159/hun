import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Download,
  Upload,
  Edit3,
  Trash2,
  ChevronUp,
  ChevronDown,
  Plus,
  Copy,
  Music,
  Save,
} from 'lucide-react';
import { useToast } from '@client/src/components/ToastProvider';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import type {
  BgmPlaylistDetail,
  BgmPlaylistItem,
  BgmPurposeTag,
} from '@shared/api.interface';
import {
  getPlaylist,
  updatePlaylist,
  deletePlaylistItem,
  updatePlaylistItem,
  importPlaylist,
  exportPlaylist,
  addPlaylistSongs,
} from '@client/src/api/bgm';

const purposeTagLabels: { key: BgmPurposeTag; label: string; color: string }[] = [
  { key: 'warmup', label: '暖场', color: 'bg-amber-100 text-amber-700 border-amber-200' },
  { key: 'entrance', label: '入场', color: 'bg-red-100 text-red-700 border-red-200' },
  { key: 'climax', label: '高潮', color: 'bg-rose-100 text-rose-700 border-rose-200' },
  { key: 'exit', label: '退场', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  { key: 'other', label: '其他', color: 'bg-gray-100 text-gray-600 border-gray-200' },
];

const BgmPlaylistPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [detail, setDetail] = useState<BgmPlaylistDetail | null>(null);
  const [loading, setLoading] = useState(true);

  // 导入对话框
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState('');
  const [importDefaultTag, setImportDefaultTag] = useState<BgmPurposeTag>('warmup');
  const [importDefaultSegment, setImportDefaultSegment] = useState('');
  const [importing, setImporting] = useState(false);

  // 导出对话框
  const [showExport, setShowExport] = useState(false);
  const [exportText, setExportText] = useState('');
  const [exportLoading, setExportLoading] = useState(false);

  // 编辑歌曲对话框
  const [showEditSong, setShowEditSong] = useState(false);
  const [editingSong, setEditingSong] = useState<BgmPlaylistItem | null>(null);
  const [editForm, setEditForm] = useState({
    title: '',
    artist: '',
    segment: '',
    purposeTag: '' as BgmPurposeTag | '',
    note: '',
  });
  const [savingEdit, setSavingEdit] = useState(false);

  // 编辑歌单信息
  const [showEditInfo, setShowEditInfo] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [savingInfo, setSavingInfo] = useState(false);

  // 粘贴导入 / 从曲库添加
  const [showAddOptions, setShowAddOptions] = useState(false);

  // 新建歌曲对话框
  const [showNewSong, setShowNewSong] = useState(false);
  const [newSongForm, setNewSongForm] = useState({
    title: '',
    artist: '',
    segment: '',
    purposeTag: '' as BgmPurposeTag | '',
  });
  const [addingNewSong, setAddingNewSong] = useState(false);

  const fetchDetail = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const data = await getPlaylist(id);
      setDetail(data);
    } catch {
      showToast('加载歌单失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchDetail();
  }, [id]);

  const getTagStyle = (tag: BgmPurposeTag | null): string => {
    const found = purposeTagLabels.find(t => t.key === tag);
    return found ? found.color : 'bg-gray-100 text-gray-600 border-gray-200';
  };

  const getTagLabel = (tag: BgmPurposeTag | null): string => {
    const found = purposeTagLabels.find(t => t.key === tag);
    return found ? found.label : '未分类';
  };

  const handleExport = async () => {
    if (!id) return;
    setExportLoading(true);
    try {
      const data = await exportPlaylist(id);
      setExportText(data.text || '');
      setShowExport(true);
    } catch {
      showToast('导出失败', 'error');
    } finally {
      setExportLoading(false);
    }
  };

  const handleCopyExport = async () => {
    try {
      await navigator.clipboard.writeText(exportText);
      showToast('已复制到剪贴板', 'success');
    } catch {
      showToast('复制失败，请手动复制', 'error');
    }
  };

  const handleImport = async () => {
    if (!id) return;
    if (!importText.trim()) {
      showToast('请输入歌曲列表', 'warning');
      return;
    }
    setImporting(true);
    try {
      await importPlaylist(id, {
        text: importText,
        defaultPurposeTag: importDefaultTag,
        defaultSegment: importDefaultSegment || undefined,
      });
      showToast('导入成功', 'success');
      setShowImport(false);
      setImportText('');
      void fetchDetail();
    } catch {
      showToast('导入失败，请检查格式', 'error');
    } finally {
      setImporting(false);
    }
  };

  const openEditSong = (song: BgmPlaylistItem) => {
    setEditingSong(song);
    setEditForm({
      title: song.title,
      artist: song.artist,
      segment: song.segment || '',
      purposeTag: song.purposeTag || '',
      note: song.note || '',
    });
    setShowEditSong(true);
  };

  const handleSaveEdit = async () => {
    if (!id || !editingSong) return;
    if (!editForm.title.trim()) {
      showToast('请输入歌曲名', 'warning');
      return;
    }
    setSavingEdit(true);
    try {
      await updatePlaylistItem(id, editingSong.id, {
        title: editForm.title,
        artist: editForm.artist,
        segment: editForm.segment,
        purposeTag: editForm.purposeTag || undefined,
        note: editForm.note,
      });
      showToast('保存成功', 'success');
      setShowEditSong(false);
      setEditingSong(null);
      void fetchDetail();
    } catch {
      showToast('保存失败', 'error');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDeleteSong = async (itemId: string) => {
    if (!id) return;
    try {
      await deletePlaylistItem(id, itemId);
      showToast('已删除', 'success');
      void fetchDetail();
    } catch {
      showToast('删除失败', 'error');
    }
  };

  const handleMoveSong = async (index: number, direction: 'up' | 'down') => {
    if (!id || !detail) return;
    const items = [...detail.items];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= items.length) return;

    const current = items[index];
    const target = items[targetIndex];

    try {
      await updatePlaylistItem(id, current.id, {
        sortOrder: target.sortOrder,
      });
      await updatePlaylistItem(id, target.id, {
        sortOrder: current.sortOrder,
      });
      void fetchDetail();
    } catch {
      showToast('排序失败', 'error');
    }
  };

  const openEditInfo = () => {
    if (!detail) return;
    setEditName(detail.name);
    setEditDesc(detail.description || '');
    setShowEditInfo(true);
  };

  const handleSaveInfo = async () => {
    if (!id) return;
    if (!editName.trim()) {
      showToast('请输入歌单名称', 'warning');
      return;
    }
    setSavingInfo(true);
    try {
      await updatePlaylist(id, {
        name: editName.trim(),
        description: editDesc,
      });
      showToast('保存成功', 'success');
      setShowEditInfo(false);
      void fetchDetail();
    } catch {
      showToast('保存失败', 'error');
    } finally {
      setSavingInfo(false);
    }
  };

  const handleAddNewSong = async () => {
    if (!id) return;
    if (!newSongForm.title.trim()) {
      showToast('请输入歌曲名', 'warning');
      return;
    }
    setAddingNewSong(true);
    try {
      await addPlaylistSongs(id, {
        songs: [
          {
            title: newSongForm.title,
            artist: newSongForm.artist,
            purposeTag: newSongForm.purposeTag || undefined,
            segment: newSongForm.segment || undefined,
          },
        ],
      });
      showToast('添加成功', 'success');
      setShowNewSong(false);
      setNewSongForm({ title: '', artist: '', segment: '', purposeTag: '' });
      void fetchDetail();
    } catch {
      showToast('添加失败', 'error');
    } finally {
      setAddingNewSong(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (!detail) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <EmptyState title="歌单不存在" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-36 page-enter">
      {/* 顶部导航 */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm px-5 pt-3 pb-3 flex items-center justify-between border-b border-border/50">
        <Link
          to="/bgm"
          className="w-10 h-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground transition-colors"
          aria-label="返回"
        >
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-base font-semibold text-foreground flex-1 text-center truncate px-2">
          {detail.name}
        </h1>
        <div className="flex items-center gap-1">
          <button
            onClick={() => void handleExport()}
            className="w-9 h-9 rounded-full hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
            aria-label="导出"
          >
            <Download size={18} />
          </button>
          <button
            onClick={() => setShowImport(true)}
            className="w-9 h-9 rounded-full hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
            aria-label="导入"
          >
            <Upload size={18} />
          </button>
          <button
            onClick={openEditInfo}
            className="w-9 h-9 rounded-full hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
            aria-label="编辑"
          >
            <Edit3 size={18} />
          </button>
        </div>
      </div>

      {/* 歌单信息卡片 */}
      <div className="px-5 pt-5">
        <div
          className="rounded-2xl p-5 text-white shadow-lg"
          style={{
            background: 'linear-gradient(135deg, #2C0A14 0%, #5C1525 50%, #B91C3C 100%)',
          }}
        >
          <h2 className="font-serif text-xl font-bold tracking-tight mb-1">
            {detail.name}
          </h2>
          {detail.description && (
            <p className="text-sm text-white/70 mb-4 leading-relaxed">
              {detail.description}
            </p>
          )}
          <div className="flex items-center gap-4 text-sm text-white/70">
            <span className="flex items-center gap-1">
              <Music size={14} />
              {detail.items.length} 首歌曲
            </span>
          </div>
        </div>
      </div>

      {/* 歌曲列表 */}
      <div className="px-5 pt-5">
        <h3 className="text-base font-semibold text-foreground mb-3">
          歌曲列表
        </h3>
        {detail.items.length === 0 ? (
          <EmptyState
            icon={<Music size={28} />}
            title="歌单还没有歌曲"
            description="点击下方按钮添加歌曲"
          />
        ) : (
          <div className="space-y-2">
            {detail.items.map((item, index) => (
              <div
                key={item.id}
                className="bg-card rounded-2xl shadow-sm p-4 border border-border/40"
              >
                <div className="flex items-start gap-3">
                  {/* 序号 */}
                  <div className="w-7 h-7 rounded-lg bg-accent-gold/15 text-accent-gold-dark flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </div>

                  {/* 歌曲信息 */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-semibold text-foreground truncate">
                        {item.title}
                      </h4>
                      <span
                        className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium border ${getTagStyle(item.purposeTag)}`}
                      >
                        {getTagLabel(item.purposeTag)}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {item.artist || '未知歌手'}
                    </p>
                    {item.segment && (
                      <p className="text-xs text-muted-foreground/80 mt-1">
                        环节：{item.segment}
                      </p>
                    )}
                    {item.note && (
                      <p className="text-xs text-muted-foreground/70 mt-1 italic">
                        备注：{item.note}
                      </p>
                    )}
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-0.5 flex-shrink-0">
                    <button
                      onClick={() => void handleMoveSong(index, 'up')}
                      disabled={index === 0}
                      className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
                      aria-label="上移"
                    >
                      <ChevronUp size={16} />
                    </button>
                    <button
                      onClick={() => void handleMoveSong(index, 'down')}
                      disabled={index === detail.items.length - 1}
                      className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
                      aria-label="下移"
                    >
                      <ChevronDown size={16} />
                    </button>
                    <button
                      onClick={() => openEditSong(item)}
                      className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                      aria-label="编辑"
                    >
                      <Edit3 size={15} />
                    </button>
                    <button
                      onClick={() => void handleDeleteSong(item.id)}
                      className="w-8 h-8 rounded-lg hover:bg-destructive/10 flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors"
                      aria-label="删除"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 底部浮动操作区 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-gradient-to-t from-background via-background to-transparent pt-6 pb-6 px-5">
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="secondary"
            fullWidth
            onClick={() => {
              setNewSongForm({ title: '', artist: '', segment: '', purposeTag: '' });
              setShowNewSong(true);
            }}
          >
            <Plus size={16} />
            手动添加
          </Button>
          <Button
            variant="primary"
            fullWidth
            onClick={() => setShowImport(true)}
          >
            <Upload size={16} />
            粘贴导入
          </Button>
        </div>
      </div>

      {/* 导入对话框 */}
      <BottomSheet
        open={showImport}
        onClose={() => setShowImport(false)}
        title="粘贴导入歌曲"
        height="large"
      >
        <div className="p-5">
          <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
            每行一首，格式：歌名-歌手（歌手可省略）
            <br />
            例：
            <br />
            今天你要嫁给我-陶喆
            <br />
            婚礼进行曲
          </p>
          <TextArea
            placeholder="今天你要嫁给我-陶喆&#10;婚礼进行曲&#10;甜蜜蜜-邓丽君"
            value={importText}
            onChange={e => setImportText(e.target.value)}
            rows={8}
            containerClassName="mb-4"
          />
          <div className="grid grid-cols-2 gap-3 mb-5">
            <div>
              <label className="block text-xs font-medium text-foreground/80 mb-2">
                默认用途标签
              </label>
              <select
                value={importDefaultTag}
                onChange={e => setImportDefaultTag(e.target.value as BgmPurposeTag)}
                className="w-full h-10 px-3 rounded-xl border border-input bg-secondary/60 text-sm text-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15"
              >
                {purposeTagLabels.map(tag => (
                  <option key={tag.key} value={tag.key}>
                    {tag.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-foreground/80 mb-2">
                默认环节
              </label>
              <Input
                placeholder="如：暖场"
                value={importDefaultSegment}
                onChange={e => setImportDefaultSegment(e.target.value)}
              />
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="secondary" fullWidth onClick={() => setShowImport(false)}>
              取消
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={() => void handleImport()}
              loading={importing}
            >
              导入
            </Button>
          </div>
        </div>
      </BottomSheet>

      {/* 导出对话框 */}
      <BottomSheet
        open={showExport}
        onClose={() => setShowExport(false)}
        title="导出歌单"
        height="large"
      >
        <div className="p-5">
          <div className="bg-secondary/60 rounded-xl p-4 mb-4 border border-border/50">
            <pre className="text-xs text-foreground/80 leading-relaxed whitespace-pre-wrap font-sans">
              {exportText || '暂无内容'}
            </pre>
          </div>
          <Button variant="primary" fullWidth onClick={() => void handleCopyExport()}>
            <Copy size={16} />
            一键复制
          </Button>
        </div>
      </BottomSheet>

      {/* 编辑歌曲对话框 */}
      <BottomSheet
        open={showEditSong}
        onClose={() => {
          setShowEditSong(false);
          setEditingSong(null);
        }}
        title="编辑歌曲"
        height="large"
      >
        <div className="p-5 space-y-4">
          <Input
            label="歌曲名"
            value={editForm.title}
            onChange={e => setEditForm(prev => ({ ...prev, title: e.target.value }))}
            placeholder="请输入歌曲名"
          />
          <Input
            label="歌手"
            value={editForm.artist}
            onChange={e => setEditForm(prev => ({ ...prev, artist: e.target.value }))}
            placeholder="请输入歌手名"
          />
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              用途标签
            </label>
            <div className="flex flex-wrap gap-2">
              {purposeTagLabels.map(tag => (
                <button
                  key={tag.key}
                  onClick={() =>
                    setEditForm(prev => ({
                      ...prev,
                      purposeTag: prev.purposeTag === tag.key ? '' : tag.key,
                    }))
                  }
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                    editForm.purposeTag === tag.key
                      ? `${tag.color} border-transparent`
                      : 'bg-card text-muted-foreground border-border hover:border-primary/30'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>
          <Input
            label="所属环节"
            value={editForm.segment}
            onChange={e => setEditForm(prev => ({ ...prev, segment: e.target.value }))}
            placeholder="如：新人入场、誓言环节"
          />
          <TextArea
            label="备注"
            value={editForm.note}
            onChange={e => setEditForm(prev => ({ ...prev, note: e.target.value }))}
            placeholder="可选备注信息"
            rows={3}
          />
          <div className="flex gap-3 pt-2">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => {
                setShowEditSong(false);
                setEditingSong(null);
              }}
            >
              取消
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={() => void handleSaveEdit()}
              loading={savingEdit}
            >
              <Save size={16} />
              保存
            </Button>
          </div>
        </div>
      </BottomSheet>

      {/* 编辑歌单信息对话框 */}
      <BottomSheet
        open={showEditInfo}
        onClose={() => setShowEditInfo(false)}
        title="编辑歌单"
        height="medium"
      >
        <div className="p-5 space-y-4">
          <Input
            label="歌单名称"
            value={editName}
            onChange={e => setEditName(e.target.value)}
            placeholder="请输入歌单名称"
          />
          <TextArea
            label="歌单描述"
            value={editDesc}
            onChange={e => setEditDesc(e.target.value)}
            placeholder="简单介绍一下这个歌单"
            rows={3}
          />
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" fullWidth onClick={() => setShowEditInfo(false)}>
              取消
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={() => void handleSaveInfo()}
              loading={savingInfo}
            >
              <Save size={16} />
              保存
            </Button>
          </div>
        </div>
      </BottomSheet>

      {/* 手动添加歌曲对话框 */}
      <BottomSheet
        open={showNewSong}
        onClose={() => {
          setShowNewSong(false);
          setNewSongForm({ title: '', artist: '', segment: '', purposeTag: '' });
        }}
        title="添加歌曲"
        height="large"
      >
        <div className="p-5 space-y-4">
          <Input
            label="歌曲名"
            value={newSongForm.title}
            onChange={e => setNewSongForm(prev => ({ ...prev, title: e.target.value }))}
            placeholder="请输入歌曲名"
          />
          <Input
            label="歌手"
            value={newSongForm.artist}
            onChange={e => setNewSongForm(prev => ({ ...prev, artist: e.target.value }))}
            placeholder="请输入歌手名"
          />
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              用途标签
            </label>
            <div className="flex flex-wrap gap-2">
              {purposeTagLabels.map(tag => (
                <button
                  key={tag.key}
                  onClick={() =>
                    setNewSongForm(prev => ({
                      ...prev,
                      purposeTag: prev.purposeTag === tag.key ? '' : tag.key,
                    }))
                  }
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                    newSongForm.purposeTag === tag.key
                      ? `${tag.color} border-transparent`
                      : 'bg-card text-muted-foreground border-border hover:border-primary/30'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>
          <Input
            label="所属环节"
            value={newSongForm.segment}
            onChange={e => setNewSongForm(prev => ({ ...prev, segment: e.target.value }))}
            placeholder="如：新人入场、誓言环节"
          />
          <div className="flex gap-3 pt-2">
            <Button
              variant="secondary"
              fullWidth
              onClick={() => {
                setShowNewSong(false);
                setNewSongForm({ title: '', artist: '', segment: '', purposeTag: '' });
              }}
            >
              取消
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={() => void handleAddNewSong()}
              loading={addingNewSong}
            >
              <Plus size={16} />
              添加
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default BgmPlaylistPage;
