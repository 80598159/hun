import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Pencil,
  Trash2,
  Calendar as CalendarIcon,
  AlertCircle,
  MapPin,
  Share2,
  Link2,
  Sparkles,
} from 'lucide-react';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import WeddingShareSheet from '@client/src/components/WeddingShareSheet/WeddingShareSheet';
import { useToast } from '@client/src/components/ToastProvider';
import {
  getSchedules,
  createSchedule,
  updateSchedule,
  deleteSchedule,
  checkConflict,
} from '@client/src/api/schedule';
import type { Schedule } from '@shared/api.interface';
import { showConfirm } from '@lark-apaas/client-toolkit';

const WEEK_DAYS = ['日', '一', '二', '三', '四', '五', '六'];
const WEEK_DAY_NAMES = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

type ViewMode = 'calendar' | 'list';

function formatDate(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getMonthDays(year: number, month: number): Date[] {
  const firstDay = new Date(year, month, 1);
  const startOffset = firstDay.getDay();
  const gridStart = new Date(year, month, 1 - startOffset);
  const days: Date[] = [];
  for (let i = 0; i < 42; i++) {
    days.push(new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i));
  }
  return days;
}

function getMonthSchedules(schedules: Schedule[], year: number, month: number): Schedule[] {
  const prefix = `${year}-${String(month + 1).padStart(2, '0')}`;
  return schedules
    .filter(s => s.weddingDate.startsWith(prefix))
    .sort((a, b) => {
      if (a.weddingDate !== b.weddingDate) return a.weddingDate < b.weddingDate ? -1 : 1;
      if (a.timeType === 'lunch' && b.timeType === 'dinner') return -1;
      if (a.timeType === 'dinner' && b.timeType === 'lunch') return 1;
      return 0;
    });
}

function groupByDate(schedules: Schedule[]): Map<string, Schedule[]> {
  const map = new Map<string, Schedule[]>();
  for (const s of schedules) {
    if (!map.has(s.weddingDate)) map.set(s.weddingDate, []);
    map.get(s.weddingDate)!.push(s);
  }
  return map;
}

const SchedulePage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const today = new Date();
  const [viewMode, setViewMode] = useState<ViewMode>('calendar');
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState<string>(formatDate(today));
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
  const [formData, setFormData] = useState({
    weddingDate: formatDate(today),
    timeType: 'lunch' as 'lunch' | 'dinner',
    coupleName: '',
    hotelName: '',
    notes: '',
  });
  const [conflictWarning, setConflictWarning] = useState<string | null>(null);
  const [submitLoading, setSubmitLoading] = useState(false);

  // 分享面板
  const [shareSheetOpen, setShareSheetOpen] = useState(false);
  const [shareProjectId, setShareProjectId] = useState<string>('');

  const calendarDays = useMemo(
    () => getMonthDays(currentYear, currentMonth),
    [currentYear, currentMonth]
  );

  const todayStr = formatDate(today);

  // 按日期分组的档期映射
  const schedulesByDate = useMemo(() => groupByDate(schedules), [schedules]);

  // 选中日期的档期
  const selectedDateSchedules = useMemo(
    () => schedulesByDate.get(selectedDate) ?? [],
    [schedulesByDate, selectedDate]
  );

  // 列表视图按日期分组的数据
  const listMonthSchedules = useMemo(
    () => getMonthSchedules(schedules, currentYear, currentMonth),
    [schedules, currentYear, currentMonth]
  );

  // 加载当月档期
  useEffect(() => {
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const startDate = formatDate(firstDay);
    const endDate = formatDate(lastDay);
    setLoading(true);
    getSchedules({ startDate, endDate })
      .then((data: Schedule[]) => {
        setSchedules(data);
      })
      .catch(() => {
        showToast('获取档期失败', 'error');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [currentYear, currentMonth, showToast]);

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentYear(currentYear - 1);
      setCurrentMonth(11);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentYear(currentYear + 1);
      setCurrentMonth(0);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(formatDate(date));
  };

  const openCreateSheet = (dateStr?: string) => {
    setEditingSchedule(null);
    setFormData({
      weddingDate: dateStr ?? selectedDate,
      timeType: 'lunch',
      coupleName: '',
      hotelName: '',
      notes: '',
    });
    setConflictWarning(null);
    setSheetOpen(true);
  };

  const openEditSheet = (schedule: Schedule) => {
    setEditingSchedule(schedule);
    setFormData({
      weddingDate: schedule.weddingDate,
      timeType: schedule.timeType,
      coupleName: schedule.coupleName,
      hotelName: schedule.hotelName,
      notes: schedule.notes,
    });
    setConflictWarning(null);
    setSheetOpen(true);
  };

  const openShareSheet = (schedule: Schedule) => {
    if (!schedule.projectId) {
      showToast('该档期未关联婚礼方案，无法分享', 'warning');
      return;
    }
    setShareProjectId(schedule.projectId);
    setShareSheetOpen(true);
  };

  const closeSheet = () => {
    setSheetOpen(false);
    setEditingSchedule(null);
    setConflictWarning(null);
  };

  const handleDelete = async (id: string) => {
    if (!await showConfirm('确认删除该档期？')) return;
    try {
      await deleteSchedule(id);
      setSchedules(prev => prev.filter(s => s.id !== id));
      showToast('删除成功', 'success');
    } catch {
      showToast('删除失败', 'error');
    }
  };

  const handleSubmit = async () => {
    if (!formData.weddingDate) {
      showToast('请选择日期', 'warning');
      return;
    }
    if (!formData.coupleName.trim()) {
      showToast('请填写新人名称', 'warning');
      return;
    }

    setSubmitLoading(true);
    try {
      // 撞单检测（编辑时排除自身）
      const conflictData = await checkConflict(formData.weddingDate, formData.timeType);
      const hasOtherConflict =
        conflictData?.hasConflict &&
        (!editingSchedule ||
          (conflictData.conflictSchedules as Schedule[]).some(
            (s: Schedule) => s.id !== editingSchedule.id
          ));

      if (hasOtherConflict && !conflictWarning) {
        setConflictWarning('该时段已有档期，是否确认添加？');
        setSubmitLoading(false);
        return;
      }

      if (editingSchedule) {
        const updated = await updateSchedule(editingSchedule.id, formData);
        setSchedules(prev => prev.map(s => (s.id === editingSchedule.id ? updated : s)));
        showToast('更新成功', 'success');
      } else {
        const created = await createSchedule(formData);
        setSchedules(prev => [...prev, created]);
        showToast('创建成功', 'success');
      }
      closeSheet();
    } catch (err: unknown) {
      // 捕获 409 撞单错误
      const error = err as { response?: { status?: number; data?: { error?: { message?: string } } } };
      if (error.response?.status === 409 && !conflictWarning) {
        setConflictWarning(error.response.data?.error?.message ?? '该时段已有档期，是否确认添加？');
      } else {
        showToast(editingSchedule ? '更新失败' : '创建失败', 'error');
      }
    } finally {
      setSubmitLoading(false);
    }
  };

  const forceSubmit = async () => {
    setSubmitLoading(true);
    try {
      if (editingSchedule) {
        const updated = await updateSchedule(editingSchedule.id, { ...formData, force: true });
        setSchedules(prev => prev.map(s => (s.id === editingSchedule.id ? updated : s)));
        showToast('更新成功', 'success');
      } else {
        const created = await createSchedule({ ...formData, force: true });
        setSchedules(prev => [...prev, created]);
        showToast('创建成功', 'success');
      }
      closeSheet();
    } catch {
      showToast(editingSchedule ? '更新失败' : '创建失败', 'error');
    } finally {
      setSubmitLoading(false);
    }
  };

  const renderDateCell = (date: Date, index: number) => {
    const dateStr = formatDate(date);
    const isCurrentMonth = date.getMonth() === currentMonth;
    const isToday = dateStr === todayStr;
    const isSelected = dateStr === selectedDate;
    const daySchedules = schedulesByDate.get(dateStr) ?? [];
    const isPast = dateStr < todayStr;
    const hasSchedule = daySchedules.length > 0;
    const hasLunch = daySchedules.some(s => s.timeType === 'lunch');
    const hasDinner = daySchedules.some(s => s.timeType === 'dinner');

    const todayStyle: React.CSSProperties | undefined = isToday
      ? {
          backgroundColor: 'transparent',
          background: 'transparent',
          border: '2px solid #B91C3C',
          boxSizing: 'border-box',
        }
      : undefined;

    return (
      <button
        key={index}
        onClick={() => handleDateClick(date)}
        style={todayStyle}
        className={`
          relative flex flex-col items-center justify-center py-2 text-sm rounded-lg transition-all
          ${isSelected && !isToday ? 'bg-primary text-white font-medium' : ''}
          ${isSelected && isToday ? 'text-primary font-bold' : ''}
          ${!isSelected && !isToday && hasSchedule && isCurrentMonth && !isPast ? 'bg-primary/90 text-white font-medium' : ''}
          ${!isSelected && !isToday && hasSchedule && isCurrentMonth && isPast ? 'bg-[#E8F0FA] text-[#4A7BA0] font-medium' : ''}
          ${!isSelected && !hasSchedule && isCurrentMonth ? 'text-foreground' : ''}
          ${!isSelected && isToday && !hasSchedule ? 'text-foreground' : ''}
          ${!isSelected && isToday && hasSchedule ? 'text-primary font-medium' : ''}
          ${!isSelected && !isCurrentMonth ? 'text-muted-foreground/40' : ''}
          hover:bg-primary/20
        `}
        aria-label={`${dateStr} 档期`}
      >
        <span className="relative">
          {date.getDate()}
        </span>
        {hasSchedule && (
          <div className="flex gap-0.5 mt-1">
            {hasLunch && (
              <span
                className={`w-1.5 h-1.5 rounded-full ${isSelected || !isCurrentMonth ? 'bg-white/80' : isPast ? 'bg-[#4A7BA0]' : 'bg-white'}`}
              />
            )}
            {hasDinner && (
              <span
                className={`w-1.5 h-1.5 rounded-full ${isSelected || !isCurrentMonth ? 'bg-white/60' : isPast ? 'bg-[#7EA3C4]' : 'bg-accent-gold'}`}
              />
            )}
          </div>
        )}
      </button>
    );
  };

  const renderScheduleCard = (schedule: Schedule) => (
    <div key={schedule.id} className="bg-card rounded-2xl shadow-sm p-4 relative">
      <div className="flex items-start justify-between mb-2">
        <span
          className={`
            rounded-full px-3 py-1 text-xs font-medium
            ${schedule.timeType === 'lunch'
              ? 'bg-accent-gold/15 text-accent-gold'
              : 'bg-primary/10 text-primary'}
          `}
        >
          {schedule.timeType === 'lunch' ? '午宴' : '晚宴'}
        </span>
        <div className="flex gap-0.5">
          <button
            onClick={() => openShareSheet(schedule)}
            className="p-2 text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
            aria-label="分享共创"
          >
            <Share2 size={16} />
          </button>
          <button
            onClick={() => openEditSheet(schedule)}
            className="p-2 text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
            aria-label="编辑档期"
          >
            <Pencil size={16} />
          </button>
          <button
            onClick={() => handleDelete(schedule.id)}
            className="p-2 text-muted-foreground hover:text-destructive transition-colors rounded-full hover:bg-destructive/5"
            aria-label="删除档期"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
      <h4 className="text-lg font-semibold text-foreground mb-1.5">
        {schedule.coupleName || '未填写新人名称'}
      </h4>
      {schedule.hotelName && (
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-1.5">
          <MapPin size={14} className="flex-shrink-0" />
          <span className="truncate">{schedule.hotelName}</span>
        </div>
      )}
      {schedule.notes && (
        <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
          {schedule.notes}
        </p>
      )}
      {schedule.projectId && (
        <button
          onClick={() => navigate(`/wedding/${schedule.projectId}`)}
          className="mt-3 flex items-center justify-between w-full px-3 py-2 rounded-xl transition-all"
          style={{ background: 'linear-gradient(135deg, rgba(185, 28, 60, 0.05), rgba(201, 169, 97, 0.06))', border: '1px solid rgba(201, 169, 97, 0.2)' }}
        >
          <div className="flex items-center gap-2">
            {schedule.source === 'auto_from_project' ? (
              <Sparkles size={13} style={{ color: '#C9A961' }} />
            ) : (
              <Link2 size={13} style={{ color: '#B91C3C' }} />
            )}
            <span className="text-xs font-medium" style={{ color: schedule.source === 'auto_from_project' ? '#C9A961' : '#B91C3C' }}>
              {schedule.source === 'auto_from_project' ? '由方案自动创建' : '已关联方案'}
            </span>
          </div>
          <span className="text-xs" style={{ color: '#6B5C5C' }}>查看方案 →</span>
        </button>
      )}
    </div>
  );

  const renderCalendarView = () => (
    <div className="space-y-5">
      {/* 月份切换 */}
      <div className="flex items-center justify-between">
        <button
          onClick={prevMonth}
          className="p-2 text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
          aria-label="上个月"
        >
          <ChevronLeft size={22} />
        </button>
        <h2 className="font-serif text-xl font-semibold text-foreground tracking-tight">
          {currentYear}年{currentMonth + 1}月
        </h2>
        <button
          onClick={nextMonth}
          className="p-2 text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
          aria-label="下个月"
        >
          <ChevronRight size={22} />
        </button>
      </div>

      {/* 日历卡片 */}
      <div className="bg-card rounded-2xl shadow-md p-4">
        {/* 星期头 */}
        <div className="grid grid-cols-7 mb-1">
          {WEEK_DAYS.map((day, i) => (
            <div
              key={i}
              className="text-center text-xs font-medium text-muted-foreground py-1.5"
            >
              {day}
            </div>
          ))}
        </div>
        {/* 日期格子 */}
        <div className="grid grid-cols-7 gap-0.5">
          {loading
            ? Array.from({ length: 42 }).map((_, i) => (
                <div key={i} className="py-2 flex items-center justify-center">
                  <div className="w-6 h-6 rounded-full bg-muted animate-pulse" />
                </div>
              ))
            : calendarDays.map((date, i) => renderDateCell(date, i))}
        </div>
      </div>

      {/* 选中日期详情 */}
      <div className="pb-20">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-serif text-lg font-semibold text-foreground">
            当日档期
          </h3>
          <span className="text-sm text-muted-foreground">
            共 {selectedDateSchedules.length} 场
          </span>
        </div>

        {selectedDateSchedules.length === 0 ? (
          <EmptyState
            icon={<CalendarIcon size={28} />}
            title="当日暂无档期"
            description="点击右下角 + 添加档期"
          />
        ) : (
          <div className="space-y-3">
            {selectedDateSchedules.map(schedule => renderScheduleCard(schedule))}
          </div>
        )}
      </div>
    </div>
  );

  const renderListView = () => {
    if (loading) {
      return (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-card rounded-2xl shadow-sm p-4 animate-pulse">
              <div className="flex gap-4">
                <div className="w-16 h-20 bg-muted rounded-xl" />
                <div className="flex-1 space-y-2">
                  <div className="h-5 w-32 bg-muted rounded" />
                  <div className="h-4 w-40 bg-muted rounded" />
                  <div className="h-4 w-24 bg-muted rounded" />
                </div>
              </div>
            </div>
          ))}
        </div>
      );
    }

    if (listMonthSchedules.length === 0) {
      return (
        <EmptyState
          icon={<CalendarIcon size={28} />}
          title="本月暂无档期"
          description="点击右下角 + 添加档期"
        />
      );
    }

    // 按日期分组展示
    const dateGroups = Array.from(groupByDate(listMonthSchedules).entries()).sort(
      (a, b) => (a[0] < b[0] ? -1 : 1)
    );

    return (
      <div className="space-y-5 pb-20">
        {/* 月份分组标题 */}
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-xl font-semibold text-foreground tracking-tight">
            {currentYear}年{currentMonth + 1}月
            <span className="text-muted-foreground font-normal text-base ml-2">
              · {listMonthSchedules.length}场
            </span>
          </h3>
          <div className="flex gap-1">
            <button
              onClick={prevMonth}
              className="p-1.5 text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
              aria-label="上个月"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={nextMonth}
              className="p-1.5 text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
              aria-label="下个月"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {dateGroups.map(([dateStr, daySchedules]) => {
            const date = new Date(dateStr);
            const day = date.getDate();
            const weekDay = WEEK_DAY_NAMES[date.getDay()];
            const isToday = dateStr === todayStr;

            return (
              <div key={dateStr} className="space-y-2">
                {/* 日期分隔 */}
                <div className="flex items-center gap-2 px-1">
                  <div
                    className={`
                      font-serif font-semibold text-lg
                      ${isToday ? 'text-primary' : 'text-foreground'}
                    `}
                  >
                    {day}
                  </div>
                  <div className="text-xs text-muted-foreground">{weekDay}</div>
                  {isToday && (
                    <span className="rounded-full bg-primary/10 text-primary text-xs px-2 py-0.5 font-medium">
                      今天
                    </span>
                  )}
                  <div className="flex-1 h-px bg-border/60" />
                </div>

                {daySchedules.map(schedule => (
                  <div
                    key={schedule.id}
                    className="bg-card rounded-2xl shadow-sm p-4 active:scale-[0.99] transition-transform"
                  >
                    <div className="flex gap-4">
                      {/* 左侧日期块 */}
                      <div className="flex flex-col items-center justify-center w-14 flex-shrink-0">
                        <span
                          className={`
                            rounded-full px-2.5 py-1 text-xs font-medium mb-1
                            ${schedule.timeType === 'lunch'
                              ? 'bg-accent-gold/15 text-accent-gold'
                              : 'bg-primary/10 text-primary'}
                          `}
                        >
                          {schedule.timeType === 'lunch' ? '午宴' : '晚宴'}
                        </span>
                      </div>

                      {/* 右侧内容 */}
                      <div className="flex-1 min-w-0">
                        <h4 className="text-base font-semibold text-foreground mb-1 truncate">
                          {schedule.coupleName || '未填写新人名称'}
                        </h4>
                        {schedule.hotelName && (
                          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-1">
                            <MapPin size={13} className="flex-shrink-0" />
                            <span className="truncate">{schedule.hotelName}</span>
                          </div>
                        )}
                        {schedule.notes && (
                          <p className="text-sm text-muted-foreground/80 line-clamp-1">
                            {schedule.notes}
                          </p>
                        )}
                      </div>

                      {/* 操作按钮 */}
                      <div className="flex flex-col gap-1 flex-shrink-0">
                        <button
                          onClick={() => openShareSheet(schedule)}
                          className="p-1.5 text-muted-foreground hover:text-primary transition-colors rounded-full"
                          aria-label="分享共创"
                        >
                          <Share2 size={15} />
                        </button>
                        <button
                          onClick={() => openEditSheet(schedule)}
                          className="p-1.5 text-muted-foreground hover:text-primary transition-colors rounded-full"
                          aria-label="编辑档期"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          onClick={() => handleDelete(schedule.id)}
                          className="p-1.5 text-muted-foreground hover:text-destructive transition-colors rounded-full"
                          aria-label="删除档期"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="档期日历" onBack={() => navigate(-1)} />

      {/* 视图切换 Tab */}
      <div className="mb-5 flex justify-center">
        <div className="inline-flex bg-muted p-1 rounded-full">
          <button
            onClick={() => setViewMode('calendar')}
            className={`
              px-6 py-2 text-sm font-medium rounded-full transition-all
              ${viewMode === 'calendar'
                ? 'bg-primary text-white shadow-sm'
                : 'text-muted-foreground hover:text-foreground'}
            `}
          >
            日历视图
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`
              px-6 py-2 text-sm font-medium rounded-full transition-all
              ${viewMode === 'list'
                ? 'bg-primary text-white shadow-sm'
                : 'text-muted-foreground hover:text-foreground'}
            `}
          >
            列表视图
          </button>
        </div>
      </div>

      {/* 视图内容 */}
      <div className="page-enter">
        {viewMode === 'calendar' ? renderCalendarView() : renderListView()}
      </div>

      {/* FAB 悬浮按钮 */}
      <button
        onClick={() => openCreateSheet()}
        className="fixed bottom-24 right-5 w-14 h-14 rounded-full bg-primary text-white shadow-lg flex items-center justify-center hover:bg-primary-dark transition-all active:scale-[0.95] z-30"
        style={{ boxShadow: '0 4px 16px rgba(185, 28, 60, 0.35)' }}
        aria-label="新建档期"
      >
        <Plus size={26} strokeWidth={2.5} />
      </button>

      {/* 新建/编辑 BottomSheet */}
      <BottomSheet
        open={sheetOpen}
        onClose={closeSheet}
        title={editingSchedule ? '编辑档期' : '新建档期'}
        height="large"
      >
        <div className="px-5 py-5 space-y-5">
          <Input
            label="日期"
            type="date"
            value={formData.weddingDate}
            onChange={e =>
              setFormData(prev => ({ ...prev, weddingDate: e.target.value }))
            }
          />

          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              时段
            </label>
            <div className="flex gap-3">
              <button
                onClick={() => setFormData(prev => ({ ...prev, timeType: 'lunch' }))}
                className={`
                  flex-1 h-12 rounded-xl text-sm font-medium transition-all
                  ${formData.timeType === 'lunch'
                    ? 'bg-accent-gold/15 text-accent-gold border-2 border-accent-gold/40 shadow-sm'
                    : 'bg-muted text-muted-foreground border-2 border-transparent hover:bg-muted/80'}
                `}
              >
                午宴
              </button>
              <button
                onClick={() => setFormData(prev => ({ ...prev, timeType: 'dinner' }))}
                className={`
                  flex-1 h-12 rounded-xl text-sm font-medium transition-all
                  ${formData.timeType === 'dinner'
                    ? 'bg-primary/10 text-primary border-2 border-primary/40 shadow-sm'
                    : 'bg-muted text-muted-foreground border-2 border-transparent hover:bg-muted/80'}
                `}
              >
                晚宴
              </button>
            </div>
          </div>

          <Input
            label="新人名称"
            placeholder="如：张先生 &amp; 李小姐"
            value={formData.coupleName}
            onChange={e =>
              setFormData(prev => ({ ...prev, coupleName: e.target.value }))
            }
          />

          <Input
            label="酒店名称"
            placeholder="请输入酒店名称"
            value={formData.hotelName}
            onChange={e =>
              setFormData(prev => ({ ...prev, hotelName: e.target.value }))
            }
          />

          <TextArea
            label="备注"
            placeholder="填写备注信息"
            rows={3}
            value={formData.notes}
            onChange={e =>
              setFormData(prev => ({ ...prev, notes: e.target.value }))
            }
          />

          {conflictWarning && (
            <div className="bg-warning/10 border border-warning/30 rounded-2xl p-4 flex gap-3">
              <AlertCircle size={20} className="text-warning flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-foreground font-medium">{conflictWarning}</p>
                <button
                  onClick={forceSubmit}
                  disabled={submitLoading}
                  className="mt-2 text-sm text-primary font-medium underline underline-offset-2"
                >
                  确认添加
                </button>
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-2">
            <Button
              variant="secondary"
              fullWidth
              onClick={closeSheet}
              disabled={submitLoading}
            >
              取消
            </Button>
            <Button
              fullWidth
              onClick={handleSubmit}
              loading={submitLoading}
            >
              {editingSchedule ? '保存' : '创建'}
            </Button>
          </div>
        </div>
      </BottomSheet>

      {/* 分享共创面板 */}
      <WeddingShareSheet
        open={shareSheetOpen}
        onClose={() => setShareSheetOpen(false)}
        projectId={shareProjectId}
      />
    </div>
  );
};

export default SchedulePage;
