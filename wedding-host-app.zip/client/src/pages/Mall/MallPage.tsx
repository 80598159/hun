import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Star,
  MapPin,
  ArrowRight,
  Store,
  ChevronRight,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import { getMerchants } from '@client/src/api/shop';
import type { MallMerchant } from '@shared/api.interface';

const categories = [
  '全部', '婚纱摄影', '婚礼策划', '酒店场地', '婚纱礼服',
  '婚车', '司仪', '跟妆', '摄影摄像', '花艺布置',
];

const defaultGradient =
  'linear-gradient(135deg, hsl(348 74% 42% / 0.15) 0%, hsl(43 44% 55% / 0.2) 100%)';

const MallPage = () => {
  const { showToast } = useToast();
  const [activeCategory, setActiveCategory] = useState('全部');
  const [searchText, setSearchText] = useState('');
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [merchants, setMerchants] = useState<MallMerchant[]>([]);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const { items } = await getMerchants(
          activeCategory === '全部' ? undefined : activeCategory,
        );
        if (cancelled) return;
        setMerchants(items);
      } catch (err) {
        if (cancelled) return;
        logger.error('加载商家列表失败', err);
        setError('商家列表加载失败，请稍后重试');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [activeCategory]);

  const filtered = merchants.filter((m) => {
    if (!searchText) return true;
    return (
      m.name.includes(searchText) ||
      m.category.includes(searchText) ||
      m.address.includes(searchText)
    );
  });

  const handleApply = () => {
    showToast('入驻申请功能开发中', 'info');
  };

  const handleViewDetail = (name: string) => {
    showToast(`${name} 详情页开发中`, 'info');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5">
        <p className="text-foreground font-medium mb-2">加载失败</p>
        <p className="text-sm text-muted-foreground mb-4 text-center">{error}</p>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => window.location.reload()}
        >
          重新加载
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="婚庆商圈" subtitle="优质商家推荐" onBack={() => navigate(-1)} />

      {/* 搜索栏 */}
      <div className="pt-2 pb-4">
        <Input
          placeholder="搜索商家名称、服务类型..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          leftIcon={<Search size={18} />}
        />
      </div>

      {/* 分类横向滚动标签 */}
      <div className="-mx-5 px-5 mb-5">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`
                flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200
                ${activeCategory === cat
                  ? 'bg-primary text-primary-foreground shadow-md shadow-primary/25'
                  : 'bg-card text-muted-foreground border border-border/60 hover:text-foreground'}
              `}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 商家卡片列表 */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-4 text-muted-foreground">
              <Store size={28} />
            </div>
            <p className="text-foreground font-medium mb-1">暂无相关商家</p>
            <p className="text-sm text-muted-foreground">换个分类或关键词试试吧</p>
          </div>
        ) : (
          filtered.map((merchant) => (
            <div
              key={merchant.id}
              className="bg-card rounded-2xl shadow-md overflow-hidden transition-all duration-200 hover:shadow-lg border border-border/30"
            >
              {/* 顶部图片/封面区 */}
              <div
                className="aspect-[16/9] relative flex items-center justify-center overflow-hidden"
                style={
                  merchant.logoUrl
                    ? { backgroundImage: `url(${merchant.logoUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
                    : { background: defaultGradient }
                }
              >
                {merchant.isAd && (
                  <span
                    className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-xs font-medium text-white"
                    style={{
                      background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                    }}
                  >
                    广告
                  </span>
                )}
                {!merchant.logoUrl && (
                  <div className="text-center">
                    <Store size={36} className="text-foreground/30 mx-auto mb-2" />
                    <span className="text-sm text-foreground/50 font-medium">
                      {merchant.category}
                    </span>
                  </div>
                )}
              </div>

              {/* 内容区 */}
              <div className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-foreground leading-tight">
                    {merchant.name}
                  </h3>
                  <div className="flex items-center gap-1 flex-shrink-0 ml-3">
                    <Star size={14} className="text-accent-gold fill-accent-gold" />
                    <span className="text-sm font-semibold text-foreground">
                      {merchant.rating.toFixed(1)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                  <MapPin size={14} className="flex-shrink-0" />
                  <span className="truncate">{merchant.address || '地址待补充'}</span>
                </div>

                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                    {merchant.category}
                  </span>
                  {merchant.isAd && (
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-accent-gold/10 text-accent-gold">
                      优质商家
                    </span>
                  )}
                </div>

                <button
                  onClick={() => handleViewDetail(merchant.name)}
                  className="w-full flex items-center justify-between py-3 border-t border-border/50 text-primary font-medium text-sm"
                  aria-label={`查看${merchant.name}详情`}
                >
                  查看详情
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          ))
        )}

        {/* 入驻招募 Banner */}
        {filtered.length > 0 && (
          <div
            className="rounded-2xl p-5 flex items-center justify-between shadow-md"
            style={{
              background: 'linear-gradient(135deg, hsl(43 60% 78% / 0.3) 0%, hsl(43 44% 55% / 0.25) 100%)',
              border: '1px solid hsl(43 44% 55% / 0.2)',
            }}
          >
            <div>
              <h4 className="text-foreground font-semibold mb-1 flex items-center gap-2">
                <span className="text-accent-gold">✦</span>
                商家入驻招募中
              </h4>
              <p className="text-xs text-muted-foreground">
                加入婚庆商圈，获得更多曝光
              </p>
            </div>
            <Button
              variant="gold"
              size="sm"
              onClick={handleApply}
            >
              立即申请
              <ArrowRight size={14} />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MallPage;
