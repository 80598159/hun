import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Plus,
  FileText,
  Edit3,
  Copy,
  Trash2,
  Download,
  Trash,
  PlusCircle,
  Save,
  Calendar,
} from 'lucide-react';
import { useToast } from '@client/src/components/ToastProvider';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import type { Quotation, QuotationItem, CreateQuotationRequest, UpdateQuotationRequest } from '@shared/api.interface';
import {
  getQuotations,
  createQuotation,
  updateQuotation,
  deleteQuotation,
  exportQuotation,
  duplicateQuotation,
} from '@client/src/api/quotation';

type ViewMode = 'list' | 'edit';

const QuotationPage = () => {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>(id ? 'edit' : 'list');
  const [currentQuotation, setCurrentQuotation] = useState<Quotation | null>(null);

  // 编辑表单
  const [form, setForm] = useState<CreateQuotationRequest>({
    title: '',
    clientName: '',
    weddingDate: null,
    hotelName: '',
    items: [{ id: '1', name: '', unitPrice: '0', quantity: 1, unit: '场' }],
    deposit: '0',
    finalPayment: '0',
    remark: '',
    isTemplate: true,
  });
  const [saving, setSaving] = useState(false);

  // 导出对话框
  const [showExport, setShowExport] = useState(false);
  const [exportText, setExportText] = useState('');
  const [exportLoading, setExportLoading] = useState(false);

  // 日期选择器
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [tempDate, setTempDate] = useState('');

  // 确认删除
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const fetchQuotations = async () => {
    setLoading(true);
    try {
      const data = await getQuotations({ pageSize: 50 });
      setQuotations(data.items || []);
    } catch {
      showToast('加载报价单失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchQuotations();
  }, []);

  useEffect(() => {
    if (id && viewMode === 'edit') {
      const found = quotations.find(q => q.id === id);
      if (found) {
        setCurrentQuotation(found);
        setForm({
          title: found.title,
          clientName: found.clientName,
          weddingDate: found.weddingDate,
          hotelName: found.hotelName,
          items: found.items,
          deposit: found.deposit,
          finalPayment: found.finalPayment,
          remark: found.remark,
          isTemplate: found.isTemplate,
        });
      }
    }
  }, [id, quotations]);

  const formatDate = (dateStr: string | null): string => {
    if (!dateStr) return '待定';
    const date = new Date(dateStr);
    return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`;
  };

  const formatDateShort = (dateStr: string | null): string => {
    if (!dateStr) return '待定';
    const date = new Date(dateStr);
    return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
  };

  // 计算总金额
  const calculateTotal = (): number => {
    return form.items?.reduce((sum: number, item: QuotationItem) => {
      const price = parseFloat(item.unitPrice) || 0;
      const qty = item.quantity || 0;
      return sum + price * qty;
    }, 0) || 0;
  };

  // 自动计算尾款
  const calculateFinalPayment = (): string => {
    const total = calculateTotal();
    const deposit = parseFloat(form.deposit || '0') || 0;
    return String(Math.max(0, total - deposit));
  };

  const handleNewQuotation = () => {
    setCurrentQuotation(null);
    setForm({
      title: '新报价单',
      clientName: '',
      weddingDate: null,
      hotelName: '',
      items: [
        { id: String(Date.now()), name: '婚礼主持服务', unitPrice: '0', quantity: 1, unit: '场' },
      ],
      deposit: '0',
      finalPayment: '0',
      remark: '',
      isTemplate: true,
    });
    setViewMode('edit');
    navigate('/quotation/new', { replace: true });
  };

  const handleEditQuotation = (quotation: Quotation) => {
    setCurrentQuotation(quotation);
    setForm({
      title: quotation.title,
      clientName: quotation.clientName,
      weddingDate: quotation.weddingDate,
      hotelName: quotation.hotelName,
      items: [...quotation.items],
      deposit: quotation.deposit,
      finalPayment: quotation.finalPayment,
      remark: quotation.remark,
      isTemplate: quotation.isTemplate,
    });
    setViewMode('edit');
    navigate(`/quotation/${quotation.id}`);
  };

  const handleSave = async () => {
    if (!form.title?.trim()) {
      showToast('请输入报价单标题', 'warning');
      return;
    }
    setSaving(true);
    try {
      const total = String(calculateTotal());
      const finalPayment = form.finalPayment && form.finalPayment !== '0'
        ? form.finalPayment
        : calculateFinalPayment();

      const data: UpdateQuotationRequest = {
        ...form,
        finalPayment,
      };

      if (currentQuotation) {
        const result = await updateQuotation(currentQuotation.id, data);
        setCurrentQuotation(result);
        showToast('保存成功', 'success');
        // 更新列表
        setQuotations(prev => prev.map(q => q.id === result.id ? result : q));
      } else {
        const result = await createQuotation(data as CreateQuotationRequest);
        setCurrentQuotation(result);
        showToast('创建成功', 'success');
        navigate(`/quotation/${result.id}`, { replace: true });
        setQuotations(prev => [result, ...prev]);
      }
    } catch {
      showToast('保存失败，请重试', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDuplicate = async (quotationId: string) => {
    try {
      const result = await duplicateQuotation(quotationId);
      showToast('复制成功', 'success');
      setQuotations(prev => [result, ...prev]);
    } catch {
      showToast('复制失败', 'error');
    }
  };

  const handleDelete = async (quotationId: string) => {
    try {
      await deleteQuotation(quotationId);
      showToast('已删除', 'success');
      setQuotations(prev => prev.filter(q => q.id !== quotationId));
      setShowDeleteConfirm(null);
      if (currentQuotation?.id === quotationId) {
        setViewMode('list');
        setCurrentQuotation(null);
        navigate('/quotation');
      }
    } catch {
      showToast('删除失败', 'error');
    }
  };

  const handleExport = async (quotationId: string) => {
    setExportLoading(true);
    try {
      const data = await exportQuotation(quotationId);
      setExportText(data.text || '');
      setShowExport(true);
    } catch {
      showToast('导出失败', 'error');
    } finally {
      setExportLoading(false);
    }
  };

  const handleCopyExport = async () => {
    try {
      await navigator.clipboard.writeText(exportText);
      showToast('已复制到剪贴板', 'success');
    } catch {
      showToast('复制失败，请手动复制', 'error');
    }
  };

  // 添加项目行
  const addItem = () => {
    setForm(prev => ({
      ...prev,
      items: [
        ...(prev.items || []),
        { id: String(Date.now()), name: '', unitPrice: '0', quantity: 1, unit: '项' },
      ],
    }));
  };

  // 删除项目行
  const removeItem = (itemId: string) => {
    setForm(prev => ({
      ...prev,
      items: (prev.items || []).filter(i => i.id !== itemId),
    }));
  };

  // 更新项目行
  const updateItem = (itemId: string, field: keyof QuotationItem, value: string | number) => {
    setForm(prev => ({
      ...prev,
      items: (prev.items || []).map(item =>
        item.id === itemId ? { ...item, [field]: value } : item
      ),
    }));
  };

  const handleDateConfirm = () => {
    if (tempDate) {
      setForm(prev => ({ ...prev, weddingDate: tempDate }));
    }
    setShowDatePicker(false);
  };

  const total = calculateTotal();

  // 列表视图
  if (viewMode === 'list') {
    return (
      <div className="min-h-screen bg-background pb-24 page-enter">
        {/* 顶部导航 */}
        <div className="pt-6 pb-4 px-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(-1)}
              className="w-10 h-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground transition-colors"
              aria-label="返回"
            >
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="font-serif text-2xl font-bold text-foreground tracking-tight">
                报价单模板
              </h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                专业报价，一键生成
              </p>
            </div>
          </div>
          <button
            onClick={handleNewQuotation}
            className="h-10 px-4 rounded-full bg-primary-gradient text-primary-foreground text-sm font-medium shadow-md shadow-primary/25 flex items-center gap-1.5 active:scale-[0.97] transition-all"
          >
            <Plus size={16} />
            新建
          </button>
        </div>

        {/* 报价单列表 */}
        <div className="px-5">
          {loading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner />
            </div>
          ) : quotations.length === 0 ? (
            <EmptyState
              icon={<FileText size={28} />}
              title="还没有报价单"
              description="创建专业报价单，规范服务收费"
              action={
                <Button variant="primary" onClick={handleNewQuotation}>
                  <Plus size={16} />
                  新建报价单
                </Button>
              }
            />
          ) : (
            <div className="space-y-3">
              {quotations.map(quotation => (
                <div
                  key={quotation.id}
                  className="bg-card rounded-2xl shadow-md p-5 border border-border/40"
                >
                  <button
                    onClick={() => handleEditQuotation(quotation)}
                    className="w-full text-left"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="text-base font-semibold text-foreground truncate">
                          {quotation.title}
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">
                          客户：{quotation.clientName || '待填写'}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          日期：{formatDateShort(quotation.weddingDate)}
                        </p>
                      </div>
                      <div className="text-right flex-shrink-0 ml-3">
                        <p className="text-xs text-muted-foreground mb-0.5">合计</p>
                        <p className="text-lg font-bold text-primary font-serif">
                          ¥{quotation.total || '0'}
                        </p>
                      </div>
                    </div>
                  </button>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-2 pt-3 border-t border-border/50">
                    <button
                      onClick={() => handleEditQuotation(quotation)}
                      className="flex-1 h-9 rounded-full text-xs font-medium text-primary bg-primary/10 hover:bg-primary/15 flex items-center justify-center gap-1 transition-colors"
                    >
                      <Edit3 size={14} />
                      编辑
                    </button>
                    <button
                      onClick={() => void handleDuplicate(quotation.id)}
                      className="flex-1 h-9 rounded-full text-xs font-medium text-accent-gold-dark bg-accent-gold/15 hover:bg-accent-gold/20 flex items-center justify-center gap-1 transition-colors"
                    >
                      <Copy size={14} />
                      复制
                    </button>
                    <button
                      onClick={() => void handleExport(quotation.id)}
                      className="flex-1 h-9 rounded-full text-xs font-medium text-info bg-info/10 hover:bg-info/15 flex items-center justify-center gap-1 transition-colors"
                    >
                      <Download size={14} />
                      导出
                    </button>
                    <button
                      onClick={() => setShowDeleteConfirm(quotation.id)}
                      className="h-9 w-9 rounded-full text-destructive hover:bg-destructive/10 flex items-center justify-center transition-colors"
                      aria-label="删除"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 删除确认对话框 */}
        <BottomSheet
          open={showDeleteConfirm !== null}
          onClose={() => setShowDeleteConfirm(null)}
          height="auto"
        >
          <div className="p-5">
            <h3 className="text-lg font-semibold text-foreground mb-2">
              确认删除
            </h3>
            <p className="text-sm text-muted-foreground mb-5 leading-relaxed">
              删除后无法恢复，确定要删除这个报价单吗？
            </p>
            <div className="flex gap-3">
              <Button variant="secondary" fullWidth onClick={() => setShowDeleteConfirm(null)}>
                取消
              </Button>
              <Button
                variant="primary"
                fullWidth
                onClick={() => showDeleteConfirm && void handleDelete(showDeleteConfirm)}
              >
                确认删除
              </Button>
            </div>
          </div>
        </BottomSheet>

        {/* 导出对话框 */}
        <BottomSheet
          open={showExport}
          onClose={() => setShowExport(false)}
          title="导出报价单"
          height="large"
        >
          <div className="p-5">
            <div className="bg-secondary/60 rounded-xl p-4 mb-4 border border-border/50">
              <pre className="text-xs text-foreground/80 leading-relaxed whitespace-pre-wrap font-sans">
                {exportText || '暂无内容'}
              </pre>
            </div>
            <Button variant="primary" fullWidth onClick={() => void handleCopyExport()}>
              <Copy size={16} />
              一键复制
            </Button>
          </div>
        </BottomSheet>
      </div>
    );
  }

  // 编辑视图
  return (
    <div className="min-h-screen bg-background pb-28 page-enter">
      {/* 顶部导航 */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm px-5 pt-3 pb-3 flex items-center justify-between border-b border-border/50">
        <button
          onClick={() => {
            setViewMode('list');
            setCurrentQuotation(null);
            navigate('/quotation');
          }}
          className="w-10 h-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground transition-colors"
          aria-label="返回"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-base font-semibold text-foreground">
          {currentQuotation ? '编辑报价单' : '新建报价单'}
        </h1>
        <button
          onClick={() => void handleSave()}
          disabled={saving}
          className="h-9 px-4 rounded-full bg-primary-gradient text-primary-foreground text-sm font-medium shadow-md shadow-primary/25 flex items-center gap-1.5 active:scale-[0.97] transition-all disabled:opacity-50"
        >
          <Save size={16} />
          保存
        </button>
      </div>

      <div className="px-5 pt-5 space-y-5">
        {/* 基本信息 */}
        <div className="bg-card rounded-2xl shadow-sm p-5 border border-border/40">
          <h3 className="text-base font-semibold text-foreground mb-4 font-serif">
            基本信息
          </h3>
          <div className="space-y-4">
            <Input
              label="报价单标题"
              value={form.title || ''}
              onChange={e => setForm(prev => ({ ...prev, title: e.target.value }))}
              placeholder="如：婚礼主持服务报价单"
            />
            <Input
              label="客户姓名"
              value={form.clientName || ''}
              onChange={e => setForm(prev => ({ ...prev, clientName: e.target.value }))}
              placeholder="新人姓名"
            />
            <div>
              <label className="block text-sm font-medium text-foreground/80 mb-2">
                婚礼日期
              </label>
              <button
                onClick={() => {
                  setTempDate(form.weddingDate || '');
                  setShowDatePicker(true);
                }}
                className="w-full h-12 px-4 rounded-xl border border-input bg-secondary/60 text-sm text-left flex items-center justify-between hover:border-primary/30 transition-colors"
              >
                <span className={form.weddingDate ? 'text-foreground' : 'text-muted-foreground/70'}>
                  {form.weddingDate ? formatDate(form.weddingDate) : '请选择日期'}
                </span>
                <Calendar size={18} className="text-muted-foreground" />
              </button>
            </div>
            <Input
              label="婚礼酒店"
              value={form.hotelName || ''}
              onChange={e => setForm(prev => ({ ...prev, hotelName: e.target.value }))}
              placeholder="酒店名称"
            />
          </div>
        </div>

        {/* 项目明细 */}
        <div className="bg-card rounded-2xl shadow-sm p-5 border border-border/40">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-foreground font-serif">
              项目明细
            </h3>
            <button
              onClick={addItem}
              className="text-xs text-primary font-medium flex items-center gap-1"
            >
              <PlusCircle size={14} />
              添加项目
            </button>
          </div>
          <div className="space-y-3">
            {form.items?.map((item, index) => (
              <div
                key={item.id}
                className="bg-secondary/40 rounded-xl p-4 border border-border/40"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-muted-foreground">
                    项目 {index + 1}
                  </span>
                  {(form.items?.length || 0) > 1 && (
                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-destructive hover:bg-destructive/10 p-1 rounded transition-colors"
                      aria-label="删除项目"
                    >
                      <Trash size={14} />
                    </button>
                  )}
                </div>
                <Input
                  label="项目名称"
                  value={item.name}
                  onChange={e => updateItem(item.id, 'name', e.target.value)}
                  placeholder="服务项目名称"
                  containerClassName="mb-3"
                />
                <div className="grid grid-cols-3 gap-3">
                  <Input
                    label="单价"
                    type="number"
                    value={item.unitPrice}
                    onChange={e => updateItem(item.id, 'unitPrice', e.target.value)}
                    placeholder="0"
                  />
                  <Input
                    label="数量"
                    type="number"
                    value={String(item.quantity)}
                    onChange={e => updateItem(item.id, 'quantity', parseInt(e.target.value) || 0)}
                    placeholder="1"
                  />
                  <Input
                    label="单位"
                    value={item.unit}
                    onChange={e => updateItem(item.id, 'unit', e.target.value)}
                    placeholder="场/项"
                  />
                </div>
                <div className="mt-3 pt-3 border-t border-border/40 flex justify-end">
                  <span className="text-sm text-muted-foreground">
                    小计：
                    <span className="font-semibold text-primary ml-1">
                      ¥{(parseFloat(item.unitPrice) || 0) * (item.quantity || 0)}
                    </span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 金额汇总 */}
        <div className="bg-card rounded-2xl shadow-sm p-5 border border-border/40">
          <h3 className="text-base font-semibold text-foreground mb-4 font-serif">
            金额汇总
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2 border-b border-border/40">
              <span className="text-sm text-muted-foreground">项目合计</span>
              <span className="text-base font-semibold text-foreground">¥{total}</span>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground/80 mb-2">
                定金
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">¥</span>
                <input
                  type="number"
                  value={form.deposit}
                  onChange={e => setForm(prev => ({ ...prev, deposit: e.target.value }))}
                  className="w-full h-12 pl-8 pr-4 rounded-xl border border-input bg-secondary/60 text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 text-sm"
                  placeholder="0"
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-foreground/80">
                  尾款
                </label>
                <button
                  onClick={() => setForm(prev => ({ ...prev, finalPayment: calculateFinalPayment() }))}
                  className="text-xs text-primary"
                >
                  自动计算
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">¥</span>
                <input
                  type="number"
                  value={form.finalPayment}
                  onChange={e => setForm(prev => ({ ...prev, finalPayment: e.target.value }))}
                  className="w-full h-12 pl-8 pr-4 rounded-xl border border-input bg-secondary/60 text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 text-sm"
                  placeholder="0"
                />
              </div>
            </div>
            <div
              className="rounded-xl p-4"
              style={{
                background: 'linear-gradient(135deg, hsl(348 74% 42% / 0.08) 0%, hsl(43 44% 55% / 0.12) 100%)',
              }}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground/80">总金额</span>
                <span className="text-2xl font-bold text-primary font-serif">
                  ¥{total}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 备注 */}
        <div className="bg-card rounded-2xl shadow-sm p-5 border border-border/40">
          <h3 className="text-base font-semibold text-foreground mb-4 font-serif">
            备注说明
          </h3>
          <TextArea
            value={form.remark || ''}
            onChange={e => setForm(prev => ({ ...prev, remark: e.target.value }))}
            placeholder="付款方式、服务说明等备注信息"
            rows={4}
          />
        </div>

        {/* 导出文本按钮 */}
        <Button
          variant="gold"
          fullWidth
          onClick={() => currentQuotation && void handleExport(currentQuotation.id)}
          disabled={!currentQuotation}
        >
          <Download size={18} />
          导出文本
        </Button>
      </div>

      {/* 日期选择对话框 */}
      <BottomSheet
        open={showDatePicker}
        onClose={() => setShowDatePicker(false)}
        title="选择日期"
        height="auto"
      >
        <div className="p-5">
          <Input
            type="date"
            value={tempDate}
            onChange={e => setTempDate(e.target.value)}
            containerClassName="mb-4"
          />
          <div className="flex gap-3">
            <Button variant="secondary" fullWidth onClick={() => setShowDatePicker(false)}>
              取消
            </Button>
            <Button variant="primary" fullWidth onClick={handleDateConfirm}>
              确认
            </Button>
          </div>
        </div>
      </BottomSheet>

      {/* 导出对话框 */}
      <BottomSheet
        open={showExport}
        onClose={() => setShowExport(false)}
        title="导出报价单"
        height="large"
      >
        <div className="p-5">
          <div className="bg-secondary/60 rounded-xl p-4 mb-4 border border-border/50">
            <pre className="text-xs text-foreground/80 leading-relaxed whitespace-pre-wrap font-sans">
              {exportText || '暂无内容'}
            </pre>
          </div>
          <Button variant="primary" fullWidth onClick={() => void handleCopyExport()}>
            <Copy size={16} />
            一键复制
          </Button>
        </div>
      </BottomSheet>
    </div>
  );
};

export default QuotationPage;
