import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus,
  Sparkles,
  BookOpen,
  Calendar,
  Hotel,
  MoreHorizontal,
  Copy,
  Archive,
  Trash2,
  ChevronRight,
  Clock,
  Zap,
} from 'lucide-react';
import type { WeddingProject, AiQuota } from '@shared/api.interface';
import {
  getProjectList,
  createProject,
  copyProject,
  archiveProject,
  unarchiveProject,
  deleteProject,
} from '@client/src/api/wedding';
import { getAiQuota } from '@client/src/api/auth';
import { useToast } from '@client/src/components/ToastProvider';
import Button from '@client/src/components/app-ui/Button';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { showConfirm } from '@lark-apaas/client-toolkit';

type TabType = 'active' | 'archived';

const HomePage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<TabType>('active');
  const [projects, setProjects] = useState<WeddingProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiQuota, setAiQuota] = useState<AiQuota | null>(null);
  const [creating, setCreating] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuProject, setMenuProject] = useState<WeddingProject | null>(null);

  const fetchProjects = async (tab: TabType) => {
    setLoading(true);
    try {
      const status = tab === 'active' ? 'active' : 'archived';
      const data = await getProjectList({ status });
      setProjects(data.items || []);
    } catch {
      showToast('加载项目列表失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchQuota = async () => {
    try {
      const data = await getAiQuota();
      setAiQuota(data);
    } catch {
      // 静默失败，不影响主流程
    }
  };

  useEffect(() => {
    fetchProjects(activeTab);
  }, [activeTab]);

  useEffect(() => {
    fetchQuota();
  }, []);

  const handleCreateProject = async () => {
    if (creating) return;
    setCreating(true);
    try {
      const result = await createProject({ title: '新婚礼方案' });
      showToast('创建成功', 'success');
      navigate(`/wedding/${result.project.id}`);
    } catch {
      showToast('创建失败，请重试', 'error');
    } finally {
      setCreating(false);
    }
  };

  const handleCopyProject = async (id: string) => {
    try {
      const data = await copyProject(id);
      showToast('复制成功', 'success');
      setMenuOpen(false);
      setMenuProject(null);
      if (activeTab === 'active') {
        setProjects(prev => [data, ...prev]);
      } else {
        fetchProjects(activeTab);
      }
    } catch {
      showToast('复制失败，请重试', 'error');
    }
  };

  const handleArchiveProject = async (id: string) => {
    try {
      await archiveProject(id);
      showToast('已归档', 'success');
      setMenuOpen(false);
      setMenuProject(null);
      setProjects(prev => prev.filter((p: WeddingProject) => p.id !== id));
    } catch {
      showToast('归档失败，请重试', 'error');
    }
  };

  const handleUnarchiveProject = async (id: string) => {
    try {
      await unarchiveProject(id);
      showToast('已取消归档', 'success');
      setMenuOpen(false);
      setMenuProject(null);
      setProjects(prev => prev.filter((p: WeddingProject) => p.id !== id));
    } catch {
      showToast('操作失败，请重试', 'error');
    }
  };

  const handleDeleteProject = async (id: string) => {
    setMenuOpen(false);
    setMenuProject(null);
    if (!await showConfirm('确定要删除这个婚礼方案吗？删除后无法恢复。')) {
      return;
    }
    try {
      await deleteProject(id);
      showToast('已删除', 'success');
      setProjects(prev => prev.filter((p: WeddingProject) => p.id !== id));
    } catch {
      showToast('删除失败，请重试', 'error');
    }
  };

  const openMenu = (project: WeddingProject) => {
    setMenuProject(project);
    setMenuOpen(true);
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '待定';
    const date = new Date(dateStr);
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    return `${month}月${day}日 ${weekdays[date.getDay()]}`;
  };

  const getTimeTypeLabel = (timeType: string) => {
    return timeType === 'lunch' ? '午宴' : '晚宴';
  };

  const totalAiRemaining = aiQuota
    ? (aiQuota.remainingFlow ?? 0) + (aiQuota.remainingScript ?? 0)
    : 0;

  // 获取新人名字首字母
  const getInitials = (groom: string, bride: string) => {
    const g = groom?.charAt(0) || '新';
    const b = bride?.charAt(0) || '娘';
    return { g, b };
  };

  // 最近项目（取前 5 个进行中项目）
  const recentProjects = projects.filter((p: WeddingProject) => p.status === 'active').slice(0, 5);

  const quickEntries = [
    {
      key: 'new',
      title: '新建方案',
      desc: '手动编辑流程',
      icon: Plus,
      bgClass: 'bg-primary-gradient',
      onClick: handleCreateProject,
    },
    {
      key: 'schedule',
      title: '档期',
      desc: '查看与管理档期',
      icon: Calendar,
      bgClass:
        'bg-gradient-to-br from-[hsl(150_30%_55%)] to-[hsl(160_35%_42%)]',
      onClick: () => navigate('/schedule'),
    },
    {
      key: 'scripts',
      title: '台词库',
      desc: '开场/誓言/父母致辞',
      icon: BookOpen,
      bgClass:
        'bg-gradient-to-br from-[hsl(340_40%_22%)] to-[hsl(348_50%_32%)]',
      onClick: () => navigate('/scripts'),
    },
    {
      key: 'ai',
      title: 'AI生成',
      desc: '输入需求智能生成',
      icon: Sparkles,
      bgClass: 'bg-gold-gradient',
      onClick: () => navigate('/ai/flow'),
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-24 page-enter">
      {/* 品牌头部 */}
      <div className="bg-wedding-gradient relative overflow-hidden">
        <div className="px-5 pt-10 pb-16">
          {/* 顶部栏 */}
          <div className="flex items-start justify-between">
            <div>
              <h1 className="font-serif text-3xl font-bold tracking-tight text-white">
                婚序
                <span className="text-accent-gold-light">.</span>
              </h1>
              <p className="mt-0.5 text-xs text-white/60 tracking-widest">
                WEDDING HOST ASSISTANT
              </p>
            </div>
            <button
              onClick={() => navigate('/profile')}
              className="flex items-center gap-1.5 bg-gold-gradient text-[hsl(40_50%_22%)] px-3 py-1.5 rounded-full text-sm font-semibold shadow-md shadow-accent-gold/30 active:scale-[0.97] transition-transform"
              aria-label="AI额度"
            >
              <Zap size={14} className="text-[hsl(40_50%_22%)]" />
              <span>剩余 {totalAiRemaining} 次</span>
            </button>
          </div>

          {/* 问候 + 标语 */}
          <div className="mt-8">
            <p className="text-sm text-white/70">你好，主持人 👋</p>
            <h2 className="mt-2 font-serif text-2xl font-bold text-white leading-relaxed tracking-tight">
              让每一场婚礼，
              <br />
              都有<span className="text-gradient-gold">完美的节奏</span>
            </h2>
          </div>
        </div>

        {/* 装饰圆点 */}
        <div className="absolute top-4 right-16 w-24 h-24 rounded-full bg-accent-gold/10 blur-xl" />
        <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full bg-primary-light/20 blur-2xl" />

        {/* 弧形底部 */}
        <div className="absolute -bottom-px left-0 right-0 h-10 bg-background rounded-t-[40px]" />
      </div>

      <div className="px-5 -mt-6 space-y-6 relative z-10">
        {/* 快捷入口区 */}
        <div className="grid grid-cols-2 gap-4 stagger-children">
          {quickEntries.map((entry) => {
            const IconComp = entry.icon;
            return (
              <button
                key={entry.key}
                onClick={entry.onClick}
                className="bg-card rounded-2xl shadow-md p-4 text-left active:scale-[0.98] transition-transform"
              >
                <div
                  className={`w-11 h-11 rounded-full ${entry.bgClass} flex items-center justify-center shadow-md`}
                >
                  <IconComp size={22} className="text-white" />
                </div>
                <h3 className="mt-3 text-base font-semibold text-foreground">
                  {entry.title}
                </h3>
                <p className="mt-0.5 text-xs text-muted-foreground leading-relaxed">
                  {entry.desc}
                </p>
              </button>
            );
          })}
        </div>

        {/* 最近项目区 */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-semibold text-foreground">最近方案</h3>
            <button
              onClick={() => {
                const el = document.getElementById('project-list-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="flex items-center gap-0.5 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <span>查看全部</span>
              <ChevronRight size={14} />
            </button>
          </div>

           {recentProjects.length === 0 ? (
             <div className="bg-card rounded-2xl shadow-sm p-8 text-center">
               <div className="w-14 h-14 mx-auto rounded-2xl bg-secondary flex items-center justify-center mb-3">
                 <Sparkles size={24} className="text-accent-gold" />
               </div>
               <p className="text-sm font-medium text-foreground">
                 还没有婚礼方案
               </p>
               <p className="mt-1 text-xs text-muted-foreground">
                 点击上方「新建方案」开始创作
               </p>
             </div>
           ) : (
             <div className="flex gap-3 overflow-x-auto scrollbar-hide -mx-5 px-5 pb-2">
               {recentProjects.map((project: WeddingProject) => {
                 const { g, b } = getInitials(project.groomName, project.brideName);
                 return (
                   <div
                     key={project.id}
                     className="flex-shrink-0 w-[200px] bg-card rounded-2xl shadow-md overflow-hidden relative"
                   >
                     {/* 海报缩略图 */}
                     <button
                       onClick={() => navigate(`/wedding/${project.id}`)}
                       className="w-full bg-wedding-gradient h-20 flex items-center justify-center relative overflow-hidden text-left active:scale-[0.98] transition-transform"
                     >
                       <div className="absolute top-2 left-3 w-8 h-8 rounded-full bg-accent-gold/20 blur-md" />
                       <div className="absolute bottom-1 right-4 w-6 h-6 rounded-full bg-accent-gold-light/20 blur-sm" />
                       <span className="font-serif text-xl font-bold text-white tracking-wider">
                         {g}
                         <span className="text-accent-gold-light mx-1 text-sm">&amp;</span>
                         {b}
                       </span>
                     </button>
                     {/* 右上角三点按钮 */}
                     <button
                       onClick={(e) => {
                         e.stopPropagation();
                         openMenu(project);
                       }}
                       className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-black/35 transition-colors active:scale-95"
                       style={{ touchAction: 'manipulation' }}
                       aria-label="更多操作"
                       type="button"
                     >
                       <MoreHorizontal size={16} />
                     </button>
                     {/* 内容 */}
                     <div
                       className="p-3 cursor-pointer"
                       onClick={() => navigate(`/wedding/${project.id}`)}
                     >
                       <h4 className="text-sm font-semibold text-foreground truncate">
                         {project.title ||
                           `${project.groomName || '新郎'} & ${project.brideName || '新娘'}`}
                       </h4>
                       <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                         <Calendar size={12} />
                         <span className="truncate">
                           {formatDate(project.weddingDate)}
                         </span>
                         <span
                           className={`flex-shrink-0 px-1.5 py-0.5 text-[10px] font-medium rounded-full ${
                             project.timeType === 'lunch'
                               ? 'bg-amber-50 text-amber-600'
                               : 'bg-indigo-50 text-indigo-600'
                           }`}
                         >
                           {getTimeTypeLabel(project.timeType)}
                         </span>
                       </div>
                       {project.hotelName && (
                         <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                           <Hotel size={12} className="flex-shrink-0" />
                           <span className="truncate">{project.hotelName}</span>
                         </div>
                       )}
                     </div>
                   </div>
                 );
               })}
             </div>
           )}
        </div>

        {/* Tab 切换 + 项目列表 */}
        <div id="project-list-section">
          {/* Tab */}
          <div className="bg-card rounded-2xl p-1 shadow-sm mb-4">
            <div className="flex">
              <button
                onClick={() => setActiveTab('active')}
                className={`flex-1 py-2.5 text-sm font-medium rounded-xl transition-all duration-200 ${
                  activeTab === 'active'
                    ? 'bg-primary-gradient text-primary-foreground shadow-md shadow-primary/25'
                    : 'text-muted-foreground'
                }`}
              >
                进行中
              </button>
              <button
                onClick={() => setActiveTab('archived')}
                className={`flex-1 py-2.5 text-sm font-medium rounded-xl transition-all duration-200 ${
                  activeTab === 'archived'
                    ? 'bg-primary-gradient text-primary-foreground shadow-md shadow-primary/25'
                    : 'text-muted-foreground'
                }`}
              >
                已归档
              </button>
            </div>
          </div>

          {/* 项目列表 */}
          {loading ? (
            <div className="flex justify-center py-16">
              <LoadingSpinner />
            </div>
          ) : projects.length === 0 ? (
            <EmptyState
              icon={<Sparkles size={28} />}
              title={
                activeTab === 'active' ? '还没有婚礼方案' : '暂无归档项目'
              }
              description={
                activeTab === 'active'
                  ? '点击上方按钮，开始创建你的第一份方案'
                  : '归档的方案会显示在这里'
              }
            />
          ) : (
            <div className="space-y-3 stagger-children">
              {projects.map((project: WeddingProject) => {
                const { g, b } = getInitials(
                  project.groomName,
                  project.brideName
                );
                return (
                  <div
                    key={project.id}
                    className="bg-card rounded-2xl shadow-md p-3 flex items-center gap-3"
                  >
                    {/* 左侧缩略海报 */}
                    <button
                      onClick={() => navigate(`/wedding/${project.id}`)}
                      className="flex-shrink-0 w-[70px] h-[80px] rounded-xl bg-wedding-gradient flex items-center justify-center relative overflow-hidden active:scale-[0.97] transition-transform"
                      aria-label={project.title || '婚礼方案'}
                    >
                      <div className="absolute top-1 left-1.5 w-4 h-4 rounded-full bg-accent-gold/25 blur-sm" />
                      <span className="font-serif text-base font-bold text-white tracking-tight">
                        {g}
                        <span className="text-accent-gold-light text-[10px] mx-0.5">&amp;</span>
                        {b}
                      </span>
                    </button>

                    {/* 右侧内容 */}
                    <div className="flex-1 min-w-0">
                      <button
                        onClick={() => navigate(`/wedding/${project.id}`)}
                        className="text-left w-full"
                      >
                        <h3 className="text-base font-semibold text-foreground truncate pr-1">
                          {project.title ||
                            `${project.groomName || '新郎'} & ${
                              project.brideName || '新娘'
                            }的婚礼`}
                        </h3>
                        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Calendar size={12} />
                          <span>{formatDate(project.weddingDate)}</span>
                          <span
                            className={`px-1.5 py-0.5 text-[10px] font-medium rounded-full ${
                              project.timeType === 'lunch'
                                ? 'bg-amber-50 text-amber-600'
                                : 'bg-indigo-50 text-indigo-600'
                            }`}
                          >
                            {getTimeTypeLabel(project.timeType)}
                          </span>
                        </div>
                        {project.hotelName && (
                          <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                            <Hotel size={12} className="flex-shrink-0" />
                            <span className="truncate">
                              {project.hotelName}
                            </span>
                          </div>
                        )}
                      </button>
                    </div>

                    {/* 更多按钮 */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openMenu(project);
                      }}
                      className="flex-shrink-0 p-2.5 text-muted-foreground hover:text-foreground rounded-xl hover:bg-secondary transition-colors active:scale-95"
                      style={{ touchAction: 'manipulation', minWidth: '40px', minHeight: '40px' }}
                      aria-label="更多操作"
                      type="button"
                    >
                      <MoreHorizontal size={20} strokeWidth={2.2} />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* 底部操作菜单 */}
      <BottomSheet open={menuOpen} onClose={() => setMenuOpen(false)} height="auto">
        <div className="px-5 py-4">
          <h3 className="text-base font-semibold text-foreground mb-1">
            {menuProject?.title || '婚礼方案'}
          </h3>
          <p className="text-xs text-muted-foreground mb-4">
            {menuProject ? formatDate(menuProject.weddingDate) : ''}
          </p>

          <div className="space-y-1">
            <button
              onClick={() => menuProject && handleCopyProject(menuProject.id)}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-foreground hover:bg-secondary transition-colors text-left"
            >
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                <Copy size={18} className="text-primary" />
              </div>
              <div>
                <div className="text-sm font-medium">复制方案</div>
                <div className="text-xs text-muted-foreground">
                  创建一个副本
                </div>
              </div>
            </button>

            {activeTab === 'active' ? (
              <button
                onClick={() =>
                  menuProject && handleArchiveProject(menuProject.id)
                }
                className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-foreground hover:bg-secondary transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-full bg-accent-gold/15 flex items-center justify-center">
                  <Archive size={18} className="text-accent-gold" />
                </div>
                <div>
                  <div className="text-sm font-medium">归档方案</div>
                  <div className="text-xs text-muted-foreground">
                    移至归档列表
                  </div>
                </div>
              </button>
            ) : (
              <button
                onClick={() =>
                  menuProject && handleUnarchiveProject(menuProject.id)
                }
                className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-foreground hover:bg-secondary transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-full bg-info/15 flex items-center justify-center">
                  <Clock size={18} className="text-info" />
                </div>
                <div>
                  <div className="text-sm font-medium">取消归档</div>
                  <div className="text-xs text-muted-foreground">
                    恢复到进行中
                  </div>
                </div>
              </button>
            )}

            <button
              onClick={() => menuProject && handleDeleteProject(menuProject.id)}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-destructive hover:bg-destructive/5 transition-colors text-left"
            >
              <div className="w-9 h-9 rounded-full bg-destructive/10 flex items-center justify-center">
                <Trash2 size={18} className="text-destructive" />
              </div>
              <div>
                <div className="text-sm font-medium">删除方案</div>
                <div className="text-xs text-destructive/70">
                  删除后无法恢复
                </div>
              </div>
            </button>
          </div>
        </div>
      </BottomSheet>

      {/* 隐藏 scrollbar-hide 样式 */}
      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default HomePage;
