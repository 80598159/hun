import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Heart, Plus, FileText, Sparkles, Copy, X, RotateCcw, AlertCircle, Save } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import Skeleton from '@client/src/components/app-ui/Skeleton';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import {
  getScriptList,
  toggleFavorite,
  createScript,
  getScriptCategories,
} from '@client/src/api/script';
import { generateScript, checkScriptQuota, consumeScriptQuota } from '@client/src/api/ai';
import type { Script, ScriptCategory } from '@shared/api.interface';

const AI_OPERATION_TYPES = [
  { key: 'generate', label: '生成新台词' },
  { key: 'rewrite', label: '改写现有' },
  { key: 'polish', label: '润色优化' },
];

const AI_SPEECH_TYPES = [
  { key: 'opening', label: '开场词' },
  { key: 'oath', label: '誓言' },
  { key: 'parents', label: '父母致辞' },
  { key: 'witness', label: '证婚词' },
  { key: 'toast', label: '敬酒词' },
  { key: 'ending', label: '结束语' },
];

const AI_SPEECH_STYLES = [
  { key: 'warm', label: '温馨感人' },
  { key: 'humorous', label: '幽默风趣' },
  { key: 'traditional', label: '中式传统' },
  { key: 'modern', label: '简约现代' },
  { key: 'grand', label: '庄重典雅' },
];

const AI_LENGTH_OPTIONS = [
  { key: 'short', label: '简短开场白（约200字）' },
  { key: 'medium', label: '500字左右' },
  { key: 'long', label: '3分钟以内（约800字）' },
];

const AI_DISCLAIMER = 'AI生成内容仅为初稿，请主持人人工审核修改，本工具不承担现场使用责任';

const ScriptsPage: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [categories, setCategories] = useState<ScriptCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [keyword, setKeyword] = useState<string>('');
  const [debouncedKeyword, setDebouncedKeyword] = useState<string>('');
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [showAiModal, setShowAiModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newCategory, setNewCategory] = useState<string>('');
  const [newContent, setNewContent] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const [aiOperationType, setAiOperationType] = useState('generate');
  const [aiSpeechType, setAiSpeechType] = useState('opening');
  const [aiSpeechStyle, setAiSpeechStyle] = useState('warm');
  const [aiLengthRequirement, setAiLengthRequirement] = useState('medium');
  const [aiKeyInformation, setAiKeyInformation] = useState('');
  const [aiOriginalContent, setAiOriginalContent] = useState('');
  const [aiAdditionalRequirements, setAiAdditionalRequirements] = useState('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiGeneratedTitle, setAiGeneratedTitle] = useState('');
  const [aiGeneratedContent, setAiGeneratedContent] = useState('');
  const [aiRemainingQuota, setAiRemainingQuota] = useState<number>(10);

  const [showAiSaveDialog, setShowAiSaveDialog] = useState(false);
  const [aiSaveTitle, setAiSaveTitle] = useState('');
  const [aiSaveCategory, setAiSaveCategory] = useState('');
  const [aiSaveTags, setAiSaveTags] = useState('');
  const [aiSaving, setAiSaving] = useState(false);

  const categoryScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadQuota = async () => {
      try {
        const data = await checkScriptQuota();
        setAiRemainingQuota(data.remainingScript ?? data.remaining ?? 0);
      } catch {
        // 静默失败
      }
    };
    void loadQuota();
  }, []);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const data = await getScriptCategories();
        const cats = (data as ScriptCategory[]) || [];
        setCategories(cats);
      } catch (error) {
        logger.error('加载分类失败', error);
      }
    };
    loadCategories();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedKeyword(keyword);
    }, 300);
    return () => clearTimeout(timer);
  }, [keyword]);

  const loadScripts = useCallback(async () => {
    setLoading(true);
    try {
      const params: { category?: string; keyword?: string; page: number; pageSize: number } = {
        page: 1,
        pageSize: 50,
      };
      if (selectedCategory) params.category = selectedCategory;
      if (debouncedKeyword) params.keyword = debouncedKeyword;
      const data = await getScriptList(params);
      setScripts((data as { items: Script[] }).items || []);
    } catch (error) {
      logger.error('加载台词列表失败', error);
      showToast('加载失败，请重试', 'error');
    } finally {
      setLoading(false);
    }
  }, [selectedCategory, debouncedKeyword, showToast]);

  useEffect(() => {
    loadScripts();
  }, [loadScripts]);

  const handleCategoryClick = (key: string) => {
    setSelectedCategory(key);
  };

  const handleToggleFavorite = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      await toggleFavorite(id);
      setScripts((prev: Script[]) =>
        prev.map((s: Script) =>
          s.id === id ? { ...s, isFavorite: !s.isFavorite } : s
        )
      );
    } catch (error) {
      logger.error('切换收藏失败', error);
      showToast('操作失败，请重试', 'error');
    }
  };

  const handleCopy = async (e: React.MouseEvent, content: string, title: string) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(content);
      showToast(`${title} 已复制`, 'success');
    } catch {
      showToast('复制失败，请手动选择', 'error');
    }
  };

  const openCreateModal = () => {
    setNewTitle('');
    setNewContent('');
    setNewCategory(selectedCategory || (categories.find((c) => c.key === 'my')?.key ?? categories[0]?.key ?? ''));
    setShowCreateModal(true);
  };

  const handleCreate = async () => {
    if (!newTitle.trim()) {
      showToast('请输入台词标题', 'warning');
      return;
    }
    if (!newCategory) {
      showToast('请选择分类', 'warning');
      return;
    }
    if (!newContent.trim()) {
      showToast('请输入台词内容', 'warning');
      return;
    }
    setSubmitting(true);
    try {
      await createScript({
        title: newTitle.trim(),
        category: newCategory,
        content: newContent.trim(),
      });
      showToast('创建成功', 'success');
      setShowCreateModal(false);
      loadScripts();
    } catch (error) {
      logger.error('创建台词失败', error);
      showToast('创建失败，请重试', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const openAiModal = () => {
    setAiGeneratedTitle('');
    setAiGeneratedContent('');
    setAiError(null);
    setAiKeyInformation('');
    setAiOriginalContent('');
    setAiAdditionalRequirements('');
    setAiOperationType('generate');
    setAiSpeechType('opening');
    setAiSpeechStyle('warm');
    setAiLengthRequirement('medium');
    setShowAiModal(true);
  };

  const handleAiGenerate = async () => {
    if (aiLoading) return;
    if (aiOperationType !== 'polish') {
      if (!aiKeyInformation.trim()) {
        showToast('请填写关键信息', 'warning');
        return;
      }
    }
    if (aiOperationType === 'rewrite' && !aiOriginalContent.trim()) {
      showToast('请输入原始台词', 'warning');
      return;
    }

    try {
      const quota = await checkScriptQuota();
      const remaining = quota.remainingScript ?? quota.remaining ?? 0;
      if (remaining <= 0) {
        showToast('本月AI台词生成额度已用完，请到商店充值', 'warning');
        return;
      }
      setAiRemainingQuota(remaining);
    } catch {
      // 额度检查失败，继续
    }

    setAiLoading(true);
    setAiError(null);
    setAiGeneratedTitle('');
    setAiGeneratedContent('');

    try {
      const data = await generateScript({
        speechType: AI_SPEECH_TYPES.find(s => s.key === aiSpeechType)?.label || aiSpeechType,
        speechStyle: AI_SPEECH_STYLES.find(s => s.key === aiSpeechStyle)?.label || aiSpeechStyle,
        operationType: AI_OPERATION_TYPES.find(o => o.key === aiOperationType)?.label || aiOperationType,
        keyInformation: aiKeyInformation,
        lengthRequirement: AI_LENGTH_OPTIONS.find(l => l.key === aiLengthRequirement)?.label || aiLengthRequirement,
        originalContent: aiOriginalContent,
        additionalRequirements: aiAdditionalRequirements,
      });

      setAiGeneratedTitle(data.title || '');
      setAiGeneratedContent(data.content || '');

      try {
        await consumeScriptQuota();
        setAiRemainingQuota(prev => Math.max(0, prev - 1));
      } catch {
        // 静默处理
      }

      showToast('生成完成', 'success');
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: { message?: string } } }; message?: string };
      const msg = error.response?.data?.error?.message || error.message || '生成失败，请稍后重试';
      setAiError(msg);
      showToast(msg, 'error');
      logger.error('AI生成台词失败', err);
    } finally {
      setAiLoading(false);
    }
  };

  const handleAiCopyResult = async () => {
    if (!aiGeneratedContent) return;
    try {
      await navigator.clipboard.writeText(aiGeneratedContent);
      showToast('已复制到剪贴板', 'success');
    } catch {
      showToast('复制失败，请手动选择', 'error');
    }
  };

  const handleAiSave = async () => {
    if (!aiGeneratedContent) return;
    try {
      const cats = await getScriptCategories();
      const catList = (cats as { items: ScriptCategory[] }).items || [];
      setCategories(catList);
      if (catList[0]) setAiSaveCategory(catList[0].key);
    } catch {
      // 使用已有的 categories
      if (categories[0]) setAiSaveCategory(categories[0].key);
    }
    const baseTitle = aiGeneratedTitle
      ? aiGeneratedTitle
      : `${AI_SPEECH_TYPES.find(s => s.key === aiSpeechType)?.label || '台词'}`;
    setAiSaveTitle(baseTitle);
    setAiSaveTags(AI_SPEECH_STYLES.find(s => s.key === aiSpeechStyle)?.label || '');
    setShowAiSaveDialog(true);
  };

  const handleAiConfirmSave = async () => {
    if (!aiSaveTitle.trim()) {
      showToast('请输入标题', 'warning');
      return;
    }
    if (!aiSaveCategory) {
      showToast('请选择分类', 'warning');
      return;
    }
    setAiSaving(true);
    try {
      await createScript({
        title: aiSaveTitle,
        category: aiSaveCategory,
        content: aiGeneratedContent,
        styleTags: aiSaveTags,
      });
      showToast('已保存到台词库', 'success');
      setShowAiSaveDialog(false);
      loadScripts();
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: { message?: string } } } };
      const msg = error.response?.data?.error?.message || '保存失败';
      showToast(msg, 'error');
    } finally {
      setAiSaving(false);
    }
  };

  const handleAiRegenerate = () => {
    handleAiGenerate();
  };

  const getAiGenerateButtonText = () => {
    if (aiLoading) return 'AI生成中...';
    if (aiOperationType === 'generate') return '生成台词';
    if (aiOperationType === 'rewrite') return '改写台词';
    return '开始润色';
  };

  const getCategoryName = (key: string): string => {
    const cat = categories.find((c: ScriptCategory) => c.key === key);
    return cat?.name || key;
  };

  const allCategories: ScriptCategory[] = [
    { key: '', name: '全部', icon: '' },
    ...categories,
  ];

  return (
    <div className="min-h-screen pb-36" style={{ background: '#FBF6F0' }}>
      <PageHeader title="台词库" onBack={() => navigate(-1)} />

      {/* AI 生成入口卡片 */}
      <div className="px-5 mb-5">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            openAiModal();
          }}
          className="w-full rounded-2xl p-5 text-left transition-all active:scale-[0.99] relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, #2C0A14 0%, #5C1525 50%, #8B1530 100%)',
            boxShadow: '0 4px 16px rgba(139, 21, 48, 0.20)',
            touchAction: 'manipulation',
            minHeight: '72px',
          }}
        >
          <div
            className="absolute top-0 right-0 w-40 h-40 rounded-full opacity-20"
            style={{
              background: 'radial-gradient(circle, #E8D5A3 0%, transparent 70%)',
              transform: 'translate(30%, -30%)',
            }}
          />
          <div className="relative z-10 flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{
                background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                boxShadow: '0 2px 8px rgba(201, 169, 97, 0.4)',
              }}
            >
              <Sparkles size={24} style={{ color: '#5C4520' }} />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-semibold font-serif" style={{ color: '#FFFDF8' }}>
                AI 生成台词
              </h3>
              <p className="text-xs mt-0.5" style={{ color: 'rgba(232, 213, 163, 0.85)' }}>
                输入描述，一键生成专业婚礼主持词
              </p>
            </div>
             {aiRemainingQuota !== null && (
               <span
                 className="text-[11px] px-2.5 py-1 rounded-full flex-shrink-0"
                 style={{
                   background: 'rgba(232, 213, 163, 0.2)',
                   color: '#E8D5A3',
                 }}
               >
                 剩 {aiRemainingQuota} 次
               </span>
             )}
          </div>
        </button>
      </div>

      {/* 搜索框 */}
      <div className="px-5 mb-4">
        <Input
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="搜索台词关键词..."
          leftIcon={<Search size={18} />}
        />
      </div>

      {/* 分类标签 - 横向滚动 */}
      <div
        ref={categoryScrollRef}
        className="flex gap-2 px-5 pb-4 overflow-x-auto scrollbar-hide"
      >
        {allCategories.map((cat: ScriptCategory) => (
          <button
            key={cat.key}
            onClick={() => handleCategoryClick(cat.key)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
              selectedCategory === cat.key
                ? 'text-white shadow-sm'
                : 'text-muted-foreground border border-border bg-card'
            }`}
            style={
              selectedCategory === cat.key
                ? {
                    background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                    boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                  }
                : {}
            }
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* 台词列表 */}
      <div className="px-5">
        {loading ? (
          <div className="space-y-3">
            {[0, 1, 2, 3].map((i: number) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-5 space-y-3"
                style={{ boxShadow: '0 2px 8px rgba(139, 21, 48, 0.06)' }}
              >
                <div className="flex items-center justify-between">
                  <Skeleton variant="text" width="70px" height="18px" />
                  <Skeleton variant="circle" width="22px" height="22px" />
                </div>
                <Skeleton variant="text" height="22px" />
                <Skeleton variant="text" />
                <Skeleton variant="text" width="60%" />
              </div>
            ))}
          </div>
        ) : scripts.length === 0 ? (
          <EmptyState
            icon={<FileText size={28} />}
            title="暂无台词"
            description={debouncedKeyword ? '换个关键词试试' : '点击上方AI生成或右下角创建台词'}
          />
        ) : (
          <div className="space-y-3 stagger-children">
            {scripts.map((script: Script) => (
              <div
                key={script.id}
                onClick={() => navigate(`/scripts/${script.id}`)}
                className="bg-white rounded-2xl p-5 cursor-pointer active:scale-[0.99] transition-transform"
                style={{ boxShadow: '0 2px 8px rgba(139, 21, 48, 0.06)' }}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <span
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                    style={{ background: 'rgba(185, 28, 60, 0.08)', color: '#B91C3C' }}
                  >
                    {getCategoryName(script.category)}
                  </span>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={(e) => handleCopy(e, script.content, script.title)}
                      className="p-1.5 text-gray-400 hover:text-gray-600 transition-colors"
                      aria-label="复制"
                    >
                      <Copy size={16} />
                    </button>
                    <button
                      onClick={(e) => handleToggleFavorite(e, script.id)}
                      className="p-1.5 transition-colors"
                      aria-label={script.isFavorite ? '取消收藏' : '收藏'}
                    >
                      <Heart
                        size={16}
                        className={
                          script.isFavorite
                            ? 'fill-primary text-primary'
                            : 'text-gray-300'
                        }
                      />
                    </button>
                  </div>
                </div>
                <h3 className="text-base font-semibold font-serif text-foreground mb-1.5 line-clamp-1 tracking-tight">
                  {script.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">
                  {script.content}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 悬浮 FAB 按钮 */}
      <button
        onClick={openCreateModal}
        className="fixed right-5 bottom-24 w-14 h-14 rounded-full text-primary-foreground flex items-center justify-center active:scale-95 transition-transform z-30"
        style={{
          background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
          boxShadow: '0 4px 16px rgba(185, 28, 60, 0.35)',
        }}
        aria-label="新建台词"
      >
        <Plus size={24} />
      </button>

      {/* 新建台词 BottomSheet */}
      <BottomSheet
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="新建台词"
        height="large"
      >
        <div className="px-5 py-5 space-y-5">
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              台词标题
            </label>
            <Input
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="请输入台词标题"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              选择分类
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat: ScriptCategory) => (
                <button
                  key={cat.key}
                  onClick={() => setNewCategory(cat.key)}
                  className="px-4 py-1.5 rounded-full text-sm font-medium transition-all"
                  style={
                    newCategory === cat.key
                      ? {
                          background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                          color: '#FFFDF8',
                          boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                        }
                      : {
                          background: '#FDF9F5',
                          color: '#6B5C5C',
                          border: '1px solid #E8DCD0',
                        }
                  }
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              台词内容
            </label>
            <TextArea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder="请输入台词内容..."
              rows={8}
            />
          </div>

          <div className="pt-2">
            <Button fullWidth loading={submitting} onClick={handleCreate}>
              {submitting ? '创建中...' : '创建台词'}
            </Button>
          </div>
        </div>
      </BottomSheet>

      {/* AI 生成台词 BottomSheet */}
      <BottomSheet
        open={showAiModal}
        onClose={() => setShowAiModal(false)}
        title="AI 生成台词"
        height="large"
      >
        <div className="px-5 py-5 space-y-5">
          {/* 操作类型分段控件 */}
          <div
            className="p-1 rounded-full flex"
            style={{ background: '#FDF9F5' }}
          >
            {AI_OPERATION_TYPES.map((op) => (
              <button
                key={op.key}
                onClick={() => {
                  setAiOperationType(op.key);
                  setAiGeneratedTitle('');
                  setAiGeneratedContent('');
                  setAiError(null);
                }}
                className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all ${
                  aiOperationType === op.key
                    ? 'shadow-md'
                    : 'text-muted-foreground'
                }`}
                style={
                  aiOperationType === op.key
                    ? {
                        background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                        color: '#FFFDF8',
                        boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                      }
                    : {}
                }
              >
                {op.label}
              </button>
            ))}
          </div>

          {/* 台词类型 */}
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              台词类型
            </label>
            <div className="flex flex-wrap gap-2">
              {AI_SPEECH_TYPES.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setAiSpeechType(s.key)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium transition-all"
                  style={
                    aiSpeechType === s.key
                      ? {
                          background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                          color: '#FFFDF8',
                          boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                        }
                      : {
                          background: '#FDF9F5',
                          color: '#6B5C5C',
                          border: '1px solid #E8DCD0',
                        }
                  }
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* 风格 */}
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              风格
            </label>
            <div className="flex flex-wrap gap-2">
              {AI_SPEECH_STYLES.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setAiSpeechStyle(s.key)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium transition-all"
                  style={
                    aiSpeechStyle === s.key
                      ? {
                          background: 'linear-gradient(135deg, #E8D5A3 0%, #C9A961 100%)',
                          color: '#5C4520',
                          boxShadow: '0 2px 8px rgba(201, 169, 97, 0.3)',
                        }
                      : {
                          background: '#FDF9F5',
                          color: '#6B5C5C',
                          border: '1px solid #E8DCD0',
                        }
                  }
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* 长度要求 */}
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              长度要求
            </label>
            <div className="flex flex-wrap gap-2">
              {AI_LENGTH_OPTIONS.map((l) => (
                <button
                  key={l.key}
                  onClick={() => setAiLengthRequirement(l.key)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium transition-all"
                  style={
                    aiLengthRequirement === l.key
                      ? {
                          background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                          color: '#FFFDF8',
                          boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                        }
                      : {
                          background: '#FDF9F5',
                          color: '#6B5C5C',
                          border: '1px solid #E8DCD0',
                        }
                  }
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* 关键信息 */}
          {aiOperationType !== 'polish' && (
            <div>
              <label className="block text-sm font-medium text-foreground/80 mb-2">
                关键信息
              </label>
              <TextArea
                value={aiKeyInformation}
                onChange={(e) => setAiKeyInformation(e.target.value)}
                placeholder="新人姓名、爱情故事、特别的记忆点等"
                rows={3}
              />
            </div>
          )}

          {/* 改写模式：原始台词 */}
          {aiOperationType === 'rewrite' && (
            <div>
              <label className="block text-sm font-medium text-foreground/80 mb-2">
                原始台词
              </label>
              <TextArea
                value={aiOriginalContent}
                onChange={(e) => setAiOriginalContent(e.target.value)}
                placeholder="粘贴需要改写的原始台词"
                rows={5}
              />
            </div>
          )}

          {/* 润色模式：待润色内容 */}
          {aiOperationType === 'polish' && (
            <div>
              <label className="block text-sm font-medium text-foreground/80 mb-2">
                待润色内容
              </label>
              <TextArea
                value={aiOriginalContent}
                onChange={(e) => setAiOriginalContent(e.target.value)}
                placeholder="粘贴需要润色优化的台词内容"
                rows={5}
              />
            </div>
          )}

          {/* 附加要求 */}
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              附加要求（选填）
            </label>
            <Input
              value={aiAdditionalRequirements}
              onChange={(e) => setAiAdditionalRequirements(e.target.value)}
              placeholder="如：需要包含古诗词、加入互动环节等"
            />
          </div>

          {/* 额度提示行 */}
          <div className="flex items-center justify-between px-1">
            <span className="text-sm text-muted-foreground">
              本月剩余 <span className="text-primary font-semibold">{aiRemainingQuota}</span> 次AI台词生成
            </span>
          </div>

          {/* 生成按钮 */}
          <Button fullWidth onClick={handleAiGenerate} loading={aiLoading}>
            <Sparkles size={18} />
            {getAiGenerateButtonText()}
          </Button>

          {/* 加载状态 */}
          {aiLoading && !aiGeneratedContent && (
            <div
              className="rounded-2xl p-8 text-center"
              style={{ background: '#FDF9F5', border: '1px solid #E8DCD0' }}
            >
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(185, 28, 60, 0.1)' }}>
                <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">AI正在为您生成</p>
              <p className="text-xs text-muted-foreground">请稍候，正在精心创作专属台词...</p>
            </div>
          )}

          {/* 错误状态 */}
          {aiError && !aiLoading && (
            <div
              className="rounded-2xl p-6 text-center"
              style={{ background: '#FDF9F5', border: '1px solid #E8DCD0' }}
            >
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(201, 48, 48, 0.1)' }}>
                <AlertCircle size={28} style={{ color: '#C93030' }} />
              </div>
              <p className="text-base font-semibold text-foreground mb-2">生成失败</p>
              <p className="text-sm text-muted-foreground mb-4">{aiError}</p>
              <Button variant="secondary" onClick={handleAiRegenerate}>
                重新生成
              </Button>
            </div>
          )}

          {/* 结果区 */}
          {aiGeneratedContent && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold font-serif text-foreground">
                  {aiGeneratedTitle || '生成结果'}
                </h3>
              </div>
              <div
                className="rounded-xl p-4 text-sm text-foreground leading-relaxed whitespace-pre-wrap min-h-[160px] max-h-[320px] overflow-y-auto"
                style={{ background: '#FDF9F5', border: '1px solid #E8DCD0' }}
              >
                {aiGeneratedContent}
              </div>
              <div className="grid grid-cols-3 gap-2">
                <Button variant="secondary" onClick={handleAiCopyResult}>
                  <Copy size={16} />
                  复制
                </Button>
                <Button variant="secondary" onClick={handleAiSave}>
                  <Save size={16} />
                  保存
                </Button>
                <Button variant="secondary" onClick={handleAiRegenerate} disabled={aiLoading}>
                  <RotateCcw size={16} />
                  重新生成
                </Button>
              </div>
              <p className="text-[11px] flex items-center gap-1.5" style={{ color: '#A09090' }}>
                <Sparkles size={12} style={{ color: '#C9A961' }} />
                {AI_DISCLAIMER}
              </p>
            </div>
          )}
        </div>
      </BottomSheet>

      {/* AI 保存到台词库 BottomSheet */}
      <BottomSheet
        open={showAiSaveDialog}
        onClose={() => setShowAiSaveDialog(false)}
        title="保存到台词库"
        height="medium"
      >
        <div className="px-5 py-5 space-y-5">
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              台词标题
            </label>
            <Input
              value={aiSaveTitle}
              onChange={(e) => setAiSaveTitle(e.target.value)}
              placeholder="请输入台词标题"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              选择分类
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.length > 0 ? (
                categories.map((cat: ScriptCategory) => (
                  <button
                    key={cat.key}
                    onClick={() => setAiSaveCategory(cat.key)}
                    className="px-4 py-1.5 rounded-full text-sm font-medium transition-all"
                    style={
                      aiSaveCategory === cat.key
                        ? {
                            background: 'linear-gradient(135deg, #D4354F 0%, #B91C3C 100%)',
                            color: '#FFFDF8',
                            boxShadow: '0 2px 8px rgba(185, 28, 60, 0.25)',
                          }
                        : {
                            background: '#FDF9F5',
                            color: '#6B5C5C',
                            border: '1px solid #E8DCD0',
                          }
                    }
                  >
                    {cat.name}
                  </button>
                ))
              ) : (
                <div className="text-sm text-muted-foreground">加载中...</div>
              )}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              标签（选填，多个用逗号分隔）
            </label>
            <Input
              value={aiSaveTags}
              onChange={(e) => setAiSaveTags(e.target.value)}
              placeholder="如：温馨感人, 户外婚礼, 轻松自然"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" fullWidth onClick={() => setShowAiSaveDialog(false)}>
              取消
            </Button>
            <Button fullWidth onClick={handleAiConfirmSave} disabled={aiSaving}>
              {aiSaving ? '保存中...' : '确认保存'}
            </Button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default ScriptsPage;
