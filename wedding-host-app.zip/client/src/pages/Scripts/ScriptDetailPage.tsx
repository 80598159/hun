import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Heart,
  Copy,
  Sparkles,
  Pencil,
  Trash2,
  ArrowLeft,
  X,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import {
  getScriptDetail,
  toggleFavorite,
  updateScript,
  deleteScript,
  getScriptCategories,
} from '@client/src/api/script';
import type { Script, ScriptCategory } from '@shared/api.interface';

const ScriptDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [script, setScript] = useState<Script | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [categories, setCategories] = useState<ScriptCategory[]>([]);

  // 编辑态
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editTitle, setEditTitle] = useState<string>('');
  const [editCategory, setEditCategory] = useState<string>('');
  const [editContent, setEditContent] = useState<string>('');
  const [editStyleTags, setEditStyleTags] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  // 删除确认
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);

  // 加载详情和分类
  useEffect(() => {
    const loadData = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const [detailData, catData] = await Promise.all([
          getScriptDetail(id),
          getScriptCategories(),
        ]);
        setScript(detailData as Script);
        setCategories((catData as ScriptCategory[]) || []);
      } catch (error) {
        logger.error('加载台词详情失败', error);
        showToast('加载失败，请重试', 'error');
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [id, showToast]);

  // 获取分类名
  const getCategoryName = (key: string): string => {
    const cat = categories.find((c: ScriptCategory) => c.key === key);
    return cat?.name || key;
  };

  // 切换收藏
  const handleToggleFavorite = async () => {
    if (!id || !script) return;
    try {
      await toggleFavorite(id);
      setScript({ ...script, isFavorite: !script.isFavorite });
    } catch (error) {
      logger.error('切换收藏失败', error);
      showToast('操作失败，请重试', 'error');
    }
  };

  // 复制全文
  const handleCopy = async () => {
    if (!script) return;
    try {
      await navigator.clipboard.writeText(script.content);
      showToast('已复制到剪贴板', 'success');
    } catch (error) {
      // 降级方案
      const textarea = document.createElement('textarea');
      textarea.value = script.content;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        showToast('已复制到剪贴板', 'success');
      } catch {
        showToast('复制失败，请手动复制', 'error');
      }
      document.body.removeChild(textarea);
    }
  };

  // 进入编辑模式
  const enterEditMode = () => {
    if (!script) return;
    setEditTitle(script.title);
    setEditCategory(script.category);
    setEditContent(script.content);
    setEditStyleTags(script.styleTags || '');
    setIsEditing(true);
  };

  // 取消编辑
  const cancelEdit = () => {
    setIsEditing(false);
  };

  // 保存编辑
  const handleSaveEdit = async () => {
    if (!id) return;
    if (!editTitle.trim()) {
      showToast('请输入台词标题', 'warning');
      return;
    }
    if (!editContent.trim()) {
      showToast('请输入台词内容', 'warning');
      return;
    }
    setSubmitting(true);
    try {
      const data = await updateScript(id, {
        title: editTitle.trim(),
        category: editCategory,
        content: editContent.trim(),
        styleTags: editStyleTags.trim(),
      });
      setScript(data as Script);
      setIsEditing(false);
      showToast('保存成功', 'success');
    } catch (error) {
      logger.error('保存失败', error);
      showToast('保存失败，请重试', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  // 删除台词
  const handleDelete = async () => {
    if (!id) return;
    setSubmitting(true);
    try {
      await deleteScript(id);
      showToast('已删除', 'success');
      navigate('/scripts');
    } catch (error) {
      logger.error('删除失败', error);
      showToast('删除失败，请重试', 'error');
      setSubmitting(false);
      setShowDeleteConfirm(false);
    }
  };

  // AI 改写
  const handleAiRewrite = () => {
    navigate('/ai/script', {
      state: script
        ? {
            originalContent: script.content,
            operationType: 'rewrite',
          }
        : undefined,
    });
  };

  // 风格标签解析
  const styleTagsList = script?.styleTags
    ? script.styleTags.split(',').filter((t: string) => t.trim())
    : [];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!script) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader title="台词详情" onBack={() => navigate(-1)} />
        <div className="px-4 py-16 text-center text-gray-500">
          台词不存在或已被删除
        </div>
      </div>
    );
  }

  const isCustom = !script.isSystem;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* 顶部导航 */}
      <PageHeader
        title={getCategoryName(script.category)}
        onBack={() => navigate(-1)}
        rightAction={
          <button
            onClick={handleToggleFavorite}
            className="p-1 -mr-1"
            aria-label={script.isFavorite ? '取消收藏' : '收藏'}
          >
            <Heart
              size={22}
              className={
                script.isFavorite
                  ? 'fill-[#C41E3A] text-[#C41E3A]'
                  : 'text-gray-600'
              }
            />
          </button>
        }
      />

      {/* 编辑模式 */}
      {isEditing ? (
        <div className="px-4">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                台词标题
              </label>
              <Input
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="请输入台词标题"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                分类
              </label>
              <div className="flex flex-wrap gap-2">
                {categories.map((cat: ScriptCategory) => (
                  <button
                    key={cat.key}
                    onClick={() => setEditCategory(cat.key)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                      editCategory === cat.key
                        ? 'bg-[#C41E3A] text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                风格标签（逗号分隔）
              </label>
              <Input
                value={editStyleTags}
                onChange={(e) => setEditStyleTags(e.target.value)}
                placeholder="如：温馨、浪漫、幽默"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                台词内容
              </label>
              <TextArea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                placeholder="请输入台词内容..."
                rows={16}
              />
            </div>
          </div>

          <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-100 flex gap-3 z-40">
            <Button variant="secondary" fullWidth onClick={cancelEdit}>
              取消
            </Button>
            <Button fullWidth disabled={submitting} onClick={handleSaveEdit}>
              {submitting ? '保存中...' : '保存'}
            </Button>
          </div>
        </div>
      ) : (
        <>
          {/* 详情内容 */}
          <div className="px-4">
            <h1 className="text-xl font-bold text-gray-900 mb-3">
              {script.title}
            </h1>

            {/* 风格标签 */}
            {styleTagsList.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-5">
                {styleTagsList.map((tag: string, index: number) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-[#D4AF37]/15 text-[#B8860B] border border-[#D4AF37]/30"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}

            {/* 台词正文 */}
            <div className="bg-white rounded-xl p-5 shadow-sm">
              <div className="text-[15px] text-gray-800 leading-[1.9] whitespace-pre-wrap">
                {script.content}
              </div>
            </div>
          </div>

          {/* 底部操作栏 */}
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-4 py-3 z-40">
            <div className="flex gap-2">
              <button
                onClick={handleCopy}
                className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-600 active:bg-gray-50 rounded-lg"
                aria-label="复制全文"
              >
                <Copy size={20} />
                <span className="text-xs">复制</span>
              </button>

              <button
                onClick={handleAiRewrite}
                className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-[#C41E3A] active:bg-[#C41E3A]/5 rounded-lg"
                aria-label="AI改写"
              >
                <Sparkles size={20} />
                <span className="text-xs">AI改写</span>
              </button>

              {isCustom && (
                <>
                  <button
                    onClick={enterEditMode}
                    className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-600 active:bg-gray-50 rounded-lg"
                    aria-label="编辑"
                  >
                    <Pencil size={20} />
                    <span className="text-xs">编辑</span>
                  </button>

                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-600 active:bg-gray-50 rounded-lg"
                    aria-label="删除"
                  >
                    <Trash2 size={20} />
                    <span className="text-xs">删除</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </>
      )}

      {/* 删除确认弹窗 */}
      {showDeleteConfirm && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4"
          onClick={() => setShowDeleteConfirm(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              确认删除
            </h3>
            <p className="text-sm text-gray-600 mb-5">
              删除后无法恢复，确定要删除这条台词吗？
            </p>
            <div className="flex gap-3">
              <Button
                variant="secondary"
                fullWidth
                onClick={() => setShowDeleteConfirm(false)}
              >
                取消
              </Button>
              <Button
                fullWidth
                disabled={submitting}
                onClick={handleDelete}
                className="bg-red-500 hover:bg-red-600"
              >
                {submitting ? '删除中...' : '删除'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScriptDetailPage;
