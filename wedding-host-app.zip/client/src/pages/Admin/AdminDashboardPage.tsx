import React, { useEffect, useState } from 'react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import {
  Users,
  Mic2,
  ClipboardList,
  Sparkles,
  DollarSign,
  ShoppingCart,
  Package,
  Store,
  Clock,
  AlertTriangle,
  TrendingUp,
} from 'lucide-react';
import { Table, type TableProps } from '@lark-apaas/client-toolkit/antd-table';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import type {
  AdminDashboardResponse,
  AdminDashboardStats,
  AdminTrendPoint,
  AdminOrderItem,
} from '@shared/api.interface';

interface StatCardConfig {
  key: keyof AdminDashboardStats;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  bg: string;
  iconBg: string;
  iconColor: string;
  valueColor: string;
  formatter?: (value: number) => string;
}

const statCards: StatCardConfig[] = [
  { key: 'totalUsers', label: '注册用户总数', icon: Users, bg: 'bg-blue-50', iconBg: 'bg-blue-500', iconColor: 'text-blue-500', valueColor: 'text-blue-600' },
  { key: 'activeHosts', label: '活跃主持人', icon: Mic2, bg: 'bg-emerald-50', iconBg: 'bg-emerald-500', iconColor: 'text-emerald-500', valueColor: 'text-emerald-600' },
  { key: 'totalProjects', label: '婚礼方案总数', icon: ClipboardList, bg: 'bg-violet-50', iconBg: 'bg-violet-500', iconColor: 'text-violet-500', valueColor: 'text-violet-600' },
  { key: 'totalAiCalls', label: 'AI调用总次数', icon: Sparkles, bg: 'bg-orange-50', iconBg: 'bg-orange-500', iconColor: 'text-orange-500', valueColor: 'text-orange-600' },
  { key: 'totalRevenue', label: '订单总额(¥)', icon: DollarSign, bg: 'bg-rose-50', iconBg: 'bg-rose-500', iconColor: 'text-rose-500', valueColor: 'text-rose-600', formatter: (v) => v.toLocaleString() },
  { key: 'totalOrders', label: '订单总数', icon: ShoppingCart, bg: 'bg-indigo-50', iconBg: 'bg-indigo-500', iconColor: 'text-indigo-500', valueColor: 'text-indigo-600' },
  { key: 'materialSales', label: '素材销量', icon: Package, bg: 'bg-cyan-50', iconBg: 'bg-cyan-500', iconColor: 'text-cyan-500', valueColor: 'text-cyan-600' },
  { key: 'merchantCount', label: '商家总数', icon: Store, bg: 'bg-pink-50', iconBg: 'bg-pink-500', iconColor: 'text-pink-500', valueColor: 'text-pink-600' },
  { key: 'pendingMerchants', label: '待审核商家', icon: Clock, bg: 'bg-amber-50', iconBg: 'bg-amber-500', iconColor: 'text-amber-500', valueColor: 'text-amber-600' },
  { key: 'pendingAudits', label: '待审核内容', icon: AlertTriangle, bg: 'bg-red-50', iconBg: 'bg-red-500', iconColor: 'text-red-500', valueColor: 'text-red-600' },
];

function buildLineOption(
  title: string,
  data: AdminTrendPoint[],
  color: string,
  yName: string,
): EChartsOption {
  return {
    title: {
      text: title,
      textStyle: { fontSize: 14, fontWeight: 600, color: '#1e293b' },
      left: 12,
      top: 12,
    },
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(30, 41, 59, 0.9)',
      borderWidth: 0,
      textStyle: { color: '#fff', fontSize: 12 },
      formatter: (params: unknown) => {
        const arr = params as { name: string; value: number }[];
        if (!arr || arr.length === 0) return '';
        return `${arr[0].name}<br/>${yName}：${arr[0].value.toLocaleString()}`;
      },
    },
    grid: {
      left: 48,
      right: 20,
      top: 56,
      bottom: 28,
      containLabel: false,
    },
    xAxis: {
      type: 'category',
      data: data.map((d) => d.date),
      boundaryGap: false,
      axisLine: { lineStyle: { color: '#e2e8f0' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      name: yName,
      nameTextStyle: { color: '#94a3b8', fontSize: 11, padding: [0, 0, 0, -36] },
      splitLine: { lineStyle: { color: '#f1f5f9', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    series: [
      {
        name: yName,
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        data: data.map((d) => d.value),
        lineStyle: { color, width: 2 },
        itemStyle: { color, borderWidth: 2, borderColor: '#fff' },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: color + '33' },
              { offset: 1, color: color + '05' },
            ],
          },
        },
      },
    ],
  };
}

const AdminDashboardPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<AdminDashboardResponse | null>(null);

  useEffect(() => {
    let cancelled = false;
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await admin.getDashboardStats();
        if (!cancelled) setData(res);
      } catch (err: unknown) {
        if (!cancelled) {
          const message =
            (err as { response?: { data?: { error?: { message?: string } } } }).response?.data
              ?.error?.message || '数据加载失败';
          setError(message);
          showToast(message, 'error');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void fetchData();
    return () => {
      cancelled = true;
    };
  }, [showToast]);

  const orderColumns: TableProps<AdminOrderItem>['columns'] = [
    {
      title: '用户',
      dataIndex: 'userNickname',
      key: 'userNickname',
      width: 120,
      ellipsis: true,
    },
    {
      title: '商品',
      dataIndex: 'productName',
      key: 'productName',
      ellipsis: true,
    },
    {
      title: '金额',
      dataIndex: 'amount',
      key: 'amount',
      width: 100,
      render: (value: number) => <span className="font-medium text-[#ef4444]">¥{value}</span>,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (value: string) => {
        const map: Record<string, { color: string; bg: string; label: string }> = {
          paid: { color: 'text-emerald-600', bg: 'bg-emerald-50', label: '已支付' },
          pending: { color: 'text-amber-600', bg: 'bg-amber-50', label: '待支付' },
          refunded: { color: 'text-rose-600', bg: 'bg-rose-50', label: '已退款' },
          cancelled: { color: 'text-gray-500', bg: 'bg-gray-100', label: '已取消' },
        };
        const conf = map[value] || { color: 'text-gray-500', bg: 'bg-gray-100', label: value };
        return (
          <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${conf.color} ${conf.bg}`}>
            {conf.label}
          </span>
        );
      },
    },
    {
      title: '时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 160,
      render: (value: string) => new Date(value).toLocaleString('zh-CN', { hour12: false }),
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 text-[#64748b] text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 border-2 border-[#2563eb] border-t-transparent rounded-full animate-spin" />
          加载中...
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-[#64748b]">
        <AlertTriangle size={32} className="text-amber-500 mb-3" />
        <p className="text-sm mb-3">{error || '暂无数据'}</p>
      </div>
    );
  }

  const { stats, userTrend, aiTrend, revenueTrend, recentOrders } = data;

  return (
    <div className="space-y-6">
      {/* Page title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-[#1e293b]">数据看板</h1>
          <p className="text-sm text-[#64748b] mt-1">实时查看平台核心运营数据</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-[#64748b]">
          <TrendingUp size={14} className="text-emerald-500" />
          <span>数据更新至今日</span>
        </div>
      </div>

      {/* Stat cards */}
      <div
        className="grid gap-4
        grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5"
      >
        {statCards.map((card) => {
          const Icon = card.icon;
          const rawValue = stats[card.key];
          const displayValue = card.formatter ? card.formatter(rawValue) : rawValue.toLocaleString();
          return (
            <div
              key={card.key}
              className={`${card.bg} bg-opacity-40 rounded-lg p-4 border border-white/60 shadow-sm
                hover:shadow-md transition-shadow duration-200`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-lg ${card.iconBg} bg-opacity-100 flex items-center justify-center text-white`}>
                  <Icon size={18} />
                </div>
              </div>
              <div className={`text-2xl font-bold ${card.valueColor} leading-tight`}>
                {displayValue}
              </div>
              <div className="text-xs text-[#64748b] mt-1.5">{card.label}</div>
            </div>
          );
        })}
      </div>

      {/* Middle charts - 2 columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg shadow-sm p-4">
          <ReactECharts
            option={buildLineOption('近7天用户新增趋势', userTrend, '#2563eb', '新增用户')}
            style={{ height: 300, width: '100%' }}
            notMerge
          />
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4">
          <ReactECharts
            option={buildLineOption('近7天收入趋势', revenueTrend, '#ef4444', '收入(元)')}
            style={{ height: 300, width: '100%' }}
            notMerge
          />
        </div>
      </div>

      {/* Bottom - AI chart + recent orders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg shadow-sm p-4">
          <ReactECharts
            option={buildLineOption('近7天 AI 调用量趋势', aiTrend, '#f97316', '调用次数')}
            style={{ height: 300, width: '100%' }}
            notMerge
          />
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="text-sm font-semibold text-[#1e293b] mb-3 px-1">最近订单</div>
          <div style={{ fontSize: 12 }}>
            <Table<AdminOrderItem>
              columns={orderColumns}
              dataSource={recentOrders.slice(0, 5)}
              rowKey="id"
              pagination={false}
              size="small"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
