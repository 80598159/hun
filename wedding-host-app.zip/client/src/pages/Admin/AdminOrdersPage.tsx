import { useState, useEffect, useCallback } from 'react';
import {
  Table,
  type TableProps,
} from '@lark-apaas/client-toolkit/antd-table';
import { Search, ShoppingCart, DollarSign, Undo2, CreditCard } from 'lucide-react';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Input } from '@client/src/components/ui/input';
import type {
  AdminOrderItem,
  AdminOrderSummary,
} from '@shared/api.interface';

const statusLabelMap: Record<string, string> = {
  pending: '待支付',
  paid: '已支付',
  refunded: '已退款',
  cancelled: '已取消',
};

const statusVariantMap: Record<string, 'default' | 'secondary' | 'outline' | 'destructive'> = {
  pending: 'secondary',
  paid: 'default',
  refunded: 'outline',
  cancelled: 'destructive',
};

const productTypeLabelMap: Record<string, string> = {
  ai_quota: 'AI充值包',
  poster_template: '海报模板',
};

interface ConfirmActionState {
  order: AdminOrderItem;
  action: 'paid' | 'refunded' | 'cancelled';
}

const AdminOrdersPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [orders, setOrders] = useState<AdminOrderItem[]>([]);
  const [summary, setSummary] = useState<AdminOrderSummary | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [keyword, setKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmState, setConfirmState] = useState<ConfirmActionState | null>(
    null,
  );
  const [submitting, setSubmitting] = useState(false);

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      const params: admin.AdminOrderListParams = {
        page,
        pageSize,
      };
      if (keyword.trim()) params.keyword = keyword.trim();
      if (statusFilter !== 'all') params.status = statusFilter;
      const res = await admin.getAdminOrders(params);
      setOrders(res.items);
      setTotal(res.total);
      setSummary(res.summary);
    } catch (err) {
      showToast('加载订单列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, keyword, statusFilter, showToast]);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const handleSearch = () => {
    setPage(1);
    fetchOrders();
  };

  const openConfirm = (order: AdminOrderItem, action: 'paid' | 'refunded' | 'cancelled') => {
    setConfirmState({ order, action });
    setConfirmOpen(true);
  };

  const handleConfirm = async () => {
    if (!confirmState) return;
    setSubmitting(true);
    try {
      await admin.updateOrderStatus(confirmState.order.id, {
        status: confirmState.action,
      });
      const actionLabels: Record<string, string> = {
        paid: '标记已支付成功',
        refunded: '标记退款成功',
        cancelled: '取消订单成功',
      };
      showToast(actionLabels[confirmState.action], 'success');
      setConfirmOpen(false);
      setConfirmState(null);
      fetchOrders();
    } catch (err) {
      showToast('操作失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const getConfirmTitle = (action: string): string => {
    const map: Record<string, string> = {
      paid: '确认标记为已支付？',
      refunded: '确认标记为已退款？',
      cancelled: '确认取消订单？',
    };
    return map[action] ?? '确认操作？';
  };

  const getConfirmDesc = (action: string, orderNo: string): string => {
    const map: Record<string, string> = {
      paid: `确定将订单 ${orderNo} 标记为已支付吗？`,
      refunded: `确定将订单 ${orderNo} 标记为已退款吗？退款后订单金额将计入退款统计。`,
      cancelled: `确定取消订单 ${orderNo} 吗？取消后订单将不可恢复。`,
    };
    return map[action] ?? '';
  };

  const renderActions = (record: AdminOrderItem): React.ReactNode => {
    const { status } = record;
    return (
      <div className="flex items-center gap-1">
        {status === 'pending' && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => openConfirm(record, 'paid')}
            aria-label="标记已支付"
          >
            <CreditCard className="h-3.5 w-3.5" />
            标记已支付
          </Button>
        )}
        {status === 'paid' && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => openConfirm(record, 'refunded')}
            aria-label="标记退款"
          >
            <Undo2 className="h-3.5 w-3.5" />
            标记退款
          </Button>
        )}
        {(status === 'pending') && (
          <Button
            size="sm"
            variant="ghost"
            className="text-destructive"
            onClick={() => openConfirm(record, 'cancelled')}
            aria-label="取消订单"
          >
            取消订单
          </Button>
        )}
      </div>
    );
  };

  const columns: TableProps<AdminOrderItem>['columns'] = [
    {
      title: '订单号',
      dataIndex: 'id',
      key: 'id',
      width: 180,
      render: (id: string) => (
        <span className="font-mono text-xs">{id.slice(0, 8)}...</span>
      ),
    },
    {
      title: '用户昵称',
      dataIndex: 'userNickname',
      key: 'userNickname',
      width: 120,
    },
    {
      title: '商品名称',
      dataIndex: 'productName',
      key: 'productName',
      minWidth: 160,
    },
    {
      title: '商品类型',
      dataIndex: 'productType',
      key: 'productType',
      width: 120,
      render: (type: string) => productTypeLabelMap[type] ?? type,
    },
    {
      title: '金额（¥）',
      dataIndex: 'amount',
      key: 'amount',
      width: 110,
      render: (amount: number) => (
        <span className="font-medium text-slate-800">
          ¥{amount.toFixed(2)}
        </span>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: string) => (
        <Badge variant={statusVariantMap[status] ?? 'outline'}>
          {statusLabelMap[status] ?? status}
        </Badge>
      ),
    },
    {
      title: '支付时间',
      dataIndex: 'paidAt',
      key: 'paidAt',
      width: 170,
      render: (paidAt: string | null) =>
        paidAt ? new Date(paidAt).toLocaleString('zh-CN') : '-',
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 170,
      render: (createdAt: string) =>
        new Date(createdAt).toLocaleString('zh-CN'),
    },
    {
      title: '操作',
      key: 'actions',
      width: 180,
      fixed: 'right',
      render: (_: unknown, record: AdminOrderItem) => renderActions(record),
    },
  ];

  const statCards = [
    {
      label: '总订单数',
      value: total.toString(),
      icon: ShoppingCart,
      color: '#2563eb',
    },
    {
      label: '总金额',
      value: `¥${summary?.totalAmount?.toFixed(2) ?? '0.00'}`,
      icon: DollarSign,
      color: '#10b981',
    },
    {
      label: '已支付金额',
      value: `¥${summary?.paidAmount?.toFixed(2) ?? '0.00'}`,
      icon: CreditCard,
      color: '#3b82f6',
    },
    {
      label: '已退款金额',
      value: `¥${summary?.refundAmount?.toFixed(2) ?? '0.00'}`,
      icon: Undo2,
      color: '#ef4444',
    },
  ];

  return (
    <div className="min-h-full" style={{ backgroundColor: '#f1f5f9' }}>
      <div className="mx-auto max-w-[1400px] p-6">
        <h1 className="text-2xl font-bold text-slate-800 mb-6">订单管理</h1>

        {/* 汇总卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {statCards.map((card, index: number) => {
            const Icon = card.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-lg p-5 shadow-sm flex items-center gap-4"
              >
                <div
                  className="flex h-12 w-12 items-center justify-center rounded-lg text-white"
                  style={{ backgroundColor: card.color }}
                >
                  <Icon className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">{card.label}</p>
                  <p className="text-2xl font-bold text-slate-800 mt-1">
                    {card.value}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* 筛选栏 */}
        <div className="bg-white rounded-lg p-4 mb-4 shadow-sm flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md">
            <Input
              placeholder="搜索订单号 / 用户昵称"
              value={keyword}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setKeyword(e.target.value)
              }
              onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                if (e.key === 'Enter') handleSearch();
              }}
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">状态：</span>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="pending">待支付</SelectItem>
                <SelectItem value="paid">已支付</SelectItem>
                <SelectItem value="refunded">已退款</SelectItem>
                <SelectItem value="cancelled">已取消</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleSearch}
            style={{ backgroundColor: '#2563eb' }}
            className="text-white hover:bg-blue-700"
          >
            <Search className="h-4 w-4" />
            搜索
          </Button>
        </div>

        {/* 表格 */}
        <div className="bg-white rounded-lg shadow-sm">
          <Table<AdminOrderItem>
            rowKey="id"
            columns={columns}
            dataSource={orders}
            loading={loading}
            pagination={{
              current: page,
              pageSize,
              total,
              onChange: (p: number) => setPage(p),
              showSizeChanger: false,
            }}
            scroll={{ x: 1150 }}
          />
        </div>
      </div>

      {/* 操作确认弹窗 */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>
              {confirmState ? getConfirmTitle(confirmState.action) : ''}
            </DialogTitle>
            <DialogDescription>
              {confirmState
                ? getConfirmDesc(
                    confirmState.action,
                    confirmState.order.id.slice(0, 8) + '...',
                  )
                : ''}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>
              取消
            </Button>
            <Button
              variant={confirmState?.action === 'cancelled' ? 'destructive' : 'default'}
              style={
                confirmState?.action !== 'cancelled'
                  ? { backgroundColor: '#2563eb' }
                  : undefined
              }
              className={confirmState?.action !== 'cancelled' ? 'text-white hover:bg-blue-700' : ''}
              disabled={submitting}
              onClick={handleConfirm}
            >
              {submitting ? '处理中...' : '确认'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminOrdersPage;
