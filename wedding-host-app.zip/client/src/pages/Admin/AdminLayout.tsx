import React, { useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  ClipboardList,
  BookOpen,
  Package,
  Receipt,
  Store,
  Shield,
  Menu,
  X,
  LogOut,
  User,
  ChevronRight,
  Key,
  Settings,
} from 'lucide-react';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';

const menuItems = [
  { path: '/admin', icon: LayoutDashboard, label: '数据看板', end: true },
  { path: '/admin/users', icon: Users, label: '用户管理' },
  { path: '/admin/projects', icon: ClipboardList, label: '婚礼方案' },
  { path: '/admin/scripts', icon: BookOpen, label: '台词库' },
  { path: '/admin/products', icon: Package, label: '素材商店' },
  { path: '/admin/orders', icon: Receipt, label: '订单管理' },
  { path: '/admin/merchants', icon: Store, label: '商圈商家' },
  { path: '/admin/audits', icon: Shield, label: '内容合规' },
  { path: '/admin/ai-api', icon: Key, label: 'API设置' },
  { path: '/admin/settings', icon: Settings, label: '系统配置' },
];

const AdminLayout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { showToast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const session = admin.getAdminSession();
  const username = session?.username || '管理员';

  const handleLogout = () => {
    admin.clearAdminSession();
    showToast('已退出登录', 'success');
    navigate('/admin/login', { replace: true });
  };

  return (
    <div className="min-h-screen bg-[#f1f5f9]" style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", "PingFang SC", sans-serif' }}>
      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-40 h-screen w-[220px] bg-[#1e293b] text-white transition-transform duration-300 ease-in-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          md:translate-x-0`}
      >
        {/* Logo */}
        <div className="flex items-center h-14 px-5 border-b border-white/10">
          <div className="w-8 h-8 rounded-lg bg-[#2563eb] flex items-center justify-center mr-3">
            <span className="text-white font-bold text-sm">婚</span>
          </div>
          <span className="text-white font-semibold text-base tracking-tight">婚序·管理后台</span>
        </div>

        {/* Menu */}
        <nav className="p-3 space-y-1 overflow-y-auto h-[calc(100vh-56px)]">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.end}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) =>
                  `flex items-center px-3 py-2.5 rounded-lg text-sm transition-colors duration-150
                  ${isActive
                    ? 'bg-[#2563eb] text-white font-medium'
                    : 'text-gray-300 hover:bg-white/10 hover:text-white'
                  }`
                }
              >
                <Icon size={18} className="mr-3 flex-shrink-0" />
                <span className="flex-1">{item.label}</span>
                <ChevronRight size={14} className="opacity-60" />
              </NavLink>
            );
          })}
        </nav>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Main content */}
      <div className="md:ml-[220px]">
        {/* Top navbar */}
        <header className="sticky top-0 z-20 h-14 bg-white border-b border-gray-200/60 shadow-sm flex items-center px-6">
          {/* Hamburger */}
          <button
            className="md:hidden mr-3 p-1.5 rounded-md hover:bg-gray-100 text-gray-600"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            aria-label={sidebarOpen ? '收起菜单' : '展开菜单'}
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Breadcrumb */}
          <div className="flex items-center text-sm text-[#64748b]">
            <span>管理后台</span>
            <ChevronRight size={14} className="mx-1.5" />
            <span className="text-[#1e293b] font-medium">
              {menuItems.find((m) =>
                m.end
                  ? location.pathname === m.path
                  : location.pathname.startsWith(m.path),
              )?.label || '数据看板'}
            </span>
          </div>

          {/* Right side */}
          <div className="ml-auto flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-[#1e293b]">
              <div className="w-7 h-7 rounded-full bg-[#2563eb]/10 flex items-center justify-center text-[#2563eb]">
                <User size={14} />
              </div>
              <span className="font-medium hidden sm:inline">{username}</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-[#64748b] hover:text-[#ef4444] hover:bg-red-50 rounded-md transition-colors"
              aria-label="退出登录"
            >
              <LogOut size={16} />
              <span className="hidden sm:inline">退出</span>
            </button>
          </div>
        </header>

        {/* Content area */}
        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
