import { useCallback, useEffect, useState } from 'react';
import {
  Table,
  type TableProps,
} from '@lark-apaas/client-toolkit/antd-table';
import { Pencil, Settings as SettingsIcon } from 'lucide-react';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import type { SystemConfigItem } from '@shared/api.interface';

const CONFIG_LABEL_MAP: Record<string, string> = {
  poster_photo_update_limit_per_project: '形象照更新次数限制/方案',
};

function getConfigLabel(configKey: string): string {
  return CONFIG_LABEL_MAP[configKey] || configKey;
}

const AdminSettingsPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [configs, setConfigs] = useState<SystemConfigItem[]>([]);

  const [editOpen, setEditOpen] = useState(false);
  const [editingConfig, setEditingConfig] = useState<SystemConfigItem | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);

  const fetchConfigs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await admin.getSystemConfigs();
      setConfigs(res.items);
    } catch {
      showToast('加载系统配置失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchConfigs();
  }, [fetchConfigs]);

  const handleEdit = (config: SystemConfigItem) => {
    setEditingConfig(config);
    setEditValue(config.configValue);
    setEditOpen(true);
  };

  const handleSave = async () => {
    if (!editingConfig) return;
    setSubmitting(true);
    try {
      await admin.updateSystemConfig(editingConfig.configKey, {
        configValue: editValue,
      });
      showToast('配置更新成功', 'success');
      setEditOpen(false);
      fetchConfigs();
    } catch {
      showToast('配置更新失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const renderValue = (config: SystemConfigItem) => {
    const { configType, configValue, configKey } = config;
    if (configKey === 'poster_photo_update_limit_per_project') {
      const num = Number(configValue);
      return (
        <span className="text-sm font-medium text-slate-700">
          {num === 0 ? '不限制' : `${num} 次`}
        </span>
      );
    }
    if (configType === 'boolean') {
      return (
        <span className={`text-sm font-medium ${configValue === 'true' ? 'text-green-600' : 'text-slate-500'}`}>
          {configValue === 'true' ? '开启' : '关闭'}
        </span>
      );
    }
    if (configType === 'number') {
      return <span className="text-sm font-medium text-slate-700">{configValue}</span>;
    }
    return (
      <span className="text-sm text-slate-700" title={configValue}>
        {configValue || '—'}
      </span>
    );
  };

  const renderEditor = () => {
    if (!editingConfig) return null;
    const { configType, configKey } = editingConfig;

    if (configKey === 'poster_photo_update_limit_per_project') {
      return (
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">配置值（0 表示不限制）</label>
          <Input
            type="number"
            min={0}
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            placeholder="请输入次数，0 表示不限制"
          />
        </div>
      );
    }

    if (configType === 'boolean') {
      return (
        <div className="flex items-center justify-between py-2">
          <span className="text-sm font-medium text-slate-700">启用</span>
          <Switch
            checked={editValue === 'true'}
            onCheckedChange={(checked: boolean) => setEditValue(checked ? 'true' : 'false')}
          />
        </div>
      );
    }

    if (configType === 'number') {
      return (
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">配置值</label>
          <Input
            type="number"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
          />
        </div>
      );
    }

    return (
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">配置值</label>
        <Input
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
        />
      </div>
    );
  };

  const columns: TableProps<SystemConfigItem>['columns'] = [
    {
      title: '配置名称',
      dataIndex: 'configKey',
      width: 260,
      render: (_: string, record: SystemConfigItem) => (
        <div>
          <div className="text-sm font-semibold text-slate-900">
            {getConfigLabel(record.configKey)}
          </div>
          <div className="text-xs text-slate-400 mt-0.5 font-mono">
            {record.configKey}
          </div>
        </div>
      ),
    },
    {
      title: '配置值',
      dataIndex: 'configValue',
      width: 200,
      render: (_: string, record: SystemConfigItem) => renderValue(record),
    },
    {
      title: '类型',
      dataIndex: 'configType',
      width: 100,
      render: (val: string) => (
        <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded">
          {val}
        </span>
      ),
    },
    {
      title: '描述',
      dataIndex: 'description',
      width: 300,
      render: (val: string) => (
        <span className="text-sm text-slate-600">{val || '—'}</span>
      ),
    },
    {
      title: '更新时间',
      dataIndex: 'updatedAt',
      width: 180,
      render: (val: string) => (
        <span className="text-sm text-slate-500">{val || '—'}</span>
      ),
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 120,
      render: (_: unknown, record: SystemConfigItem) => (
        <Button variant="ghost" size="sm" onClick={() => handleEdit(record)}>
          <Pencil size={14} className="mr-1" />
          编辑
        </Button>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100 p-6">
      <div className="max-w-[1400px] mx-auto space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
            <SettingsIcon size={20} className="text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">系统参数配置</h1>
            <p className="text-sm text-slate-500 mt-1">管理应用全局系统参数与限制</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm">
          <Table
            rowKey="id"
            columns={columns}
            dataSource={configs}
            loading={loading}
            scroll={{ x: 1100, y: 560 }}
            pagination={false}
          />
        </div>

        {/* 编辑弹窗 */}
        <Dialog open={editOpen} onOpenChange={setEditOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>编辑配置</DialogTitle>
              <DialogDescription>
                {editingConfig
                  ? getConfigLabel(editingConfig.configKey)
                  : ''}
              </DialogDescription>
            </DialogHeader>
            {editingConfig && (
              <div className="space-y-4 py-2">
                {renderEditor()}
                {editingConfig.description && (
                  <p className="text-xs text-slate-400">
                    说明：{editingConfig.description}
                  </p>
                )}
              </div>
            )}
            <DialogFooter>
              <Button variant="ghost" onClick={() => setEditOpen(false)}>取消</Button>
              <Button onClick={handleSave} disabled={submitting}>
                {submitting ? '保存中...' : '保存'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminSettingsPage;
