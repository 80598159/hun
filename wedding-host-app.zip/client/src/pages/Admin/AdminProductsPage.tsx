import { useState, useEffect, useCallback } from 'react';
import {
  Table,
  type TableProps,
} from '@lark-apaas/client-toolkit/antd-table';
import { Plus, Trash2, Pencil, ArrowUpDown } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import type { AdminProduct } from '@shared/api.interface';

const productFormSchema = z.object({
  type: z.enum(['ai_quota', 'poster_template']),
  name: z.string().min(1, '请输入商品名称'),
  description: z.string().optional(),
  price: z.coerce.number().min(0, '价格不能小于0'),
  originalPrice: z.coerce.number().min(0, '原价不能小于0').nullable().default(null),
  flowQuota: z.coerce.number().min(0, '流程额度不能小于0').default(0),
  scriptQuota: z.coerce.number().min(0, '台词额度不能小于0').default(0),
  sortOrder: z.coerce.number().int('排序号必须为整数').default(0),
});

type ProductFormValues = z.infer<typeof productFormSchema>;

const typeLabelMap: Record<string, string> = {
  ai_quota: 'AI充值包',
  poster_template: '海报模板',
};

const AdminProductsPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [formOpen, setFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<AdminProduct | null>(
    null,
  );
  const [submitting, setSubmitting] = useState(false);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deletingProduct, setDeletingProduct] = useState<AdminProduct | null>(
    null,
  );
  const [deleting, setDeleting] = useState(false);

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema) as any,
    defaultValues: {
      type: 'ai_quota',
      name: '',
      description: '',
      price: 0,
      originalPrice: 0,
      flowQuota: 0,
      scriptQuota: 0,
      sortOrder: 0,
    },
  });

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params: admin.AdminProductListParams = {};
      if (typeFilter !== 'all') params.type = typeFilter;
      if (statusFilter === 'active') params.isActive = true;
      if (statusFilter === 'inactive') params.isActive = false;
      const res = await admin.getAdminProducts(params);
      setProducts(res.items);
    } catch (err) {
      showToast('加载商品列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [typeFilter, statusFilter, showToast]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const handleAdd = () => {
    setEditingProduct(null);
    form.reset({
      type: 'ai_quota',
      name: '',
      description: '',
      price: 0,
      originalPrice: 0,
      flowQuota: 0,
      scriptQuota: 0,
      sortOrder: 0,
    });
    setFormOpen(true);
  };

  const handleEdit = (product: AdminProduct) => {
    setEditingProduct(product);
    form.reset({
      type: product.type as 'ai_quota' | 'poster_template',
      name: product.name,
      description: product.description,
      price: product.price,
      originalPrice: product.originalPrice ?? 0,
      flowQuota: product.flowQuota,
      scriptQuota: product.scriptQuota,
      sortOrder: product.sortOrder,
    });
    setFormOpen(true);
  };

  const handleSubmit = async (values: ProductFormValues) => {
    setSubmitting(true);
    try {
      if (editingProduct) {
        await admin.updateAdminProduct(editingProduct.id, values);
        showToast('商品更新成功', 'success');
      } else {
        await admin.createAdminProduct(values);
        showToast('商品创建成功', 'success');
      }
      setFormOpen(false);
      fetchProducts();
    } catch (err) {
      showToast(editingProduct ? '更新商品失败' : '创建商品失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (product: AdminProduct) => {
    try {
      await admin.updateAdminProduct(product.id, {
        isActive: !product.isActive,
      });
      showToast(product.isActive ? '已下架' : '已上架', 'success');
      fetchProducts();
    } catch (err) {
      showToast('操作失败', 'error');
    }
  };

  const handleDeleteClick = (product: AdminProduct) => {
    setDeletingProduct(product);
    setDeleteOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingProduct) return;
    setDeleting(true);
    try {
      await admin.deleteAdminProduct(deletingProduct.id);
      showToast('删除成功', 'success');
      setDeleteOpen(false);
      setDeletingProduct(null);
      fetchProducts();
    } catch (err) {
      showToast('删除失败', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const columns: TableProps<AdminProduct>['columns'] = [
    {
      title: '排序号',
      dataIndex: 'sortOrder',
      width: 80,
      key: 'sortOrder',
    },
    {
      title: '商品名称',
      dataIndex: 'name',
      key: 'name',
      minWidth: 160,
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      width: 120,
      render: (type: string) => (
        <Badge variant="secondary">{typeLabelMap[type] ?? type}</Badge>
      ),
    },
    {
      title: '价格（¥）',
      dataIndex: 'price',
      key: 'price',
      width: 100,
      render: (price: number) => `¥${price.toFixed(2)}`,
    },
    {
      title: '原价（¥）',
      dataIndex: 'originalPrice',
      key: 'originalPrice',
      width: 100,
      render: (originalPrice: number | null) =>
        originalPrice !== null && originalPrice > 0
          ? `¥${originalPrice.toFixed(2)}`
          : '-',
    },
    {
      title: 'AI额度（流程/台词）',
      key: 'quota',
      width: 140,
      render: (_: unknown, record: AdminProduct) =>
        `${record.flowQuota} / ${record.scriptQuota}`,
    },
    {
      title: '销量',
      dataIndex: 'salesCount',
      key: 'salesCount',
      width: 80,
    },
    {
      title: '状态',
      dataIndex: 'isActive',
      key: 'isActive',
      width: 100,
      render: (isActive: boolean) => (
        <Badge variant={isActive ? 'default' : 'outline'}>
          {isActive ? '上架' : '下架'}
        </Badge>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 170,
      render: (createdAt: string) =>
        new Date(createdAt).toLocaleString('zh-CN'),
    },
    {
      title: '操作',
      key: 'actions',
      width: 220,
      fixed: 'right',
      render: (_: unknown, record: AdminProduct) => (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleEdit(record)}
            aria-label={`编辑 ${record.name}`}
          >
            <Pencil className="h-3.5 w-3.5" />
            编辑
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleToggleStatus(record)}
            aria-label={record.isActive ? '下架' : '上架'}
          >
            <ArrowUpDown className="h-3.5 w-3.5" />
            {record.isActive ? '下架' : '上架'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="text-destructive"
            onClick={() => handleDeleteClick(record)}
            aria-label={`删除 ${record.name}`}
          >
            <Trash2 className="h-3.5 w-3.5" />
            删除
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-full" style={{ backgroundColor: '#f1f5f9' }}>
      <div className="mx-auto max-w-[1400px] p-6">
        <h1 className="text-2xl font-bold text-slate-800 mb-6">
          素材商店管理
        </h1>

        {/* 筛选栏 */}
        <div className="bg-white rounded-lg p-4 mb-4 shadow-sm flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">类型：</span>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="ai_quota">AI充值包</SelectItem>
                <SelectItem value="poster_template">海报模板</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">状态：</span>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="active">上架</SelectItem>
                <SelectItem value="inactive">下架</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="ml-auto">
            <Button
              onClick={handleAdd}
              style={{ backgroundColor: '#2563eb' }}
              className="text-white hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              新增商品
            </Button>
          </div>
        </div>

        {/* 表格 */}
        <div className="bg-white rounded-lg shadow-sm">
          <Table<AdminProduct>
            rowKey="id"
            columns={columns}
            dataSource={products}
            loading={loading}
            pagination={false}
            scroll={{ x: 1100 }}
          />
        </div>
      </div>

      {/* 新增/编辑弹窗 */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="sm:max-w-[520px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? '编辑商品' : '新增商品'}
            </DialogTitle>
            <DialogDescription>
              填写商品基本信息，点击确定保存。
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(handleSubmit)}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>类型</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择类型" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ai_quota">AI充值包</SelectItem>
                          <SelectItem value="poster_template">
                            海报模板
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>名称</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入商品名称" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>描述</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="请输入商品描述"
                        className="min-h-[80px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>价格（元）</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="originalPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>原价（元）</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="flowQuota"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>流程额度</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="scriptQuota"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>台词额度</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="sortOrder"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>排序号</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setFormOpen(false)}
                >
                  取消
                </Button>
                <Button
                  type="submit"
                  disabled={submitting}
                  style={{ backgroundColor: '#2563eb' }}
                  className="text-white hover:bg-blue-700"
                >
                  {submitting ? '保存中...' : '确定'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* 删除确认弹窗 */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>确认删除</DialogTitle>
            <DialogDescription>
              确定要删除商品「{deletingProduct?.name}」吗？此操作不可恢复。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>
              取消
            </Button>
            <Button
              variant="destructive"
              disabled={deleting}
              onClick={handleDeleteConfirm}
            >
              {deleting ? '删除中...' : '确认删除'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminProductsPage;
