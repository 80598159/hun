import { useState, useEffect, useCallback } from 'react';
import {
  Table,
  type TableProps,
} from '@lark-apaas/client-toolkit/antd-table';
import { Plus, Search, Trash2, Pencil, Check, Ban, Star } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Switch } from '@client/src/components/ui/switch';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import type { AdminMerchant } from '@shared/api.interface';

const merchantFormSchema = z.object({
  name: z.string().min(1, '请输入商家名称'),
  category: z.string().min(1, '请选择分类'),
  contactPerson: z.string().optional(),
  contactPhone: z.string().optional(),
  address: z.string().optional(),
  description: z.string().optional(),
  rating: z.preprocess(
    (val) => Number(val),
    z.number().min(0, '评分不能小于0').max(5, '评分不能大于5'),
  ),
  sortOrder: z.preprocess(
    (val) => Number(val),
    z.number().int('排序号必须为整数'),
  ),
  isAd: z.boolean(),
});

type MerchantFormValues = z.infer<typeof merchantFormSchema>;

const categoryOptions = [
  '婚纱摄影', '婚礼策划', '酒店场地', '婚纱礼服',
  '婚车', '司仪', '跟妆', '摄影摄像', '花艺布置', '其他',
];

const AdminMerchantsPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [merchants, setMerchants] = useState<AdminMerchant[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [keyword, setKeyword] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [approveFilter, setApproveFilter] = useState<string>('all');
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const [formOpen, setFormOpen] = useState(false);
  const [editingMerchant, setEditingMerchant] = useState<AdminMerchant | null>(
    null,
  );
  const [submitting, setSubmitting] = useState(false);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deletingMerchant, setDeletingMerchant] = useState<AdminMerchant | null>(
    null,
  );
  const [deleting, setDeleting] = useState(false);

  const form = useForm<MerchantFormValues>({
    resolver: zodResolver(merchantFormSchema) as never,
    defaultValues: {
      name: '',
      category: '婚礼策划',
      contactPerson: '',
      contactPhone: '',
      address: '',
      description: '',
      rating: 5,
      sortOrder: 0,
      isAd: false,
    },
  });

  const fetchMerchants = useCallback(async () => {
    setLoading(true);
    try {
      const params: admin.AdminMerchantListParams = {
        page,
        pageSize,
      };
      if (keyword.trim()) params.keyword = keyword.trim();
      if (categoryFilter !== 'all') params.category = categoryFilter;
      if (approveFilter === 'approved') params.isApproved = true;
      if (approveFilter === 'pending') params.isApproved = false;
      if (activeFilter === 'active') params.isActive = true;
      if (activeFilter === 'inactive') params.isActive = false;
      const res = await admin.getAdminMerchants(params);
      setMerchants(res.items);
      setTotal(res.total);
    } catch (err) {
      showToast('加载商家列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, keyword, categoryFilter, approveFilter, activeFilter, showToast]);

  useEffect(() => {
    fetchMerchants();
  }, [fetchMerchants]);

  const handleSearch = () => {
    setPage(1);
    fetchMerchants();
  };

  const handleAdd = () => {
    setEditingMerchant(null);
    form.reset({
      name: '',
      category: '婚礼策划',
      contactPerson: '',
      contactPhone: '',
      address: '',
      description: '',
      rating: 5,
      sortOrder: 0,
      isAd: false,
    });
    setFormOpen(true);
  };

  const handleEdit = (merchant: AdminMerchant) => {
    setEditingMerchant(merchant);
    form.reset({
      name: merchant.name,
      category: merchant.category,
      contactPerson: merchant.contactPerson,
      contactPhone: merchant.contactPhone,
      address: merchant.address,
      description: merchant.description,
      rating: merchant.rating,
      sortOrder: merchant.sortOrder,
      isAd: merchant.isAd,
    });
    setFormOpen(true);
  };

  const handleSubmit = async (values: MerchantFormValues) => {
    setSubmitting(true);
    try {
      if (editingMerchant) {
        await admin.updateAdminMerchant(editingMerchant.id, values);
        showToast('商家更新成功', 'success');
      } else {
        await admin.createAdminMerchant(values);
        showToast('商家创建成功', 'success');
      }
      setFormOpen(false);
      fetchMerchants();
    } catch (err) {
      showToast(editingMerchant ? '更新商家失败' : '创建商家失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async (merchant: AdminMerchant) => {
    try {
      await admin.updateAdminMerchant(merchant.id, {
        isApproved: !merchant.isApproved,
      });
      showToast(merchant.isApproved ? '已取消审核通过' : '审核通过', 'success');
      fetchMerchants();
    } catch (err) {
      showToast('操作失败', 'error');
    }
  };

  const handleToggleActive = async (merchant: AdminMerchant) => {
    try {
      await admin.updateAdminMerchant(merchant.id, {
        isActive: !merchant.isActive,
      });
      showToast(merchant.isActive ? '已下架' : '已上架', 'success');
      fetchMerchants();
    } catch (err) {
      showToast('操作失败', 'error');
    }
  };

  const handleDeleteClick = (merchant: AdminMerchant) => {
    setDeletingMerchant(merchant);
    setDeleteOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingMerchant) return;
    setDeleting(true);
    try {
      await admin.deleteAdminMerchant(deletingMerchant.id);
      showToast('删除成功', 'success');
      setDeleteOpen(false);
      setDeletingMerchant(null);
      fetchMerchants();
    } catch (err) {
      showToast('删除失败', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const columns: TableProps<AdminMerchant>['columns'] = [
    {
      title: '商家名称',
      dataIndex: 'name',
      key: 'name',
      minWidth: 160,
    },
    {
      title: '分类',
      dataIndex: 'category',
      key: 'category',
      width: 110,
      render: (category: string) => (
        <Badge variant="secondary">{category}</Badge>
      ),
    },
    {
      title: '联系人',
      dataIndex: 'contactPerson',
      key: 'contactPerson',
      width: 100,
      render: (val: string) => val || '-',
    },
    {
      title: '联系电话',
      dataIndex: 'contactPhone',
      key: 'contactPhone',
      width: 120,
      render: (val: string) => val || '-',
    },
    {
      title: '评分',
      dataIndex: 'rating',
      key: 'rating',
      width: 100,
      render: (rating: number) => (
        <div className="flex items-center gap-1">
          <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
          <span className="text-sm font-medium">{rating.toFixed(1)}</span>
        </div>
      ),
    },
    {
      title: '广告位',
      dataIndex: 'isAd',
      key: 'isAd',
      width: 90,
      render: (isAd: boolean) => (
        <Badge variant={isAd ? 'default' : 'outline'}>
          {isAd ? '是' : '否'}
        </Badge>
      ),
    },
    {
      title: '审核状态',
      dataIndex: 'isApproved',
      key: 'isApproved',
      width: 100,
      render: (isApproved: boolean) => (
        <Badge variant={isApproved ? 'default' : 'secondary'}>
          {isApproved ? '已通过' : '待审核'}
        </Badge>
      ),
    },
    {
      title: '上架状态',
      dataIndex: 'isActive',
      key: 'isActive',
      width: 100,
      render: (isActive: boolean) => (
        <Badge variant={isActive ? 'default' : 'outline'}>
          {isActive ? '已上架' : '已下架'}
        </Badge>
      ),
    },
    {
      title: '排序',
      dataIndex: 'sortOrder',
      key: 'sortOrder',
      width: 80,
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 170,
      render: (createdAt: string) =>
        new Date(createdAt).toLocaleString('zh-CN'),
    },
    {
      title: '操作',
      key: 'actions',
      width: 240,
      fixed: 'right',
      render: (_: unknown, record: AdminMerchant) => (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleEdit(record)}
            aria-label={`编辑 ${record.name}`}
          >
            <Pencil className="h-3.5 w-3.5" />
            编辑
          </Button>
          {!record.isApproved && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => handleApprove(record)}
              aria-label="审核通过"
            >
              <Check className="h-3.5 w-3.5" />
              通过
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleToggleActive(record)}
            aria-label={record.isActive ? '下架' : '上架'}
          >
            <Ban className="h-3.5 w-3.5" />
            {record.isActive ? '下架' : '上架'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="text-destructive"
            onClick={() => handleDeleteClick(record)}
            aria-label={`删除 ${record.name}`}
          >
            <Trash2 className="h-3.5 w-3.5" />
            删除
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-full" style={{ backgroundColor: '#f1f5f9' }}>
      <div className="mx-auto max-w-[1400px] p-6">
        <h1 className="text-2xl font-bold text-slate-800 mb-6">
          商圈商家管理
        </h1>

        {/* 筛选栏 */}
        <div className="bg-white rounded-lg p-4 mb-4 shadow-sm flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[200px] max-w-sm">
            <Input
              placeholder="搜索商家名称"
              value={keyword}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setKeyword(e.target.value)
              }
              onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                if (e.key === 'Enter') handleSearch();
              }}
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">分类：</span>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                {categoryOptions.map((cat: string) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">审核：</span>
            <Select value={approveFilter} onValueChange={setApproveFilter}>
              <SelectTrigger className="w-28">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="pending">待审核</SelectItem>
                <SelectItem value="approved">已通过</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">上架：</span>
            <Select value={activeFilter} onValueChange={setActiveFilter}>
              <SelectTrigger className="w-28">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="active">已上架</SelectItem>
                <SelectItem value="inactive">已下架</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleSearch}
            style={{ backgroundColor: '#2563eb' }}
            className="text-white hover:bg-blue-700"
          >
            <Search className="h-4 w-4" />
            搜索
          </Button>

          <div className="ml-auto">
            <Button
              onClick={handleAdd}
              style={{ backgroundColor: '#2563eb' }}
              className="text-white hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              新增商家
            </Button>
          </div>
        </div>

        {/* 表格 */}
        <div className="bg-white rounded-lg shadow-sm">
          <Table<AdminMerchant>
            rowKey="id"
            columns={columns}
            dataSource={merchants}
            loading={loading}
            pagination={{
              current: page,
              pageSize,
              total,
              onChange: (p: number) => setPage(p),
              showSizeChanger: false,
            }}
            scroll={{ x: 1300 }}
          />
        </div>
      </div>

      {/* 新增/编辑弹窗 */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="sm:max-w-[560px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingMerchant ? '编辑商家' : '新增商家'}
            </DialogTitle>
            <DialogDescription>
              填写商家基本信息，点击确定保存。
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(handleSubmit)}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>商家名称</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入商家名称" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>分类</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择分类" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categoryOptions.map((cat: string) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="contactPerson"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>联系人</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入联系人" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>联系电话</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入联系电话" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>地址</FormLabel>
                    <FormControl>
                      <Input placeholder="请输入地址" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>描述</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="请输入商家描述"
                        className="min-h-[80px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="rating"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>评分（0-5）</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          max="5"
                          step="0.1"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sortOrder"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>排序号</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="isAd"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>广告位</FormLabel>
                      <p className="text-sm text-muted-foreground">
                        开启后商家将展示在广告位
                      </p>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setFormOpen(false)}
                >
                  取消
                </Button>
                <Button
                  type="submit"
                  disabled={submitting}
                  style={{ backgroundColor: '#2563eb' }}
                  className="text-white hover:bg-blue-700"
                >
                  {submitting ? '保存中...' : '确定'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* 删除确认弹窗 */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>确认删除</DialogTitle>
            <DialogDescription>
              确定要删除商家「{deletingMerchant?.name}」吗？此操作不可恢复。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>
              取消
            </Button>
            <Button
              variant="destructive"
              disabled={deleting}
              onClick={handleDeleteConfirm}
            >
              {deleting ? '删除中...' : '确认删除'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminMerchantsPage;
