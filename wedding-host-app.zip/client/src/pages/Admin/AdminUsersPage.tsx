import { useEffect, useState, useCallback } from 'react';
import { Table, type TableProps } from '@lark-apaas/client-toolkit/antd-table';
import {
  Search,
  Settings,
  Shield,
  ShieldOff,
  Ban,
  CheckCircle2,
  UserPlus,
  Pencil,
  KeyRound,
  Trash2,
} from 'lucide-react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { admin } from '@client/src/api';
import type { AdminUserItem } from '@shared/api.interface';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/components/ToastProvider';
import { Image } from '@client/src/components/ui/image';

const statusOptions = [
  { value: '', label: '全部状态' },
  { value: 'active', label: '正常' },
  { value: 'disabled', label: '禁用' },
];

const quotaFormSchema = z.object({
  monthlyFlowQuota: z.coerce.number().int().min(0, '不能小于0'),
  monthlyScriptQuota: z.coerce.number().int().min(0, '不能小于0'),
  totalFlowQuota: z.coerce.number().int().min(0, '不能小于0'),
  totalScriptQuota: z.coerce.number().int().min(0, '不能小于0'),
});

type QuotaFormValues = z.infer<typeof quotaFormSchema>;

const createUserSchema = z.object({
  username: z.string().min(3, '账号长度至少3位').max(64, '账号过长'),
  password: z.string().min(6, '密码长度至少6位').max(64, '密码过长'),
  nickname: z.string().min(1, '昵称不能为空').max(100, '昵称过长'),
  remark: z.string().max(500, '备注过长').optional(),
});

type CreateUserFormValues = z.infer<typeof createUserSchema>;

const editUserSchema = z.object({
  nickname: z.string().min(1, '昵称不能为空').max(100, '昵称过长'),
  avatarUrl: z.string().max(500, '头像URL过长').optional().or(z.literal('')),
  phone: z.string().max(20, '手机号过长').optional().or(z.literal('')),
  city: z.string().max(100, '城市过长').optional().or(z.literal('')),
  experienceYears: z.coerce
    .number()
    .int('从业年限需为整数')
    .min(0, '不能小于0')
    .max(80, '不合理'),
  bio: z.string().max(2000, '简介过长').optional().or(z.literal('')),
  styleTags: z.string().max(255, '风格标签过长').optional().or(z.literal('')),
  status: z.enum(['active', 'disabled']),
  isAdmin: z.boolean(),
});

type EditUserFormValues = z.infer<typeof editUserSchema>;

const resetPasswordSchema = z
  .object({
    password: z.string().min(6, '密码长度至少6位').max(64, '密码过长'),
    confirmPassword: z.string().min(6, '确认密码长度至少6位'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: '两次输入的密码不一致',
    path: ['confirmPassword'],
  });

type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

type ConfirmAction =
  | 'disable'
  | 'enable'
  | 'setAdmin'
  | 'cancelAdmin'
  | 'delete'
  | null;

const AdminUsersPage = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AdminUserItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [keyword, setKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [searchStatus, setSearchStatus] = useState('');

  const [quotaDialogOpen, setQuotaDialogOpen] = useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [confirmAction, setConfirmAction] = useState<ConfirmAction>(null);
  const [currentUser, setCurrentUser] = useState<AdminUserItem | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [resetDialogOpen, setResetDialogOpen] = useState(false);

  const quotaForm = useForm<QuotaFormValues>({
    resolver: zodResolver(quotaFormSchema) as any,
    defaultValues: {
      monthlyFlowQuota: 0,
      monthlyScriptQuota: 0,
      totalFlowQuota: 0,
      totalScriptQuota: 0,
    },
  });

  const createForm = useForm<CreateUserFormValues>({
    resolver: zodResolver(createUserSchema) as any,
    defaultValues: {
      username: '',
      password: '',
      nickname: '',
      remark: '',
    },
  });

  const editForm = useForm<EditUserFormValues>({
    resolver: zodResolver(editUserSchema) as any,
    defaultValues: {
      nickname: '',
      avatarUrl: '',
      phone: '',
      city: '',
      experienceYears: 0,
      bio: '',
      styleTags: '',
      status: 'active',
      isAdmin: false,
    },
  });

  const resetForm = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema) as any,
    defaultValues: {
      password: '',
      confirmPassword: '',
    },
  });

  const fetchList = useCallback(async () => {
    setLoading(true);
    try {
      const res = await admin.getAdminUsers({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        status: searchStatus || undefined,
      });
      setData(res.items);
      setTotal(res.total);
    } catch (error) {
      showToast('加载用户列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, searchKeyword, searchStatus, showToast]);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const handleSearch = () => {
    setSearchKeyword(keyword.trim());
    setSearchStatus(statusFilter);
    setPage(1);
  };

  const openQuotaDialog = (user: AdminUserItem) => {
    setCurrentUser(user);
    quotaForm.reset({
      monthlyFlowQuota: user.monthlyFlowQuota,
      monthlyScriptQuota: user.monthlyScriptQuota,
      totalFlowQuota: user.totalFlowQuota,
      totalScriptQuota: user.totalScriptQuota,
    });
    setQuotaDialogOpen(true);
  };

  const handleQuotaSubmit = async (values: QuotaFormValues) => {
    if (!currentUser) return;
    setSubmitting(true);
    try {
      await admin.adjustUserQuota(currentUser.userId, values);
      showToast('额度调整成功', 'success');
      setQuotaDialogOpen(false);
      fetchList();
    } catch (error: any) {
      const msg = error?.response?.data?.error?.message || '额度调整失败';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const openCreateDialog = () => {
    createForm.reset({
      username: '',
      password: '',
      nickname: '',
      remark: '',
    });
    setCreateDialogOpen(true);
  };

  const handleCreateSubmit = async (values: CreateUserFormValues) => {
    setSubmitting(true);
    try {
      await admin.createAdminUser(values);
      showToast('用户创建成功', 'success');
      setCreateDialogOpen(false);
      setPage(1);
      fetchList();
    } catch (error: any) {
      const msg = error?.response?.data?.error?.message || '创建用户失败';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const openEditDialog = (user: AdminUserItem) => {
    setCurrentUser(user);
    editForm.reset({
      nickname: user.nickname || '',
      avatarUrl: user.avatarUrl || '',
      phone: user.phone || '',
      city: user.city || '',
      experienceYears: user.experienceYears ?? 0,
      bio: '',
      styleTags: '',
      status: (user.status as 'active' | 'disabled') || 'active',
      isAdmin: user.isAdmin || false,
    });
    setEditDialogOpen(true);
  };

  const handleEditSubmit = async (values: EditUserFormValues) => {
    if (!currentUser) return;
    setSubmitting(true);
    try {
      await admin.updateAdminUser(currentUser.userId, values);
      showToast('用户信息已更新', 'success');
      setEditDialogOpen(false);
      fetchList();
    } catch (error: any) {
      const msg = error?.response?.data?.error?.message || '更新失败';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const openResetDialog = (user: AdminUserItem) => {
    setCurrentUser(user);
    resetForm.reset({
      password: '',
      confirmPassword: '',
    });
    setResetDialogOpen(true);
  };

  const handleResetSubmit = async (values: ResetPasswordFormValues) => {
    if (!currentUser) return;
    setSubmitting(true);
    try {
      await admin.resetAdminUserPassword(currentUser.userId, values.password);
      showToast(`已为用户「${currentUser.nickname}」重置密码`, 'success');
      setResetDialogOpen(false);
    } catch (error: any) {
      const msg = error?.response?.data?.error?.message || '重置密码失败';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const openConfirm = (user: AdminUserItem, action: ConfirmAction) => {
    setCurrentUser(user);
    setConfirmAction(action);
    setConfirmDialogOpen(true);
  };

  const getConfirmText = (): { title: string; desc: string; danger: boolean } => {
    if (!currentUser || !confirmAction)
      return { title: '', desc: '', danger: false };
    const name = currentUser.nickname;
    switch (confirmAction) {
      case 'disable':
        return {
          title: '确认禁用用户',
          desc: `禁用后用户「${name}」将无法登录，确认操作？`,
          danger: true,
        };
      case 'enable':
        return {
          title: '确认启用用户',
          desc: `启用后用户「${name}」恢复正常使用，确认操作？`,
          danger: false,
        };
      case 'setAdmin':
        return {
          title: '确认设为管理员',
          desc: `将用户「${name}」设为后台管理员，确认操作？`,
          danger: false,
        };
      case 'cancelAdmin':
        return {
          title: '取消管理员',
          desc: `取消用户「${name}」的后台管理员权限，确认操作？`,
          danger: false,
        };
      case 'delete':
        return {
          title: '确认删除用户',
          desc: `删除后用户「${name}」的婚礼方案、台词、档期等数据将一并清除，无法恢复。确定要删除吗？`,
          danger: true,
        };
    }
  };

  const handleConfirm = async () => {
    if (!currentUser || !confirmAction) return;
    setSubmitting(true);
    try {
      if (confirmAction === 'disable') {
        await admin.updateAdminUser(currentUser.userId, { status: 'disabled' });
        showToast('已禁用用户', 'success');
      } else if (confirmAction === 'enable') {
        await admin.updateAdminUser(currentUser.userId, { status: 'active' });
        showToast('已启用用户', 'success');
      } else if (confirmAction === 'setAdmin') {
        await admin.updateAdminUser(currentUser.userId, { isAdmin: true });
        showToast('已设为管理员', 'success');
      } else if (confirmAction === 'cancelAdmin') {
        await admin.updateAdminUser(currentUser.userId, { isAdmin: false });
        showToast('已取消管理员', 'success');
      } else if (confirmAction === 'delete') {
        await admin.deleteAdminUser(currentUser.userId);
        showToast('用户已删除', 'success');
      }
      setConfirmDialogOpen(false);
      fetchList();
    } catch (error: any) {
      const msg = error?.response?.data?.error?.message || '操作失败';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const columns: TableProps<AdminUserItem>['columns'] = [
    {
      title: '用户ID',
      dataIndex: 'userId',
      width: 140,
      fixed: 'left',
      render: (val: string) => (
        <span
          className="font-mono text-xs text-muted-foreground truncate max-w-[120px] inline-block align-middle"
          title={val}
        >
          {val}
        </span>
      ),
    },
    {
      title: '用户',
      dataIndex: 'nickname',
      width: 180,
      render: (_: string, record: AdminUserItem) => (
        <div className="flex items-center gap-2">
          {record.avatarUrl ? (
            <Image
              src={record.avatarUrl}
              alt={record.nickname}
              className="w-8 h-8 rounded-full object-cover flex-shrink-0"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs text-secondary-foreground flex-shrink-0">
              {record.nickname?.[0] ?? '?'}
            </div>
          )}
          <div className="min-w-0">
            <div className="text-sm font-medium truncate">
              {record.nickname}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {record.phone || '—'}
            </div>
          </div>
        </div>
      ),
    },
    {
      title: '城市',
      dataIndex: 'city',
      width: 100,
      render: (val: string) => <span className="text-sm">{val || '—'}</span>,
    },
    {
      title: '从业年限',
      dataIndex: 'experienceYears',
      width: 100,
      render: (val: number) => (
        <span className="text-sm">{val ?? 0} 年</span>
      ),
    },
    {
      title: 'AI剩余额度',
      width: 160,
      render: (_: unknown, record: AdminUserItem) => (
        <div className="text-sm space-y-0.5">
          <div className="flex justify-between gap-2">
            <span className="text-muted-foreground">流程</span>
            <span className="font-medium">{record.remainingFlow}</span>
          </div>
          <div className="flex justify-between gap-2">
            <span className="text-muted-foreground">台词</span>
            <span className="font-medium">{record.remainingScript}</span>
          </div>
        </div>
      ),
    },
    {
      title: '方案数',
      dataIndex: 'projectCount',
      width: 90,
      render: (val: number) => <span className="text-sm">{val ?? 0}</span>,
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 90,
      render: (val: string) => (
        <Badge variant={val === 'active' ? 'default' : 'destructive'}>
          {val === 'active' ? '正常' : '禁用'}
        </Badge>
      ),
    },
    {
      title: '管理员',
      dataIndex: 'isAdmin',
      width: 100,
      render: (val: boolean) =>
        val ? (
          <Badge variant="secondary">管理员</Badge>
        ) : (
          <Badge variant="outline" className="text-muted-foreground">
            普通用户
          </Badge>
        ),
    },
    {
      title: '注册时间',
      dataIndex: 'createdAt',
      width: 170,
      render: (val: string) => (
        <span className="text-sm text-muted-foreground">{val}</span>
      ),
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 340,
      render: (_: unknown, record: AdminUserItem) => (
        <div className="flex flex-wrap gap-1">
          <Button variant="ghost" size="sm" onClick={() => openEditDialog(record)}>
            <Pencil size={14} />
            编辑
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => openQuotaDialog(record)}
          >
            <Settings size={14} />
            调额度
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => openResetDialog(record)}
          >
            <KeyRound size={14} />
            重置密码
          </Button>
          {record.status === 'active' ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => openConfirm(record, 'disable')}
            >
              <Ban size={14} />
              禁用
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => openConfirm(record, 'enable')}
            >
              <CheckCircle2 size={14} />
              启用
            </Button>
          )}
          {record.isAdmin ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => openConfirm(record, 'cancelAdmin')}
            >
              <ShieldOff size={14} />
              取消管理员
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => openConfirm(record, 'setAdmin')}
            >
              <Shield size={14} />
              设为管理员
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            className="text-red-500 hover:text-red-600 hover:bg-red-50"
            onClick={() => openConfirm(record, 'delete')}
          >
            <Trash2 size={14} />
            删除
          </Button>
        </div>
      ),
    },
  ];

  const { title: confirmTitle, desc: confirmDesc, danger: confirmDanger } =
    getConfirmText();

  return (
    <div className="min-h-screen bg-slate-100 p-6">
      <div className="max-w-[1400px] mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">用户管理</h1>
            <p className="text-sm text-slate-500 mt-1">
              管理平台注册用户、AI额度和管理员权限
            </p>
          </div>
          <Button onClick={openCreateDialog} className="bg-[#2563eb] hover:bg-[#1d4ed8]">
            <UserPlus size={16} />
            新增用户
          </Button>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">
                关键词搜索
              </label>
              <Input
                placeholder="昵称 / 手机号"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                className="w-64"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearch();
                }}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">状态</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="全部状态" />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleSearch}>
              <Search size={16} />
              搜索
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm">
          <Table
            rowKey="userId"
            columns={columns}
            dataSource={data}
            loading={loading}
            scroll={{ x: 1600, y: 560 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: false,
              showTotal: (t: number) => `共 ${t} 条`,
              onChange: (p: number) => setPage(p),
            }}
          />
        </div>

        {/* 新增用户弹窗 */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>新增用户</DialogTitle>
              <DialogDescription>手动创建一个新的主持人账号</DialogDescription>
            </DialogHeader>
            <Form {...createForm}>
              <form
                onSubmit={createForm.handleSubmit(handleCreateSubmit)}
                className="space-y-4"
              >
                <FormField
                  control={createForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>账号</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入登录账号" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>初始密码</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="至少6位"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="nickname"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>昵称</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入昵称" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="remark"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>备注</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="可选，内部备注信息"
                          rows={2}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setCreateDialogOpen(false)}
                  >
                    取消
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitting}
                    className="bg-[#2563eb] hover:bg-[#1d4ed8]"
                  >
                    {submitting ? '创建中...' : '创建用户'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* 编辑用户弹窗 */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>编辑用户</DialogTitle>
              <DialogDescription>
                {currentUser?.nickname &&
                  `修改用户「${currentUser.nickname}」的资料信息`}
              </DialogDescription>
            </DialogHeader>
            <Form {...editForm}>
              <form
                onSubmit={editForm.handleSubmit(handleEditSubmit)}
                className="space-y-4"
              >
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="nickname"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>昵称</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>手机号</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ''} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={editForm.control}
                  name="avatarUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>头像URL</FormLabel>
                      <FormControl>
                        <Input {...field} value={field.value || ''} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>城市</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ''} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editForm.control}
                    name="experienceYears"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>从业年限</FormLabel>
                        <FormControl>
                          <Input type="number" min={0} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={editForm.control}
                  name="styleTags"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>风格标签</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="如：温馨大气、幽默风趣"
                          {...field}
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>个人简介</FormLabel>
                      <FormControl>
                        <Textarea
                          rows={3}
                          placeholder="主持人个人简介"
                          {...field}
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                  <FormField
                    control={editForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>账号状态</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">正常</SelectItem>
                            <SelectItem value="disabled">禁用</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editForm.control}
                    name="isAdmin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>管理员权限</FormLabel>
                        <div className="flex items-center h-10">
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                          <span className="ml-3 text-sm text-slate-600">
                            {field.value ? '已开启' : '未开启'}
                          </span>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setEditDialogOpen(false)}
                  >
                    取消
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitting}
                    className="bg-[#2563eb] hover:bg-[#1d4ed8]"
                  >
                    {submitting ? '保存中...' : '保存修改'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* 重置密码弹窗 */}
        <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>重置密码</DialogTitle>
              <DialogDescription>
                {currentUser?.nickname &&
                  `为用户「${currentUser.nickname}」设置新密码`}
              </DialogDescription>
            </DialogHeader>
            <Form {...resetForm}>
              <form
                onSubmit={resetForm.handleSubmit(handleResetSubmit)}
                className="space-y-4"
              >
                <FormField
                  control={resetForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>新密码</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="至少6位"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={resetForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>确认新密码</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="再次输入新密码"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setResetDialogOpen(false)}
                  >
                    取消
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitting}
                    className="bg-[#2563eb] hover:bg-[#1d4ed8]"
                  >
                    {submitting ? '提交中...' : '确认重置'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* 调整额度弹窗 */}
        <Dialog open={quotaDialogOpen} onOpenChange={setQuotaDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>调整AI额度</DialogTitle>
              <DialogDescription>
                {currentUser?.nickname &&
                  `为用户「${currentUser.nickname}」调整AI生成额度`}
              </DialogDescription>
            </DialogHeader>
            <Form {...quotaForm}>
              <form
                onSubmit={quotaForm.handleSubmit(handleQuotaSubmit)}
                className="space-y-4"
              >
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={quotaForm.control}
                    name="monthlyFlowQuota"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>月度流程额度</FormLabel>
                        <FormControl>
                          <Input type="number" min={0} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={quotaForm.control}
                    name="monthlyScriptQuota"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>月度台词额度</FormLabel>
                        <FormControl>
                          <Input type="number" min={0} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={quotaForm.control}
                    name="totalFlowQuota"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>累计流程额度</FormLabel>
                        <FormControl>
                          <Input type="number" min={0} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={quotaForm.control}
                    name="totalScriptQuota"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>累计台词额度</FormLabel>
                        <FormControl>
                          <Input type="number" min={0} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setQuotaDialogOpen(false)}
                  >
                    取消
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? '保存中...' : '保存'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* 确认弹窗 */}
        <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>{confirmTitle}</DialogTitle>
              <DialogDescription>{confirmDesc}</DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setConfirmDialogOpen(false)}>
                取消
              </Button>
              <Button
                variant={confirmDanger ? 'destructive' : 'default'}
                onClick={handleConfirm}
                disabled={submitting}
              >
                {submitting ? '处理中...' : '确认'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminUsersPage;
