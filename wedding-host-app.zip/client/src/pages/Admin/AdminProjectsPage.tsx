import { useEffect, useState, useCallback } from 'react';
import { Table, type TableProps } from '@lark-apaas/client-toolkit/antd-table';
import { Search, Eye, Trash2, Calendar, Clock, Hotel, User, RotateCcw } from 'lucide-react';
import { admin } from '@client/src/api';
import type { AdminProjectItem } from '@shared/api.interface';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ToastProvider';

const AdminProjectsPage = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AdminProjectItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [keyword, setKeyword] = useState('');
  const [userIdInput, setUserIdInput] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [searchUserId, setSearchUserId] = useState('');

  const [detailOpen, setDetailOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [currentProject, setCurrentProject] = useState<AdminProjectItem | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const fetchList = useCallback(async () => {
    setLoading(true);
    try {
      const res = await admin.getAdminProjects({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        userId: searchUserId || undefined,
      });
      setData(res.items);
      setTotal(res.total);
    } catch (error) {
      showToast('加载方案列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, searchKeyword, searchUserId, showToast]);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const handleSearch = () => {
    setSearchKeyword(keyword.trim());
    setSearchUserId(userIdInput.trim());
    setPage(1);
  };

  const openDetail = (project: AdminProjectItem) => {
    setCurrentProject(project);
    setDetailOpen(true);
  };

  const openDelete = (project: AdminProjectItem) => {
    setCurrentProject(project);
    setDeleteOpen(true);
  };

  const openReset = (project: AdminProjectItem) => {
    setCurrentProject(project);
    setResetOpen(true);
  };

  const handleReset = async () => {
    if (!currentProject) return;
    setSubmitting(true);
    try {
      await admin.resetProjectPosterPhotoCount(currentProject.id);
      showToast('重置成功', 'success');
      setResetOpen(false);
      fetchList();
    } catch {
      showToast('重置失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!currentProject) return;
    setSubmitting(true);
    try {
      await admin.deleteAdminProject(currentProject.id);
      showToast('删除成功', 'success');
      setDeleteOpen(false);
      fetchList();
    } catch (error) {
      showToast('删除失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const columns: TableProps<AdminProjectItem>['columns'] = [
    {
      title: '方案标题',
      dataIndex: 'title',
      width: 200,
      fixed: 'left',
      render: (val: string) => (
        <span className="text-sm font-medium text-slate-900 truncate block max-w-[180px]" title={val}>
          {val || '未命名方案'}
        </span>
      ),
    },
    {
      title: '新人',
      width: 180,
      render: (_: unknown, record: AdminProjectItem) => (
        <div className="text-sm space-y-0.5">
          <div className="flex items-center gap-1">
            <User size={12} className="text-slate-400" />
            <span>{record.groomName || '—'}</span>
          </div>
          <div className="flex items-center gap-1">
            <User size={12} className="text-slate-400" />
            <span>{record.brideName || '—'}</span>
          </div>
        </div>
      ),
    },
    {
      title: '婚礼日期',
      dataIndex: 'weddingDate',
      width: 130,
      render: (val: string | null) => (
        <div className="flex items-center gap-1.5 text-sm">
          <Calendar size={14} className="text-slate-400" />
          <span>{val || '—'}</span>
        </div>
      ),
    },
    {
      title: '时段',
      dataIndex: 'timeType',
      width: 90,
      render: (val: string) => (
        <div className="flex items-center gap-1.5 text-sm">
          <Clock size={14} className="text-slate-400" />
          <span>{val === 'lunch' ? '午宴' : val === 'dinner' ? '晚宴' : '—'}</span>
        </div>
      ),
    },
    {
      title: '酒店',
      dataIndex: 'hotelName',
      width: 180,
      render: (val: string) => (
        <div className="flex items-center gap-1.5 text-sm">
          <Hotel size={14} className="text-slate-400 flex-shrink-0" />
          <span className="truncate max-w-[150px]" title={val}>{val || '—'}</span>
        </div>
      ),
    },
    {
      title: '主持人',
      dataIndex: 'userNickname',
      width: 120,
      render: (val: string) => <span className="text-sm">{val || '—'}</span>,
    },
    { title: '环节数', dataIndex: 'stepCount', width: 90,
      render: (val: number) => <span className="text-sm">{val ?? 0} 个</span> },
    {
      title: '形象照更新次数',
      dataIndex: 'posterPhotoUpdateCount',
      width: 140,
      align: 'center',
      render: (val: number) => (
        <span className="text-sm font-medium text-slate-700">{val ?? 0}</span>
      ),
    },
    {
      title: '状态',
      dataIndex: 'isArchived',
      width: 100,
      render: (val: boolean) => (
        val
          ? <Badge variant="secondary">已归档</Badge>
          : <Badge variant="default">进行中</Badge>
      ),
    },
    { title: '创建时间', dataIndex: 'createdAt', width: 170,
      render: (val: string) => <span className="text-sm text-muted-foreground">{val}</span> },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 200,
      render: (_: unknown, record: AdminProjectItem) => (
        <div className="flex gap-1">
          <Button variant="ghost" size="sm" onClick={() => openDetail(record)}>
            <Eye size={14} />
            详情
          </Button>
          <Button variant="ghost" size="sm" onClick={() => openReset(record)} className="text-amber-600 hover:text-amber-700 hover:bg-amber-50">
            <RotateCcw size={14} />
            重置
          </Button>
          <Button variant="ghost" size="sm" onClick={() => openDelete(record)} className="text-destructive hover:text-destructive">
            <Trash2 size={14} />
            删除
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100 p-6">
      <div className="max-w-[1400px] mx-auto space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">婚礼方案管理</h1>
          <p className="text-sm text-slate-500 mt-1">查看和管理用户创建的婚礼方案</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">关键词搜索</label>
              <Input
                placeholder="方案名 / 酒店"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                className="w-64"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearch();
                }}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">用户ID</label>
              <Input
                placeholder="可选，精确匹配"
                value={userIdInput}
                onChange={(e) => setUserIdInput(e.target.value)}
                className="w-52"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearch();
                }}
              />
            </div>
            <Button onClick={handleSearch}>
              <Search size={16} />
              搜索
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm">
          <Table
            rowKey="id"
            columns={columns}
            dataSource={data}
            loading={loading}
            scroll={{ x: 1350, y: 560 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: false,
              showTotal: (t: number) => `共 ${t} 条`,
              onChange: (p: number) => setPage(p),
            }}
          />
        </div>

        {/* 详情弹窗 */}
        <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
          <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>方案详情</DialogTitle>
              <DialogDescription>方案完整信息</DialogDescription>
            </DialogHeader>
            {currentProject && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">
                    {currentProject.title || '未命名方案'}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={currentProject.isArchived ? 'secondary' : 'default'}>
                      {currentProject.isArchived ? '已归档' : '进行中'}
                    </Badge>
                    <span className="text-xs text-slate-500">
                      {currentProject.stepCount} 个环节
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-slate-500 text-xs mb-1">新郎</div>
                    <div className="font-medium">{currentProject.groomName || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">新娘</div>
                    <div className="font-medium">{currentProject.brideName || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">婚礼日期</div>
                    <div className="font-medium">{currentProject.weddingDate || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">时段</div>
                    <div className="font-medium">
                      {currentProject.timeType === 'lunch' ? '午宴'
                        : currentProject.timeType === 'dinner' ? '晚宴' : '—'}
                    </div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-slate-500 text-xs mb-1">酒店</div>
                    <div className="font-medium">{currentProject.hotelName || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">策划师</div>
                    <div>{currentProject.planner || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">督导</div>
                    <div>{currentProject.supervisor || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">摄像</div>
                    <div>{currentProject.videographer || '—'}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-xs mb-1">摄影</div>
                    <div>{currentProject.photographer || '—'}</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-slate-500 text-xs mb-1">音控</div>
                    <div>{currentProject.soundController || '—'}</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-slate-500 text-xs mb-1">主持人</div>
                    <div>{currentProject.userNickname || '—'}</div>
                  </div>
                  {currentProject.specialNotes && (
                    <div className="col-span-2">
                      <div className="text-slate-500 text-xs mb-1">特别说明</div>
                      <div className="bg-slate-50 p-3 rounded-md whitespace-pre-wrap">
                        {currentProject.specialNotes}
                      </div>
                    </div>
                  )}
                  <div className="col-span-2 pt-2 border-t text-xs text-slate-400 space-y-0.5">
                    <div>创建时间：{currentProject.createdAt}</div>
                    <div>更新时间：{currentProject.updatedAt}</div>
                    <div>海报模板：{currentProject.posterTemplate || '—'}</div>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button onClick={() => setDetailOpen(false)}>关闭</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 删除确认弹窗 */}
        <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>确认删除方案</DialogTitle>
              <DialogDescription>
                {currentProject
                  ? `删除方案「${currentProject.title || '未命名方案'}」后不可恢复，确认操作？`
                  : ''}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setDeleteOpen(false)}>取消</Button>
              <Button variant="destructive" onClick={handleDelete} disabled={submitting}>
                {submitting ? '删除中...' : '确认删除'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 重置形象照次数确认弹窗 */}
        <Dialog open={resetOpen} onOpenChange={setResetOpen}>
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>重置形象照更新次数</DialogTitle>
              <DialogDescription>
                {currentProject
                  ? `确定要重置方案「${currentProject.title || '未命名方案'}」的形象照更新次数吗？重置后该方案的形象照可重新更新。`
                  : ''}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setResetOpen(false)}>取消</Button>
              <Button onClick={handleReset} disabled={submitting}>
                {submitting ? '重置中...' : '确认重置'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminProjectsPage;
