import { useEffect, useState, useCallback } from 'react';
import { Table, type TableProps } from '@lark-apaas/client-toolkit/antd-table';
import { Search, Plus, Edit3, Trash2, Heart } from 'lucide-react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { admin } from '@client/src/api';
import type { AdminScriptItem } from '@shared/api.interface';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/components/ToastProvider';

const categoryOptions = [
  { value: '', label: '全部分类' },
  { value: 'opening', label: '开场致辞' },
  { value: 'groom', label: '新郎誓言' },
  { value: 'bride', label: '新娘誓言' },
  { value: 'parents', label: '父母致辞' },
  { value: 'witness', label: '证婚人致辞' },
  { value: 'ring', label: '交换戒指' },
  { value: 'toast', label: '祝酒词' },
  { value: 'ending', label: '结束语' },
  { value: 'other', label: '其他' },
];

const typeOptions = [
  { value: '', label: '全部类型' },
  { value: 'system', label: '系统预置' },
  { value: 'user', label: '用户创建' },
];

const scriptFormSchema = z.object({
  category: z.string().min(1, '请选择分类'),
  title: z.string().min(1, '请输入标题').max(100, '标题不超过100字'),
  content: z.string().min(1, '请输入内容').max(5000, '内容不超过5000字'),
  styleTags: z.string().max(100, '风格标签不超过100字').optional().or(z.literal('')),
});

type ScriptFormValues = z.infer<typeof scriptFormSchema>;

const AdminScriptsPage = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AdminScriptItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [keyword, setKeyword] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [searchCategory, setSearchCategory] = useState('');
  const [searchIsSystem, setSearchIsSystem] = useState<boolean | undefined>(undefined);

  const [formDialogOpen, setFormDialogOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [currentScript, setCurrentScript] = useState<AdminScriptItem | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<ScriptFormValues>({
    resolver: zodResolver(scriptFormSchema),
    defaultValues: {
      category: '',
      title: '',
      content: '',
      styleTags: '',
    },
  });

  const fetchList = useCallback(async () => {
    setLoading(true);
    try {
      const res = await admin.getAdminScripts({
        page,
        pageSize,
        keyword: searchKeyword || undefined,
        category: searchCategory || undefined,
        isSystem: searchIsSystem,
      });
      setData(res.items);
      setTotal(res.total);
    } catch (error) {
      showToast('加载台词列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, searchKeyword, searchCategory, searchIsSystem, showToast]);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const handleSearch = () => {
    setSearchKeyword(keyword.trim());
    setSearchCategory(categoryFilter);
    if (typeFilter === 'system') {
      setSearchIsSystem(true);
    } else if (typeFilter === 'user') {
      setSearchIsSystem(false);
    } else {
      setSearchIsSystem(undefined);
    }
    setPage(1);
  };

  const openCreate = () => {
    setIsEditing(false);
    setCurrentScript(null);
    form.reset({
      category: '',
      title: '',
      content: '',
      styleTags: '',
    });
    setFormDialogOpen(true);
  };

  const openEdit = (script: AdminScriptItem) => {
    setIsEditing(true);
    setCurrentScript(script);
    form.reset({
      category: script.category,
      title: script.title,
      content: script.content,
      styleTags: script.styleTags || '',
    });
    setFormDialogOpen(true);
  };

  const handleFormSubmit = async (values: ScriptFormValues) => {
    setSubmitting(true);
    try {
      if (isEditing && currentScript) {
        await admin.updateAdminScript(currentScript.id, {
          category: values.category,
          title: values.title,
          content: values.content,
          styleTags: values.styleTags || undefined,
        });
        showToast('编辑成功', 'success');
      } else {
        await admin.createAdminScript({
          category: values.category,
          title: values.title,
          content: values.content,
          styleTags: values.styleTags || undefined,
        });
        showToast('创建成功', 'success');
      }
      setFormDialogOpen(false);
      fetchList();
    } catch (error) {
      showToast(isEditing ? '编辑失败' : '创建失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const openDelete = (script: AdminScriptItem) => {
    setCurrentScript(script);
    setDeleteOpen(true);
  };

  const handleDelete = async () => {
    if (!currentScript) return;
    setSubmitting(true);
    try {
      await admin.deleteAdminScript(currentScript.id);
      showToast('删除成功', 'success');
      setDeleteOpen(false);
      fetchList();
    } catch (error) {
      showToast('删除失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const getCategoryName = (key: string): string => {
    const found = categoryOptions.find((c) => c.value === key);
    return found ? found.label : key;
  };

  const columns: TableProps<AdminScriptItem>['columns'] = [
    {
      title: '标题',
      dataIndex: 'title',
      width: 240,
      fixed: 'left',
      render: (val: string) => (
        <span className="text-sm font-medium text-slate-900 truncate block max-w-[220px]" title={val}>
          {val}
        </span>
      ),
    },
    {
      title: '分类',
      dataIndex: 'category',
      width: 120,
      render: (val: string) => (
        <Badge variant="secondary">{getCategoryName(val)}</Badge>
      ),
    },
    {
      title: '类型',
      dataIndex: 'isSystem',
      width: 110,
      render: (val: boolean) => (
        val
          ? <Badge variant="default">系统预置</Badge>
          : <Badge variant="outline" className="text-slate-600">用户创建</Badge>
      ),
    },
    {
      title: '作者',
      dataIndex: 'userNickname',
      width: 140,
      render: (val: string, record: AdminScriptItem) => (
        <span className="text-sm">
          {record.isSystem ? '系统预置' : val || '未知用户'}
        </span>
      ),
    },
    {
      title: '风格标签',
      dataIndex: 'styleTags',
      width: 180,
      render: (val: string) => {
        if (!val) return <span className="text-sm text-slate-400">—</span>;
        const tags = val.split(/[,，、]/).filter(Boolean);
        return (
          <div className="flex flex-wrap gap-1">
            {tags.slice(0, 3).map((tag: string, i: number) => (
              <span
                key={i}
                className="text-xs px-2 py-0.5 bg-slate-100 text-slate-600 rounded-full"
              >
                {tag.trim()}
              </span>
            ))}
            {tags.length > 3 && (
              <span className="text-xs px-2 py-0.5 text-slate-400">+{tags.length - 3}</span>
            )}
          </div>
        );
      },
    },
    {
      title: '是否收藏',
      dataIndex: 'isFavorite',
      width: 100,
      render: (val: boolean) => (
        val
          ? <span className="flex items-center gap-1 text-sm text-rose-500">
              <Heart size={14} fill="currentColor" /> 已收藏
            </span>
          : <span className="text-sm text-slate-400">未收藏</span>
      ),
    },
    { title: '创建时间', dataIndex: 'createdAt', width: 170,
      render: (val: string) => <span className="text-sm text-muted-foreground">{val}</span> },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 140,
      render: (_: unknown, record: AdminScriptItem) => (
        <div className="flex gap-1">
          <Button variant="ghost" size="sm" onClick={() => openEdit(record)}>
            <Edit3 size={14} />
            编辑
          </Button>
          <Button variant="ghost" size="sm" onClick={() => openDelete(record)} className="text-destructive hover:text-destructive">
            <Trash2 size={14} />
            删除
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100 p-6">
      <div className="max-w-[1400px] mx-auto space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">台词库管理</h1>
            <p className="text-sm text-slate-500 mt-1">管理系统预置和用户创建的台词内容</p>
          </div>
          <Button onClick={openCreate}>
            <Plus size={16} />
            新增系统台词
          </Button>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">关键词搜索</label>
              <Input
                placeholder="标题 / 内容"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                className="w-64"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearch();
                }}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">分类</label>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="全部分类" />
                </SelectTrigger>
                <SelectContent>
                  {categoryOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-600">类型</label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="全部类型" />
                </SelectTrigger>
                <SelectContent>
                  {typeOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleSearch}>
              <Search size={16} />
              搜索
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm">
          <Table
            rowKey="id"
            columns={columns}
            dataSource={data}
            loading={loading}
            scroll={{ x: 1200, y: 560 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: false,
              showTotal: (t: number) => `共 ${t} 条`,
              onChange: (p: number) => setPage(p),
            }}
          />
        </div>

        {/* 新增/编辑弹窗 */}
        <Dialog open={formDialogOpen} onOpenChange={setFormDialogOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{isEditing ? '编辑台词' : '新增系统台词'}</DialogTitle>
              <DialogDescription>
                {isEditing ? '修改台词内容和分类信息' : '创建一条新的系统预置台词'}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>分类</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="请选择分类" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categoryOptions
                            .filter((opt) => opt.value !== '')
                            .map((opt) => (
                              <SelectItem key={opt.value} value={opt.value}>
                                {opt.label}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>标题</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入台词标题" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>内容</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="请输入台词内容"
                          rows={8}
                          className="resize-y"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="styleTags"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>风格标签</FormLabel>
                      <FormControl>
                        <Input placeholder="多个标签用逗号分隔，如：温馨,浪漫,中式" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setFormDialogOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? '保存中...' : '保存'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* 删除确认弹窗 */}
        <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>确认删除台词</DialogTitle>
              <DialogDescription>
                {currentScript
                  ? `删除台词「${currentScript.title}」后不可恢复，确认操作？`
                  : ''}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setDeleteOpen(false)}>取消</Button>
              <Button variant="destructive" onClick={handleDelete} disabled={submitting}>
                {submitting ? '删除中...' : '确认删除'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminScriptsPage;
