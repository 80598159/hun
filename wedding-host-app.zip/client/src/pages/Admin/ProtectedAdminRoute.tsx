import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { admin } from '@client/src/api';

interface ProtectedAdminRouteProps {
  children: React.ReactNode;
}

const ProtectedAdminRoute: React.FC<ProtectedAdminRouteProps> = ({ children }) => {
  const location = useLocation();

  if (!admin.isAdminLoggedIn()) {
    return <Navigate to="/admin/login" state={{ from: location.pathname }} replace />;
  }

  return <>{children}</>;
};

export default ProtectedAdminRoute;
