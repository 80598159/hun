import { useState, useEffect, useCallback } from 'react';
import {
  Table,
  type TableProps,
} from '@lark-apaas/client-toolkit/antd-table';
import { Search, Eye, CheckCircle, XCircle } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import type { AdminAuditItem } from '@shared/api.interface';

const auditDetailSchema = z.object({
  status: z.enum(['pending', 'approved', 'rejected']),
  riskLevel: z.enum(['low', 'medium', 'high']),
  remark: z.string().optional(),
});

type AuditDetailValues = z.infer<typeof auditDetailSchema>;

const riskLevelLabelMap: Record<string, string> = {
  low: '低',
  medium: '中',
  high: '高',
};

const riskLevelVariantMap: Record<
  string,
  'default' | 'secondary' | 'destructive' | 'outline'
> = {
  low: 'default',
  medium: 'secondary',
  high: 'destructive',
};

const statusLabelMap: Record<string, string> = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

const statusVariantMap: Record<
  string,
  'default' | 'secondary' | 'destructive' | 'outline'
> = {
  pending: 'secondary',
  approved: 'default',
  rejected: 'destructive',
};

const contentTypeLabelMap: Record<string, string> = {
  ai_generated: 'AI生成',
  user_input: '用户输入',
  script: '台词',
  flow: '方案',
  other: '其他',
};

interface ConfirmState {
  audit: AdminAuditItem;
  action: 'approve' | 'reject';
}

const AdminAuditsPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [audits, setAudits] = useState<AdminAuditItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [keyword, setKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [riskLevelFilter, setRiskLevelFilter] = useState<string>('all');

  const [detailOpen, setDetailOpen] = useState(false);
  const [viewingAudit, setViewingAudit] = useState<AdminAuditItem | null>(null);
  const [detailSubmitting, setDetailSubmitting] = useState(false);

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmState, setConfirmState] = useState<ConfirmState | null>(null);
  const [rejectRemark, setRejectRemark] = useState('');
  const [confirmSubmitting, setConfirmSubmitting] = useState(false);

  const detailForm = useForm<AuditDetailValues>({
    resolver: zodResolver(auditDetailSchema),
    defaultValues: {
      status: 'pending',
      riskLevel: 'low',
      remark: '',
    },
  });

  const fetchAudits = useCallback(async () => {
    setLoading(true);
    try {
      const params: admin.AdminAuditListParams = {
        page,
        pageSize,
      };
      if (keyword.trim()) params.keyword = keyword.trim();
      if (statusFilter !== 'all') params.status = statusFilter;
      if (riskLevelFilter !== 'all') params.riskLevel = riskLevelFilter;
      const res = await admin.getAdminAudits(params);
      setAudits(res.items);
      setTotal(res.total);
    } catch (err) {
      showToast('加载内容审核列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, keyword, statusFilter, riskLevelFilter, showToast]);

  useEffect(() => {
    fetchAudits();
  }, [fetchAudits]);

  const handleSearch = () => {
    setPage(1);
    fetchAudits();
  };

  const handleViewDetail = (audit: AdminAuditItem) => {
    setViewingAudit(audit);
    detailForm.reset({
      status: audit.status as 'pending' | 'approved' | 'rejected',
      riskLevel: audit.riskLevel as 'low' | 'medium' | 'high',
      remark: audit.remark || '',
    });
    setDetailOpen(true);
  };

  const handleDetailSubmit = async (values: AuditDetailValues) => {
    if (!viewingAudit) return;
    setDetailSubmitting(true);
    try {
      await admin.updateAdminAudit(viewingAudit.id, values);
      showToast('审核更新成功', 'success');
      setDetailOpen(false);
      setViewingAudit(null);
      fetchAudits();
    } catch (err) {
      showToast('更新失败', 'error');
    } finally {
      setDetailSubmitting(false);
    }
  };

  const handleApprove = (audit: AdminAuditItem) => {
    setConfirmState({ audit, action: 'approve' });
    setConfirmOpen(true);
  };

  const handleReject = (audit: AdminAuditItem) => {
    setRejectRemark('');
    setConfirmState({ audit, action: 'reject' });
    setConfirmOpen(true);
  };

  const handleConfirm = async () => {
    if (!confirmState) return;
    setConfirmSubmitting(true);
    try {
      await admin.updateAdminAudit(confirmState.audit.id, {
        status: confirmState.action === 'approve' ? 'approved' : 'rejected',
        remark:
          confirmState.action === 'reject' ? rejectRemark : undefined,
      });
      showToast(
        confirmState.action === 'approve' ? '已通过审核' : '已驳回',
        'success',
      );
      setConfirmOpen(false);
      setConfirmState(null);
      fetchAudits();
    } catch (err) {
      showToast('操作失败', 'error');
    } finally {
      setConfirmSubmitting(false);
    }
  };

  const columns: TableProps<AdminAuditItem>['columns'] = [
    {
      title: '内容类型',
      dataIndex: 'contentType',
      key: 'contentType',
      width: 120,
      render: (contentType: string) =>
        contentTypeLabelMap[contentType] ?? contentType,
    },
    {
      title: '内容摘要',
      dataIndex: 'content',
      key: 'content',
      minWidth: 240,
      render: (content: string) => (
        <span className="text-sm text-slate-700">
          {content.length > 50 ? content.slice(0, 50) + '...' : content}
        </span>
      ),
    },
    {
      title: '风险等级',
      dataIndex: 'riskLevel',
      key: 'riskLevel',
      width: 100,
      render: (riskLevel: string) => (
        <Badge variant={riskLevelVariantMap[riskLevel] ?? 'outline'}>
          {riskLevelLabelMap[riskLevel] ?? riskLevel}
        </Badge>
      ),
    },
    {
      title: '敏感词',
      dataIndex: 'flaggedWords',
      key: 'flaggedWords',
      width: 140,
      render: (flaggedWords: string) =>
        flaggedWords ? (
          <span className="text-sm text-destructive">{flaggedWords}</span>
        ) : (
          <span className="text-sm text-slate-400">无</span>
        ),
    },
    {
      title: 'AI生成',
      dataIndex: 'aiGenerated',
      key: 'aiGenerated',
      width: 90,
      render: (aiGenerated: boolean) => (
        <Badge variant={aiGenerated ? 'default' : 'outline'}>
          {aiGenerated ? '是' : '否'}
        </Badge>
      ),
    },
    {
      title: '用户昵称',
      dataIndex: 'userNickname',
      key: 'userNickname',
      width: 120,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: string) => (
        <Badge variant={statusVariantMap[status] ?? 'outline'}>
          {statusLabelMap[status] ?? status}
        </Badge>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      width: 170,
      render: (createdAt: string) =>
        new Date(createdAt).toLocaleString('zh-CN'),
    },
    {
      title: '操作',
      key: 'actions',
      width: 220,
      fixed: 'right',
      render: (_: unknown, record: AdminAuditItem) => (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleViewDetail(record)}
            aria-label="查看详情"
          >
            <Eye className="h-3.5 w-3.5" />
            详情
          </Button>
          {record.status === 'pending' && (
            <>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleApprove(record)}
                aria-label="通过"
              >
                <CheckCircle className="h-3.5 w-3.5" />
                通过
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="text-destructive"
                onClick={() => handleReject(record)}
                aria-label="驳回"
              >
                <XCircle className="h-3.5 w-3.5" />
                驳回
              </Button>
            </>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-full" style={{ backgroundColor: '#f1f5f9' }}>
      <div className="mx-auto max-w-[1400px] p-6">
        <h1 className="text-2xl font-bold text-slate-800 mb-6">
          内容合规管理
        </h1>

        {/* 筛选栏 */}
        <div className="bg-white rounded-lg p-4 mb-4 shadow-sm flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[200px] max-w-sm">
            <Input
              placeholder="搜索内容关键词"
              value={keyword}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setKeyword(e.target.value)
              }
              onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                if (e.key === 'Enter') handleSearch();
              }}
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">状态：</span>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-28">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="pending">待审核</SelectItem>
                <SelectItem value="approved">已通过</SelectItem>
                <SelectItem value="rejected">已驳回</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">风险等级：</span>
            <Select
              value={riskLevelFilter}
              onValueChange={setRiskLevelFilter}
            >
              <SelectTrigger className="w-28">
                <SelectValue placeholder="全部" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="low">低</SelectItem>
                <SelectItem value="medium">中</SelectItem>
                <SelectItem value="high">高</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleSearch}
            style={{ backgroundColor: '#2563eb' }}
            className="text-white hover:bg-blue-700"
          >
            <Search className="h-4 w-4" />
            搜索
          </Button>
        </div>

        {/* 表格 */}
        <div className="bg-white rounded-lg shadow-sm">
          <Table<AdminAuditItem>
            rowKey="id"
            columns={columns}
            dataSource={audits}
            loading={loading}
            pagination={{
              current: page,
              pageSize,
              total,
              onChange: (p: number) => setPage(p),
              showSizeChanger: false,
            }}
            scroll={{ x: 1200 }}
          />
        </div>
      </div>

      {/* 详情弹窗 */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>内容审核详情</DialogTitle>
            <DialogDescription>
              查看完整内容并审核处理。
            </DialogDescription>
          </DialogHeader>

          {viewingAudit && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-slate-500 mb-1">内容类型</p>
                  <p className="font-medium">
                    {contentTypeLabelMap[viewingAudit.contentType] ??
                      viewingAudit.contentType}
                  </p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">用户昵称</p>
                  <p className="font-medium">{viewingAudit.userNickname}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">风险等级</p>
                  <Badge
                    variant={
                      riskLevelVariantMap[viewingAudit.riskLevel] ?? 'outline'
                    }
                  >
                    {riskLevelLabelMap[viewingAudit.riskLevel] ??
                      viewingAudit.riskLevel}
                  </Badge>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">AI生成</p>
                  <p className="font-medium">
                    {viewingAudit.aiGenerated ? '是' : '否'}
                  </p>
                </div>
              </div>

              <div>
                <p className="text-slate-500 text-sm mb-1">敏感词</p>
                <p className="text-sm text-destructive">
                  {viewingAudit.flaggedWords || '无'}
                </p>
              </div>

              <div>
                <p className="text-slate-500 text-sm mb-1">完整内容</p>
                <div className="bg-slate-50 rounded-lg p-4 text-sm whitespace-pre-wrap max-h-[200px] overflow-y-auto">
                  {viewingAudit.content}
                </div>
              </div>

              <Form {...detailForm}>
                <form
                  onSubmit={detailForm.handleSubmit(handleDetailSubmit)}
                  className="space-y-4 pt-2"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={detailForm.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>审核状态</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="选择状态" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="pending">待审核</SelectItem>
                              <SelectItem value="approved">已通过</SelectItem>
                              <SelectItem value="rejected">已驳回</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={detailForm.control}
                      name="riskLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>风险等级</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="选择等级" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="low">低</SelectItem>
                              <SelectItem value="medium">中</SelectItem>
                              <SelectItem value="high">高</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={detailForm.control}
                    name="remark"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>审核备注</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="请输入审核备注（选填）"
                            className="min-h-[80px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setDetailOpen(false)}
                    >
                      关闭
                    </Button>
                    <Button
                      type="submit"
                      disabled={detailSubmitting}
                      style={{ backgroundColor: '#2563eb' }}
                      className="text-white hover:bg-blue-700"
                    >
                      {detailSubmitting ? '保存中...' : '保存'}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* 通过/驳回确认弹窗 */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle>
              {confirmState?.action === 'approve' ? '确认通过' : '确认驳回'}
            </DialogTitle>
            <DialogDescription>
              {confirmState?.action === 'approve'
                ? '确定通过该条内容的审核吗？'
                : '确定驳回该条内容的审核吗？驳回后可填写备注说明。'}
            </DialogDescription>
          </DialogHeader>

          {confirmState?.action === 'reject' && (
            <div className="space-y-2">
              <label className="text-sm font-medium">驳回备注（选填）</label>
              <Textarea
                placeholder="请输入驳回原因"
                value={rejectRemark}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                  setRejectRemark(e.target.value)
                }
                className="min-h-[80px]"
              />
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>
              取消
            </Button>
            <Button
              variant={confirmState?.action === 'reject' ? 'destructive' : 'default'}
              style={
                confirmState?.action === 'approve'
                  ? { backgroundColor: '#2563eb' }
                  : undefined
              }
              className={confirmState?.action === 'approve' ? 'text-white hover:bg-blue-700' : ''}
              disabled={confirmSubmitting}
              onClick={handleConfirm}
            >
              {confirmSubmitting ? '处理中...' : '确认'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminAuditsPage;
