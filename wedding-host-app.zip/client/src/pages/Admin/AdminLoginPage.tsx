import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, User as UserIcon } from 'lucide-react';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import type { AdminLoginRequest } from '@shared/api.interface';

const AdminLoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (admin.isAdminLoggedIn()) {
      navigate('/admin', { replace: true });
    }
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      showToast('请输入用户名和密码', 'warning');
      return;
    }

    setLoading(true);
    try {
      const data: AdminLoginRequest = { username: username.trim(), password };
      const res = await admin.adminLogin(data);
      admin.setAdminSession(res);
      showToast('登录成功', 'success');
      navigate('/admin', { replace: true });
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { error?: { message?: string } } } }).response?.data?.error
          ?.message || '登录失败，请检查用户名和密码';
      showToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = () => {
    const demo = admin.getDemoAdminPassword();
    setUsername(demo.username);
    setPassword(demo.password);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{
        background: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #2563eb 100%)',
        fontFamily: 'system-ui, -apple-system, "Segoe UI", "PingFang SC", sans-serif',
      }}
    >
      {/* Decorative shapes */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-20 -left-20 w-96 h-96 rounded-full bg-white/5" />
        <div className="absolute -bottom-32 -right-20 w-[500px] h-[500px] rounded-full bg-white/5" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo area */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white shadow-lg mb-4">
            <span className="text-[#2563eb] font-bold text-2xl">婚</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">婚序·管理后台</h1>
          <p className="text-blue-200 text-sm mt-1.5">专业运营数据管理平台</p>
        </div>

        {/* Login card */}
        <div className="bg-white rounded-xl shadow-2xl p-8">
          <h2 className="text-lg font-semibold text-[#1e293b] mb-6">管理员登录</h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Username */}
            <div>
              <label
                htmlFor="admin-username"
                className="block text-sm font-medium text-[#1e293b] mb-1.5"
              >
                用户名
              </label>
              <div className="relative">
                <UserIcon
                  size={18}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  id="admin-username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="请输入用户名"
                  className="w-full h-11 pl-10 pr-3 text-sm border border-gray-200 rounded-lg bg-gray-50
                    focus:bg-white focus:border-[#2563eb] focus:ring-2 focus:ring-[#2563eb]/20
                    outline-none transition-colors"
                  autoComplete="username"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label
                htmlFor="admin-password"
                className="block text-sm font-medium text-[#1e293b] mb-1.5"
              >
                密码
              </label>
              <div className="relative">
                <Lock
                  size={18}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  id="admin-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="请输入密码"
                  className="w-full h-11 pl-10 pr-3 text-sm border border-gray-200 rounded-lg bg-gray-50
                    focus:bg-white focus:border-[#2563eb] focus:ring-2 focus:ring-[#2563eb]/20
                    outline-none transition-colors"
                  autoComplete="current-password"
                />
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full h-11 bg-[#2563eb] hover:bg-[#1d4ed8] text-white text-sm font-medium
                rounded-lg transition-colors disabled:opacity-60 disabled:cursor-not-allowed
                shadow-sm hover:shadow-md"
            >
              {loading ? '登录中...' : '登 录'}
            </button>
          </form>

          {/* Demo hint */}
          <div className="mt-6 pt-5 border-t border-gray-100">
            <div className="flex items-center justify-between text-xs text-[#64748b]">
              <span>演示账号：admin / 123456</span>
              <button
                type="button"
                onClick={fillDemo}
                className="text-[#2563eb] hover:text-[#1d4ed8] font-medium"
              >
                一键填入
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-blue-200/70 text-xs mt-6">
          © 2026 婚序·婚礼主持助手 管理系统
        </p>
      </div>
    </div>
  );
};

export default AdminLoginPage;
