import { useCallback, useEffect, useState } from 'react';
import {
  Table,
  type TableProps,
} from '@lark-apaas/client-toolkit/antd-table';
import { Plus, Trash2, Pencil, Activity, Power, PowerOff, ChevronDown, ChevronUp } from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { admin } from '@client/src/api';
import { useToast } from '@client/src/components/ToastProvider';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import type { AiApiConfigItem } from '@shared/api.interface';

function protocolLabel(protocol: string): string {
  if (protocol === 'cloudflare_workers_ai') return 'Workers AI';
  if (protocol === 'cloudflare_images') return 'Cloudflare Images';
  if (protocol === 'aliyun_imageseg') return '阿里云图像分割';
  if (protocol === 'volcengine_visual') return '火山引擎视觉';
  return 'OpenAI';
}

const formSchema = z.object({
  name: z.string().min(1, '请输入接口名称'),
  protocol: z.enum(['openai', 'cloudflare_workers_ai', 'cloudflare_images', 'aliyun_imageseg', 'volcengine_visual']),
  baseUrl: z.string().min(1, '请输入接口地址'),
  apiKey: z.string().min(1, '请输入 API Key'),
  modelName: z.string().optional(),
  appId: z.string().optional(),
  cfAccountId: z.string().optional(),
  r2AccessKey: z.string().optional(),
  r2SecretKey: z.string().optional(),
  r2Bucket: z.string().optional(),
  r2Endpoint: z.string().optional(),
  r2PublicDomain: z.string().optional(),
  status: z.enum(['active', 'inactive']),
  priority: z.coerce.number().int('优先级必须为整数').min(1, '优先级最小为1'),
  remark: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const AdminAiApiPage: React.FC = () => {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [configs, setConfigs] = useState<AiApiConfigItem[]>([]);

  const [formOpen, setFormOpen] = useState(false);
  const [editingConfig, setEditingConfig] = useState<AiApiConfigItem | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deletingConfig, setDeletingConfig] = useState<AiApiConfigItem | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    steps?: {
      r2Upload?: { success: boolean; message: string; detail?: string; argumentName?: string };
      r2Url?: { success: boolean; message: string };
      cfImages?: { success: boolean; message: string };
    };
  } | null>(null);
  const [r2Collapsed, setR2Collapsed] = useState(true);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema) as any,
    defaultValues: {
      name: '',
      protocol: 'openai',
      baseUrl: 'https://',
      apiKey: '',
      modelName: '',
      status: 'active',
      priority: 1,
      remark: '',
    },
  });

  const fetchConfigs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await admin.getAiApiConfigs();
      setConfigs(res.items);
    } catch (err) {
      showToast('加载API配置列表失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchConfigs();
  }, [fetchConfigs]);

  const handleAdd = () => {
    setEditingConfig(null);
    form.reset({
      name: '',
      protocol: 'openai',
      baseUrl: 'https://',
      apiKey: '',
      modelName: '',
      appId: '',
      cfAccountId: '',
      r2AccessKey: '',
      r2SecretKey: '',
      r2Bucket: '',
      r2Endpoint: '',
      r2PublicDomain: '',
      status: 'active',
      priority: configs.length + 1,
      remark: '',
    });
    setFormOpen(true);
  };

  const handleEdit = (config: AiApiConfigItem) => {
    setEditingConfig(config);
    form.reset({
      name: config.name,
      protocol: config.protocol,
      baseUrl: config.baseUrl,
      apiKey: '',
      modelName: config.modelName,
      appId: config.appId || '',
      cfAccountId: config.cfAccountId || '',
      r2AccessKey: config.r2AccessKey || '',
      r2SecretKey: '',
      r2Bucket: config.r2Bucket || '',
      r2Endpoint: config.r2Endpoint || '',
      r2PublicDomain: config.r2PublicDomain || '',
      status: config.status,
      priority: config.priority,
      remark: config.remark || '',
    });
    setFormOpen(true);
  };

  const handleSubmit = async (values: FormValues) => {
    setSubmitting(true);
    try {
      const payload: any = { ...values };
      if (!payload.modelName) {
        payload.modelName = 'remove-background';
      }
      if (editingConfig && !values.apiKey) {
        delete payload.apiKey;
      }
      if (editingConfig) {
        await admin.updateAiApiConfig(editingConfig.id, payload);
        showToast('接口配置更新成功', 'success');
      } else {
        await admin.createAiApiConfig(payload);
        showToast('接口配置创建成功', 'success');
      }
      setFormOpen(false);
      fetchConfigs();
    } catch (err) {
      showToast(editingConfig ? '更新失败' : '创建失败', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (config: AiApiConfigItem) => {
    try {
      const nextStatus = config.status === 'active' ? 'inactive' : 'active';
      await admin.toggleAiApiConfig(config.id, nextStatus);
      showToast(nextStatus === 'active' ? '已启用' : '已停用', 'success');
      fetchConfigs();
    } catch (err) {
      showToast('操作失败', 'error');
    }
  };

  const handleTest = async (config: AiApiConfigItem) => {
    setTestingId(config.id);
    setTestResult(null);
    try {
      const res = await admin.testAiApiConfig(config.id);
      setTestResult({
        success: res.success,
        message: res.message,
        steps: res.steps,
      });
      if (res.success) {
        showToast(`连通性测试成功，耗时 ${res.latencyMs}ms`, 'success');
      } else {
        showToast(`测试失败：${res.message}`, 'error');
      }
      fetchConfigs();
    } catch (err) {
      showToast('测试请求失败', 'error');
    } finally {
      setTestingId(null);
    }
  };

  const handleDeleteClick = (config: AiApiConfigItem) => {
    setDeletingConfig(config);
    setDeleteOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingConfig) return;
    setDeleting(true);
    try {
      await admin.deleteAiApiConfig(deletingConfig.id);
      showToast('删除成功', 'success');
      setDeleteOpen(false);
      setDeletingConfig(null);
      fetchConfigs();
    } catch (err) {
      showToast('删除失败', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const columns: TableProps<AiApiConfigItem>['columns'] = [
    {
      title: '优先级',
      dataIndex: 'priority',
      width: 80,
      key: 'priority',
      render: (value: number) => (
        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-blue-50 text-blue-600 text-xs font-semibold">
          {value}
        </span>
      ),
    },
    {
      title: '接口名称',
      dataIndex: 'name',
      key: 'name',
      render: (value: string, record: AiApiConfigItem) => (
        <div>
          <div className="font-medium text-gray-900">{value}</div>
          <div className="text-xs text-gray-500 mt-0.5">
            {record.modelName} · {protocolLabel(record.protocol)}
          </div>
        </div>
      ),
    },
    {
      title: 'Base URL',
      dataIndex: 'baseUrl',
      key: 'baseUrl',
      width: 220,
      ellipsis: true,
      render: (value: string) => (
        <span className="text-sm text-gray-600 font-mono" title={value}>
          {value}
        </span>
      ),
    },
    {
      title: 'API Key',
      dataIndex: 'apiKeyMasked',
      key: 'apiKeyMasked',
      width: 180,
      render: (value: string) => (
        <span className="font-mono text-sm text-gray-600 bg-gray-50 px-2 py-1 rounded">
          {value}
        </span>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (value: string, record: AiApiConfigItem) => {
        const isActive = value === 'active';
        const healthColor = record.lastCallStatus === 'failed'
          ? 'bg-red-100 text-red-700 border-red-200'
          : isActive
            ? 'bg-green-50 text-green-700 border-green-200'
            : 'bg-gray-100 text-gray-500 border-gray-200';
        const healthText = record.lastCallStatus === 'failed'
          ? '异常'
          : isActive
            ? '运行中'
            : '已停用';
        return (
          <Badge variant="outline" className={healthColor}>
            {healthText}
          </Badge>
        );
      },
    },
    {
      title: '健康状态',
      key: 'health',
      width: 180,
      render: (_: unknown, record: AiApiConfigItem) => {
        if (record.lastCallStatus === 'failed') {
          return (
            <div className="text-xs">
              <div className="text-red-600 font-medium">最近调用失败</div>
              <div className="text-gray-500 mt-0.5">
                失败 {record.failCount} 次
              </div>
              {record.lastError && (
                <div className="text-gray-400 mt-0.5 truncate" title={record.lastError}>
                  {record.lastError}
                </div>
              )}
            </div>
          );
        }
        if (record.lastCallStatus === 'success') {
          return (
            <div className="text-xs text-green-600 font-medium">
              最近调用成功
            </div>
          );
        }
        return <span className="text-xs text-gray-400">暂无调用记录</span>;
      },
    },
    {
      title: '操作',
      key: 'actions',
      width: 220,
      fixed: 'right',
      render: (_: unknown, record: AiApiConfigItem) => (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 px-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
            onClick={() => handleTest(record)}
            disabled={testingId === record.id}
          >
            <Activity size={14} className="mr-1" />
            {testingId === record.id ? '测试中...' : '测试'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 px-2 text-gray-600 hover:text-gray-800"
            onClick={() => handleEdit(record)}
          >
            <Pencil size={14} className="mr-1" />
            编辑
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={`h-8 px-2 ${
              record.status === 'active'
                ? 'text-amber-600 hover:text-amber-700 hover:bg-amber-50'
                : 'text-green-600 hover:text-green-700 hover:bg-green-50'
            }`}
            onClick={() => handleToggleStatus(record)}
          >
            {record.status === 'active' ? (
              <PowerOff size={14} className="mr-1" />
            ) : (
              <Power size={14} className="mr-1" />
            )}
            {record.status === 'active' ? '停用' : '启用'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={() => handleDeleteClick(record)}
          >
            <Trash2 size={14} className="mr-1" />
            删除
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">大模型API接口管理</h1>
          <p className="text-sm text-gray-500 mt-1">
            配置AI能力使用的大模型接口，支持多接口按优先级自动故障转移
          </p>
        </div>
        <Button onClick={handleAdd}>
          <Plus size={16} className="mr-2" />
          新增接口
        </Button>
      </div>

      {configs.length > 0 && (
        <div className="mb-4 p-4 bg-blue-50 border border-blue-100 rounded-lg">
          <div className="text-sm text-blue-800">
            <span className="font-medium">自动故障转移已启用。</span>
            系统将按优先级从高到低（1号为首选）依次调用接口，当前一个接口失败时自动切换到下一个。
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <Table<AiApiConfigItem>
          rowKey="id"
          columns={columns}
          dataSource={configs}
          loading={loading}
          pagination={false}
          size="middle"
        />
        {!loading && configs.length === 0 && (
          <div className="py-16 text-center">
            <div className="text-gray-400 text-sm">暂无API接口配置</div>
            <Button variant="outline" className="mt-4" onClick={handleAdd}>
              <Plus size={14} className="mr-2" />
              添加第一个接口
            </Button>
          </div>
        )}
      </div>

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="sm:max-w-lg !p-0 flex flex-col max-h-[85vh]">
          <DialogHeader className="px-6 pt-6 pb-3 shrink-0">
            <DialogTitle>
              {editingConfig ? '编辑接口配置' : '新增接口配置'}
            </DialogTitle>
            <DialogDescription>
              配置大模型API接口信息，API Key 将加密存储，列表中仅显示脱敏后的值。
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="flex flex-col flex-1 min-h-0">
              <div className="px-6 py-4 overflow-y-auto space-y-3 flex-1">
                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem className="mb-0">
                        <FormLabel>接口名称 <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input placeholder="如：豆包、通义千问" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="protocol"
                    render={({ field }) => (
                      <FormItem className="mb-0">
                        <FormLabel>接口协议 <span className="text-red-500">*</span></FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange as (val: string) => void}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="选择协议" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="openai">OpenAI 兼容</SelectItem>
                            <SelectItem value="cloudflare_workers_ai">Cloudflare Workers AI</SelectItem>
                            <SelectItem value="cloudflare_images">Cloudflare Images（抠图）</SelectItem>
                            <SelectItem value="aliyun_imageseg">阿里云图像分割（抠图）</SelectItem>
                            <SelectItem value="volcengine_visual">火山引擎视觉（抠图）</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={form.control}
                    name="modelName"
                    render={({ field }) => {
                      const protocol = form.watch('protocol');
                      if (protocol === 'cloudflare_images' || protocol === 'aliyun_imageseg' || protocol === 'volcengine_visual') return null;
                      return (
                        <FormItem className="mb-0">
                          <FormLabel>模型名称 <span className="text-red-500">*</span></FormLabel>
                          <FormControl>
                            <Input placeholder="如：gpt-4o、doubao-pro" {...field} value={field.value || ''} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />
                  <FormField
                    control={form.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem className="mb-0">
                        <FormLabel>优先级 <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input type="number" min={1} {...field} />
                        </FormControl>
                        <p className="text-xs text-gray-500">数字越小优先级越高</p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="baseUrl"
                  render={({ field }) => {
                    const protocol = form.watch('protocol');
                    if (protocol === 'cloudflare_images') return null;
                    return (
                      <FormItem className="mb-0">
                        <FormLabel>接口地址 (URL) <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input
                            placeholder={
                              protocol === 'cloudflare_workers_ai'
                                ? 'https://api.cloudflare.com/client/v4/accounts/{ACCOUNT_ID}/ai/run'
                                : protocol === 'aliyun_imageseg'
                                    ? 'imageseg.cn-shanghai.aliyuncs.com'
                                    : protocol === 'volcengine_visual'
                                      ? 'https://visual.volcengineapi.com'
                                      : 'https://api.example.com/v1'
                            }
                            {...field}
                          />
                        </FormControl>
                        <p className="text-xs text-gray-500">
                          {protocol === 'cloudflare_workers_ai'
                              ? 'Cloudflare Workers AI run 端点，不含模型名，如 .../accounts/xxx/ai/run'
                              : protocol === 'aliyun_imageseg'
                                ? '阿里云图像分割服务Endpoint，如 imageseg.cn-shanghai.aliyuncs.com'
                                : protocol === 'volcengine_visual'
                                  ? '火山引擎视觉API地址，通常为 https://visual.volcengineapi.com'
                                  : 'OpenAI 兼容格式，以 /v1 结尾，不含 /chat/completions'}
                        </p>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />

                <FormField
                  control={form.control}
                  name="apiKey"
                  render={({ field }) => {
                    const protocol = form.watch('protocol');
                    if (protocol === 'cloudflare_images') return null;
                    return (
                      <FormItem className="mb-0">
                        <FormLabel>API Key <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder={editingConfig ? '留空表示不修改' : 'sk-xxxxxxxxxx'}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />

                <FormField
                  control={form.control}
                  name="appId"
                  render={({ field }) => {
                    const protocol = form.watch('protocol');
                    if (protocol !== 'aliyun_imageseg' && protocol !== 'volcengine_visual') return null;
                    return (
                      <FormItem className="mb-0">
                        <FormLabel>AppID / Region ID</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={protocol === 'volcengine_visual' ? '如 cn-north-1（可选）' : '可选'}
                            {...field}
                            value={field.value || ''}
                          />
                        </FormControl>
                        <p className="text-xs text-gray-500">
                          {protocol === 'volcengine_visual'
                            ? '火山引擎Region，默认cn-north-1'
                            : '阿里云可选，留空即可'}
                        </p>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />

                <FormField
                  control={form.control}
                  name="cfAccountId"
                  render={({ field }) => {
                    const protocol = form.watch('protocol');
                    if (protocol !== 'cloudflare_images') return null;
                    return (
                      <FormItem className="mb-0">
                        <FormLabel>Cloudflare Account ID</FormLabel>
                        <FormControl>
                          <Input placeholder="如 dd9d97a9968780976884986a721f3fa4" {...field} value={field.value || ''} />
                        </FormControl>
                        <p className="text-xs text-gray-500">32位Account ID，也可在接口地址里自动识别</p>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem className="mb-0">
                        <FormLabel>状态</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange as (val: string) => void}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="选择状态" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="active">启用</SelectItem>
                            <SelectItem value="inactive">停用</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {form.watch('protocol') === 'cloudflare_images' && (
                  <div className="p-3 rounded-xl bg-rose-50/50 border border-rose-200/50">
                    <div className="text-sm font-semibold text-rose-900">
                      R2 对象存储配置 <span className="text-red-500">*</span>
                    </div>
                    <p className="text-xs text-rose-700 mt-2 mb-3">
                      Cloudflare Images 免费版通过 R2 + Image Transform URL 方式实现抠图，无需付费 Images 存储，每月 5000 次免费转换额度。
                    </p>
                    <div className="space-y-3">
                        <div className="space-y-2">
                          <label className="text-xs text-gray-700">R2 Endpoint</label>
                          <Input
                            placeholder="https://{account_id}.r2.cloudflarestorage.com"
                            value={form.watch('r2Endpoint') || ''}
                            onChange={(e) => form.setValue('r2Endpoint', e.target.value)}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <label className="text-xs text-gray-700">R2 Access Key ID</label>
                            <Input
                              placeholder="AKIA..."
                              value={form.watch('r2AccessKey') || ''}
                              onChange={(e) => form.setValue('r2AccessKey', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs text-gray-700">R2 Secret Key</label>
                            <Input
                              type="password"
                              placeholder={editingConfig ? '留空不修改' : 'sk-...'}
                              value={form.watch('r2SecretKey') || ''}
                              onChange={(e) => form.setValue('r2SecretKey', e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <label className="text-xs text-gray-700">R2 Bucket 名称</label>
                            <Input
                              placeholder="如 wedding-images"
                              value={form.watch('r2Bucket') || ''}
                              onChange={(e) => form.setValue('r2Bucket', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs text-gray-700">R2 公开访问域名</label>
                            <Input
                              placeholder="https://pub-xxx.r2.dev"
                              value={form.watch('r2PublicDomain') || ''}
                              onChange={(e) => form.setValue('r2PublicDomain', e.target.value)}
                            />
                            <p className="text-xs text-amber-600">需在 R2 开启 Public Access</p>
                          </div>
                        </div>
                        <div className="pt-2 border-t border-amber-200/50">
                          <div className="text-xs font-medium text-amber-900 mb-1">
                            ⚠️ R2 CORS 配置说明
                          </div>
                          <p className="text-xs text-amber-700 leading-relaxed">
                            请在 Cloudflare R2 控制台为该 Bucket 配置 CORS 规则，允许本应用域名的 GET/PUT 请求。否则公开 URL 可能无法在浏览器中访问。
                          </p>
                        </div>
                    </div>
                  </div>
                )}

                <FormField
                  control={form.control}
                  name="remark"
                  render={({ field }) => (
                    <FormItem className="mb-0">
                      <FormLabel>备注</FormLabel>
                      <FormControl>
                        <Textarea rows={2} placeholder="可选，备注说明" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="px-6 py-4 border-t border-gray-200 bg-white shrink-0 space-y-3">
                {testResult && editingConfig && (
                  <div
                    className={`p-3 rounded-xl text-sm ${
                      testResult.success
                        ? 'bg-green-50 border border-green-200 text-green-800'
                        : 'bg-red-50 border border-red-200 text-red-800'
                    }`}
                  >
                    <div className="font-medium mb-2">{testResult.message}</div>
                    {testResult.steps && Object.keys(testResult.steps).length > 0 && (
                      <div className="space-y-1.5 text-xs">
                        {testResult.steps.r2Upload && (
                          <div>
                            <div className="flex items-center gap-2">
                              <span>{testResult.steps.r2Upload.success ? '✓' : '✗'}</span>
                              <span>R2 上传：{testResult.steps.r2Upload.message}</span>
                            </div>
                            {testResult.steps.r2Upload.detail && (
                              <div className="mt-1 ml-5 p-2 rounded-md bg-black/5 font-mono text-[11px] break-all whitespace-pre-wrap line-clamp-6 overflow-hidden">
                                {testResult.steps.r2Upload.detail}
                              </div>
                            )}
                          </div>
                        )}
                        {testResult.steps.r2Url && (
                          <div className="flex items-center gap-2">
                            <span>{testResult.steps.r2Url.success ? '✓' : '✗'}</span>
                            <span>公开 URL 访问：{testResult.steps.r2Url.message}</span>
                          </div>
                        )}
                        {testResult.steps.cfImages && (
                          <div className="flex items-center gap-2">
                            <span>{testResult.steps.cfImages.success ? '✓' : '✗'}</span>
                            <span>Cloudflare Images 抠图：{testResult.steps.cfImages.message}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
                <DialogFooter className="!m-0 gap-2">
                  {editingConfig && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => handleTest(editingConfig)}
                      disabled={testingId === editingConfig.id}
                      className="mr-auto"
                    >
                      <Activity size={14} className="mr-2" />
                      {testingId === editingConfig.id ? '测试中...' : '测试连接'}
                    </Button>
                  )}
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setFormOpen(false)}
                  >
                    取消
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? '保存中...' : '保存'}
                  </Button>
                </DialogFooter>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>确认删除接口配置</DialogTitle>
            <DialogDescription>
              确定要删除「{deletingConfig?.name}」吗？删除后该接口将不再用于AI调用。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm} disabled={deleting}>
              {deleting ? '删除中...' : '确认删除'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminAiApiPage;
