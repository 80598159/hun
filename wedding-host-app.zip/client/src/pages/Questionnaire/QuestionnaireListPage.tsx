import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, ClipboardCheck, Calendar, FileText } from 'lucide-react';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import { questionnaire, wedding } from '@client/src/api';
import type { Questionnaire, WeddingProject } from '@shared/api.interface';

const statusConfig: Record<string, { label: string; className: string }> = {
  draft: { label: '草稿', className: 'bg-muted text-muted-foreground' },
  published: { label: '已发布', className: 'bg-success/15 text-success' },
  closed: { label: '已关闭', className: 'bg-destructive/15 text-destructive' },
};

const QuestionnaireListPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<Questionnaire[]>([]);
  const [creating, setCreating] = useState(false);
  const [projects, setProjects] = useState<WeddingProject[]>([]);

  const loadList = async () => {
    setLoading(true);
    try {
      const data = await questionnaire.list();
      setItems(data.items || []);
    } catch {
      showToast('加载问卷列表失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadProjects = async () => {
    try {
      const data = await wedding.getProjectList({ pageSize: 50 });
      setProjects(data.items || []);
    } catch {
      // 忽略项目列表错误
    }
  };

  useEffect(() => {
    void loadList();
    void loadProjects();
  }, []);

  const handleCreate = async () => {
    if (projects.length === 0) {
      showToast('请先创建婚礼方案', 'warning');
      navigate('/');
      return;
    }
    setCreating(true);
    try {
      const firstProject = projects[0];
      const data = await questionnaire.create({
        projectId: firstProject.id,
        title: '新人问卷',
      });
      showToast('已创建问卷', 'success');
      navigate(`/questionnaire/${data.questionnaire.id}`);
    } catch {
      showToast('创建失败', 'error');
    } finally {
      setCreating(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  const getProjectTitle = (projectId: string) => {
    const p = projects.find((pr: WeddingProject) => pr.id === projectId);
    return p?.title || '';
  };

  return (
    <div className="min-h-screen bg-background px-5 pb-24">
      <PageHeader title="新人问卷" onBack={() => navigate(-1)} />

      {loading ? (
        <div className="flex justify-center py-16">
          <LoadingSpinner />
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={<ClipboardCheck size={32} />}
          title="暂无问卷"
          description="创建第一份新人问卷，快速收集新人信息"
          action={
            <Button onClick={handleCreate} loading={creating}>
              <Plus size={18} />
              新建问卷
            </Button>
          }
        />
      ) : (
        <div className="space-y-3 mt-2">
          {items.map((item: Questionnaire) => {
            const status = statusConfig[item.status] || statusConfig.draft;
            const projectTitle = getProjectTitle(item.projectId);
            return (
              <button
                key={item.id}
                onClick={() => navigate(`/questionnaire/${item.id}`)}
                className="w-full text-left bg-card rounded-2xl shadow-md p-5 transition-all duration-200 active:scale-[0.99] hover:shadow-lg"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-base font-semibold text-foreground flex-1 truncate mr-3">
                    {item.title}
                  </h3>
                  <span
                    className={`flex-shrink-0 px-2.5 py-0.5 rounded-full text-xs font-medium ${status.className}`}
                  >
                    {status.label}
                  </span>
                </div>
                {projectTitle && (
                  <p className="text-xs text-accent-gold-dark mb-2">
                    关联方案：{projectTitle}
                  </p>
                )}
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar size={12} />
                    {formatDate(item.createdAt)}
                  </span>
                  <span className="flex items-center gap-1">
                    <FileText size={12} />
                    {item.fields?.length || 0} 个字段
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* 悬浮新建按钮 */}
      <button
        onClick={handleCreate}
        disabled={creating}
        className="fixed bottom-24 right-5 w-14 h-14 rounded-full bg-primary-gradient shadow-lg shadow-primary/40 text-primary-foreground flex items-center justify-center transition-all duration-200 active:scale-95 z-30 disabled:opacity-60"
        aria-label="新建问卷"
      >
        <Plus size={24} />
      </button>
    </div>
  );
};

export default QuestionnaireListPage;
