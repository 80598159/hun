import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Heart, Check, Loader2 } from 'lucide-react';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import Button from '@client/src/components/app-ui/Button';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import { questionnaire as qApi } from '@client/src/api';
import type { Questionnaire, QuestionnaireField } from '@shared/api.interface';

const QuestionnaireFillPage = () => {
  const { shareCode = '' } = useParams<{ shareCode: string }>();
  const { showToast } = useToast();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Questionnaire | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [submitterName, setSubmitterName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const load = async () => {
      if (!shareCode) return;
      setLoading(true);
      try {
        const res = await qApi.getByShareCode(shareCode);
        setData(res.questionnaire);
        const initial: Record<string, string> = {};
        res.questionnaire.fields.forEach((f: QuestionnaireField) => {
          initial[f.fieldKey] = '';
        });
        setFormData(initial);
      } catch {
        showToast('加载问卷失败', 'error');
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, [shareCode, showToast]);

  const validate = (): boolean => {
    if (!data) return false;
    const newErrors: Record<string, string> = {};
    data.fields.forEach((field: QuestionnaireField) => {
      if (field.required && !formData[field.fieldKey]?.trim()) {
        newErrors[field.fieldKey] = '此项为必填';
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!data) return;
    if (!validate()) {
      showToast('请完善必填项', 'warning');
      return;
    }
    setSubmitting(true);
    try {
      await qApi.submitAnswer({
        shareCode: data.shareCode,
        answerData: formData,
        submitterName: submitterName || undefined,
      });
      setSubmitted(true);
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: { message?: string } } } };
      const msg = error.response?.data?.error?.message || '提交失败，请重试';
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background px-5 flex items-center justify-center">
        <EmptyState title="问卷不存在" description="请检查链接是否正确" />
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="w-24 h-24 rounded-full bg-primary-gradient flex items-center justify-center shadow-lg shadow-primary/30 mb-6">
          <Check size={40} className="text-primary-foreground" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-2 font-serif">
          提交成功
        </h1>
        <p className="text-muted-foreground text-center mb-2">
          感谢您的填写
        </p>
        <p className="text-sm text-muted-foreground text-center max-w-[280px]">
          您的信息已安全送达，主持人会尽快为您定制专属婚礼方案
        </p>
        <div className="mt-8">
          <Heart size={32} className="text-primary/40" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* 顶部品牌区 */}
      <div
        className="px-5 pt-10 pb-8 text-center text-primary-foreground"
        style={{ background: 'linear-gradient(135deg, #2C0A14 0%, #5C1525 50%, #8B1530 100%)' }}
      >
        <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center">
          <Heart size={28} fill="currentColor" className="text-accent-gold" />
        </div>
        <h1 className="text-xl font-bold font-serif tracking-tight mb-1">
          {data.title}
        </h1>
        <p className="text-sm text-white/60">
          请如实填写，帮助我们为您定制完美婚礼
        </p>
      </div>

      {/* 表单区 */}
      <div className="px-5 -mt-4 pb-24">
        <div className="bg-card rounded-2xl shadow-lg p-5 space-y-5">
          {/* 提交人姓名（可选） */}
          <Input
            label="您的称呼（选填）"
            placeholder="例如：张先生 / 李小姐"
            value={submitterName}
            onChange={(e) => setSubmitterName(e.target.value)}
          />

          <div className="h-px bg-border/60 -mx-5" />

          {data.fields.map((field: QuestionnaireField) => {
            const error = errors[field.fieldKey];

            return (
              <div key={field.id}>
                {field.fieldType === 'textarea' ? (
                  <TextArea
                    label={`${field.label}${field.required ? ' *' : ''}`}
                    placeholder={field.placeholder || '请填写...'}
                    value={formData[field.fieldKey] || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, [field.fieldKey]: e.target.value }))}
                    rows={4}
                    error={error}
                  />
                ) : (
                  <Input
                    label={`${field.label}${field.required ? ' *' : ''}`}
                    type={field.fieldType === 'tel' ? 'tel' : field.fieldType === 'date' ? 'date' : 'text'}
                    placeholder={field.placeholder || '请填写...'}
                    value={formData[field.fieldKey] || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, [field.fieldKey]: e.target.value }))}
                    error={error}
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* 底部提交按钮 */}
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-card/80 backdrop-blur-md border-t border-border/60 px-5 py-4">
          <Button fullWidth size="lg" onClick={handleSubmit} loading={submitting}>
            {submitting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                提交中...
              </>
            ) : (
              <>
                <Heart size={18} fill="currentColor" />
                提交问卷
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuestionnaireFillPage;
