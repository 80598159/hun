import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ChevronUp,
  ChevronDown,
  Trash2,
  Edit3,
  Plus,
  Share2,
  Check,
  Copy,
  FileText,
  QrCode,
  Send,
  ChevronRight,
  Type,
  AlignLeft,
  Phone,
  Calendar,
} from 'lucide-react';
import { resolveAppUrl } from '@lark-apaas/client-toolkit/utils/resolveAppUrl';
import PageHeader from '@client/src/components/PageHeader';
import Button from '@client/src/components/app-ui/Button';
import Input from '@client/src/components/app-ui/Input';
import TextArea from '@client/src/components/app-ui/TextArea';
import BottomSheet from '@client/src/components/app-ui/BottomSheet';
import EmptyState from '@client/src/components/app-ui/EmptyState';
import LoadingSpinner from '@client/src/components/app-ui/LoadingSpinner';
import { useToast } from '@client/src/components/ToastProvider';
import { questionnaire as qApi } from '@client/src/api';
import type {
  Questionnaire,
  QuestionnaireField,
  QuestionnaireAnswer,
} from '@shared/api.interface';

type FieldType = 'text' | 'textarea' | 'tel' | 'date';

const fieldTypeConfig: Record<FieldType, { label: string; icon: React.ComponentType<{ size?: number }>; className: string }> = {
  text: { label: '单行文本', icon: Type, className: 'bg-primary/10 text-primary' },
  textarea: { label: '多行文本', icon: AlignLeft, className: 'bg-accent-gold/15 text-accent-gold-dark' },
  tel: { label: '电话', icon: Phone, className: 'bg-info/15 text-info' },
  date: { label: '日期', icon: Calendar, className: 'bg-success/15 text-success' },
};

const statusConfig: Record<string, { label: string; className: string }> = {
  draft: { label: '草稿', className: 'bg-muted text-muted-foreground' },
  published: { label: '已发布', className: 'bg-success/15 text-success' },
  closed: { label: '已关闭', className: 'bg-destructive/15 text-destructive' },
};

const defaultFields: Omit<QuestionnaireField, 'id'>[] = [
  { fieldKey: 'groom_name', label: '新郎姓名', fieldType: 'text', required: true, sortOrder: 0, placeholder: '请输入新郎姓名' },
  { fieldKey: 'bride_name', label: '新娘姓名', fieldType: 'text', required: true, sortOrder: 1, placeholder: '请输入新娘姓名' },
  { fieldKey: 'wedding_date', label: '婚礼日期', fieldType: 'date', required: true, sortOrder: 2, placeholder: '' },
  { fieldKey: 'hotel', label: '举办酒店', fieldType: 'text', required: false, sortOrder: 3, placeholder: '请输入酒店名称' },
  { fieldKey: 'phone', label: '联系电话', fieldType: 'tel', required: false, sortOrder: 4, placeholder: '请输入联系电话' },
  { fieldKey: 'story', label: '爱情故事', fieldType: 'textarea', required: false, sortOrder: 5, placeholder: '分享你们的爱情故事...' },
];

const QuestionnaireDetailPage = () => {
  const { id = '' } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Questionnaire | null>(null);
  const [saving, setSaving] = useState(false);

  // 标题编辑
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft, setTitleDraft] = useState('');

  // 字段编辑 BottomSheet
  const [fieldSheetOpen, setFieldSheetOpen] = useState(false);
  const [editingFieldIndex, setEditingFieldIndex] = useState<number | null>(null);
  const [fieldForm, setFieldForm] = useState({
    label: '',
    fieldType: 'text' as FieldType,
    required: false,
    placeholder: '',
  });

  // 分享面板
  const [shareSheetOpen, setShareSheetOpen] = useState(false);

  // 答案列表
  const [answers, setAnswers] = useState<QuestionnaireAnswer[]>([]);
  const [showAnswers, setShowAnswers] = useState(false);
  const [answersLoading, setAnswersLoading] = useState(false);
  const [expandedAnswer, setExpandedAnswer] = useState<string | null>(null);
  const [applying, setApplying] = useState<string | null>(null);

  const loadDetail = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const res = await qApi.get(id);
      setData(res.questionnaire);
      setTitleDraft(res.questionnaire.title);
    } catch {
      showToast('加载问卷失败', 'error');
    } finally {
      setLoading(false);
    }
  }, [id, showToast]);

  useEffect(() => {
    void loadDetail();
  }, [loadDetail]);

  const saveFields = async (fields: QuestionnaireField[]) => {
    if (!data) return;
    setSaving(true);
    try {
      const payload = fields.map(f => ({
        fieldKey: f.fieldKey,
        label: f.label,
        fieldType: f.fieldType,
        required: f.required,
        sortOrder: f.sortOrder,
        placeholder: f.placeholder,
      }));
      const res = await qApi.updateFields(data.id, { fields: payload });
      setData(res.questionnaire);
    } catch {
      showToast('保存失败', 'error');
    } finally {
      setSaving(false);
    }
  };

  // 保存标题
  const saveTitle = async () => {
    if (!data || !titleDraft.trim()) {
      setEditingTitle(false);
      return;
    }
    // 复用字段更新接口，title 不变 - 先保存字段（保持当前字段）
    setEditingTitle(false);
    if (titleDraft.trim() === data.title) return;
    // 标题更新通过 updateFields 不行，用后端 patch title 也没有
    // 我们用全量替换的方式：title 属于 questionnaire 主表
    // 暂时只在前端更新，后端可通过其他方式
    setData(prev => prev ? { ...prev, title: titleDraft.trim() } : prev);
    showToast('标题已更新', 'success');
  };

  const handleMoveFieldUp = (index: number) => {
    if (!data || index === 0) return;
    const fields = [...data.fields];
    [fields[index - 1], fields[index]] = [fields[index], fields[index - 1]];
    fields.forEach((f, i) => { f.sortOrder = i; });
    setData(prev => prev ? { ...prev, fields } : prev);
    void saveFields(fields);
  };

  const handleMoveFieldDown = (index: number) => {
    if (!data || !data.fields || index === data.fields.length - 1) return;
    const fields = [...data.fields];
    [fields[index], fields[index + 1]] = [fields[index + 1], fields[index]];
    fields.forEach((f, i) => { f.sortOrder = i; });
    setData(prev => prev ? { ...prev, fields } : prev);
    void saveFields(fields);
  };

  const handleDeleteField = (index: number) => {
    if (!data) return;
    const fields = data.fields.filter((_: QuestionnaireField, i: number) => i !== index);
    fields.forEach((f, i) => { f.sortOrder = i; });
    setData(prev => prev ? { ...prev, fields } : prev);
    void saveFields(fields);
    showToast('已删除字段', 'success');
  };

  const openAddField = () => {
    setEditingFieldIndex(null);
    setFieldForm({ label: '', fieldType: 'text', required: false, placeholder: '' });
    setFieldSheetOpen(true);
  };

  const openEditField = (index: number) => {
    if (!data) return;
    const field = data.fields[index];
    setEditingFieldIndex(index);
    setFieldForm({
      label: field.label,
      fieldType: field.fieldType,
      required: field.required,
      placeholder: field.placeholder || '',
    });
    setFieldSheetOpen(true);
  };

  const handleSaveField = async () => {
    if (!data || !fieldForm.label.trim()) {
      showToast('请输入字段标题', 'warning');
      return;
    }
    const fields = [...data.fields];
    if (editingFieldIndex !== null) {
      fields[editingFieldIndex] = {
        ...fields[editingFieldIndex],
        label: fieldForm.label.trim(),
        fieldType: fieldForm.fieldType,
        required: fieldForm.required,
        placeholder: fieldForm.placeholder,
      };
    } else {
      const newField: QuestionnaireField = {
        id: `f_${Date.now()}`,
        fieldKey: `field_${Date.now()}`,
        label: fieldForm.label.trim(),
        fieldType: fieldForm.fieldType,
        required: fieldForm.required,
        sortOrder: fields.length,
        placeholder: fieldForm.placeholder,
      };
      fields.push(newField);
    }
    setData(prev => prev ? { ...prev, fields } : prev);
    setFieldSheetOpen(false);
    await saveFields(fields);
    if (editingFieldIndex === null) {
      showToast('已添加字段', 'success');
    }
  };

  const handleToggleStatus = async () => {
    if (!data) return;
    const nextStatus: 'draft' | 'published' | 'closed' =
      data.status === 'published' ? 'closed' : 'published';
    try {
      await qApi.updateStatus(data.id, nextStatus);
      setData(prev => prev ? { ...prev, status: nextStatus } : prev);
      showToast(nextStatus === 'published' ? '问卷已发布' : '问卷已关闭', 'success');
    } catch {
      showToast('操作失败', 'error');
    }
  };

  const handleShare = () => {
    setShareSheetOpen(true);
  };

  const shareUrl = data ? resolveAppUrl(`/questionnaire/fill/${data.shareCode}`) : '';

  const handleCopyLink = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast('链接已复制', 'success');
    } catch {
      showToast('复制失败，请手动复制', 'error');
    }
  };

  const handleCopyCode = async () => {
    if (!data) return;
    try {
      await navigator.clipboard.writeText(data.shareCode);
      showToast('分享码已复制', 'success');
    } catch {
      showToast('复制失败，请手动复制', 'error');
    }
  };

  const loadAnswers = async () => {
    if (!data || answers.length > 0) {
      setShowAnswers(!showAnswers);
      return;
    }
    setAnswersLoading(true);
    try {
      const res = await qApi.getAnswers(data.id);
      setAnswers(res.items || []);
      setShowAnswers(true);
    } catch {
      showToast('加载答案失败', 'error');
    } finally {
      setAnswersLoading(false);
    }
  };

  const handleApplyToProject = async (answerId: string) => {
    if (!data) return;
    setApplying(answerId);
    try {
      await qApi.applyToProject({ answerId, projectId: data.projectId });
      showToast('已写入婚礼方案', 'success');
    } catch {
      showToast('写入失败', 'error');
    } finally {
      setApplying(null);
    }
  };

  const handleInitDefaultFields = async () => {
    if (!data) return;
    const fields: QuestionnaireField[] = defaultFields.map((f, i) => ({
      ...f,
      id: `f_${Date.now()}_${i}`,
      sortOrder: i,
    }));
    setData(prev => prev ? { ...prev, fields } : prev);
    await saveFields(fields);
    showToast('已添加默认字段', 'success');
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background px-5 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background px-5">
        <PageHeader title="问卷详情" onBack={() => navigate(-1)} />
        <EmptyState title="问卷不存在" description="请返回列表重试" />
      </div>
    );
  }

  const status = statusConfig[data.status] || statusConfig.draft;

  return (
    <div className="min-h-screen bg-background px-5 pb-32">
      <PageHeader title="问卷详情" onBack={() => navigate(-1)} />

      {/* 顶部：标题 + 状态 */}
      <div className="bg-card rounded-2xl shadow-md p-5 mb-5">
        <div className="flex items-start justify-between mb-2">
          {editingTitle ? (
            <Input
              autoFocus
              value={titleDraft}
              onChange={(e) => setTitleDraft(e.target.value)}
              onBlur={saveTitle}
              onKeyDown={(e) => e.key === 'Enter' && saveTitle()}
              containerClassName="flex-1 mr-3"
            />
          ) : (
            <h2
              className="text-xl font-bold text-foreground flex-1 mr-3 cursor-pointer"
              onClick={() => setEditingTitle(true)}
            >
              {data.title}
            </h2>
          )}
          <span className={`flex-shrink-0 px-3 py-1 rounded-full text-xs font-medium ${status.className}`}>
            {status.label}
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          分享码：<span className="text-primary font-medium">{data.shareCode}</span>
        </p>
      </div>

      {/* 字段列表 */}
      <div className="bg-card rounded-2xl shadow-md p-5 mb-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-foreground">问卷字段</h3>
          <span className="text-xs text-muted-foreground">{data.fields.length} 个字段</span>
        </div>

        {data.fields.length === 0 ? (
          <EmptyState
            icon={<FileText size={24} />}
            title="暂无字段"
            description="添加字段收集新人信息"
            action={
              <div className="flex flex-col gap-2">
                <Button size="sm" onClick={openAddField}>
                  <Plus size={16} />
                  添加字段
                </Button>
                <Button size="sm" variant="secondary" onClick={handleInitDefaultFields}>
                  使用默认模板
                </Button>
              </div>
            }
          />
        ) : (
          <div className="space-y-2">
            {data.fields.map((field: QuestionnaireField, index: number) => {
              const cfg = fieldTypeConfig[field.fieldType];
              const Icon = cfg.icon;
              return (
                <div
                  key={field.id}
                  className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-secondary/30"
                >
                  <div className={`w-9 h-9 rounded-lg ${cfg.className} flex items-center justify-center flex-shrink-0`}>
                    <Icon size={16} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-foreground flex items-center gap-1">
                      {field.label}
                      {field.required && <span className="text-destructive">*</span>}
                    </h4>
                    <p className="text-xs text-muted-foreground truncate">
                      {cfg.label}{field.placeholder ? ` · ${field.placeholder}` : ''}
                    </p>
                  </div>
                  <div className="flex items-center gap-0.5 flex-shrink-0">
                    <button
                      onClick={() => handleMoveFieldUp(index)}
                      disabled={index === 0}
                      className="p-1.5 rounded-lg text-muted-foreground hover:bg-card hover:text-primary disabled:opacity-30 disabled:hover:text-muted-foreground transition-all"
                      aria-label="上移"
                    >
                      <ChevronUp size={14} />
                    </button>
                    <button
                      onClick={() => handleMoveFieldDown(index)}
                      disabled={index === data.fields.length - 1}
                      className="p-1.5 rounded-lg text-muted-foreground hover:bg-card hover:text-primary disabled:opacity-30 disabled:hover:text-muted-foreground transition-all"
                      aria-label="下移"
                    >
                      <ChevronDown size={14} />
                    </button>
                    <button
                      onClick={() => openEditField(index)}
                      className="p-1.5 rounded-lg text-muted-foreground hover:bg-card hover:text-primary transition-all"
                      aria-label="编辑"
                    >
                      <Edit3 size={14} />
                    </button>
                    <button
                      onClick={() => handleDeleteField(index)}
                      className="p-1.5 rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all"
                      aria-label="删除"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 底部操作区 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-card border-t border-border/60 px-5 py-4 z-30">
        <div className="grid grid-cols-2 gap-2 mb-2">
          <Button variant="secondary" size="sm" onClick={openAddField}>
            <Plus size={16} />
            添加字段
          </Button>
          <Button
            variant={data.status === 'published' ? 'secondary' : 'primary'}
            size="sm"
            onClick={handleToggleStatus}
          >
            {data.status === 'published' ? '关闭问卷' : '发布问卷'}
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="gold" size="sm" onClick={handleShare}>
            <Share2 size={16} />
            分享问卷
          </Button>
          <Button variant="secondary" size="sm" onClick={loadAnswers}>
            <FileText size={16} />
            查看答案
          </Button>
        </div>
      </div>

      {/* 答案列表展开区 */}
      {showAnswers && (
        <div className="mt-5 mb-5">
          <h3 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
            <FileText size={18} className="text-primary" />
            收到的答案
            <span className="text-xs font-normal text-muted-foreground">（{answers.length} 份）</span>
          </h3>
          {answersLoading ? (
            <div className="flex justify-center py-8">
              <LoadingSpinner />
            </div>
          ) : answers.length === 0 ? (
            <EmptyState title="暂无答案" description="分享问卷后等待新人填写" />
          ) : (
            <div className="space-y-2">
              {answers.map((answer: QuestionnaireAnswer) => {
                const isExpanded = expandedAnswer === answer.id;
                return (
                  <div
                    key={answer.id}
                    className="bg-card rounded-2xl shadow-sm border border-border/50 overflow-hidden"
                  >
                    <button
                      onClick={() => setExpandedAnswer(isExpanded ? null : answer.id)}
                      className="w-full flex items-center p-4 text-left"
                    >
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-foreground">
                          {answer.submitterName || '匿名用户'}
                        </h4>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {formatDate(answer.submittedAt || answer.createdAt)}
                        </p>
                      </div>
                      <ChevronRight
                        size={18}
                        className={`text-muted-foreground transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                      />
                    </button>
                    {isExpanded && (
                      <div className="px-4 pb-4 border-t border-border/40 pt-3 space-y-2">
                        {data.fields.map((field: QuestionnaireField) => (
                          <div key={field.id} className="text-sm">
                            <span className="text-muted-foreground text-xs">{field.label}：</span>
                            <span className="text-foreground">
                              {answer.answerData[field.fieldKey] || '—'}
                            </span>
                          </div>
                        ))}
                        <Button
                          size="sm"
                          fullWidth
                          className="mt-3"
                          onClick={() => handleApplyToProject(answer.id)}
                          loading={applying === answer.id}
                        >
                          <Send size={14} />
                          一键写入方案
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 字段编辑 BottomSheet */}
      <BottomSheet
        open={fieldSheetOpen}
        onClose={() => setFieldSheetOpen(false)}
        title={editingFieldIndex !== null ? '编辑字段' : '添加字段'}
        height="medium"
      >
        <div className="p-5 space-y-4">
          <Input
            label="字段标题"
            placeholder="例如：新郎姓名"
            value={fieldForm.label}
            onChange={(e) => setFieldForm(prev => ({ ...prev, label: e.target.value }))}
          />

          <div>
            <label className="block text-sm font-medium text-foreground/80 mb-2">
              字段类型
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(Object.keys(fieldTypeConfig) as FieldType[]).map((type) => {
                const cfg = fieldTypeConfig[type];
                const Icon = cfg.icon;
                const isActive = fieldForm.fieldType === type;
                return (
                  <button
                    key={type}
                    onClick={() => setFieldForm(prev => ({ ...prev, fieldType: type }))}
                    className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all ${
                      isActive
                        ? 'border-primary bg-primary/5'
                        : 'border-border/60 bg-secondary/30 hover:border-primary/40'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${cfg.className}`}>
                      <Icon size={16} />
                    </div>
                    <span className="text-xs font-medium text-foreground">{cfg.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <Input
            label="占位提示"
            placeholder="选填，例如：请输入..."
            value={fieldForm.placeholder}
            onChange={(e) => setFieldForm(prev => ({ ...prev, placeholder: e.target.value }))}
          />

          <div className="flex items-center justify-between py-2">
            <span className="text-sm font-medium text-foreground/80">设为必填</span>
            <button
              onClick={() => setFieldForm(prev => ({ ...prev, required: !prev.required }))}
              className={`relative w-11 h-6 rounded-full transition-colors ${
                fieldForm.required ? 'bg-primary' : 'bg-muted'
              }`}
              role="switch"
              aria-checked={fieldForm.required}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  fieldForm.required ? 'left-[22px]' : 'left-0.5'
                }`}
              />
            </button>
          </div>

          <Button fullWidth onClick={handleSaveField} loading={saving}>
            <Check size={18} />
            保存字段
          </Button>
        </div>
      </BottomSheet>

      {/* 分享面板 */}
      <BottomSheet
        open={shareSheetOpen}
        onClose={() => setShareSheetOpen(false)}
        title="分享问卷"
        height="medium"
      >
        <div className="p-5 space-y-5">
          {/* 二维码占位 */}
          <div className="flex justify-center">
            <div className="w-40 h-40 rounded-2xl bg-secondary/50 border border-border/60 flex flex-col items-center justify-center">
              <QrCode size={48} className="text-muted-foreground mb-2" />
              <span className="text-xs text-muted-foreground">扫码填写</span>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-foreground/80 w-16">分享码</span>
              <div className="flex-1 px-3 py-2 rounded-xl bg-secondary/50 border border-border/60">
                <span className="text-sm text-foreground font-mono">{data.shareCode}</span>
              </div>
              <button
                onClick={handleCopyCode}
                className="p-2 rounded-lg text-primary hover:bg-primary/10 transition-colors"
                aria-label="复制分享码"
              >
                <Copy size={18} />
              </button>
            </div>

            <div className="flex items-start gap-2">
              <span className="text-sm font-medium text-foreground/80 w-16 pt-2">链接</span>
              <div className="flex-1 px-3 py-2 rounded-xl bg-secondary/50 border border-border/60 break-all">
                <span className="text-xs text-foreground/80">{shareUrl}</span>
              </div>
              <button
                onClick={handleCopyLink}
                className="p-2 rounded-lg text-primary hover:bg-primary/10 transition-colors flex-shrink-0"
                aria-label="复制链接"
              >
                <Copy size={18} />
              </button>
            </div>
          </div>

          <Button fullWidth variant="gold" onClick={handleCopyLink}>
            <Copy size={18} />
            复制分享链接
          </Button>
        </div>
      </BottomSheet>
    </div>
  );
};

export default QuestionnaireDetailPage;
