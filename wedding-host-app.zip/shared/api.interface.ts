// 婚礼项目
export interface WeddingProject {
  id: string;
  title: string;
  groomName: string;
  brideName: string;
  weddingDate: string | null;
  timeType: 'lunch' | 'dinner';
  hotelName: string;
  planner: string;
  supervisor: string;
  videographer: string;
  photographer: string;
  soundController: string;
  specialNotes: string;
  status: string;
  isArchived: boolean;
  posterTemplate: string;
  scheduleId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface WeddingStep {
  id: string;
  projectId: string;
  stepName: string;
  duration: number;
  bgmSuggest: string;
  hostTip: string;
  sortOrder: number;
  isCustom: boolean;
}

export interface WeddingCollaborator {
  id: string;
  projectId: string;
  userId: string;
  role: 'owner' | 'collaborator';
  invitedBy: string;
  joinedAt: string;
}

export interface WeddingShareLink {
  id: string;
  projectId: string;
  shareCode: string;
  createdBy: string;
  expiresAt: string | null;
  isActive: boolean;
  joinCount: number;
  createdAt: string;
}

export interface ProjectAccessInfo {
  role: 'owner' | 'collaborator' | 'none';
  collaborators: WeddingCollaborator[];
}

export interface CreateProjectRequest {
  title?: string;
  groomName?: string;
  brideName?: string;
  weddingDate?: string | null;
  timeType?: 'lunch' | 'dinner';
  hotelName?: string;
  autoLinkSchedule?: boolean;
}

export interface UpdateProjectRequest {
  title?: string;
  groomName?: string;
  brideName?: string;
  weddingDate?: string | null;
  timeType?: 'lunch' | 'dinner';
  hotelName?: string;
  planner?: string;
  supervisor?: string;
  videographer?: string;
  photographer?: string;
  soundController?: string;
  specialNotes?: string;
  isArchived?: boolean;
  posterTemplate?: string;
  autoLinkSchedule?: boolean;
}

export interface ProjectScheduleLinkResult {
  project: WeddingProject;
  scheduleId: string | null;
  linkAction: 'created' | 'linked' | 'conflict' | 'skipped' | 'unlinked';
  message: string;
  conflictSchedule?: Schedule;
}

export interface ProjectListResponse {
  items: WeddingProject[];
  total: number;
}

export interface AddStepRequest {
  stepName: string;
  duration?: number;
  bgmSuggest?: string;
  hostTip?: string;
  isCustom?: boolean;
}

export interface UpdateStepRequest {
  stepName?: string;
  duration?: number;
  bgmSuggest?: string;
  hostTip?: string;
  sortOrder?: number;
}

export interface ReorderStepRequest {
  stepId: string;
  targetIndex: number;
}

// 台词
export interface Script {
  id: string;
  category: string;
  title: string;
  content: string;
  isSystem: boolean;
  isFavorite: boolean;
  styleTags: string;
}

export interface ScriptListResponse {
  items: Script[];
  total: number;
}

export interface CreateScriptRequest {
  category: string;
  title: string;
  content: string;
  styleTags?: string;
}

export interface UpdateScriptRequest {
  title?: string;
  content?: string;
  category?: string;
  isFavorite?: boolean;
  styleTags?: string;
}

// 档期
export interface Schedule {
  id: string;
  weddingDate: string;
  timeType: 'lunch' | 'dinner';
  hotelName: string;
  coupleName: string;
  notes: string;
  projectId: string | null;
  source: 'manual' | 'auto_from_project';
}

export interface CreateScheduleRequest {
  weddingDate: string;
  timeType?: 'lunch' | 'dinner';
  hotelName?: string;
  coupleName?: string;
  notes?: string;
  projectId?: string;
}

export interface ScheduleConflictResponse {
  hasConflict: boolean;
  conflictSchedules: Schedule[];
}

// AI 额度
export interface AiQuota {
  flowGenerateCount: number;
  scriptGenerateCount: number;
  monthlyFlowQuota: number;
  monthlyScriptQuota: number;
  totalFlowQuota: number;
  totalScriptQuota: number;
  remainingFlow: number;
  remainingScript: number;
  resetDate: string;
}

// AI 婚礼流程生成
export interface AiFlowGenerateRequest {
  description: string;
}

export interface AiFlowGenerateResponse {
  weddingInfo: {
    timeType: string;
    totalMinutes: number;
    specialTip: string;
  };
  flowList: {
    stepName: string;
    duration: number;
    bgmSuggest: string;
    hostTip: string;
  }[];
}

// AI 台词生成
export interface AiScriptGenerateRequest {
  speechType: string;
  speechStyle: string;
  keyInformation?: string;
  lengthRequirement?: string;
  operationType: string;
  originalContent?: string;
  additionalRequirements?: string;
}

export interface AiScriptGenerateResponse {
  title: string;
  content: string;
  category: string;
  aiDisclaimer: string;
}

// AI 需求解析
export interface AiRequirementParseRequest {
  text: string;
}

export interface AiRequirementParseResponse {
  groomName: string;
  brideName: string;
  weddingDate: string;
  timeType: string;
  hotelName: string;
  style: string;
  specialRequirements: string;
  parentsOnStage: boolean;
  tabooLinks: string[];
}

// AI 风险检测
export interface AiRiskDetectRequest {
  flowList: {
    stepName: string;
    duration: number;
    hostTip: string;
  }[];
  weddingInfo: {
    timeType: string;
    totalMinutes: number;
  };
}

export interface AiRiskDetectResponse {
  risks: {
    level: string;
    content: string;
    suggestion: string;
  }[];
}

// 订单
export interface Order {
  id: string;
  productType: string;
  productName: string;
  amount: number;
  status: string;
  flowQuota: number;
  scriptQuota: number;
  paidAt: string | null;
  createdAt: string;
}

export interface CreateOrderRequest {
  productType: string;
  productName: string;
  amount: number;
  flowQuota: number;
  scriptQuota: number;
}

// 商店商品
export interface ShopProduct {
  id: string;
  type: string;
  name: string;
  description: string;
  price: number;
  originalPrice: number | null;
  flowQuota: number;
  scriptQuota: number;
  posterTemplate: string | null;
}

export interface ShopProductsResponse {
  items: ShopProduct[];
}

// 商圈商家
export interface MallMerchant {
  id: string;
  name: string;
  category: string;
  logoUrl: string | null;
  coverUrl: string | null;
  address: string;
  description: string;
  rating: number;
  isAd: boolean;
}

export interface MallMerchantsResponse {
  items: MallMerchant[];
}

// 用户资料
export interface UserProfileData {
  nickname: string;
  avatarUrl: string;
  phone: string;
  city: string;
  experienceYears: number;
  bio: string;
  styleTags: string;
  posterPhotoUrl: string;
}

export interface UpdatePosterPhotoRequest {
  posterPhotoUrl: string;
  projectId?: string;
}

export interface UpdatePosterPhotoResponse {
  success: boolean;
  posterPhotoUrl: string;
  remainingUpdates: number;
  totalLimit: number;
  message?: string;
}

// 应用登录（账号密码）
export interface AppLoginRequest {
  username: string;
  password: string;
}

export interface AppLoginResponse {
  token: string;
  userId: string;
  nickname: string;
  avatarUrl: string;
  isAdmin: boolean;
  expiresAt: string;
}

export interface AppRegisterRequest {
  username: string;
  password: string;
  nickname?: string;
}

export interface ChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}

// 预设环节库
export interface PresetStep {
  stepName: string;
  duration: number;
  bgmSuggest: string;
  hostTip: string;
  category: string;
}

// 台词分类
export interface ScriptCategory {
  key: string;
  name: string;
  icon: string;
}

// ===================== 后台管理 =====================

// 管理员登录
export interface AdminLoginRequest {
  username: string;
  password: string;
}

export interface AdminLoginResponse {
  token: string;
  username: string;
  expiresAt: string;
}

// 数据看板
export interface AdminDashboardStats {
  totalUsers: number;
  activeHosts: number;
  totalProjects: number;
  totalAiCalls: number;
  totalRevenue: number;
  totalOrders: number;
  materialSales: number;
  merchantCount: number;
  pendingMerchants: number;
  pendingAudits: number;
}

export interface AdminTrendPoint {
  date: string;
  value: number;
}

export interface AdminDashboardResponse {
  stats: AdminDashboardStats;
  userTrend: AdminTrendPoint[];
  aiTrend: AdminTrendPoint[];
  revenueTrend: AdminTrendPoint[];
  recentOrders: AdminOrderItem[];
}

// 用户管理
export interface AdminUserItem {
  userId: string;
  nickname: string;
  avatarUrl: string;
  phone: string;
  city: string;
  experienceYears: number;
  status: string;
  isAdmin: boolean;
  createdAt: string;
  remainingFlow: number;
  remainingScript: number;
  monthlyFlowQuota: number;
  monthlyScriptQuota: number;
  totalFlowQuota: number;
  totalScriptQuota: number;
  projectCount: number;
}

export interface AdminUserListResponse {
  items: AdminUserItem[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AdminUpdateUserRequest {
  status?: 'active' | 'disabled';
  isAdmin?: boolean;
  nickname?: string;
  avatarUrl?: string;
  city?: string;
  phone?: string;
  experienceYears?: number;
  bio?: string;
  styleTags?: string;
  remark?: string;
}

export interface AdminCreateUserRequest {
  username: string;
  password: string;
  nickname: string;
  remark?: string;
}

export interface AdminResetPasswordRequest {
  password: string;
}

export interface AdminAdjustQuotaRequest {
  monthlyFlowQuota?: number;
  monthlyScriptQuota?: number;
  totalFlowQuota?: number;
  totalScriptQuota?: number;
}

// 婚礼方案管理
export interface AdminProjectItem extends WeddingProject {
  userNickname: string;
  stepCount: number;
  posterPhotoUpdateCount: number;
}

export interface AdminProjectListResponse {
  items: AdminProjectItem[];
  total: number;
  page: number;
  pageSize: number;
}

// 系统配置
export interface SystemConfigItem {
  id: string;
  configKey: string;
  configValue: string;
  configType: 'string' | 'number' | 'boolean';
  description: string;
  updatedAt: string;
}

export interface SystemConfigListResponse {
  items: SystemConfigItem[];
}

export interface SystemConfigUpdateRequest {
  configValue: string;
  description?: string;
}

// 台词库管理
export interface AdminScriptItem extends Script {
  userNickname: string;
  createdAt: string;
}

export interface AdminScriptListResponse {
  items: AdminScriptItem[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AdminCreateScriptRequest {
  category: string;
  title: string;
  content: string;
  styleTags?: string;
}

export interface AdminUpdateScriptRequest {
  category?: string;
  title?: string;
  content?: string;
  styleTags?: string;
}

// 素材商店管理
export interface AdminProduct {
  id: string;
  type: string;
  name: string;
  description: string;
  price: number;
  originalPrice: number | null;
  flowQuota: number;
  scriptQuota: number;
  posterTemplate: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  salesCount: number;
}

export interface AdminProductListResponse {
  items: AdminProduct[];
  total: number;
}

export interface AdminCreateProductRequest {
  type: string;
  name: string;
  description?: string;
  price: number;
  originalPrice?: number;
  flowQuota?: number;
  scriptQuota?: number;
  posterTemplate?: string;
  sortOrder?: number;
}

export interface AdminUpdateProductRequest {
  type?: string;
  name?: string;
  description?: string;
  price?: number;
  originalPrice?: number;
  flowQuota?: number;
  scriptQuota?: number;
  posterTemplate?: string;
  isActive?: boolean;
  sortOrder?: number;
}

// 订单管理
export interface AdminOrderItem {
  id: string;
  userId: string;
  userNickname: string;
  productType: string;
  productName: string;
  amount: number;
  status: string;
  paidAt: string | null;
  createdAt: string;
}

export interface AdminOrderSummary {
  totalAmount: number;
  paidAmount: number;
  refundAmount: number;
  paidCount: number;
}

export interface AdminOrderListResponse {
  items: AdminOrderItem[];
  total: number;
  page: number;
  pageSize: number;
  summary: AdminOrderSummary;
}

export interface AdminUpdateOrderStatusRequest {
  status: 'pending' | 'paid' | 'refunded' | 'cancelled';
}

// 商圈商家管理
export interface AdminMerchant {
  id: string;
  name: string;
  category: string;
  logoUrl: string;
  coverUrl: string;
  contactPerson: string;
  contactPhone: string;
  address: string;
  description: string;
  rating: number;
  isApproved: boolean;
  isActive: boolean;
  sortOrder: number;
  isAd: boolean;
  createdAt: string;
}

export interface AdminMerchantListResponse {
  items: AdminMerchant[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AdminCreateMerchantRequest {
  name: string;
  category: string;
  contactPerson?: string;
  contactPhone?: string;
  address?: string;
  description?: string;
  coverUrl?: string;
  rating?: number;
  sortOrder?: number;
  isAd?: boolean;
}

export interface AdminUpdateMerchantRequest {
  name?: string;
  category?: string;
  contactPerson?: string;
  contactPhone?: string;
  address?: string;
  description?: string;
  coverUrl?: string;
  rating?: number;
  isApproved?: boolean;
  isActive?: boolean;
  sortOrder?: number;
  isAd?: boolean;
}

// 内容安全 / 合规
export interface AdminAuditItem {
  id: string;
  userId: string;
  userNickname: string;
  contentType: string;
  content: string;
  riskLevel: string;
  status: string;
  flaggedWords: string;
  aiGenerated: boolean;
  remark: string;
  createdAt: string;
}

export interface AdminAuditListResponse {
  items: AdminAuditItem[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AdminUpdateAuditRequest {
  status?: 'pending' | 'approved' | 'rejected';
  riskLevel?: 'low' | 'medium' | 'high';
  remark?: string;
}

// BGM音乐库 & 歌单
export type BgmCategory = 'prelude' | 'entrance' | 'vows' | 'rings' | 'tea' | 'speech' | 'exit' | 'climax' | 'other';
export type BgmPurposeTag = 'warmup' | 'entrance' | 'climax' | 'exit' | 'other';

export interface BgmSong {
  id: string;
  title: string;
  artist: string;
  category: BgmCategory;
  mood: string;
  isSystem: boolean;
}

export interface BgmLibraryListResponse {
  items: BgmSong[];
  total: number;
  categories: { key: BgmCategory; label: string }[];
}

export interface BgmPlaylist {
  id: string;
  name: string;
  description: string;
  projectId: string | null;
  songCount: number;
  createdAt: string;
}

export interface BgmPlaylistItem {
  id: string;
  songId: string | null;
  title: string;
  artist: string;
  purposeTag: BgmPurposeTag | null;
  segment: string;
  sortOrder: number;
  note: string;
}

export interface BgmPlaylistDetail {
  id: string;
  name: string;
  description: string;
  projectId: string | null;
  items: BgmPlaylistItem[];
}

export interface CreatePlaylistRequest {
  name: string;
  description?: string;
  projectId?: string;
}

export interface UpdatePlaylistRequest {
  name?: string;
  description?: string;
}

export interface AddPlaylistSongsRequest {
  songs: { songId?: string; title: string; artist?: string; purposeTag?: BgmPurposeTag; segment?: string }[];
}

export interface UpdatePlaylistItemRequest {
  title?: string;
  artist?: string;
  purposeTag?: BgmPurposeTag;
  segment?: string;
  note?: string;
  sortOrder?: number;
}

export interface ImportPlaylistRequest {
  playlistId: string;
  text: string;
  defaultPurposeTag?: BgmPurposeTag;
  defaultSegment?: string;
}

export interface ExportPlaylistResponse {
  text: string;
  title: string;
}

// 报价单
export interface QuotationItem {
  id: string;
  name: string;
  unitPrice: string;
  quantity: number;
  unit: string;
}

export interface Quotation {
  id: string;
  title: string;
  clientName: string;
  weddingDate: string | null;
  hotelName: string;
  items: QuotationItem[];
  deposit: string;
  finalPayment: string;
  total: string;
  remark: string;
  isTemplate: boolean;
  createdAt: string;
}

export interface QuotationListResponse {
  items: Quotation[];
  total: number;
}

export interface CreateQuotationRequest {
  title?: string;
  clientName?: string;
  weddingDate?: string | null;
  hotelName?: string;
  items?: QuotationItem[];
  deposit?: string;
  finalPayment?: string;
  remark?: string;
  isTemplate?: boolean;
}

export interface UpdateQuotationRequest {
  title?: string;
  clientName?: string;
  weddingDate?: string | null;
  hotelName?: string;
  items?: QuotationItem[];
  deposit?: string;
  finalPayment?: string;
  remark?: string;
  isTemplate?: boolean;
}

export interface ExportQuotationResponse {
  text: string;
  title: string;
}

// ==================== AI API 配置管理 ====================

export type CutoutServiceType = 'local_wasm' | 'aliyun_imageseg' | 'volcengine_visual' | 'cloudflare_images';
export type CutoutScene = 'portrait' | 'product' | 'universal';
export type CutoutOutputMode = 'transparent' | 'color';

export interface AiApiConfigItem {
  id: string;
  name: string;
  protocol: 'openai' | 'cloudflare_workers_ai' | 'cloudflare_images' | 'aliyun_imageseg' | 'volcengine_visual';
  baseUrl: string;
  apiKeyMasked: string;
  modelName: string;
  appId?: string;
  r2AccessKey?: string;
  r2SecretKeyMasked?: string;
  r2Bucket?: string;
  r2Endpoint?: string;
  r2PublicDomain?: string;
  cfAccountId?: string;
  status: 'active' | 'inactive';
  priority: number;
  remark: string;
  lastCallStatus: 'success' | 'failed' | null;
  lastCallAt: string | null;
  lastError: string | null;
  failCount: number;
  createdAt: string;
}

export interface AiApiConfigListResponse {
  items: AiApiConfigItem[];
}

export interface AiApiConfigCreateRequest {
  name: string;
  protocol: 'openai' | 'cloudflare_workers_ai' | 'cloudflare_images' | 'aliyun_imageseg' | 'volcengine_visual';
  baseUrl: string;
  apiKey: string;
  modelName: string;
  appId?: string;
  r2AccessKey?: string;
  r2SecretKey?: string;
  r2Bucket?: string;
  r2Endpoint?: string;
  r2PublicDomain?: string;
  cfAccountId?: string;
  status?: 'active' | 'inactive';
  priority?: number;
  remark?: string;
}

export interface AiApiConfigUpdateRequest {
  name?: string;
  protocol?: 'openai' | 'cloudflare_workers_ai' | 'cloudflare_images' | 'aliyun_imageseg' | 'volcengine_visual';
  baseUrl?: string;
  apiKey?: string;
  modelName?: string;
  appId?: string;
  r2AccessKey?: string;
  r2SecretKey?: string;
  r2Bucket?: string;
  r2Endpoint?: string;
  r2PublicDomain?: string;
  cfAccountId?: string;
  status?: 'active' | 'inactive';
  priority?: number;
  remark?: string;
}

export interface AiApiTestResponse {
  success: boolean;
  latencyMs: number;
  message: string;
  steps?: {
    r2Upload?: { success: boolean; message: string; detail?: string; argumentName?: string };
    r2Url?: { success: boolean; message: string };
    cfImages?: { success: boolean; message: string };
  };
}

export interface RemoveBackgroundRequest {
  imageDataUrl: string;
  scene?: CutoutScene;
  outputMode?: CutoutOutputMode;
  backgroundColor?: string;
  edgeFeathering?: boolean;
  autoCrop?: boolean;
}

export interface RemoveBackgroundResponse {
  success: boolean;
  imageDataUrl?: string;
  message?: string;
  serviceUsed?: CutoutServiceType;
  fallbackFrom?: CutoutServiceType;
}

export interface CutoutServiceConfig {
  serviceType: CutoutServiceType;
  defaultScene: CutoutScene;
  defaultOutputMode: CutoutOutputMode;
  defaultBackgroundColor: string;
  edgeFeathering: boolean;
  autoCrop: boolean;
}

// ========== 新人问卷 ==========

export interface QuestionnaireField {
  id: string;
  fieldKey: string;
  label: string;
  fieldType: 'text' | 'textarea' | 'tel' | 'date';
  placeholder?: string;
  sortOrder: number;
  required: boolean;
}

export interface Questionnaire {
  id: string;
  projectId: string;
  userId: string;
  title: string;
  shareCode: string;
  status: 'draft' | 'published' | 'closed';
  createdAt: string;
  updatedAt: string;
  fields: QuestionnaireField[];
}

export interface QuestionnaireAnswer {
  id: string;
  questionnaireId: string;
  projectId: string;
  answerData: { [key: string]: string };
  submittedAt: string | null;
  submitterName: string | null;
  createdAt: string;
}

export interface QuestionnaireListResponse { items: Questionnaire[]; }
export interface QuestionnaireDetailResponse { questionnaire: Questionnaire; }
export interface QuestionnaireCreateRequest {
  projectId: string;
  title?: string;
}
export interface QuestionnaireUpdateFieldsRequest {
  fields: Omit<QuestionnaireField, 'id'>[];
}
export interface QuestionnaireAnswerSubmitRequest {
  shareCode: string;
  answerData: { [key: string]: string };
  submitterName?: string;
}
export interface QuestionnaireAnswerListResponse { items: QuestionnaireAnswer[]; }
export interface QuestionnaireApplyToProjectRequest {
  answerId: string;
  projectId: string;
}
