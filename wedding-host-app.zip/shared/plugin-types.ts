// ---- plugin:wedding_speech_generation_1 ----
// ============================================================
// 插件 wedding_speech_generation_1 (婚礼台词智能生成与润色) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export type WeddingSpeechGenerationOneInput = {
  /** 期望的台词风格，如温馨感人、幽默风趣、正式庄重、浪漫唯美等 */
  speech_style?: string;
  /** 需要融入台词的关键信息，如新人姓名、爱情故事片段、特殊纪念日、共同经历等 */
  key_information?: string;
  /** 台词长度要求，如3分钟以内、500字左右、简短开场白等 */
  length_requirement?: string;
  /** 操作类型，如生成新台词、改写现有台词、润色优化现有台词 */
  operation_type: string;
  /** 原始台词内容（改写或润色场景时填写） */
  original_content?: string;
  /** 其他特殊要求或自定义说明 */
  additional_requirements?: string;
  /** 婚礼台词类型，如新郎致辞、新娘致辞、主持人开场白、证婚人讲话、父母致辞等 */
  speech_type: string;
};

/**
 * const input: WeddingSpeechGenerationOneInput = { speech_style, key_information, length_requirement, ... };
 * capabilityClient.load('wedding_speech_generation_1').callStream<WeddingSpeechGenerationOneOutput>('textGenerate', input)
 * 每个 chunk 就是下面这个扁平对象，字段名与 WeddingSpeechGenerationOneOutput 一致，外面没有 data / choices / message 包装：
 *   {"content":"示例文本","response":"示例文本"}
 * 返回值可能是 AsyncIterable<chunk>，也可能是 { output: AsyncIterable<chunk> }，取流前先归一化。
 * 逐段累加：
 *   for await (const chunk of stream) { result += chunk.content ?? ''; }
 */
export type WeddingSpeechGenerationOneOutput = {
  content: string;
  response?: string;
};
// ---- end:wedding_speech_generation_1 ----

// ---- plugin:wedding_process_text_to_json_1 ----
// ============================================================
// 插件 wedding_process_text_to_json_1 (婚礼流程需求文本转JSON) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface WeddingProcessTextToJsonOneInput {
  /** 用户输入的婚礼需求文本，包含婚礼时间、地点、人数、风格、预算、特殊要求等信息 */
  wedding_requirement: string;
}

/**
 * capabilityClient.load('wedding_process_text_to_json_1').call<WeddingProcessTextToJsonOneOutput>('textToJson', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { basicInfo, coupleInfo, processArrangement, ... } = result;
 * 返回值形如：
 *   {"basicInfo":{},"coupleInfo":{},"processArrangement":[],"vendorList":[],"itemList":[],"riskDetection":[],"budgetEstimate":{}}
 */
export interface WeddingProcessTextToJsonOneOutput {
  /** 婚礼基本信息，schema: {weddingDate: string(婚礼日期YYYY-MM-DD), weddingTime: string(婚礼开始时间HH:mm), location: string(婚礼地点), guestCount: Number(预计宾客人数), budget: Number(总预算金额，单位：元), style: string(婚礼风格，如中式、西式、简约、复古等), theme: string(婚礼主题), isOutdoor: Boolean(是否户外婚礼)} */
  basicInfo: Record<string, unknown>;
  /** 新人信息，schema: {groomName: string(新郎姓名), brideName: string(新娘姓名), contactPhone: string(联系电话), specialRequirement: string(新人特殊要求)} */
  coupleInfo: Record<string, unknown>;
  /** 婚礼流程安排列表，items schema: {time: string(时间点HH:mm), event: string(流程内容), duration: Number(预计时长，单位：分钟), personInCharge: string(负责人), location: string(地点)} */
  processArrangement: unknown[];
  /** 供应商列表，items schema: {type: string(供应商类型，如摄影、摄像、化妆、主持、场地、餐饮等), name: string(供应商名称), contact: string(联系方式), cost: Number(费用金额，单位：元), requirement: string(对供应商的特殊要求)} */
  vendorList: unknown[];
  /** 婚礼物品清单，items schema: {name: string(物品名称), quantity: Number(数量), unit: string(单位), cost: Number(单价，单位：元), note: string(备注)} */
  itemList: unknown[];
  /** 风险检测列表，items schema: {riskLevel: string(风险等级，如高、中、低), riskContent: string(风险内容描述), suggestion: string(应对建议)} */
  riskDetection: unknown[];
  /** 预算估算，schema: {totalEstimate: Number(总预估费用，单位：元), detail: Array(预算明细，items schema: {item: string(项目名称), cost: Number(费用金额，单位：元), proportion: string(占总预算比例)})} */
  budgetEstimate: Record<string, unknown>;
}
// ---- end:wedding_process_text_to_json_1 ----

// ---- plugin:host_image_generation_1 ----
// ============================================================
// 插件 host_image_generation_1 (时尚主持人形象照片生成) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export type HostImageGenerationOneInput = {
  /** 主持人形象描述，包括外貌特征、服装风格、气质类型等细节 */
  host_description: string;
};

/**
 * const input: HostImageGenerationOneInput = { host_description };
 * capabilityClient.load('host_image_generation_1').call<HostImageGenerationOneOutput>('textToImage', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { images } = result;
 * 返回值形如：
 *   {"images":["示例文本"]}
 */
export type HostImageGenerationOneOutput = {
  images: string[];
};
// ---- end:host_image_generation_1 ----

// ---- plugin:wedding_poster_host_photo_composition_1 ----
// ============================================================
// 插件 wedding_poster_host_photo_composition_1 (婚礼海报主持人照片合成插件) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export type WeddingPosterHostPhotoCompositionOneInput = {
  /** 主持人个人照片 */
  host_photo: string[];
  /** 婚礼海报背景图 */
  wedding_poster: string[];
  /** 额外的图片修改要求（可选） */
  additional_requirements?: string;
};

/**
 * const input: WeddingPosterHostPhotoCompositionOneInput = { host_photo, wedding_poster, additional_requirements };
 * capabilityClient.load('wedding_poster_host_photo_composition_1').call<WeddingPosterHostPhotoCompositionOneOutput>('imageToImage', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { images } = result;
 * 返回值形如：
 *   {"images":["示例文本"]}
 */
export type WeddingPosterHostPhotoCompositionOneOutput = {
  images: string[];
};
// ---- end:wedding_poster_host_photo_composition_1 ----

// ---- plugin:host_photo_background_matting_1 ----
// ============================================================
// 插件 host_photo_background_matting_1 (主持人形象照AI抠图) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export type HostPhotoBackgroundMattingOneInput = {
  /** 需要处理的主持人形象照图片 */
  host_photo: string[];
};

/**
 * const input: HostPhotoBackgroundMattingOneInput = { host_photo };
 * capabilityClient.load('host_photo_background_matting_1').call<HostPhotoBackgroundMattingOneOutput>('imageMatting', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { images } = result;
 * 返回值形如：
 *   {"images":["示例文本"]}
 */
export type HostPhotoBackgroundMattingOneOutput = {
  images: string[];
};
// ---- end:host_photo_background_matting_1 ----