import { IsString, IsOptional, MaxLength } from 'class-validator';

export class CreateScriptDto {
  @IsString()
  @MaxLength(50)
  category!: string;

  @IsString()
  @MaxLength(200)
  title!: string;

  @IsString()
  content!: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  styleTags?: string;
}
