import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { scripts } from '@server/database/schema';
import { eq, and, count, desc, ilike, or } from 'drizzle-orm';
import type {
  Script,
  ScriptCategory,
  ScriptListResponse,
} from '@shared/api.interface';
import type { CreateScriptDto } from './dto/create-script.dto';
import type { UpdateScriptDto } from './dto/update-script.dto';

const CATEGORIES: ScriptCategory[] = [
  { key: 'opening', name: '开场词', icon: 'mic' },
  { key: 'vows', name: '誓言环节', icon: 'heart' },
  { key: 'rings', name: '戒指环节', icon: 'gem' },
  { key: 'parents', name: '父母环节', icon: 'users' },
  { key: 'tea', name: '敬茶环节', icon: 'coffee' },
  { key: 'champagne', name: '香槟塔', icon: 'wine' },
  { key: 'bouquet', name: '手捧花', icon: 'flower-2' },
  { key: 'finale', name: '礼成退场', icon: 'door-open' },
  { key: 'chinese', name: '中式台词', icon: 'scroll' },
  { key: 'outdoor', name: '户外婚礼', icon: 'trees' },
  { key: 'emergency', name: '应急救场', icon: 'alert-triangle' },
  { key: 'custom', name: '我的台词', icon: 'book-open' },
];

@Injectable()
export class ScriptService {
  private readonly logger = new Logger(ScriptService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  getCategories(): ScriptCategory[] {
    return CATEGORIES;
  }

  async getList(params: {
    userId: string | null;
    category?: string;
    keyword?: string;
    isFavorite?: boolean;
    page: number;
    pageSize: number;
  }): Promise<ScriptListResponse> {
    const { userId, category, keyword, isFavorite, page, pageSize } = params;

    const conditions: any[] = [];

    // 可见范围：系统台词 + 当前用户的自定义台词
    if (userId) {
      conditions.push(or(eq(scripts.isSystem, true), eq(scripts.userId, userId)));
    } else {
      conditions.push(eq(scripts.isSystem, true));
    }

    if (category) {
      conditions.push(eq(scripts.category, category));
    }

    if (keyword) {
      conditions.push(
        or(
          ilike(scripts.title, `%${keyword}%`),
          ilike(scripts.content, `%${keyword}%`),
        ),
      );
    }

    if (isFavorite !== undefined) {
      if (!userId) {
        // 未登录用户无法筛选收藏，返回空
        return { items: [], total: 0 };
      }
      conditions.push(eq(scripts.isFavorite, isFavorite));
    }

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, itemsResult] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(scripts)
        .where(where),
      this.db
        .select()
        .from(scripts)
        .where(where)
        .orderBy(desc(scripts.isFavorite), desc(scripts.createdAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    const items: Script[] = itemsResult.map((row) => ({
      id: row.id,
      category: row.category,
      title: row.title,
      content: row.content,
      isSystem: row.isSystem ?? false,
      isFavorite: row.isFavorite ?? false,
      styleTags: row.styleTags ?? '',
    }));

    return { items, total };
  }

  async getDetail(id: string, userId: string | null): Promise<Script> {
    const conditions: any[] = [eq(scripts.id, id)];

    if (userId) {
      conditions.push(
        or(eq(scripts.isSystem, true), eq(scripts.userId, userId)),
      );
    } else {
      conditions.push(eq(scripts.isSystem, true));
    }

    const result = await this.db
      .select()
      .from(scripts)
      .where(and(...conditions))
      .limit(1);

    if (result.length === 0) {
      throw new NotFoundException('台词不存在或无权限查看');
    }

    const row = result[0];
    return {
      id: row.id,
      category: row.category,
      title: row.title,
      content: row.content,
      isSystem: row.isSystem ?? false,
      isFavorite: row.isFavorite ?? false,
      styleTags: row.styleTags ?? '',
    };
  }

  async create(dto: CreateScriptDto, userId: string): Promise<Script> {
    const result = await this.db
      .insert(scripts)
      .values({
        userId,
        category: dto.category,
        title: dto.title,
        content: dto.content,
        styleTags: dto.styleTags ?? '',
        isSystem: false,
        isFavorite: false,
      })
      .returning();

    const row = result[0];
    return {
      id: row.id,
      category: row.category,
      title: row.title,
      content: row.content,
      isSystem: row.isSystem ?? false,
      isFavorite: row.isFavorite ?? false,
      styleTags: row.styleTags ?? '',
    };
  }

  async update(
    id: string,
    dto: UpdateScriptDto,
    userId: string,
  ): Promise<Script> {
    const existing = await this.db
      .select()
      .from(scripts)
      .where(eq(scripts.id, id))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('台词不存在');
    }

    const row = existing[0];
    if (row.isSystem) {
      throw new ForbiddenException('系统台词不可修改');
    }
    if (row.userId !== userId) {
      throw new ForbiddenException('无权限修改此台词');
    }

    const patch: Record<string, any> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.content !== undefined) patch.content = dto.content;
    if (dto.category !== undefined) patch.category = dto.category;
    if (dto.styleTags !== undefined) patch.styleTags = dto.styleTags;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db
      .update(scripts)
      .set(patch)
      .where(eq(scripts.id, id))
      .returning();

    const updated = result[0];
    return {
      id: updated.id,
      category: updated.category,
      title: updated.title,
      content: updated.content,
      isSystem: updated.isSystem ?? false,
      isFavorite: updated.isFavorite ?? false,
      styleTags: updated.styleTags ?? '',
    };
  }

  async delete(id: string, userId: string): Promise<void> {
    const existing = await this.db
      .select()
      .from(scripts)
      .where(eq(scripts.id, id))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('台词不存在');
    }

    const row = existing[0];
    if (row.isSystem) {
      throw new ForbiddenException('系统台词不可删除');
    }
    if (row.userId !== userId) {
      throw new ForbiddenException('无权限删除此台词');
    }

    await this.db.delete(scripts).where(eq(scripts.id, id));
  }

  async toggleFavorite(id: string, userId: string): Promise<Script> {
    const conditions: any[] = [eq(scripts.id, id)];
    conditions.push(
      or(eq(scripts.isSystem, true), eq(scripts.userId, userId)),
    );

    const existing = await this.db
      .select()
      .from(scripts)
      .where(and(...conditions))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('台词不存在或无权限操作');
    }

    const row = existing[0];
    const newFavorite = !row.isFavorite;

    const result = await this.db
      .update(scripts)
      .set({ isFavorite: newFavorite })
      .where(eq(scripts.id, id))
      .returning();

    const updated = result[0];
    return {
      id: updated.id,
      category: updated.category,
      title: updated.title,
      content: updated.content,
      isSystem: updated.isSystem ?? false,
      isFavorite: updated.isFavorite ?? false,
      styleTags: updated.styleTags ?? '',
    };
  }
}
