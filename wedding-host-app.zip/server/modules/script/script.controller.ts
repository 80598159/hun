import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { ScriptService } from './script.service';
import { CreateScriptDto } from './dto/create-script.dto';
import { UpdateScriptDto } from './dto/update-script.dto';
import type {
  Script,
  ScriptCategory,
  ScriptListResponse,
} from '@shared/api.interface';

@Controller('api/scripts')
export class ScriptController {
  constructor(private readonly scriptService: ScriptService) {}

  @Get('categories')
  getCategories(): ScriptCategory[] {
    return this.scriptService.getCategories();
  }

  @Get()
  async getList(
    @Req() req: Request,
    @Query('category') category?: string,
    @Query('keyword') keyword?: string,
    @Query('isFavorite') isFavorite?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ScriptListResponse> {
    const userId = req.userContext?.userId ?? null;
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 20;
    const isFavoriteBool =
      isFavorite !== undefined ? isFavorite === 'true' : undefined;

    return this.scriptService.getList({
      userId,
      category,
      keyword,
      isFavorite: isFavoriteBool,
      page: pageNum,
      pageSize: pageSizeNum,
    });
  }

  @Get(':id')
  async getDetail(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<Script> {
    const userId = req.userContext?.userId ?? null;
    return this.scriptService.getDetail(id, userId);
  }

  @UseGuards(AppAuthGuard)
  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateScriptDto,
  ): Promise<Script> {
    const { userId } = req.userContext;
    return this.scriptService.create(dto, userId);
  }

  @UseGuards(AppAuthGuard)
  @Put(':id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateScriptDto,
  ): Promise<Script> {
    const { userId } = req.userContext;
    return this.scriptService.update(id, dto, userId);
  }

  @UseGuards(AppAuthGuard)
  @Delete(':id')
  async delete(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: boolean }> {
    const { userId } = req.userContext;
    await this.scriptService.delete(id, userId);
    return { success: true };
  }

  @UseGuards(AppAuthGuard)
  @Post(':id/favorite')
  async toggleFavorite(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<Script> {
    const { userId } = req.userContext;
    return this.scriptService.toggleFavorite(id, userId);
  }
}
