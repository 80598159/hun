import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { ShopService } from './shop.service';
import type { CreateOrderRequest } from '@shared/api.interface';

@Controller('api/shop')
export class ShopController {
  constructor(private readonly shopService: ShopService) {}

  @Get('products')
  async getProducts() {
    const items = await this.shopService.getProducts();
    return { items };
  }

  @Get('merchants')
  async getMerchants(@Query('category') category?: string) {
    const items = await this.shopService.getMerchants(category);
    return { items };
  }

  @UseGuards(AppAuthGuard)
  @Post('orders')
  async createOrder(
    @Req() req: Request,
    @Body() body: CreateOrderRequest,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new BadRequestException('未登录');
    }
    return this.shopService.createOrder(userId, body);
  }

  @UseGuards(AppAuthGuard)
  @Get('orders/:id')
  async getOrder(@Req() req: Request, @Param('id') orderId: string) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new BadRequestException('未登录');
    }
    return this.shopService.getOrder(userId, orderId);
  }

  @UseGuards(AppAuthGuard)
  @Post('orders/:id/pay')
  async payOrder(@Req() req: Request, @Param('id') orderId: string) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new BadRequestException('未登录');
    }
    return this.shopService.payOrder(userId, orderId);
  }
}
