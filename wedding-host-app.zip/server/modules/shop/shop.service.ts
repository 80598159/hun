import {
  BadRequestException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { orders, aiQuotas, products, mallMerchants } from '@server/database/schema';
import { eq, and, asc, desc } from 'drizzle-orm';
import type { CreateOrderRequest, Order, ShopProduct, MallMerchant } from '@shared/api.interface';

interface OrderRow {
  id: string;
  userId: string;
  productType: string;
  productName: string;
  amount: string | number;
  status: string | null;
  flowQuota: number | null;
  scriptQuota: number | null;
  paidAt: Date | null;
  createdAt: Date;
}

function orderToInterface(order: OrderRow): Order {
  return {
    id: order.id,
    productType: order.productType,
    productName: order.productName,
    amount: Number(order.amount),
    status: order.status ?? 'pending',
    flowQuota: order.flowQuota ?? 0,
    scriptQuota: order.scriptQuota ?? 0,
    paidAt: order.paidAt ? order.paidAt.toISOString() : null,
    createdAt: order.createdAt.toISOString(),
  };
}

@Injectable()
export class ShopService {
  private readonly logger = new Logger(ShopService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getProducts(): Promise<ShopProduct[]> {
    const rows = await this.db
      .select()
      .from(products)
      .where(eq(products.isActive, true))
      .orderBy(asc(products.sortOrder), asc(products.id));

    return rows.map((row): ShopProduct => ({
      id: row.id,
      type: row.type,
      name: row.name,
      description: row.description ?? '',
      price: Number(row.price),
      originalPrice: row.originalPrice != null ? Number(row.originalPrice) : null,
      flowQuota: row.flowQuota ?? 0,
      scriptQuota: row.scriptQuota ?? 0,
      posterTemplate: row.posterTemplate ?? null,
    }));
  }

  async getMerchants(category?: string): Promise<MallMerchant[]> {
    const conditions = [
      eq(mallMerchants.isActive, true),
      eq(mallMerchants.isApproved, true),
    ];
    if (category && category !== '全部') {
      conditions.push(eq(mallMerchants.category, category));
    }

    const rows = await this.db
      .select()
      .from(mallMerchants)
      .where(and(...conditions))
      .orderBy(
        desc(mallMerchants.isAd),
        asc(mallMerchants.sortOrder),
        asc(mallMerchants.id),
      );

    return rows.map((row): MallMerchant => ({
      id: row.id,
      name: row.name,
      category: row.category,
      logoUrl: row.logoUrl ?? null,
      coverUrl: row.coverUrl ?? null,
      address: row.address ?? '',
      description: row.description ?? '',
      rating: Number(row.rating),
      isAd: row.isAd,
    }));
  }

  async createOrder(
    userId: string,
    dto: CreateOrderRequest,
  ): Promise<Order> {
    if (!dto.productType || !dto.productName) {
      throw new BadRequestException('商品类型和名称不能为空');
    }
    if (dto.amount == null || dto.amount < 0) {
      throw new BadRequestException('金额不合法');
    }

    const [created] = await this.db
      .insert(orders)
      .values({
        userId,
        productType: dto.productType,
        productName: dto.productName,
        amount: String(dto.amount),
        status: 'pending',
        flowQuota: dto.flowQuota ?? 0,
        scriptQuota: dto.scriptQuota ?? 0,
      })
      .returning();

    return orderToInterface(created as unknown as OrderRow);
  }

  async getOrder(userId: string, orderId: string): Promise<Order> {
    const result = await this.db
      .select()
      .from(orders)
      .where(eq(orders.id, orderId))
      .limit(1);

    if (result.length === 0) {
      throw new NotFoundException('订单不存在');
    }

    const order = result[0] as unknown as OrderRow;
    if (order.userId !== userId) {
      throw new NotFoundException('订单不存在');
    }

    return orderToInterface(order);
  }

  async payOrder(userId: string, orderId: string): Promise<Order> {
    const result = await this.db
      .select()
      .from(orders)
      .where(eq(orders.id, orderId))
      .limit(1);

    if (result.length === 0) {
      throw new NotFoundException('订单不存在');
    }

    const order = result[0] as unknown as OrderRow;
    if (order.userId !== userId) {
      throw new NotFoundException('订单不存在');
    }

    if (order.status === 'paid') {
      return orderToInterface(order);
    }

    const flowQuota = order.flowQuota ?? 0;
    const scriptQuota = order.scriptQuota ?? 0;

    const [paidOrder] = await this.db.transaction(async (tx) => {
      const [updated] = await tx
        .update(orders)
        .set({
          status: 'paid',
          paidAt: new Date(),
        })
        .where(eq(orders.id, orderId))
        .returning();

      if (flowQuota > 0 || scriptQuota > 0) {
        const existing = await tx
          .select()
          .from(aiQuotas)
          .where(eq(aiQuotas.userId, userId))
          .limit(1);

        if (existing.length > 0) {
          await tx
            .update(aiQuotas)
            .set({
              totalFlowQuota:
                (existing[0].totalFlowQuota ?? 0) + flowQuota,
              totalScriptQuota:
                (existing[0].totalScriptQuota ?? 0) + scriptQuota,
            })
            .where(eq(aiQuotas.id, existing[0].id));
        } else {
          await tx.insert(aiQuotas).values({
            userId,
            totalFlowQuota: flowQuota,
            totalScriptQuota: scriptQuota,
          });
        }
      }

      return [updated];
    });

    this.logger.log(
      `订单支付成功：orderId=${orderId}, flowQuota=${flowQuota}, scriptQuota=${scriptQuota}`,
    );

    return orderToInterface(paidOrder as unknown as OrderRow);
  }
}
