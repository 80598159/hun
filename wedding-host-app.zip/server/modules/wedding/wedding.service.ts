import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  eq,
  and,
  count,
  desc,
  asc,
  sql,
} from 'drizzle-orm';
import { weddingProjects, weddingSteps, weddingCollaborators, weddingShareLinks, schedules, systemConfigs } from '@server/database/schema';
import type {
  WeddingProject,
  WeddingStep,
  ProjectListResponse,
  PresetStep,
  WeddingCollaborator,
  WeddingShareLink,
  ProjectAccessInfo,
  ProjectScheduleLinkResult,
  Schedule,
} from '@shared/api.interface';
import type { CreateProjectDto } from './dto/create-project.dto';
import type { UpdateProjectDto } from './dto/update-project.dto';
import type { AddStepDto } from './dto/add-step.dto';
import type { UpdateStepDto } from './dto/update-step.dto';

const PRESET_STEPS: PresetStep[] = [
  // 暖场类
  { stepName: '暖场音乐', duration: 30, bgmSuggest: '轻松浪漫轻音乐', hostTip: '宾客陆续入场时播放，音量适中', category: '暖场类' },
  { stepName: '灯光秀', duration: 3, bgmSuggest: '震撼开场音乐', hostTip: '配合灯光效果，营造仪式感', category: '暖场类' },
  { stepName: '快闪视频', duration: 5, bgmSuggest: '视频自带配乐', hostTip: '播放新人成长/恋爱故事视频', category: '暖场类' },
  // 仪式类
  { stepName: '主持人开场', duration: 3, bgmSuggest: '舒缓背景音乐', hostTip: '问候来宾，介绍新人故事背景', category: '仪式类' },
  { stepName: '新人入场', duration: 2, bgmSuggest: '婚礼进行曲', hostTip: '新郎新娘携手步入仪式区', category: '仪式类' },
  { stepName: '交接仪式', duration: 2, bgmSuggest: '温馨感人音乐', hostTip: '父亲将女儿交给新郎，拥抱祝福', category: '仪式类' },
  { stepName: '誓言', duration: 5, bgmSuggest: '轻柔钢琴曲', hostTip: '新人面对面宣读结婚誓言', category: '仪式类' },
  { stepName: '交换戒指', duration: 3, bgmSuggest: '浪漫抒情音乐', hostTip: '伴郎伴娘送上戒指，新人互换佩戴', category: '仪式类' },
  { stepName: '敬茶', duration: 5, bgmSuggest: '传统喜庆音乐', hostTip: '向双方父母敬茶改口，父母给红包', category: '仪式类' },
  { stepName: '父母致辞', duration: 4, bgmSuggest: '温馨感人音乐', hostTip: '双方父亲或母亲代表发言祝福', category: '仪式类' },
  { stepName: '倒香槟', duration: 3, bgmSuggest: '欢快优雅音乐', hostTip: '新人共同倾倒香槟塔，寓意幸福绵长', category: '仪式类' },
  { stepName: '手捧花', duration: 3, bgmSuggest: '活泼轻快音乐', hostTip: '新娘抛手捧花，未婚女宾客上台接花', category: '仪式类' },
  { stepName: '礼成退场', duration: 2, bgmSuggest: '欢快喜庆音乐', hostTip: '仪式结束，新人携手退场，宾客欢送', category: '仪式类' },
  // 互动类
  { stepName: '游戏环节', duration: 10, bgmSuggest: '欢快活泼音乐', hostTip: '组织宾客参与互动游戏，活跃气氛', category: '互动类' },
  { stepName: '抽奖环节', duration: 8, bgmSuggest: '紧张刺激音乐', hostTip: '抽取幸运奖品，带动全场热情', category: '互动类' },
  { stepName: '亲友致辞', duration: 5, bgmSuggest: '温馨背景音乐', hostTip: '邀请亲友代表上台送上祝福', category: '互动类' },
];

@Injectable()
export class WeddingService {
  private readonly logger = new Logger(WeddingService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ========== 项目管理 ==========

  async getProjectList(
    userId: string,
    page: number,
    pageSize: number,
    status: 'active' | 'archived' | 'all' = 'active',
  ): Promise<ProjectListResponse> {
    const whereConditions = [eq(weddingProjects.userId, userId)];
    if (status === 'active') {
      whereConditions.push(eq(weddingProjects.isArchived, false));
    } else if (status === 'archived') {
      whereConditions.push(eq(weddingProjects.isArchived, true));
    }

    const [countResult] = await this.db
      .select({ count: count() })
      .from(weddingProjects)
      .where(and(...whereConditions));

    const total: number = Number(countResult.count);
    const offset = (page - 1) * pageSize;

    const projects = await this.db
      .select()
      .from(weddingProjects)
      .where(and(...whereConditions))
      .orderBy(desc(weddingProjects.updatedAt))
      .limit(pageSize)
      .offset(offset);

    return {
      items: projects.map((p) => this.mapProject(p)),
      total,
    };
  }

  async createProject(
    userId: string,
    dto: CreateProjectDto,
  ): Promise<ProjectScheduleLinkResult> {
    const autoLink = dto.autoLinkSchedule !== false; // 默认开启

    const result = await this.db.transaction(async (tx) => {
      const [project] = await tx
        .insert(weddingProjects)
        .values({
          userId,
          title: dto.title || '新婚礼方案',
          groomName: dto.groomName ?? null,
          brideName: dto.brideName ?? null,
          weddingDate: dto.weddingDate ?? null,
          timeType: dto.timeType ?? 'dinner',
          hotelName: dto.hotelName ?? null,
        })
        .returning();

      const linkResult = await this.handleScheduleLinkInTx(
        tx,
        userId,
        project.id,
        null,
        dto.weddingDate ?? null,
        (dto.timeType ?? 'dinner') as 'lunch' | 'dinner',
        autoLink,
      );

      const updatedProject = linkResult.projectScheduleId !== undefined
        ? { ...project, scheduleId: linkResult.projectScheduleId }
        : project;

      return { project: updatedProject, linkResult };
    });

    return {
      project: this.mapProject(result.project),
      scheduleId: result.linkResult.scheduleId,
      linkAction: result.linkResult.action,
      message: result.linkResult.message,
      conflictSchedule: result.linkResult.conflictSchedule,
    };
  }

  async getProjectDetail(
    userId: string,
    id: string,
  ): Promise<WeddingProject & { steps: WeddingStep[]; posterPhotoUpdateCount: number; posterPhotoUpdateLimit: number }> {
    const { role, project } = await this.getProjectAccess(userId, id);
    if (role === 'none') {
      throw new ForbiddenException('无权访问该项目');
    }

    const steps = await this.db
      .select()
      .from(weddingSteps)
      .where(eq(weddingSteps.projectId, id))
      .orderBy(asc(weddingSteps.sortOrder));

    const [configRow] = await this.db
      .select({ configValue: systemConfigs.configValue })
      .from(systemConfigs)
      .where(eq(systemConfigs.configKey, 'poster_photo_update_limit_per_project'))
      .limit(1);

    const limitValue: number = configRow?.configValue
      ? parseInt(configRow.configValue, 10) || 0
      : 0;

    return {
      ...this.mapProject(project!),
      steps: steps.map((s) => this.mapStep(s)),
      posterPhotoUpdateCount: project?.posterPhotoUpdateCount ?? 0,
      posterPhotoUpdateLimit: limitValue,
    };
  }

  async updateProject(
    userId: string,
    id: string,
    dto: UpdateProjectDto,
  ): Promise<ProjectScheduleLinkResult> {
    const project = await this.ensureCanEdit(userId, id);

    const patch: Partial<typeof weddingProjects.$inferInsert> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.groomName !== undefined) patch.groomName = dto.groomName;
    if (dto.brideName !== undefined) patch.brideName = dto.brideName;
    if (dto.weddingDate !== undefined) patch.weddingDate = dto.weddingDate ?? null;
    if (dto.timeType !== undefined) patch.timeType = dto.timeType;
    if (dto.hotelName !== undefined) patch.hotelName = dto.hotelName;
    if (dto.planner !== undefined) patch.planner = dto.planner;
    if (dto.supervisor !== undefined) patch.supervisor = dto.supervisor;
    if (dto.videographer !== undefined) patch.videographer = dto.videographer;
    if (dto.photographer !== undefined) patch.photographer = dto.photographer;
    if (dto.soundController !== undefined) patch.soundController = dto.soundController;
    if (dto.specialNotes !== undefined) patch.specialNotes = dto.specialNotes;
    if (dto.isArchived !== undefined) patch.isArchived = dto.isArchived;
    if (dto.posterTemplate !== undefined) patch.posterTemplate = dto.posterTemplate;

    const hasDataPatch = Object.keys(patch).length > 0;
    if (hasDataPatch) {
      patch.updatedAt = new Date();
    }

    const dateChanged = dto.weddingDate !== undefined || dto.timeType !== undefined;
    const autoLink = dto.autoLinkSchedule !== false;

    const result = await this.db.transaction(async (tx) => {
      let updatedProject = project;

      if (hasDataPatch) {
        const [updated] = await tx
          .update(weddingProjects)
          .set(patch)
          .where(eq(weddingProjects.id, id))
          .returning();
        updatedProject = updated;
      }

      let linkResult: {
        scheduleId: string | null;
        action: 'created' | 'linked' | 'conflict' | 'skipped' | 'unlinked';
        message: string;
        conflictSchedule?: Schedule;
        projectScheduleId: string | null;
      } = {
        scheduleId: (updatedProject.scheduleId ?? null) as string | null,
        action: 'skipped',
        message: '',
        projectScheduleId: updatedProject.scheduleId ?? null,
      };

      if (dateChanged || (autoLink && updatedProject.weddingDate && !updatedProject.scheduleId)) {
        linkResult = await this.handleScheduleLinkInTx(
          tx,
          userId,
          id,
          project.scheduleId ?? null,
          updatedProject.weddingDate ?? null,
          ((updatedProject.timeType as 'lunch' | 'dinner') ?? 'dinner') as 'lunch' | 'dinner',
          autoLink,
        );

        if (linkResult.projectScheduleId !== undefined &&
            linkResult.projectScheduleId !== updatedProject.scheduleId) {
          const [refreshed] = await tx
            .select()
            .from(weddingProjects)
            .where(eq(weddingProjects.id, id))
            .limit(1);
          if (refreshed) updatedProject = refreshed;
        }
      }

      return { project: updatedProject, linkResult };
    });

    return {
      project: this.mapProject(result.project),
      scheduleId: result.linkResult.scheduleId,
      linkAction: result.linkResult.action,
      message: result.linkResult.message,
      conflictSchedule: result.linkResult.conflictSchedule,
    };
  }

  async deleteProject(userId: string, id: string): Promise<void> {
    const project = await this.findProjectById(id);
    if (!project) {
      throw new NotFoundException('项目不存在');
    }
    if (project.userId !== userId) {
      throw new ForbiddenException('无权操作该项目');
    }

    await this.db.transaction(async (tx) => {
      if (project.scheduleId) {
        const [sch] = await tx
          .select()
          .from(schedules)
          .where(eq(schedules.id, project.scheduleId))
          .limit(1);
        if (sch && sch.source === 'auto_from_project') {
          await tx.delete(schedules).where(eq(schedules.id, project.scheduleId!));
        } else if (sch) {
          await tx.update(schedules)
            .set({ projectId: null })
            .where(eq(schedules.id, project.scheduleId!));
        }
      }

      await tx
        .delete(weddingProjects)
        .where(eq(weddingProjects.id, id));
    });
  }

  async copyProject(
    userId: string,
    id: string,
  ): Promise<WeddingProject & { steps: WeddingStep[] }> {
    const project = await this.findProjectById(id);
    if (!project) {
      throw new NotFoundException('项目不存在');
    }
    if (project.userId !== userId) {
      throw new ForbiddenException('无权操作该项目');
    }

    const steps = await this.db
      .select()
      .from(weddingSteps)
      .where(eq(weddingSteps.projectId, id))
      .orderBy(asc(weddingSteps.sortOrder));

    return this.db.transaction(async (tx) => {
      const [newProject] = await tx
        .insert(weddingProjects)
        .values({
          userId,
          title: `${project.title} 副本`,
          groomName: project.groomName,
          brideName: project.brideName,
          weddingDate: project.weddingDate,
          timeType: project.timeType,
          hotelName: project.hotelName,
          planner: project.planner,
          supervisor: project.supervisor,
          videographer: project.videographer,
          photographer: project.photographer,
          soundController: project.soundController,
          specialNotes: project.specialNotes,
          status: 'active',
          isArchived: false,
          posterTemplate: project.posterTemplate,
        })
        .returning();

      let newSteps: WeddingStep[] = [];
      if (steps.length > 0) {
        const insertedSteps = await tx
          .insert(weddingSteps)
          .values(
            steps.map((s) => ({
              projectId: newProject.id,
              stepName: s.stepName,
              duration: s.duration,
              bgmSuggest: s.bgmSuggest,
              hostTip: s.hostTip,
              sortOrder: s.sortOrder,
              isCustom: s.isCustom,
            })),
          )
          .returning();
        newSteps = insertedSteps.map((s) => this.mapStep(s));
      }

      return {
        ...this.mapProject(newProject),
        steps: newSteps,
      };
    });
  }

  async archiveProject(userId: string, id: string): Promise<WeddingProject> {
    const result = await this.updateProject(userId, id, { isArchived: true, autoLinkSchedule: false } as UpdateProjectDto);
    return result.project;
  }

  async unarchiveProject(userId: string, id: string): Promise<WeddingProject> {
    const result = await this.updateProject(userId, id, { isArchived: false, autoLinkSchedule: false } as UpdateProjectDto);
    return result.project;
  }

  // ========== 档期自动关联 ==========

  private async handleScheduleLinkInTx(
    tx: PostgresJsDatabase,
    userId: string,
    projectId: string,
    oldScheduleId: string | null,
    newWeddingDate: string | null,
    newTimeType: 'lunch' | 'dinner',
    autoLink: boolean,
  ): Promise<{
    scheduleId: string | null;
    action: 'created' | 'linked' | 'conflict' | 'skipped' | 'unlinked';
    message: string;
    conflictSchedule?: Schedule;
    projectScheduleId: string | null;
  }> {
    if (!autoLink || !newWeddingDate) {
      if (oldScheduleId) {
        await tx.update(schedules)
          .set({ projectId: null })
          .where(eq(schedules.id, oldScheduleId));
        await tx.update(weddingProjects)
          .set({ scheduleId: null })
          .where(eq(weddingProjects.id, projectId));
        return {
          scheduleId: null,
          action: 'unlinked',
          message: '已取消档期关联',
          projectScheduleId: null,
        };
      }
      return {
        scheduleId: oldScheduleId,
        action: 'skipped',
        message: '',
        projectScheduleId: oldScheduleId,
      };
    }

    const [existingSchedule] = await tx
      .select()
      .from(schedules)
      .where(
        and(
          eq(schedules.userId, userId),
          eq(schedules.weddingDate, newWeddingDate),
          eq(schedules.timeType, newTimeType),
        ),
      )
      .limit(1);

    if (existingSchedule) {
      if (existingSchedule.projectId && existingSchedule.projectId !== projectId) {
        const conflict = this.mapSchedule(existingSchedule);
        return {
          scheduleId: existingSchedule.id,
          action: 'conflict',
          message: '该日期同一时段已有档期，且已关联其他方案，请注意撞单',
          conflictSchedule: conflict,
          projectScheduleId: oldScheduleId,
        };
      }

      if (oldScheduleId && oldScheduleId !== existingSchedule.id) {
        const [oldSch] = await tx
          .select()
          .from(schedules)
          .where(eq(schedules.id, oldScheduleId))
          .limit(1);
        if (oldSch && oldSch.source === 'auto_from_project') {
          await tx.delete(schedules).where(eq(schedules.id, oldScheduleId));
        } else if (oldSch) {
          await tx.update(schedules)
            .set({ projectId: null })
            .where(eq(schedules.id, oldScheduleId));
        }
      }

      await tx.update(schedules)
        .set({ projectId })
        .where(eq(schedules.id, existingSchedule.id));
      await tx.update(weddingProjects)
        .set({ scheduleId: existingSchedule.id })
        .where(eq(weddingProjects.id, projectId));

      return {
        scheduleId: existingSchedule.id,
        action: 'linked',
        message: '该日期已有档期，已自动关联',
        projectScheduleId: existingSchedule.id,
      };
    }

    if (oldScheduleId) {
      const [oldSch] = await tx
        .select()
        .from(schedules)
        .where(eq(schedules.id, oldScheduleId))
        .limit(1);
      if (oldSch && oldSch.source === 'auto_from_project') {
        await tx.delete(schedules).where(eq(schedules.id, oldScheduleId));
      } else if (oldSch) {
        await tx.update(schedules)
          .set({ projectId: null })
          .where(eq(schedules.id, oldScheduleId));
      }
    }

    const [projectRow] = await tx
      .select()
      .from(weddingProjects)
      .where(eq(weddingProjects.id, projectId))
      .limit(1);

    const coupleName = [projectRow?.brideName, projectRow?.groomName]
      .filter(Boolean).join(' & ') || '';

    const [newSchedule] = await tx
      .insert(schedules)
      .values({
        userId,
        weddingDate: newWeddingDate,
        timeType: newTimeType,
        hotelName: projectRow?.hotelName ?? '',
        coupleName,
        projectId,
        source: 'auto_from_project',
        notes: '由方案自动关联创建',
      })
      .returning();

    await tx.update(weddingProjects)
      .set({ scheduleId: newSchedule.id })
      .where(eq(weddingProjects.id, projectId));

    return {
      scheduleId: newSchedule.id,
      action: 'created',
      message: '已自动为您创建档期记录',
      projectScheduleId: newSchedule.id,
    };
  }

  private mapSchedule(row: typeof schedules.$inferSelect): Schedule {
    return {
      id: row.id,
      weddingDate: row.weddingDate as string,
      timeType: (row.timeType as 'lunch' | 'dinner') ?? 'dinner',
      hotelName: row.hotelName ?? '',
      coupleName: row.coupleName ?? '',
      notes: row.notes ?? '',
      projectId: row.projectId ?? null,
      source: (row.source as 'manual' | 'auto_from_project') ?? 'manual',
    };
  }

  // ========== 环节管理 ==========

  async addStep(
    userId: string,
    projectId: string,
    dto: AddStepDto,
  ): Promise<WeddingStep> {
    const project = await this.ensureCanEdit(userId, projectId);

    const maxResult = await this.db
      .select({ maxOrder: sql<number>`max(${weddingSteps.sortOrder})` })
      .from(weddingSteps)
      .where(eq(weddingSteps.projectId, projectId));

    const maxOrder: number = maxResult[0]?.maxOrder ?? -1;
    const nextOrder: number = maxOrder + 1;

    const [step] = await this.db
      .insert(weddingSteps)
      .values({
        projectId,
        stepName: dto.stepName,
        duration: dto.duration ?? 5,
        bgmSuggest: dto.bgmSuggest ?? '',
        hostTip: dto.hostTip ?? '',
        sortOrder: nextOrder,
        isCustom: dto.isCustom ?? true,
      })
      .returning();

    return this.mapStep(step);
  }

  async updateStep(
    userId: string,
    stepId: string,
    dto: UpdateStepDto,
  ): Promise<WeddingStep> {
    const step = await this.findStepById(stepId);
    if (!step) {
      throw new NotFoundException('环节不存在');
    }

    await this.ensureCanEdit(userId, step.projectId);

    const patch: Partial<typeof weddingSteps.$inferInsert> = {};
    if (dto.stepName !== undefined) patch.stepName = dto.stepName;
    if (dto.duration !== undefined) patch.duration = dto.duration;
    if (dto.bgmSuggest !== undefined) patch.bgmSuggest = dto.bgmSuggest;
    if (dto.hostTip !== undefined) patch.hostTip = dto.hostTip;
    if (dto.sortOrder !== undefined) patch.sortOrder = dto.sortOrder;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const [updated] = await this.db
      .update(weddingSteps)
      .set(patch)
      .where(eq(weddingSteps.id, stepId))
      .returning();

    return this.mapStep(updated);
  }

  async deleteStep(userId: string, stepId: string): Promise<void> {
    const step = await this.findStepById(stepId);
    if (!step) {
      throw new NotFoundException('环节不存在');
    }

    await this.ensureCanEdit(userId, step.projectId);

    await this.db
      .delete(weddingSteps)
      .where(eq(weddingSteps.id, stepId));
  }

  async reorderSteps(
    userId: string,
    projectId: string,
    stepId: string,
    targetIndex: number,
  ): Promise<WeddingStep[]> {
    await this.ensureCanEdit(userId, projectId);

    const steps = await this.db
      .select()
      .from(weddingSteps)
      .where(eq(weddingSteps.projectId, projectId))
      .orderBy(asc(weddingSteps.sortOrder));

    const currentIndex = steps.findIndex((s) => s.id === stepId);
    if (currentIndex === -1) {
      throw new NotFoundException('环节不存在');
    }
    if (targetIndex < 0 || targetIndex >= steps.length) {
      throw new BadRequestException('目标位置无效');
    }

    // 移动元素到目标位置
    const [moved] = steps.splice(currentIndex, 1);
    steps.splice(targetIndex, 0, moved);

    // 批量更新 sort_order
    const updates = steps.map((s, i) =>
      this.db
        .update(weddingSteps)
        .set({ sortOrder: i })
        .where(eq(weddingSteps.id, s.id))
    );

    await Promise.all(updates);

    const updatedSteps = await this.db
      .select()
      .from(weddingSteps)
      .where(eq(weddingSteps.projectId, projectId))
      .orderBy(asc(weddingSteps.sortOrder));

    return updatedSteps.map((s) => this.mapStep(s));
  }

  // ========== 预设环节库 ==========

  getPresetSteps(): PresetStep[] {
    return PRESET_STEPS;
  }

  // ========== 辅助方法 ==========

  private async findProjectById(id: string) {
    const [project] = await this.db
      .select()
      .from(weddingProjects)
      .where(eq(weddingProjects.id, id));
    return project ?? null;
  }

  private async findStepById(id: string) {
    const [step] = await this.db
      .select()
      .from(weddingSteps)
      .where(eq(weddingSteps.id, id));
    return step ?? null;
  }

  private mapProject(p: typeof weddingProjects.$inferSelect): WeddingProject {
    return {
      id: p.id,
      title: p.title,
      groomName: p.groomName ?? '',
      brideName: p.brideName ?? '',
      weddingDate: p.weddingDate ?? null,
      timeType: (p.timeType as 'lunch' | 'dinner') ?? 'dinner',
      hotelName: p.hotelName ?? '',
      planner: p.planner ?? '',
      supervisor: p.supervisor ?? '',
      videographer: p.videographer ?? '',
      photographer: p.photographer ?? '',
      soundController: p.soundController ?? '',
      specialNotes: p.specialNotes ?? '',
      status: p.status ?? 'active',
      isArchived: p.isArchived ?? false,
      posterTemplate: p.posterTemplate ?? 'classic',
      scheduleId: p.scheduleId ?? null,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    };
  }

  private mapStep(s: typeof weddingSteps.$inferSelect): WeddingStep {
    return {
      id: s.id,
      projectId: s.projectId,
      stepName: s.stepName,
      duration: s.duration,
      bgmSuggest: s.bgmSuggest ?? '',
      hostTip: s.hostTip ?? '',
      sortOrder: s.sortOrder,
      isCustom: s.isCustom ?? false,
    };
  }

  // ========== 权限校验 ==========

  private async getProjectAccess(
    userId: string,
    projectId: string,
  ): Promise<{ role: 'owner' | 'collaborator' | 'none'; project: typeof weddingProjects.$inferSelect | null }> {
    const project = await this.findProjectById(projectId);
    if (!project) {
      return { role: 'none', project: null };
    }
    if (project.userId === userId) {
      return { role: 'owner', project };
    }
    const collab = await this.db
      .select()
      .from(weddingCollaborators)
      .where(
        and(
          eq(weddingCollaborators.projectId, projectId),
          eq(weddingCollaborators.userId, userId),
        ),
      )
      .limit(1);
    if (collab.length > 0) {
      return { role: 'collaborator', project };
    }
    return { role: 'none', project };
  }

  private async ensureCanEdit(userId: string, projectId: string): Promise<typeof weddingProjects.$inferSelect> {
    const { role, project } = await this.getProjectAccess(userId, projectId);
    if (role === 'none') {
      throw new ForbiddenException('无权操作该项目');
    }
    return project!;
  }

  private async ensureIsOwner(userId: string, projectId: string): Promise<typeof weddingProjects.$inferSelect> {
    const { role, project } = await this.getProjectAccess(userId, projectId);
    if (role !== 'owner') {
      throw new ForbiddenException('只有方案创建人可执行此操作');
    }
    return project!;
  }

  // ========== 协作共享 ==========

  async getProjectAccessInfo(
    userId: string,
    projectId: string,
  ): Promise<ProjectAccessInfo> {
    const { role } = await this.getProjectAccess(userId, projectId);
    const collabRows = await this.db
      .select()
      .from(weddingCollaborators)
      .where(eq(weddingCollaborators.projectId, projectId))
      .orderBy(asc(weddingCollaborators.joinedAt));
    const collaborators: WeddingCollaborator[] = collabRows.map((r) => ({
      id: r.id,
      projectId: r.projectId,
      userId: r.userId,
      role: r.role as 'owner' | 'collaborator',
      invitedBy: r.invitedBy ?? '',
      joinedAt: r.joinedAt.toISOString(),
    }));
    return { role, collaborators };
  }

  async createShareLink(
    userId: string,
    projectId: string,
  ): Promise<WeddingShareLink> {
    await this.ensureIsOwner(userId, projectId);
    const shareCode = Math.random().toString(36).slice(2, 10).toUpperCase();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    const [link] = await this.db
      .insert(weddingShareLinks)
      .values({
        projectId,
        shareCode,
        createdBy: userId,
        expiresAt,
      })
      .returning();
    return this.mapShareLink(link);
  }

  async getShareLinks(
    userId: string,
    projectId: string,
  ): Promise<WeddingShareLink[]> {
    await this.ensureIsOwner(userId, projectId);
    const links = await this.db
      .select()
      .from(weddingShareLinks)
      .where(eq(weddingShareLinks.projectId, projectId))
      .orderBy(desc(weddingShareLinks.createdAt));
    return links.map((l) => this.mapShareLink(l));
  }

  async revokeShareLink(
    userId: string,
    linkId: string,
  ): Promise<void> {
    const link = await this.db
      .select()
      .from(weddingShareLinks)
      .where(eq(weddingShareLinks.id, linkId))
      .limit(1);
    if (link.length === 0) {
      throw new NotFoundException('分享链接不存在');
    }
    await this.ensureIsOwner(userId, link[0].projectId);
    await this.db
      .update(weddingShareLinks)
      .set({ isActive: false })
      .where(eq(weddingShareLinks.id, linkId));
  }

  async joinByShareCode(
    userId: string,
    shareCode: string,
  ): Promise<{ projectId: string; role: 'owner' | 'collaborator' }> {
    const link = await this.db
      .select()
      .from(weddingShareLinks)
      .where(
        and(
          eq(weddingShareLinks.shareCode, shareCode.toUpperCase()),
          eq(weddingShareLinks.isActive, true),
        ),
      )
      .limit(1);
    if (link.length === 0) {
      throw new BadRequestException('分享码无效或已失效');
    }
    const shareLink = link[0];
    if (shareLink.expiresAt && shareLink.expiresAt < new Date()) {
      throw new BadRequestException('分享链接已过期');
    }

    const project = await this.findProjectById(shareLink.projectId);
    if (!project) {
      throw new NotFoundException('方案不存在');
    }

    if (project.userId === userId) {
      return { projectId: project.id, role: 'owner' };
    }

    const existing = await this.db
      .select()
      .from(weddingCollaborators)
      .where(
        and(
          eq(weddingCollaborators.projectId, project.id),
          eq(weddingCollaborators.userId, userId),
        ),
      )
      .limit(1);

    if (existing.length === 0) {
      await this.db.insert(weddingCollaborators).values({
        projectId: project.id,
        userId,
        role: 'collaborator',
        invitedBy: shareLink.createdBy,
      });
      await this.db
        .update(weddingShareLinks)
        .set({ joinCount: shareLink.joinCount + 1 })
        .where(eq(weddingShareLinks.id, shareLink.id));
    }

    return { projectId: project.id, role: 'collaborator' };
  }

  async removeCollaborator(
    userId: string,
    projectId: string,
    collaboratorId: string,
  ): Promise<void> {
    await this.ensureIsOwner(userId, projectId);
    const collab = await this.db
      .select()
      .from(weddingCollaborators)
      .where(eq(weddingCollaborators.id, collaboratorId))
      .limit(1);
    if (collab.length === 0) {
      throw new NotFoundException('协作者不存在');
    }
    if (collab[0].projectId !== projectId) {
      throw new BadRequestException('参数不匹配');
    }
    if (collab[0].userId === userId) {
      throw new BadRequestException('不能移除方案创建者');
    }
    await this.db
      .delete(weddingCollaborators)
      .where(eq(weddingCollaborators.id, collaboratorId));
  }

  private mapShareLink(l: typeof weddingShareLinks.$inferSelect): WeddingShareLink {
    return {
      id: l.id,
      projectId: l.projectId,
      shareCode: l.shareCode,
      createdBy: l.createdBy,
      expiresAt: l.expiresAt ? l.expiresAt.toISOString() : null,
      isActive: l.isActive,
      joinCount: l.joinCount,
      createdAt: l.createdAt.toISOString(),
    };
  }
}
