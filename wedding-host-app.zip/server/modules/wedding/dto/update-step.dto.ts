import { IsString, IsOptional, IsInt } from 'class-validator';
import type { UpdateStepRequest } from '@shared/api.interface';

export class UpdateStepDto implements UpdateStepRequest {
  @IsOptional()
  @IsString()
  stepName?: string;

  @IsOptional()
  @IsInt()
  duration?: number;

  @IsOptional()
  @IsString()
  bgmSuggest?: string;

  @IsOptional()
  @IsString()
  hostTip?: string;

  @IsOptional()
  @IsInt()
  sortOrder?: number;
}
