import { IsOptional, IsString, IsIn, IsBoolean } from 'class-validator';
import type { CreateProjectRequest } from '@shared/api.interface';

export class CreateProjectDto implements CreateProjectRequest {
  @IsOptional()
  @IsString()
  title?: string;

  @IsOptional()
  @IsString()
  groomName?: string;

  @IsOptional()
  @IsString()
  brideName?: string;

  @IsOptional()
  @IsString()
  weddingDate?: string | null;

  @IsOptional()
  @IsString()
  @IsIn(['lunch', 'dinner'])
  timeType?: 'lunch' | 'dinner';

  @IsOptional()
  @IsString()
  hotelName?: string;

  @IsOptional()
  @IsBoolean()
  autoLinkSchedule?: boolean;
}
