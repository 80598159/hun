import { IsOptional, IsString, IsIn, IsBoolean } from 'class-validator';
import type { UpdateProjectRequest } from '@shared/api.interface';

export class UpdateProjectDto implements UpdateProjectRequest {
  @IsOptional()
  @IsString()
  title?: string;

  @IsOptional()
  @IsString()
  groomName?: string;

  @IsOptional()
  @IsString()
  brideName?: string;

  @IsOptional()
  @IsString()
  weddingDate?: string | null;

  @IsOptional()
  @IsString()
  @IsIn(['lunch', 'dinner'])
  timeType?: 'lunch' | 'dinner';

  @IsOptional()
  @IsString()
  hotelName?: string;

  @IsOptional()
  @IsString()
  planner?: string;

  @IsOptional()
  @IsString()
  supervisor?: string;

  @IsOptional()
  @IsString()
  videographer?: string;

  @IsOptional()
  @IsString()
  photographer?: string;

  @IsOptional()
  @IsString()
  soundController?: string;

  @IsOptional()
  @IsString()
  specialNotes?: string;

  @IsOptional()
  @IsBoolean()
  isArchived?: boolean;

  @IsOptional()
  @IsString()
  posterTemplate?: string;

  @IsOptional()
  @IsBoolean()
  autoLinkSchedule?: boolean;
}
