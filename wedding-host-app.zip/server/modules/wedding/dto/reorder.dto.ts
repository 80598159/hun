import { IsString, IsInt } from 'class-validator';
import type { ReorderStepRequest } from '@shared/api.interface';

export class ReorderDto implements ReorderStepRequest {
  @IsString()
  stepId!: string;

  @IsInt()
  targetIndex!: number;
}
