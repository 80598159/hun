import { IsString, IsOptional, IsInt, IsBoolean } from 'class-validator';
import type { AddStepRequest } from '@shared/api.interface';

export class AddStepDto implements AddStepRequest {
  @IsString()
  stepName!: string;

  @IsOptional()
  @IsInt()
  duration?: number;

  @IsOptional()
  @IsString()
  bgmSuggest?: string;

  @IsOptional()
  @IsString()
  hostTip?: string;

  @IsOptional()
  @IsBoolean()
  isCustom?: boolean;
}
