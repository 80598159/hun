import { IsString, IsNotEmpty, MaxLength } from 'class-validator';

export class ShareCodeDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(32)
  shareCode!: string;
}
