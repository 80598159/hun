import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Req,
  ParseIntPipe,
  DefaultValuePipe,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { WeddingService } from './wedding.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { AddStepDto } from './dto/add-step.dto';
import { UpdateStepDto } from './dto/update-step.dto';
import { ReorderDto } from './dto/reorder.dto';
import { ShareCodeDto } from './dto/share-code.dto';

@Controller('api/wedding')
export class WeddingController {
  constructor(private readonly weddingService: WeddingService) {}

  // ========== 预设环节库（公开） ==========

  @Get('preset-steps')
  getPresetSteps() {
    return this.weddingService.getPresetSteps();
  }

  // ========== 项目管理 ==========

  @UseGuards(AppAuthGuard)
  @Get('projects')
  getProjectList(
    @Req() req: Request,
    @Query('page', new DefaultValuePipe('1'), ParseIntPipe) page: number,
    @Query('pageSize', new DefaultValuePipe('10'), ParseIntPipe) pageSize: number,
    @Query('status', new DefaultValuePipe('active')) status: 'active' | 'archived' | 'all',
  ) {
    const { userId } = req.userContext;
    return this.weddingService.getProjectList(userId, page, pageSize, status);
  }

  @UseGuards(AppAuthGuard)
  @Post('projects')
  createProject(@Req() req: Request, @Body() dto: CreateProjectDto) {
    const { userId } = req.userContext;
    return this.weddingService.createProject(userId, dto);
  }

  @UseGuards(AppAuthGuard)
  @Get('projects/:id')
  getProjectDetail(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.weddingService.getProjectDetail(userId, id);
  }

  @UseGuards(AppAuthGuard)
  @Put('projects/:id')
  updateProject(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateProjectDto,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.updateProject(userId, id, dto);
  }

  @UseGuards(AppAuthGuard)
  @Delete('projects/:id')
  deleteProject(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.weddingService.deleteProject(userId, id);
  }

  @UseGuards(AppAuthGuard)
  @Post('projects/:id/copy')
  copyProject(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.weddingService.copyProject(userId, id);
  }

  @UseGuards(AppAuthGuard)
  @Post('projects/:id/archive')
  archiveProject(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.weddingService.archiveProject(userId, id);
  }

  @UseGuards(AppAuthGuard)
  @Post('projects/:id/unarchive')
  unarchiveProject(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.weddingService.unarchiveProject(userId, id);
  }

  // ========== 环节管理 ==========

  @UseGuards(AppAuthGuard)
  @Post('projects/:id/steps')
  addStep(
    @Req() req: Request,
    @Param('id') projectId: string,
    @Body() dto: AddStepDto,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.addStep(userId, projectId, dto);
  }

  @UseGuards(AppAuthGuard)
  @Put('steps/:stepId')
  updateStep(
    @Req() req: Request,
    @Param('stepId') stepId: string,
    @Body() dto: UpdateStepDto,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.updateStep(userId, stepId, dto);
  }

  @UseGuards(AppAuthGuard)
  @Delete('steps/:stepId')
  deleteStep(@Req() req: Request, @Param('stepId') stepId: string) {
    const { userId } = req.userContext;
    return this.weddingService.deleteStep(userId, stepId);
  }

  @UseGuards(AppAuthGuard)
  @Post('projects/:id/steps/reorder')
  reorderSteps(
    @Req() req: Request,
    @Param('id') projectId: string,
    @Body() dto: ReorderDto,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.reorderSteps(
      userId,
      projectId,
      dto.stepId,
      dto.targetIndex,
    );
  }

  // ========== 协作共享 ==========

  @UseGuards(AppAuthGuard)
  @Get('projects/:id/access')
  getProjectAccessInfo(
    @Req() req: Request,
    @Param('id') projectId: string,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.getProjectAccessInfo(userId, projectId);
  }

  @UseGuards(AppAuthGuard)
  @Post('projects/:id/share')
  createShareLink(
    @Req() req: Request,
    @Param('id') projectId: string,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.createShareLink(userId, projectId);
  }

  @UseGuards(AppAuthGuard)
  @Get('projects/:id/share')
  getShareLinks(
    @Req() req: Request,
    @Param('id') projectId: string,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.getShareLinks(userId, projectId);
  }

  @UseGuards(AppAuthGuard)
  @Delete('share/:linkId')
  revokeShareLink(
    @Req() req: Request,
    @Param('linkId') linkId: string,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.revokeShareLink(userId, linkId);
  }

  @UseGuards(AppAuthGuard)
  @Post('share/join')
  joinByShareCode(
    @Req() req: Request,
    @Body() dto: ShareCodeDto,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.joinByShareCode(userId, dto.shareCode);
  }

  @UseGuards(AppAuthGuard)
  @Delete('projects/:id/collaborators/:collaboratorId')
  removeCollaborator(
    @Req() req: Request,
    @Param('id') projectId: string,
    @Param('collaboratorId') collaboratorId: string,
  ) {
    const { userId } = req.userContext;
    return this.weddingService.removeCollaborator(
      userId,
      projectId,
      collaboratorId,
    );
  }
}
