import { IsString, IsOptional, IsIn, MaxLength, IsBoolean } from 'class-validator';

export class UpdateScheduleDto {
  @IsOptional()
  @IsString()
  weddingDate?: string;

  @IsOptional()
  @IsString()
  @IsIn(['lunch', 'dinner'])
  timeType?: 'lunch' | 'dinner';

  @IsOptional()
  @IsString()
  @MaxLength(200)
  hotelName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  coupleName?: string;

  @IsOptional()
  @IsString()
  notes?: string;

  @IsOptional()
  @IsString()
  projectId?: string;

  @IsOptional()
  @IsBoolean()
  force?: boolean;
}
