import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ForbiddenException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { schedules } from '@server/database/schema';
import { eq, and, desc, gte, lte, ne } from 'drizzle-orm';
import type {
  Schedule,
  ScheduleConflictResponse,
} from '@shared/api.interface';
import type { CreateScheduleDto } from './dto/create-schedule.dto';
import type { UpdateScheduleDto } from './dto/update-schedule.dto';

@Injectable()
export class ScheduleService {
  private readonly logger = new Logger(ScheduleService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getList(
    userId: string,
    startDate?: string,
    endDate?: string,
  ): Promise<Schedule[]> {
    const conditions: any[] = [eq(schedules.userId, userId)];

    if (startDate) {
      conditions.push(gte(schedules.weddingDate, startDate));
    }
    if (endDate) {
      conditions.push(lte(schedules.weddingDate, endDate));
    }

    const result = await this.db
      .select()
      .from(schedules)
      .where(and(...conditions))
      .orderBy(schedules.weddingDate, desc(schedules.createdAt));

    return result.map((row) => this.mapToSchedule(row));
  }

  async getDetail(id: string, userId: string): Promise<Schedule> {
    const result = await this.db
      .select()
      .from(schedules)
      .where(and(eq(schedules.id, id), eq(schedules.userId, userId)))
      .limit(1);

    if (result.length === 0) {
      throw new NotFoundException('档期不存在或无权限查看');
    }

    return this.mapToSchedule(result[0]);
  }

  async create(dto: CreateScheduleDto, userId: string): Promise<Schedule> {
    // 撞单检测
    const timeType = dto.timeType ?? 'dinner';
    const conflicts = await this.findConflicts(
      userId,
      dto.weddingDate,
      timeType,
      null,
    );
    if (conflicts.length > 0 && !dto.force) {
      throw new ConflictException('该日期同一时段已有档期安排');
    }

    const result = await this.db
      .insert(schedules)
      .values({
        userId,
        weddingDate: dto.weddingDate,
        timeType,
        hotelName: dto.hotelName ?? '',
        coupleName: dto.coupleName ?? '',
        notes: dto.notes ?? '',
        projectId: dto.projectId ?? null,
        source: 'manual',
      })
      .returning();

    return this.mapToSchedule(result[0]);
  }

  async update(
    id: string,
    dto: UpdateScheduleDto,
    userId: string,
  ): Promise<Schedule> {
    const existing = await this.db
      .select()
      .from(schedules)
      .where(eq(schedules.id, id))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('档期不存在');
    }

    const row = existing[0];
    if (row.userId !== userId) {
      throw new ForbiddenException('无权限修改此档期');
    }

    const patch: Record<string, any> = {};
    if (dto.weddingDate !== undefined) patch.weddingDate = dto.weddingDate;
    if (dto.timeType !== undefined) patch.timeType = dto.timeType;
    if (dto.hotelName !== undefined) patch.hotelName = dto.hotelName;
    if (dto.coupleName !== undefined) patch.coupleName = dto.coupleName;
    if (dto.notes !== undefined) patch.notes = dto.notes;
    if (dto.projectId !== undefined) patch.projectId = dto.projectId;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    // 撞单检测（排除自身）
    const checkDate = dto.weddingDate ?? row.weddingDate;
    const checkTimeType = (dto.timeType ?? row.timeType) as 'lunch' | 'dinner';
    if (dto.weddingDate !== undefined || dto.timeType !== undefined) {
      const conflicts = await this.findConflicts(
        userId,
        checkDate,
        checkTimeType,
        id,
      );
      if (conflicts.length > 0 && !dto.force) {
        throw new ConflictException('该日期同一时段已有档期安排');
      }
    }

    const result = await this.db
      .update(schedules)
      .set(patch)
      .where(eq(schedules.id, id))
      .returning();

    return this.mapToSchedule(result[0]);
  }

  async delete(id: string, userId: string): Promise<void> {
    const existing = await this.db
      .select()
      .from(schedules)
      .where(eq(schedules.id, id))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('档期不存在');
    }

    if (existing[0].userId !== userId) {
      throw new ForbiddenException('无权限删除此档期');
    }

    await this.db.delete(schedules).where(eq(schedules.id, id));
  }

  async checkConflict(
    userId: string,
    date: string,
    timeType: 'lunch' | 'dinner',
  ): Promise<ScheduleConflictResponse> {
    const conflictSchedules = await this.findConflicts(
      userId,
      date,
      timeType,
      null,
    );
    return {
      hasConflict: conflictSchedules.length > 0,
      conflictSchedules: conflictSchedules.map((row) =>
        this.mapToSchedule(row),
      ),
    };
  }

  private async findConflicts(
    userId: string,
    date: string,
    timeType: string,
    excludeId: string | null,
  ) {
    const conditions: any[] = [
      eq(schedules.userId, userId),
      eq(schedules.weddingDate, date),
      eq(schedules.timeType, timeType),
    ];

    if (excludeId) {
      conditions.push(ne(schedules.id, excludeId));
    }

    return this.db
      .select()
      .from(schedules)
      .where(and(...conditions));
  }

  private mapToSchedule(row: typeof schedules.$inferSelect): Schedule {
    return {
      id: row.id,
      weddingDate: row.weddingDate as string,
      timeType: (row.timeType as 'lunch' | 'dinner') ?? 'dinner',
      hotelName: row.hotelName ?? '',
      coupleName: row.coupleName ?? '',
      notes: row.notes ?? '',
      projectId: row.projectId ?? null,
      source: (row.source as 'manual' | 'auto_from_project') ?? 'manual',
    };
  }

  async findByDateAndTime(
    userId: string,
    weddingDate: string,
    timeType: 'lunch' | 'dinner' = 'dinner',
  ): Promise<Schedule | null> {
    const [row] = await this.db
      .select()
      .from(schedules)
      .where(
        and(
          eq(schedules.userId, userId),
          eq(schedules.weddingDate, weddingDate),
          eq(schedules.timeType, timeType),
        ),
      )
      .limit(1);
    return row ? this.mapToSchedule(row) : null;
  }

  async linkProject(
    scheduleId: string,
    projectId: string,
    userId: string,
  ): Promise<Schedule> {
    const [updated] = await this.db
      .update(schedules)
      .set({ projectId })
      .where(and(eq(schedules.id, scheduleId), eq(schedules.userId, userId)))
      .returning();
    if (!updated) {
      throw new NotFoundException('档期不存在');
    }
    return this.mapToSchedule(updated);
  }

  async unlinkProject(
    scheduleId: string,
    userId: string,
  ): Promise<void> {
    await this.db
      .update(schedules)
      .set({ projectId: null })
      .where(and(eq(schedules.id, scheduleId), eq(schedules.userId, userId)));
  }

  async createAutoFromProject(
    userId: string,
    data: {
      weddingDate: string;
      timeType: 'lunch' | 'dinner';
      hotelName?: string;
      coupleName?: string;
      projectId: string;
    },
  ): Promise<Schedule> {
    const [row] = await this.db
      .insert(schedules)
      .values({
        userId,
        weddingDate: data.weddingDate,
        timeType: data.timeType,
        hotelName: data.hotelName ?? '',
        coupleName: data.coupleName ?? '',
        projectId: data.projectId,
        source: 'auto_from_project',
        notes: '由方案自动关联创建',
      })
      .returning();
    return this.mapToSchedule(row);
  }

  async isAutoFromProject(
    scheduleId: string,
    userId: string,
  ): Promise<boolean> {
    const [row] = await this.db
      .select()
      .from(schedules)
      .where(and(eq(schedules.id, scheduleId), eq(schedules.userId, userId)))
      .limit(1);
    return row?.source === 'auto_from_project';
  }
}
