import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { ScheduleService } from './schedule.service';
import { CreateScheduleDto } from './dto/create-schedule.dto';
import { UpdateScheduleDto } from './dto/update-schedule.dto';
import type {
  Schedule,
  ScheduleConflictResponse,
} from '@shared/api.interface';

@UseGuards(AppAuthGuard)
@Controller('api/schedules')
export class ScheduleController {
  constructor(private readonly scheduleService: ScheduleService) {}

  @Get()
  async getList(
    @Req() req: Request,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ): Promise<Schedule[]> {
    const { userId } = req.userContext;
    return this.scheduleService.getList(userId, startDate, endDate);
  }

  @Get('check-conflict')
  async checkConflict(
    @Req() req: Request,
    @Query('date') date: string,
    @Query('timeType') timeType: 'lunch' | 'dinner',
  ): Promise<ScheduleConflictResponse> {
    const { userId } = req.userContext;
    return this.scheduleService.checkConflict(userId, date, timeType);
  }

  @Get(':id')
  async getDetail(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<Schedule> {
    const { userId } = req.userContext;
    return this.scheduleService.getDetail(id, userId);
  }

  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateScheduleDto,
  ): Promise<Schedule> {
    const { userId } = req.userContext;
    return this.scheduleService.create(dto, userId);
  }

  @Put(':id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<Schedule> {
    const { userId } = req.userContext;
    return this.scheduleService.update(id, dto, userId);
  }

  @Delete(':id')
  async delete(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: boolean }> {
    const { userId } = req.userContext;
    await this.scheduleService.delete(id, userId);
    return { success: true };
  }
}
