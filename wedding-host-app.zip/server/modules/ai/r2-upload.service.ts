import { Injectable, Logger } from '@nestjs/common';
import * as crypto from 'node:crypto';

export interface R2Config {
  accessKeyId: string;
  secretAccessKey: string;
  endpoint: string;
  bucket: string;
  publicDomain: string;
}

export interface R2UploadResult {
  success: boolean;
  url?: string;
  statusCode?: number;
  errorCode?: string;
  errorMessage?: string;
  errorDetail?: string;
  argumentName?: string;
  requestId?: string;
  debugInfo?: {
    url: string;
    method: string;
    signedHeaders: string;
    payloadHash: string;
    contentType: string;
    contentLength: number;
    amzDate: string;
    authorization: string;
    canonicalRequest?: string;
    stringToSign?: string;
  };
}

export interface R2TestResult {
  uploadStep: {
    success: boolean;
    message: string;
    durationMs?: number;
    detail?: string;
    argumentName?: string;
  };
  urlStep: { success: boolean; message: string; durationMs?: number };
  overall: { success: boolean; message: string };
}

@Injectable()
export class R2UploadService {
  private readonly logger = new Logger(R2UploadService.name);

  async uploadImage(
    config: R2Config,
    fileBuffer: Buffer,
    fileName: string,
    contentType: string,
  ): Promise<string> {
    const result = await this.uploadImageDetailed(config, fileBuffer, fileName, contentType);
    if (!result.success || !result.url) {
      throw new Error(
        result.errorMessage || result.errorDetail || 'R2 上传失败',
      );
    }
    return result.url;
  }

  async uploadImageDetailed(
    config: R2Config,
    fileBuffer: Buffer,
    fileName: string,
    contentType: string,
    includeDebug = false,
  ): Promise<R2UploadResult> {
    const endpoint = this.normalizeEndpoint(config.endpoint);
    const bucket = config.bucket.trim();
    const objectKey = fileName.replace(/^\//, '');

    const url = `${endpoint}/${bucket}/${objectKey}`;
    const canonicalUri = this.buildCanonicalUri(bucket, objectKey);

    const now = new Date();
    const dateStamp = now.toISOString().slice(0, 10).replace(/-/g, '');
    const amzDate = this.buildAmzDate(now);
    const region = 'auto';
    const service = 's3';

    const host = new URL(endpoint).host.toLowerCase();
    const payloadHash = crypto
      .createHash('sha256')
      .update(fileBuffer)
      .digest('hex');

    const contentTypeLower = contentType.toLowerCase();

    const magic = this.detectImageMagic(fileBuffer);
    this.logger.log(
      `[R2上传校验] size=${fileBuffer.length}, content-type=${contentTypeLower}, magic=${magic}`,
    );

    const isPng = fileBuffer.length >= 4
      && fileBuffer[0] === 0x89 && fileBuffer[1] === 0x50
      && fileBuffer[2] === 0x4e && fileBuffer[3] === 0x47;
    const isJpeg = fileBuffer.length >= 3
      && fileBuffer[0] === 0xff && fileBuffer[1] === 0xd8
      && fileBuffer[2] === 0xff;
    const isGif = fileBuffer.length >= 3
      && fileBuffer[0] === 0x47 && fileBuffer[1] === 0x49 && fileBuffer[2] === 0x46;
    const isWebp = fileBuffer.length >= 12
      && fileBuffer[0] === 0x52 && fileBuffer[1] === 0x49
      && fileBuffer[2] === 0x46 && fileBuffer[3] === 0x46
      && fileBuffer[8] === 0x57 && fileBuffer[9] === 0x45
      && fileBuffer[10] === 0x42 && fileBuffer[11] === 0x50;

    if (contentTypeLower.startsWith('image/') && !isPng && !isJpeg && !isGif && !isWebp) {
      this.logger.error(
        `[R2上传校验] 失败！Content-Type=${contentTypeLower} 但魔数不匹配，实际前16字节: ${fileBuffer.slice(0, 16).toString('hex').toUpperCase()}`,
      );
      const asciiPreview = fileBuffer.slice(0, 40).toString('ascii').replace(/[\x00-\x1f\x7f]/g, '.');
      this.logger.error(`[R2上传校验] 前40字节ASCII: ${asciiPreview}`);
      throw new Error(
        `图片数据损坏，不是有效的图片文件（魔数=${magic}）`,
      );
    }

    const canonicalHeaders = [
      `content-type:${contentTypeLower}`,
      `host:${host}`,
      `x-amz-content-sha256:${payloadHash}`,
      `x-amz-date:${amzDate}`,
    ].join('\n') + '\n';
    const signedHeaders = 'content-type;host;x-amz-content-sha256;x-amz-date';

    const canonicalQueryString = '';

    const canonicalRequest = [
      'PUT',
      canonicalUri,
      canonicalQueryString,
      canonicalHeaders,
      signedHeaders,
      payloadHash,
    ].join('\n');

    const algorithm = 'AWS4-HMAC-SHA256';
    const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
    const hashedCanonicalRequest = crypto
      .createHash('sha256')
      .update(canonicalRequest, 'utf8')
      .digest('hex');
    const stringToSign = [
      algorithm,
      amzDate,
      credentialScope,
      hashedCanonicalRequest,
    ].join('\n');

    const hmac = (key: Buffer | string, msg: string): Buffer =>
      crypto.createHmac('sha256', key).update(msg, 'utf8').digest();

    const kDate = hmac(`AWS4${config.secretAccessKey}`, dateStamp);
    const kRegion = hmac(kDate, region);
    const kService = hmac(kRegion, service);
    const kSigning = hmac(kService, 'aws4_request');
    const signature = crypto
      .createHmac('sha256', kSigning)
      .update(stringToSign, 'utf8')
      .digest('hex');

    const authorization =
      `${algorithm} Credential=${config.accessKeyId}/${credentialScope}, ` +
      `SignedHeaders=${signedHeaders}, Signature=${signature}`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    const debugInfo = includeDebug
      ? {
          url,
          method: 'PUT',
          signedHeaders,
          payloadHash,
          contentType: contentTypeLower,
          contentLength: fileBuffer.length,
          amzDate,
          authorization,
          canonicalRequest,
          stringToSign,
        }
      : undefined;

    try {
      this.logger.debug(
        `R2 PUT ${url}, content-type=${contentTypeLower}, size=${fileBuffer.length}`,
      );

      const resp = await fetch(url, {
        method: 'PUT',
        headers: {
          'Content-Type': contentTypeLower,
          'X-Amz-Content-Sha256': payloadHash,
          'X-Amz-Date': amzDate,
          Authorization: authorization,
        },
        body: new Uint8Array(fileBuffer),
        signal: controller.signal,
        redirect: 'follow',
      });

      if (!resp.ok) {
        const errText = await resp.text().catch(() => '');
        this.logger.error(
          `R2 上传失败 HTTP ${resp.status}: ${errText.slice(0, 1000)}`,
        );
        if (includeDebug) {
          this.logger.error(
            `R2 debug: url=${url}, amzDate=${amzDate}, payloadHash=${payloadHash}, signedHeaders=${signedHeaders}`,
          );
          this.logger.error(`CanonicalRequest:\n${canonicalRequest}`);
        }

        const parsed = this.parseS3Error(errText);

        return {
          success: false,
          statusCode: resp.status,
          errorCode: parsed.errorCode,
          errorMessage: this.humanizeR2Error(
            resp.status,
            parsed.errorCode,
            parsed.errorMessage,
            parsed.argumentName,
          ),
          errorDetail: errText.slice(0, 2000),
          argumentName: parsed.argumentName,
          requestId: parsed.requestId,
          debugInfo,
        };
      }

      const publicDomain = config.publicDomain.replace(/\/$/, '');
      const publicUrl = `${publicDomain}/${objectKey}`;

      this.logger.debug(`R2 上传成功: ${publicUrl}`);
      return {
        success: true,
        url: publicUrl,
        statusCode: resp.status,
        debugInfo,
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.logger.error(`R2 上传异常: ${msg}`);
      return {
        success: false,
        errorCode: 'NetworkError',
        errorMessage: this.humanizeNetworkError(msg),
        errorDetail: msg,
        debugInfo,
      };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  async testUpload(config: R2Config): Promise<R2TestResult> {
    const testData = Buffer.from('r2-connection-test');
    const testFileName = `_connection_test_${Date.now()}.txt`;
    const startTime = Date.now();

    const uploadResult = await this.uploadImageDetailed(
      config,
      testData,
      testFileName,
      'text/plain',
      true,
    );
    const uploadDuration = Date.now() - startTime;

    let detailMessage = '';
    if (!uploadResult.success && uploadResult.errorMessage) {
      detailMessage = uploadResult.errorMessage;
      if (uploadResult.errorCode && uploadResult.errorCode !== 'InvalidArgument') {
        detailMessage = `[${uploadResult.errorCode}] ${uploadResult.errorMessage}`;
      }
    }

    const uploadStep = {
      success: uploadResult.success,
      message: uploadResult.success
        ? `R2 上传成功 (${uploadDuration}ms)`
        : `R2 上传失败：${uploadResult.errorMessage || '未知错误'}`,
      durationMs: uploadDuration,
      detail: uploadResult.errorDetail || undefined,
      argumentName: uploadResult.argumentName || undefined,
    };

    let urlStep = {
      success: false,
      message: '未测试',
      durationMs: 0,
    };

    if (uploadResult.success && uploadResult.url) {
      const urlStartTime = Date.now();
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);
        try {
          const resp = await fetch(uploadResult.url, {
            method: 'GET',
            signal: controller.signal,
          });
          const urlDuration = Date.now() - urlStartTime;
          if (resp.ok) {
            urlStep = {
              success: true,
              message: `公开 URL 可访问 (${urlDuration}ms)`,
              durationMs: urlDuration,
            };
          } else {
            urlStep = {
              success: false,
              message: `公开 URL 访问失败: HTTP ${resp.status}（请检查 R2 Public Access 和 CORS 配置）`,
              durationMs: urlDuration,
            };
          }
        } finally {
          clearTimeout(timeoutId);
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        urlStep = {
          success: false,
          message: `公开 URL 访问异常：${msg}`,
          durationMs: Date.now() - urlStartTime,
        };
      }
    }

    const overallSuccess = uploadStep.success && urlStep.success;
    return {
      uploadStep,
      urlStep,
      overall: {
        success: overallSuccess,
        message: overallSuccess
          ? 'R2 配置完全正常'
          : uploadStep.success
            ? `上传成功但 URL 访问失败：${urlStep.message}`
            : uploadStep.message,
      },
    };
  }

  private normalizeEndpoint(endpoint: string): string {
    let ep = endpoint.trim().replace(/\/$/, '');
    if (!/^https?:\/\//i.test(ep)) {
      ep = `https://${ep}`;
    }
    return ep;
  }

  private buildAmzDate(date: Date): string {
    const pad = (n: number): string => n.toString().padStart(2, '0');
    const y = date.getUTCFullYear();
    const mo = pad(date.getUTCMonth() + 1);
    const d = pad(date.getUTCDate());
    const h = pad(date.getUTCHours());
    const mi = pad(date.getUTCMinutes());
    const s = pad(date.getUTCSeconds());
    return `${y}${mo}${d}T${h}${mi}${s}Z`;
  }

  private buildCanonicalUri(bucket: string, key: string): string {
    const encodePathSegment = (segment: string): string =>
      encodeURIComponent(segment).replace(/%2F/g, '/');
    const encodedKey = key
      .split('/')
      .map((seg) => encodePathSegment(seg))
      .join('/');
    return `/${bucket}/${encodedKey}`;
  }

  private parseS3Error(xmlBody: string): {
    errorCode: string;
    errorMessage: string;
    argumentName: string;
    requestId: string;
  } {
    if (!xmlBody) return { errorCode: '', errorMessage: '', argumentName: '', requestId: '' };
    const getTag = (tag: string): string => {
      const re = new RegExp(`<${tag}>([^<]+)</${tag}>`, 'i');
      const m = xmlBody.match(re);
      return m ? m[1] : '';
    };
    return {
      errorCode: getTag('Code'),
      errorMessage: getTag('Message'),
      argumentName: getTag('ArgumentName'),
      requestId: getTag('RequestId'),
    };
  }

  private humanizeR2Error(
    statusCode: number,
    errorCode: string,
    rawMessage: string,
    argumentName?: string,
  ): string {
    const code = errorCode.toUpperCase();
    const argInfo = argumentName ? `（参数：${argumentName}）` : '';
    const rawMsgInfo = rawMessage ? `：${rawMessage}` : '';

    switch (code) {
      case 'INVALIDACCESSKEYID':
        return 'Access Key ID 无效或不存在，请检查 R2 Access Key 是否正确' + argInfo;
      case 'SIGNATUREDOESNOTMATCH':
        return '签名不匹配，请检查 Secret Access Key 是否正确' + argInfo;
      case 'INVALIDSECURITY':
        return '密钥无效，请检查 Access Key 和 Secret Key' + argInfo;
      case 'NOSUCHBUCKET':
        return 'Bucket 不存在，请检查 Bucket 名称或 Endpoint 是否正确' + argInfo;
      case 'ACCESSDENIED':
      case 'FORBIDDEN':
        return '访问被拒绝，请确认 R2 令牌具有该 Bucket 的读写权限' + argInfo;
      case 'ENTITYTOOLARGE':
        return '文件过大，超出 R2 单文件大小限制' + argInfo;
      case 'INVALIDARGUMENT':
        return `参数无效${argInfo}${rawMsgInfo}。请检查请求参数是否正确`;
      case 'MALFORMEDXML':
        return '请求体格式错误' + rawMsgInfo;
      case 'INTERNALERROR':
        return 'R2 服务端内部错误，请稍后重试' + argInfo;
      default:
        break;
    }

    if (statusCode === 403) {
      return `403 无权限${rawMsgInfo}。请检查 Access Key / Secret Key 是否正确，以及令牌是否有 Bucket 读写权限`;
    }
    if (statusCode === 404) {
      return `404 未找到${rawMsgInfo}。请检查 Endpoint 地址和 Bucket 名称是否正确`;
    }
    if (statusCode === 400) {
      return `400 请求错误${argInfo}${rawMsgInfo}`;
    }
    if (statusCode >= 500) {
      return `${statusCode} 服务端错误：R2 服务端异常，请稍后重试`;
    }

    return rawMessage || `HTTP ${statusCode} 错误`;
  }

  private humanizeNetworkError(message: string): string {
    if (message.includes('aborted') || message.includes('timeout')) {
      return '连接超时，请检查 Endpoint 地址是否正确、网络是否通畅';
    }
    if (message.includes('ENOTFOUND') || message.includes('getaddrinfo')) {
      return '域名解析失败，请检查 Endpoint 地址是否正确';
    }
    if (message.includes('ECONNREFUSED')) {
      return '连接被拒绝，请检查 Endpoint 端口和地址';
    }
    if (message.includes('certificate') || message.includes('TLS')) {
      return 'SSL/TLS 证书错误，请检查 Endpoint 是否使用正确的 HTTPS 地址';
    }
    return `网络错误：${message}`;
  }

  private detectImageMagic(buffer: Buffer): string {
    if (buffer.length < 4) return 'too-small';
    const hex = buffer.slice(0, 8).toString('hex').toUpperCase();
    if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
      return `PNG (${hex})`;
    }
    if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
      return `JPEG (${hex})`;
    }
    if (buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46) {
      return `GIF (${hex})`;
    }
    if (buffer[0] === 0x52 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x46) {
      return `WebP (${hex})`;
    }
    const str = buffer.slice(0, 20).toString('ascii');
    if (/^[A-Za-z0-9+/=\s]+$/.test(str)) {
      return `base64-text? (${hex})`;
    }
    return `unknown (${hex})`;
  }
}
