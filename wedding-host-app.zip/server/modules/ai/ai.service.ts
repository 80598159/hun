import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { aiQuotas } from '@server/database/schema';
import { eq } from 'drizzle-orm';
import type {
  AiFlowGenerateResponse,
  AiRequirementParseResponse,
  AiRiskDetectRequest,
  AiRiskDetectResponse,
  AiScriptGenerateRequest,
  AiScriptGenerateResponse,
} from '@shared/api.interface';
import type { WeddingProcessTextToJsonOneOutput, WeddingSpeechGenerationOneOutput } from '@shared/plugin-types';
import { LlmRouterService } from './llm-router.service';

const TEXT_TO_JSON_INSTANCE_ID = 'wedding_process_text_to_json_1';
const SPEECH_GENERATION_INSTANCE_ID = 'wedding_speech_generation_1';
const AI_DISCLAIMER =
  'AI生成内容仅为初稿，请主持人人工审核修改，本工具不承担现场使用责任';

const FLOW_GENERATE_SYSTEM_PROMPT = `
【系统指令：你是一位资深婚礼策划师与主持人培训导师】

请根据用户提供的婚礼需求，生成一份**完整、专业、可直接用于现场执行**的婚礼仪式流程方案。

## 硬性要求

### 1. 流程完整性（最重要，不得偷工减料）
生成的 processArrangement 必须是一套**完整的婚礼仪式流程**，环节数量**不少于15个**，必须完整覆盖以下六大环节组，按时间顺序排列：

- 开场暖场类（2-4个）：迎宾暖场/宾客签到、灯光秀、开场视频或快闪短片、主持人开场白/暖场互动
- 入场仪式类（3-5个）：新郎入场、新娘入场（含父亲陪伴/妈妈盖头纱/交接仪式）、新郎迎接新娘、共同入场/挽手入场、登上舞台
- 仪式核心类（4-6个）：婚礼誓言、交换戒指/戴戒指仪式、拥吻、证婚人证婚/主婚人致辞、倒香槟塔/合卺酒/交杯酒、切蛋糕
- 感恩敬茶类（2-4个）：敬茶改口、父母致辞/新人感恩父母、全家人合影
- 互动环节类（2-3个）：手捧花抛送/传递、抽奖游戏或幸运环节、亲友祝福/伴郎伴娘致辞
- 收尾礼成类（2-3个）：礼成退场/新人退场、大合影答谢、答谢宴开席/宣布开席

### 2. 风格智能适配
根据用户描述的婚礼风格（中式/西式/户外/简约/复古/森系等）智能匹配特色环节：
- 中式婚礼：拜天地、掀盖头、跨火盆、敬茶改口、合卺酒等传统环节
- 户外婚礼：First Look、第一支舞、草坪仪式、气球放飞等
- 晚宴婚礼：烛光仪式、星空背景、after party 等
- 简约婚礼：环节精简但核心仪式完整，不能遗漏入场/誓言/戒指/敬茶
- 绝对不能只生成3-5个环节的极简简陋流程

### 3. 每个环节必填字段
processArrangement 数组中每一项都必须包含：
- event：环节名称（简洁明确）
- duration：预计时长（分钟，整数，总时长控制在40-70分钟之间）
- time：建议时间点（HH:mm格式）
- bgmSuggest：推荐背景音乐曲名或风格（如"婚礼进行曲-门德尔松"、"轻音乐-卡农"）
- hostTip：主持人主持要点/提示/注意事项（一句话）
- personInCharge：负责人（可选）
- location：地点（可选）

### 4. 输出要求
- 严格按照指定的JSON结构输出
- 流程按时间先后顺序排列
- 日期YYYY-MM-DD，时间HH:mm
- 数值字段为数字类型，布尔字段为true/false
- 未找到的字段填空字符串、0或false

---

【用户的婚礼需求如下】
`;

interface StandardStepTemplate {
  stepName: string;
  duration: number;
  bgmSuggest: string;
  hostTip: string;
  category: '暖场' | '入场' | '仪式' | '感恩' | '互动' | '收尾';
  tags: string[];
}

const STANDARD_FLOW_TEMPLATE: StandardStepTemplate[] = [
  { stepName: '宾客签到与迎宾暖场', duration: 5, bgmSuggest: '轻音乐-轻松愉悦钢琴曲', hostTip: '播放轻松音乐，引导宾客就座', category: '暖场', tags: ['通用'] },
  { stepName: '灯光秀', duration: 2, bgmSuggest: '大气开场音乐-史诗感', hostTip: '灯光配合音乐渐强，营造仪式氛围', category: '暖场', tags: ['通用', '晚宴'] },
  { stepName: '开场视频/快闪短片', duration: 3, bgmSuggest: '新人专属背景音乐', hostTip: '视频播放时保持安静，结尾时灯光渐亮', category: '暖场', tags: ['通用'] },
  { stepName: '主持人开场白', duration: 3, bgmSuggest: '背景音乐压低', hostTip: '问候来宾、介绍新人、宣布仪式开始', category: '暖场', tags: ['通用'] },
  { stepName: '新郎入场', duration: 2, bgmSuggest: '新郎入场音乐', hostTip: '新郎从侧台入场，挥手致意，走向舞台中央', category: '入场', tags: ['通用'] },
  { stepName: '新娘入场（父亲陪伴交接）', duration: 4, bgmSuggest: '婚礼进行曲-门德尔松', hostTip: '新娘挽父亲手臂入场，新郎走下舞台迎接，父亲交接', category: '入场', tags: ['通用', '西式'] },
  { stepName: '新郎迎接新娘', duration: 2, bgmSuggest: '浪漫抒情音乐', hostTip: '新郎献花、告白，单膝跪地求婚仪式', category: '入场', tags: ['通用'] },
  { stepName: '新人共同入场', duration: 2, bgmSuggest: '婚礼进行曲-瓦格纳', hostTip: '新人挽手共同走向舞台，来宾掌声欢迎', category: '入场', tags: ['通用'] },
  { stepName: '婚礼誓言', duration: 5, bgmSuggest: '抒情轻音乐', hostTip: '新人面对面，分别说出爱的誓言，保持真诚氛围', category: '仪式', tags: ['通用'] },
  { stepName: '交换戒指', duration: 3, bgmSuggest: '神圣感音乐', hostTip: '伴郎伴娘送上戒指，新人互相佩戴，展示给来宾', category: '仪式', tags: ['通用'] },
  { stepName: '新人拥吻', duration: 1, bgmSuggest: '高潮音乐配合', hostTip: '倒数3-2-1，邀请新人拥吻，全场欢呼', category: '仪式', tags: ['通用'] },
  { stepName: '证婚人证婚', duration: 3, bgmSuggest: '庄重背景音乐', hostTip: '邀请证婚人上台致辞，见证婚姻', category: '仪式', tags: ['通用'] },
  { stepName: '倒香槟塔/交杯酒', duration: 3, bgmSuggest: '轻快浪漫音乐', hostTip: '新人共倒香槟塔或饮交杯酒，寓意甜蜜美满', category: '仪式', tags: ['通用', '西式'] },
  { stepName: '敬茶改口', duration: 5, bgmSuggest: '温馨亲情音乐', hostTip: '新人向双方父母敬茶，改口叫爸妈，父母给红包', category: '感恩', tags: ['通用', '中式'] },
  { stepName: '父母致辞', duration: 4, bgmSuggest: '感动温情音乐', hostTip: '双方父母代表上台致辞，表达祝福与嘱托', category: '感恩', tags: ['通用'] },
  { stepName: '全家人合影', duration: 2, bgmSuggest: '温馨音乐', hostTip: '新人与双方父母全家上台合影留念', category: '感恩', tags: ['通用'] },
  { stepName: '手捧花抛送', duration: 3, bgmSuggest: '欢快活泼音乐', hostTip: '邀请未婚女生上台，新娘背身抛手捧花', category: '互动', tags: ['通用'] },
  { stepName: '幸运抽奖/互动游戏', duration: 5, bgmSuggest: '欢乐互动音乐', hostTip: '主持人带动全场互动抽奖，活跃气氛', category: '互动', tags: ['通用'] },
  { stepName: '礼成退场', duration: 2, bgmSuggest: '喜庆热烈退场音乐', hostTip: '宣布婚礼礼成，新人手牵手退场，来宾撒花祝福', category: '收尾', tags: ['通用'] },
  { stepName: '大合影答谢', duration: 3, bgmSuggest: '欢乐音乐', hostTip: '新人重返舞台，与全体来宾大合影留念', category: '收尾', tags: ['通用'] },
  { stepName: '答谢宴开席', duration: 1, bgmSuggest: '轻快用餐音乐', hostTip: '主持人宣布婚宴开始，祝大家用餐愉快', category: '收尾', tags: ['通用'] },
];

const CORE_STEP_KEYWORDS = ['誓言', '戒指', '入场', '敬茶'];

const FALLBACK_SCRIPTS: Record<string, string> = {
  '主持人开场白': '尊敬的各位来宾、各位亲朋好友，大家好！\n\n今天是一个特别的日子，我们欢聚一堂，共同见证一对新人的幸福时刻。我是今天的婚礼主持人，非常荣幸能够与在座的每一位，共同分享这份喜悦与感动。\n\n此刻，宴会厅内灯光璀璨、高朋满座。让我们用最热烈的掌声，有请今天最幸福的新郎，闪亮登场！',
  '新郎誓言': '亲爱的，从遇见你的那一刻起，我就知道，你是我一生要守护的人。\n\n感谢你走进我的生命，给我带来那么多温暖和快乐。从今以后，我会用全部的爱去呵护你、陪伴你。无论顺境还是逆境，无论贫穷还是富有，无论健康还是疾病，我都会紧握你的手，一起走过人生的每一个春夏秋冬。\n\n我爱你，今天爱，明天爱，永远爱。',
  '新娘誓言': '亲爱的，谢谢你出现在我的生命里。\n\n和你在一起的每一天，我都觉得自己是世界上最幸福的人。你给我的不仅是爱情，还有归属感和安全感。我愿意与你一起，面对未来的风风雨雨，分享生活中的点点滴滴。\n\n我会做你最坚强的后盾，也会做你最温柔的港湾。执子之手，与子偕老。我爱你。',
  '父母致辞': '各位来宾、各位亲朋好友，大家好！\n\n今天是我孩子大喜的日子，我的心情无比激动。首先，感谢各位在百忙之中前来参加婚礼，你们的到来是对孩子最好的祝福。\n\n孩子们，从今天起，你们组成了自己的小家庭。爸爸妈妈希望你们在今后的日子里，互相理解、互相包容、互相关心、互相支持。经营好自己的婚姻和家庭，好好工作、好好生活。\n\n最后，再次感谢各位来宾的光临，希望大家今天吃得开心、喝得尽兴！',
  '证婚词': '各位来宾、各位亲友，大家好！\n\n今天，我受两位新人的委托，担任他们的证婚人，感到非常荣幸。\n\n爱情是美好的，而婚姻则是爱情的升华与责任的开始。此刻，我见证了两位新人从相识、相知到相爱的历程。他们的感情真挚而坚定，他们的结合是天作之合。\n\n现在，我郑重地向大家宣布：这对新人的婚姻，合法有效！愿你们白头偕老，永结同心！',
  '交杯酒主持词': '爱情是甜蜜的，而婚姻，就像这杯美酒，需要两个人共同品尝、共同回味。\n\n接下来，请工作人员呈上美酒。有请新人面对面，举起你们手中的酒杯——\n\n这第一杯，敬相遇，感谢茫茫人海中，你们找到了彼此；\n这第二杯，敬相守，愿你们在未来的岁月里，同甘共苦，不离不弃；\n这第三杯，敬永恒，愿你们的爱情，如这美酒般，越陈越香，越久越浓。\n\n来，干杯！',
  '敬茶主持词': '俗话说，水有源，树有根。儿女不忘养育恩。\n\n今天，两位新人组成了自己的小家庭，但永远不会忘记的，是父母的养育之情。接下来，将进行敬茶改口仪式。\n\n首先，请新娘为公公婆婆敬茶。一杯清茶表孝心，从此就是一家人。\n\n（新娘敬茶）\n好，爸妈请喝茶！——哎，好儿媳妇！\n\n接下来，请新郎为岳父岳母敬茶。从今以后，你们就是彼此父母共同的孩子。\n\n（新郎敬茶）\n好，爸妈请喝茶！——哎，好女婿！',
  '手捧花环节': '接下来，是大家非常期待的手捧花环节！\n\n据说，在婚礼上接到新娘手捧花的人，将会是下一个步入婚姻殿堂的幸运儿。\n\n那现在，我想邀请在场所有还没有结婚的姑娘们，来到舞台前方。来，别害羞，幸福要靠自己争取！\n\n好，所有的美女都就位了。新娘，准备好了吗？我倒数三个数——3，2，1——抛！',
  '婚礼结束语': '亲爱的朋友们，美好的时光总是短暂的，但幸福的记忆却是永恒的。\n\n今天，我们共同见证了一对新人最幸福的时刻。让我们再次用热烈的掌声，祝福新人：新婚快乐，百年好合，早生贵子，永结同心！\n\n现在我宣布：婚礼仪式圆满礼成！让我们共同举杯，为新人的幸福未来，干杯！',
  '开场白': '尊敬的各位来宾、各位亲朋好友，大家好！\n\n今天是一个充满爱与喜悦的日子。我们在这里，共同见证一对新人的幸福结合。我是今天的主持人，很荣幸能够与大家一起，分享这份甜蜜与感动。\n\n此刻，让我们屏住呼吸，用最热烈的掌声，有请今天最帅气的新郎，登场！',
  '感恩父母': '有一句话说得好：谁言寸草心，报得三春晖。\n\n从我们呱呱坠地，到长大成人，父母付出了无数的心血。今天，儿女成家了，最开心、最欣慰的，莫过于爸爸妈妈。\n\n接下来，有请双方父母上台。新人，请面向父母，深深一鞠躬——\n\n一鞠躬，感谢父母生育之恩；\n再鞠躬，感谢父母养育之情；\n三鞠躬，祝福父母身体健康，福寿绵长！',
  '退场词': '各位来宾，各位亲友，婚礼仪式到这里就圆满礼成了。\n\n让我们再一次用最热烈的掌声，欢送新人步入幸福的新篇章！\n\n愿你们三冬暖，愿你们春不寒；愿你们天黑有灯，下雨有伞；愿你们一路上，有良人相伴。\n\n祝福你们，新婚快乐！',
};

function getFallbackScript(speechType: string, speechStyle: string): string {
  const key = speechType || '开场白';
  const content = FALLBACK_SCRIPTS[key] || FALLBACK_SCRIPTS['开场白'] || '';
  if (speechStyle === '幽默搞笑') {
    return content + '\n\n（温馨提示：以上为标准版本，幽默风格建议在AI可用时重新生成）';
  }
  return content;
}

function validateAndSupplementFlow(
  flowList: { stepName: string; duration: number; bgmSuggest: string; hostTip: string }[],
): { flowList: { stepName: string; duration: number; bgmSuggest: string; hostTip: string }[]; wasSupplemented: boolean; supplementedCount: number } {
  const existingNames = new Set(flowList.map((s) => s.stepName));
  const missingCore: string[] = [];

  for (const keyword of CORE_STEP_KEYWORDS) {
    const hasCore = flowList.some((s) => s.stepName.includes(keyword));
    if (!hasCore) {
      missingCore.push(keyword);
    }
  }

  const needSupplement = flowList.length < 8 || missingCore.length > 0;
  if (!needSupplement) {
    return { flowList, wasSupplemented: false, supplementedCount: 0 };
  }

  const supplemented = [...flowList];
  let addedCount = 0;

  for (const template of STANDARD_FLOW_TEMPLATE) {
    const alreadyHas = supplemented.some(
      (s) => s.stepName.includes(template.stepName.slice(0, 4)) ||
             template.stepName.includes(s.stepName.slice(0, 4)),
    );
    if (!alreadyHas) {
      supplemented.push({
        stepName: template.stepName,
        duration: template.duration,
        bgmSuggest: template.bgmSuggest,
        hostTip: template.hostTip,
      });
      addedCount += 1;
    }
  }

  const categories: Record<string, number> = {
    暖场: 0, 入场: 1, 仪式: 2, 感恩: 3, 互动: 4, 收尾: 5,
  };
  const getCat = (name: string): number => {
    if (/暖场|迎宾|签到|灯光秀|开场|视频|快闪|开场白/.test(name)) return 0;
    if (/入场|迎接|交接|盖头纱|登上|上台/.test(name)) return 1;
    if (/誓言|戒指|拥吻|证婚|香槟|蛋糕|合卺|交杯|拜天地|掀盖头|火盆/.test(name)) return 2;
    if (/敬茶|父母|感恩|致辞|合影/.test(name)) return 3;
    if (/手捧|抽奖|游戏|互动|祝福|才艺|伴郎|伴娘/.test(name)) return 4;
    if (/礼成|退场|开席|答谢|大合影/.test(name)) return 5;
    return 2;
  };

  supplemented.sort((a, b) => getCat(a.stepName) - getCat(b.stepName));

  return { flowList: supplemented, wasSupplemented: true, supplementedCount: addedCount };
}

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly llmRouter: LlmRouterService,
  ) {}

  private readonly scriptRateLimiter = new Map<string, number>();
  private readonly flowRateLimiter = new Map<string, number>();
  private readonly SCRIPT_RATE_LIMIT_MS = 10 * 1000;
  private readonly FLOW_RATE_LIMIT_MS = 10 * 1000;

  private parseJsonResponse<T>(text: string): T {
    let cleaned = text.trim();
    const jsonMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (jsonMatch) {
      cleaned = jsonMatch[1].trim();
    }
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      cleaned = cleaned.slice(firstBrace, lastBrace + 1);
    }
    try {
      return JSON.parse(cleaned) as T;
    } catch {
      this.logger.warn(`JSON解析失败，原始内容前300字：${text.slice(0, 300)}`);
      throw new Error('AI返回内容无法解析为JSON');
    }
  }

  private getCurrentMonthStart(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}-01`;
  }

  private async getOrCreateQuota(userId: string) {
    const existing = await this.db
      .select()
      .from(aiQuotas)
      .where(eq(aiQuotas.userId, userId))
      .limit(1);

    if (existing.length > 0) {
      const quota = existing[0];
      const monthStart = this.getCurrentMonthStart();
      const resetDateStr = String(quota.resetDate).slice(0, 10);

      if (resetDateStr < monthStart) {
        const [updated] = await this.db
          .update(aiQuotas)
          .set({
            flowGenerateCount: 0,
            scriptGenerateCount: 0,
            resetDate: monthStart,
          })
          .where(eq(aiQuotas.id, quota.id))
          .returning();
        return updated;
      }
      return quota;
    }

    const [created] = await this.db
      .insert(aiQuotas)
      .values({ userId })
      .returning();
    return created;
  }

  private async checkAndConsumeFlow(userId: string): Promise<void> {
    const quota = await this.getOrCreateQuota(userId);
    const remaining =
      (quota.monthlyFlowQuota ?? 0) +
      (quota.totalFlowQuota ?? 0) -
      (quota.flowGenerateCount ?? 0);
    if (remaining <= 0) {
      throw new HttpException(
        {
          message: '流程生成额度不足，请前往商店购买',
          remaining: 0,
        },
        HttpStatus.PAYMENT_REQUIRED,
      );
    }
    await this.db
      .update(aiQuotas)
      .set({ flowGenerateCount: (quota.flowGenerateCount ?? 0) + 1 })
      .where(eq(aiQuotas.id, quota.id));
  }

  private async checkAndConsumeScript(userId: string): Promise<void> {
    const quota = await this.getOrCreateQuota(userId);
    const remaining =
      (quota.monthlyScriptQuota ?? 0) +
      (quota.totalScriptQuota ?? 0) -
      (quota.scriptGenerateCount ?? 0);
    if (remaining <= 0) {
      throw new HttpException(
        {
          message: '台词生成额度不足，请前往商店购买',
          remaining: 0,
        },
        HttpStatus.PAYMENT_REQUIRED,
      );
    }
    await this.db
      .update(aiQuotas)
      .set({ scriptGenerateCount: (quota.scriptGenerateCount ?? 0) + 1 })
      .where(eq(aiQuotas.id, quota.id));
  }

  async getRemainingFlow(userId: string): Promise<number> {
    const quota = await this.getOrCreateQuota(userId);
    return (
      (quota.monthlyFlowQuota ?? 0) +
      (quota.totalFlowQuota ?? 0) -
      (quota.flowGenerateCount ?? 0)
    );
  }

  async getRemainingScript(userId: string): Promise<number> {
    const quota = await this.getOrCreateQuota(userId);
    return (
      (quota.monthlyScriptQuota ?? 0) +
      (quota.totalScriptQuota ?? 0) -
      (quota.scriptGenerateCount ?? 0)
    );
  }

  private async rollbackFlow(userId: string): Promise<void> {
    const quota = await this.getOrCreateQuota(userId);
    if ((quota.flowGenerateCount ?? 0) > 0) {
      await this.db
        .update(aiQuotas)
        .set({ flowGenerateCount: (quota.flowGenerateCount ?? 0) - 1 })
        .where(eq(aiQuotas.id, quota.id));
    }
  }

  async generateFlow(
    userId: string,
    description: string,
  ): Promise<AiFlowGenerateResponse & { aiDisclaimer: string }> {
    if (!description || description.trim().length === 0) {
      throw new BadRequestException('请输入婚礼需求描述');
    }

    const now = Date.now();
    const lastFlow = this.flowRateLimiter.get(userId) ?? 0;
    const waitMs = this.FLOW_RATE_LIMIT_MS - (now - lastFlow);
    if (waitMs > 0) {
      const waitSec = Math.ceil(waitMs / 1000);
      throw new HttpException(
        {
          message: `生成太频繁，请${waitSec}秒后再试`,
          retryAfter: waitSec,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    await this.checkAndConsumeFlow(userId);

    const enhancedInput = FLOW_GENERATE_SYSTEM_PROMPT + '\n' + description;

    let result: WeddingProcessTextToJsonOneOutput;
    let usedFallback = false;
    try {
      const llmResult = await this.llmRouter.chatComplete(
        [
          { role: 'system', content: '你是一位资深婚礼策划师与主持人培训导师。请根据用户的婚礼需求，生成一份完整专业的婚礼仪式流程方案。输出必须是严格的JSON格式，不要包含任何额外的解释文字。' },
          { role: 'user', content: enhancedInput },
        ],
        { temperature: 0.7, maxTokens: 4000, responseFormat: 'json' },
      );
      result = this.parseJsonResponse<WeddingProcessTextToJsonOneOutput>(llmResult.content);
    } catch (error) {
      this.logger.warn('AI流程生成失败，使用本地兜底模板', error instanceof Error ? error.message : '');
      usedFallback = true;
      result = {
        basicInfo: {},
        coupleInfo: {},
        vendorList: [],
        itemList: [],
        riskDetection: [],
        budgetEstimate: {},
        processArrangement: STANDARD_FLOW_TEMPLATE.map((t) => ({
          event: t.stepName,
          duration: t.duration,
          bgmSuggest: t.bgmSuggest,
          hostTip: t.hostTip,
          category: t.category,
        })) as unknown[],
      } as WeddingProcessTextToJsonOneOutput;
    }

    const processArr = Array.isArray(result.processArrangement)
      ? result.processArrangement
      : [];
    const basicInfo = result.basicInfo ?? {};

    const rawFlowList = processArr.map((item: unknown) => {
      const obj = item as Record<string, unknown>;
      const tipParts: string[] = [];
      if (obj.hostTip) {
        tipParts.push(String(obj.hostTip));
      }
      if (obj.time) {
        tipParts.push(`时间：${String(obj.time)}`);
      }
      if (obj.personInCharge) {
        tipParts.push(`负责人：${String(obj.personInCharge)}`);
      }
      if (obj.location) {
        tipParts.push(`地点：${String(obj.location)}`);
      }
      return {
        stepName: String(obj.event ?? ''),
        duration: Number(obj.duration) || 5,
        bgmSuggest: String(obj.bgmSuggest ?? ''),
        hostTip: tipParts.join('；'),
      };
    }).filter((s) => s.stepName && s.stepName.trim().length > 0);

    const { flowList, wasSupplemented, supplementedCount } =
      validateAndSupplementFlow(rawFlowList);

    const totalMinutes = flowList.reduce(
      (sum: number, s) => sum + (s.duration || 0),
      0,
    );

    let specialTip = '';
    if (wasSupplemented) {
      specialTip = `AI生成环节不完整，已自动补齐${supplementedCount}个标准环节，请人工审核调整顺序`;
    }

    const weddingTime = String(basicInfo.weddingTime ?? '');
    const timeType = weddingTime && parseInt(weddingTime.split(':')[0] || '0', 10) < 14
      ? 'lunch'
      : 'dinner';

    this.flowRateLimiter.set(userId, Date.now());

    return {
      weddingInfo: {
        timeType,
        totalMinutes,
        specialTip,
      },
      flowList,
      aiDisclaimer: AI_DISCLAIMER,
    };
  }

  async generateScript(
    userId: string,
    req: AiScriptGenerateRequest,
  ): Promise<AiScriptGenerateResponse & { aiDisclaimer: string }> {
    const description = req.keyInformation?.trim() || req.additionalRequirements?.trim();
    if (!req.speechType || !req.speechType.trim()) {
      throw new BadRequestException('请选择台词类型');
    }
    if (req.operationType === 'generate' && !description) {
      throw new BadRequestException('请描述您想要的台词风格或内容');
    }
    const isGenerate = req.operationType === 'generate' || req.operationType === '生成新台词';
    if (!isGenerate && !req.originalContent?.trim()) {
      throw new BadRequestException('请提供原始台词内容');
    }

    const now = Date.now();
    const lastGen = this.scriptRateLimiter.get(userId) ?? 0;
    const waitMs = this.SCRIPT_RATE_LIMIT_MS - (now - lastGen);
    if (waitMs > 0) {
      const waitSec = Math.ceil(waitMs / 1000);
      throw new HttpException(
        {
          message: `生成太频繁，请${waitSec}秒后再试`,
          retryAfter: waitSec,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    await this.checkAndConsumeScript(userId);

    let result: WeddingSpeechGenerationOneOutput;
    try {
      const sysPrompt = '你是一位资深婚礼主持人与台词创作专家。请根据用户要求创作或改写婚礼台词，输出为纯文本格式的台词内容，不要任何JSON包装、不要标题、直接输出完整台词正文。';
      const userPrompt = `
台词类型：${req.speechType}
风格：${req.speechStyle || '温馨感人'}
关键信息：${req.keyInformation || ''}
长度要求：${req.lengthRequirement || ''}
操作类型：${req.operationType || '生成新台词'}
${req.originalContent ? `原始内容：\n${req.originalContent}` : ''}
${req.additionalRequirements ? `额外要求：${req.additionalRequirements}` : ''}
`.trim();

      const llmResult = await this.llmRouter.chatComplete(
        [
          { role: 'system', content: sysPrompt },
          { role: 'user', content: userPrompt },
        ],
        { temperature: 0.8, maxTokens: 3000 },
      );
      result = { content: llmResult.content } as WeddingSpeechGenerationOneOutput;
    } catch (error) {
      this.logger.warn('AI台词生成失败，使用本地兜底模板', error instanceof Error ? error.message : '');
      const fallbackContent = getFallbackScript(req.speechType, req.speechStyle);
      result = { content: fallbackContent } as WeddingSpeechGenerationOneOutput;
    }

    const content = (result.content || result.response || '').trim();
    if (!content) {
      this.scriptRateLimiter.delete(userId);
      await this.rollbackScript(userId);
      throw new BadRequestException('AI生成内容为空，请重试');
    }

    const firstLine = content.split(/[\n。！？]/).filter((s) => s.trim()).slice(0, 1)[0] || '';
    const title = firstLine.slice(0, 30) || 'AI生成台词';

    this.scriptRateLimiter.set(userId, Date.now());

    return {
      title,
      content,
      category: 'my',
      aiDisclaimer: AI_DISCLAIMER,
    };
  }

  private async rollbackScript(userId: string): Promise<void> {
    const quota = await this.getOrCreateQuota(userId);
    if ((quota.scriptGenerateCount ?? 0) > 0) {
      await this.db
        .update(aiQuotas)
        .set({ scriptGenerateCount: (quota.scriptGenerateCount ?? 0) - 1 })
        .where(eq(aiQuotas.id, quota.id));
    }
  }

  async checkScriptQuota(userId: string): Promise<{
    canUse: boolean;
    remaining: number;
    remainingScript: number;
    type: string;
  }> {
    const remaining = await this.getRemainingScript(userId);
    return {
      canUse: remaining > 0,
      remaining,
      remainingScript: remaining,
      type: 'script',
    };
  }

  async consumeScript(userId: string): Promise<{
    success: boolean;
    remaining: number;
  }> {
    await this.checkAndConsumeScript(userId);
    const remaining = await this.getRemainingScript(userId);
    return { success: true, remaining };
  }

  async parseRequirement(
    userId: string,
    text: string,
  ): Promise<AiRequirementParseResponse & { aiDisclaimer: string }> {
    if (!text || text.trim().length === 0) {
      throw new BadRequestException('请输入需求文本');
    }

    await this.checkAndConsumeFlow(userId);

    let result: WeddingProcessTextToJsonOneOutput;
    try {
      const sysPrompt = '你是一位婚礼需求分析专家。请从用户的婚礼需求描述中提取关键信息，输出严格的JSON格式，包含coupleInfo（新郎新娘信息）和basicInfo（婚礼基本信息）。不要任何额外解释。';
      const userPrompt = `请从以下婚礼需求描述中提取结构化信息：\n\n${text}\n\n输出JSON字段：\n- coupleInfo.groomName: 新郎姓名\n- coupleInfo.brideName: 新娘姓名\n- coupleInfo.specialRequirement: 新人的特殊要求\n- basicInfo.weddingDate: 婚礼日期(YYYY-MM-DD)\n- basicInfo.weddingTime: 午宴/晚宴(lunch/dinner)\n- basicInfo.location: 酒店或场地名称\n- basicInfo.style: 婚礼风格`;

      const llmResult = await this.llmRouter.chatComplete(
        [
          { role: 'system', content: sysPrompt },
          { role: 'user', content: userPrompt },
        ],
        { temperature: 0.3, maxTokens: 1000, responseFormat: 'json' },
      );
      result = this.parseJsonResponse<WeddingProcessTextToJsonOneOutput>(llmResult.content);
    } catch (error) {
      this.logger.error('AI需求解析失败', error);
      await this.rollbackFlow(userId);
      throw new BadRequestException('AI需求解析失败，请稍后重试');
    }

    const coupleInfo = result.coupleInfo ?? {};
    const basicInfo = result.basicInfo ?? {};

    return {
      groomName: String(coupleInfo.groomName ?? ''),
      brideName: String(coupleInfo.brideName ?? ''),
      weddingDate: String(basicInfo.weddingDate ?? ''),
      timeType: String(basicInfo.weddingTime ?? 'dinner'),
      hotelName: String(basicInfo.location ?? ''),
      style: String(basicInfo.style ?? ''),
      specialRequirements: String(coupleInfo.specialRequirement ?? ''),
      parentsOnStage: false,
      tabooLinks: [],
      aiDisclaimer: AI_DISCLAIMER,
    };
  }

  async detectRisk(
    userId: string,
    flowList: AiRiskDetectRequest['flowList'],
    weddingInfo: AiRiskDetectRequest['weddingInfo'],
  ): Promise<AiRiskDetectResponse & { aiDisclaimer: string }> {
    await this.checkAndConsumeFlow(userId);

    const description =
      `婚礼总时长：${weddingInfo.totalMinutes}分钟，时段：${weddingInfo.timeType}\n` +
      `流程安排：\n${flowList
        .map(
          (step: { stepName: string; duration: number; hostTip: string }) =>
            `- ${step.stepName}（${step.duration}分钟）${step.hostTip ? `：${step.hostTip}` : ''}`,
        )
        .join('\n')}`;

    let result: WeddingProcessTextToJsonOneOutput;
    try {
      const sysPrompt = '你是一位资深婚礼风险管控专家。请分析婚礼流程安排，识别潜在风险点并给出建议。输出严格的JSON格式，包含riskDetection数组。不要任何额外解释。';
      const userPrompt = `请分析以下婚礼流程安排中的潜在风险：\n\n${description}\n\n输出JSON格式：\n{\n  "riskDetection": [\n    {\n      "riskLevel": "高/中/低",\n      "riskContent": "风险描述",\n      "suggestion": "改进建议"\n    }\n  ]\n}`;

      const llmResult = await this.llmRouter.chatComplete(
        [
          { role: 'system', content: sysPrompt },
          { role: 'user', content: userPrompt },
        ],
        { temperature: 0.5, maxTokens: 2000, responseFormat: 'json' },
      );
      result = this.parseJsonResponse<WeddingProcessTextToJsonOneOutput>(llmResult.content);
    } catch (error) {
      this.logger.error('AI风险检测失败', error);
      await this.rollbackFlow(userId);
      throw new BadRequestException('AI风险检测失败，请稍后重试');
    }

    const riskArr = Array.isArray(result.riskDetection)
      ? result.riskDetection
      : [];

    const risks = riskArr.map((item: unknown) => {
      const obj = item as Record<string, unknown>;
      return {
        level: String(obj.riskLevel ?? '中'),
        content: String(obj.riskContent ?? ''),
        suggestion: String(obj.suggestion ?? ''),
      };
    });

    return {
      risks,
      aiDisclaimer: AI_DISCLAIMER,
    };
  }
}
