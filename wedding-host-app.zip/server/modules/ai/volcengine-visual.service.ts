import { Injectable, Logger } from '@nestjs/common';
import * as crypto from 'node:crypto';

interface VolcengineVisualConfig {
  accessKey: string;
  secretKey: string;
  region: string;
  endpoint: string;
}

@Injectable()
export class VolcengineVisualService {
  private readonly logger = new Logger(VolcengineVisualService.name);

  parseConfig(baseUrl: string, apiKey: string, appId?: string): VolcengineVisualConfig {
    const parts = apiKey.split(':');
    const accessKey = parts[0] || '';
    const secretKey = parts[1] || parts[0] || '';
    const endpoint = baseUrl.trim() || 'https://visual.volcengineapi.com';
    const region = appId?.trim() || 'cn-north-1';
    return { accessKey, secretKey, region, endpoint };
  }

  private hmacSha256(key: Buffer | string, msg: string): Buffer {
    return crypto.createHmac('sha256', key).update(msg, 'utf8').digest();
  }

  private getSignature(
    method: string,
    path: string,
    query: Record<string, string>,
    headers: Record<string, string>,
    body: string,
    config: VolcengineVisualConfig,
    service: string,
  ): string {
    const now = new Date();
    const date = now.toISOString().slice(0, 10).replace(/-/g, '');

    const signedHeaders = Object.keys(headers).sort().join(';');
    const canonicalQuery = Object.keys(query).sort()
      .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(query[k])}`)
      .join('&');
    const payloadHash = crypto.createHash('sha256').update(body, 'utf8').digest('hex');
    const canonicalHeaders = Object.entries(headers).sort((a, b) => a[0].localeCompare(b[0]))
      .map(([k, v]) => `${k.toLowerCase()}:${v.trim()}\n`).join('');

    const canonicalRequest = [
      method.toUpperCase(),
      path,
      canonicalQuery,
      canonicalHeaders,
      signedHeaders,
      payloadHash,
    ].join('\n');

    const algorithm = 'HMAC-SHA256';
    const credentialScope = `${date}/${config.region}/${service}/request`;
    const hash = crypto.createHash('sha256').update(canonicalRequest, 'utf8').digest('hex');
    const stringToSign = `${algorithm}\n${date}T000000Z\n${credentialScope}\n${hash}`;

    const kDate = this.hmacSha256(config.secretKey, date);
    const kRegion = this.hmacSha256(kDate, config.region);
    const kService = this.hmacSha256(kRegion, service);
    const kSigning = this.hmacSha256(kService, 'request');
    const signature = crypto
      .createHmac('sha256', kSigning)
      .update(stringToSign, 'utf8')
      .digest('hex');

    return `${algorithm} Credential=${config.accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  }

  async testConnection(config: VolcengineVisualConfig): Promise<{ success: boolean; message: string }> {
    try {
      const service = 'visual';
      const path = '/';
      const query: Record<string, string> = {
        Action: 'SegmentBody',
        Version: '2020-08-26',
      };
      const body = JSON.stringify({ image_url: 'https://test-1254859775.cos.ap-shanghai.myqcloud.com/test/portrait.jpg' });
      const contentSha = crypto.createHash('sha256').update(body, 'utf8').digest('hex');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        Host: 'visual.volcengineapi.com',
        'X-Date': new Date().toISOString().replace(/[-:T]/g, '').slice(0, 16) + 'Z',
        'X-Content-Sha256': contentSha,
      };

      const auth = this.getSignature('POST', path, query, headers, body, config, service);
      headers['Authorization'] = auth;

      const url = `${config.endpoint}/?${Object.entries(query)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&')}`;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);
      const resp = await fetch(url, { method: 'POST', headers, body, signal: controller.signal });
      clearTimeout(timeoutId);

      if (!resp.ok) {
        const text = await resp.text().catch(() => '');
        if (resp.status === 400 || resp.status === 401 || resp.status === 403) {
          return { success: false, message: `鉴权失败 HTTP ${resp.status}: ${text.slice(0, 200)}` };
        }
        return { success: false, message: `HTTP ${resp.status}: ${text.slice(0, 200)}` };
      }

      const data = await resp.json() as any;
      if (data?.ResponseMetadata?.Error) {
        return { success: false, message: data.ResponseMetadata.Error.Message || 'API调用返回错误' };
      }
      return { success: true, message: '连接成功，火山引擎抠图可正常调用' };
    } catch (err: any) {
      return { success: false, message: err?.message || '连接异常' };
    }
  }

  async removeBackground(
    config: VolcengineVisualConfig,
    imageBuffer: Buffer,
    options: {
      scene: 'portrait' | 'product' | 'universal';
      outputMode: 'transparent' | 'color';
      backgroundColor?: string;
      edgeFeathering?: boolean;
      autoCrop?: boolean;
    },
  ): Promise<string> {
    const service = 'visual';
    const path = '/';

    let action = 'SegmentImage';
    if (options.scene === 'portrait') action = 'SegmentBody';
    else if (options.scene === 'product') action = 'SegmentCommodity';
    else action = 'SegmentImage';

    const base64Image = imageBuffer.toString('base64');
    const reqBody: Record<string, any> = {
      image_base64: base64Image,
    };

    if (options.outputMode === 'color' && options.backgroundColor) {
      reqBody.bg_color = options.backgroundColor.replace('#', '');
    }
    if (options.edgeFeathering !== undefined) {
      reqBody.edge_enhance = options.edgeFeathering;
    }
    if (options.autoCrop !== undefined) {
      reqBody.auto_crop = options.autoCrop;
    }

    const body = JSON.stringify(reqBody);
    const contentSha = crypto.createHash('sha256').update(body, 'utf8').digest('hex');

    const query: Record<string, string> = {
      Action: action,
      Version: '2020-08-26',
    };

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Host: 'visual.volcengineapi.com',
      'X-Date': new Date().toISOString().replace(/[-:T]/g, '').slice(0, 16) + 'Z',
      'X-Content-Sha256': contentSha,
    };

    const auth = this.getSignature('POST', path, query, headers, body, config, service);
    headers['Authorization'] = auth;

    const url = `${config.endpoint}/?${Object.entries(query)
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&')}`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);
    const resp = await fetch(url, { method: 'POST', headers, body, signal: controller.signal });
    clearTimeout(timeoutId);

    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      throw new Error(`火山引擎抠图失败 HTTP ${resp.status}: ${text.slice(0, 300)}`);
    }

    const data = await resp.json() as any;
    if (data?.ResponseMetadata?.Error) {
      throw new Error(`火山引擎抠图错误: ${data.ResponseMetadata.Error.Message || JSON.stringify(data.ResponseMetadata.Error)}`);
    }

    let resultBase64 = '';
    if (data?.Result?.image) {
      resultBase64 = data.Result.image;
    } else if (data?.image) {
      resultBase64 = data.image;
    } else if (data?.Result?.mask) {
      resultBase64 = data.Result.mask;
    }

    if (!resultBase64) {
      throw new Error('火山引擎抠图返回无结果：' + JSON.stringify(data).slice(0, 200));
    }

    const imgBuffer = Buffer.from(resultBase64, 'base64');
    return `image/png;base64,${imgBuffer.toString('base64')}`.startsWith('data:')
      ? `data:image/png;base64,${resultBase64}`
      : `data:image/png;base64,${resultBase64}`;
  }
}
