import { Injectable, Logger, BadGatewayException } from '@nestjs/common';
import { AiApiConfigService } from '../admin/ai-api-config.service';
import {
  buildLlmRequest,
  parseLlmResponse,
  normalizeProtocol,
  type ChatMessage,
  type LlmChatOptions,
} from './llm-protocol.adapter';

interface LlmCallResult {
  content: string;
  usedConfigId: string;
  usedConfigName: string;
}

interface RawConfig {
  id: string;
  name: string;
  protocol: string;
  baseUrl: string;
  apiKey: string;
  modelName: string;
  status: string;
  priority: number;
  remark: string | null;
  lastCallStatus: string | null;
  lastCallAt: Date | null;
  lastError: string | null;
  failCount: number;
  createdAt: Date;
}

@Injectable()
export class LlmRouterService {
  private readonly logger = new Logger(LlmRouterService.name);

  constructor(
    private readonly aiApiConfigService: AiApiConfigService,
  ) {}

  async chatComplete(
    messages: ChatMessage[],
    options: LlmChatOptions = {},
  ): Promise<LlmCallResult> {
    const configs = await this.aiApiConfigService.getActiveConfigsOrdered();

    if (configs.length === 0) {
      this.logger.error('No active AI API configs available');
      throw new BadGatewayException('AI服务暂时不可用，请稍后再试');
    }

    const lastErrors: string[] = [];

    for (const config of configs) {
      try {
        const content = await this.callChatCompletion(config, messages, options);
        await this.aiApiConfigService.markSuccess(config.id);
        this.logger.log(`AI call succeeded with config: ${config.name}`);
        return {
          content,
          usedConfigId: config.id,
          usedConfigName: config.name,
        };
      } catch (error: unknown) {
        const errorMsg = error instanceof Error ? error.message : '未知错误';
        lastErrors.push(`${config.name}: ${errorMsg}`);
        this.logger.warn(`AI config ${config.name} failed: ${errorMsg}`);
        try {
          await this.aiApiConfigService.markFailure(config.id, errorMsg);
        } catch (markErr) {
          this.logger.error('Failed to mark failure status', markErr);
        }
      }
    }

    this.logger.error(`All AI configs failed. Errors: ${lastErrors.join(' | ')}`);
    throw new BadGatewayException('AI服务暂时不可用，请稍后再试');
  }

  private async callChatCompletion(
    config: RawConfig,
    messages: ChatMessage[],
    options: LlmChatOptions,
  ): Promise<string> {
    const protocol = normalizeProtocol(config.protocol);
    const { url, headers, body } = buildLlmRequest(
      protocol,
      config.baseUrl,
      config.apiKey,
      config.modelName,
      messages,
      options,
    );
    const timeoutMs = options.timeoutMs ?? 60000;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers,
        body,
        signal: controller.signal,
      });

      if (!response.ok) {
        let errorBody = '';
        try {
          errorBody = await response.text();
        } catch {
          // ignore
        }
        throw new Error(`HTTP ${response.status}: ${errorBody.slice(0, 300)}`);
      }

      const data = await response.json() as unknown;
      const content = parseLlmResponse(protocol, data);

      if (!content.trim()) {
        throw new Error('Empty response from model');
      }

      return content;
    } finally {
      clearTimeout(timeoutId);
    }
  }
}
