import { Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { R2UploadService, type R2Config } from './r2-upload.service';

interface CloudflareImagesConfig {
  accountId: string;
  apiToken: string;
  baseUrl: string;
}

@Injectable()
export class CloudflareImagesService {
  private readonly logger = new Logger(CloudflareImagesService.name);

  parseConfig(baseUrl: string, apiKey: string): CloudflareImagesConfig {
    let accountId = '';
    const match = baseUrl.match(/accounts\/([a-f0-9]{32})/i);
    if (match) {
      accountId = match[1];
    }
    const apiBase = baseUrl.replace(/\/$/, '');
    return {
      accountId,
      apiToken: apiKey,
      baseUrl: apiBase,
    };
  }

  async removeBackgroundByUrl(
    config: CloudflareImagesConfig,
    imageUrl: string,
  ): Promise<string> {
    this.logger.log(`[后端抠图调试] 开始 Cloudflare Image Transform 抠图（URL 模式）`);
    this.logger.log(`[后端抠图调试] 原始R2 URL: ${imageUrl}`);

    const options = 'format=png,quality=95,segment=foreground';
    const transformUrl = this.buildTransformUrl(imageUrl, options);
    this.logger.log(`[后端抠图调试] 完整转换URL: ${transformUrl}`);

    const altTransformUrl = this.buildAltTransformUrl(imageUrl, options);
    this.logger.log(`[后端抠图调试] 备用转换URL: ${altTransformUrl}`);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60000);

    let response: Response;
    const startTime = Date.now();
    let usedAlt = false;
    try {
      response = await fetch(transformUrl, {
        method: 'GET',
        signal: controller.signal,
        redirect: 'follow',
      });

      if (response.status === 404) {
        this.logger.warn(`[后端抠图调试] 主转换URL返回404，尝试备用URL格式`);
        usedAlt = true;
        const altController = new AbortController();
        const altTimeoutId = setTimeout(() => altController.abort(), 60000);
        try {
          response = await fetch(altTransformUrl, {
            method: 'GET',
            signal: altController.signal,
            redirect: 'follow',
          });
        } finally {
          clearTimeout(altTimeoutId);
        }
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : '未知错误';
      this.logger.error(`[后端抠图调试] Cloudflare Image Transform 请求异常: ${msg}`);
      if (msg.includes('aborted') || msg.includes('timeout')) {
        throw new Error('Cloudflare Images 转换请求超时（60秒）');
      }
      throw new Error(`Cloudflare Images 转换请求失败：${msg}`);
    } finally {
      clearTimeout(timeoutId);
    }

    const cost = Date.now() - startTime;
    const finalUrl = usedAlt ? altTransformUrl : transformUrl;
    this.logger.log(`[后端抠图调试] 请求转换URL，状态码：${response.status}，使用URL：${usedAlt ? '备用格式' : '主格式'}，耗时：${cost}ms`);

    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      this.logger.error(`[后端抠图调试] Cloudflare Images 转换失败！状态码：${response.status}，耗时：${cost}ms`);
      this.logger.error(`[后端抠图调试] 错误响应体：${errText.slice(0, 500)}`);
      throw new Error(
        `Cloudflare Images转换失败：HTTP ${response.status} ${errText.slice(0, 150)}`,
      );
    }

    const contentType = response.headers.get('content-type') || '';
    this.logger.log(`[后端抠图调试] 转换成功，Content-Type: ${contentType}`);

    const arrayBuffer = await response.arrayBuffer();
    const resultBuffer = Buffer.from(arrayBuffer);
    this.logger.log(`[后端抠图调试] 抠图结果大小：${resultBuffer.length} bytes，耗时：${cost}ms`);

    const resultMagic = resultBuffer.length >= 8
      ? resultBuffer.slice(0, 8).toString('hex').toUpperCase()
      : 'too-small';
    const isPngResult = resultBuffer.length >= 4
      && resultBuffer[0] === 0x89 && resultBuffer[1] === 0x50
      && resultBuffer[2] === 0x4e && resultBuffer[3] === 0x47;
    this.logger.log(`[后端抠图调试] 结果魔数: ${resultMagic} (PNG=${isPngResult})`);

    if (resultBuffer.length < 100) {
      throw new Error('Cloudflare Images 转换返回数据过小，抠图可能失败');
    }

    if (!isPngResult) {
      this.logger.warn(`[后端抠图调试] 警告：返回结果不是 PNG 格式（魔数=${resultMagic}），但仍按 PNG 返回`);
    }

    return `data:image/png;base64,${resultBuffer.toString('base64')}`;
  }

  async removeBackgroundWithR2(
    config: CloudflareImagesConfig,
    r2Config: R2Config,
    r2UploadService: R2UploadService,
    fileBuffer: Buffer,
    contentType: string,
    ext: string,
  ): Promise<string> {
    const startTime = Date.now();
    this.logger.log(`[后端抠图调试] 开始 R2 + Image Transform 抠图流程`);
    this.logger.log(`[后端抠图调试] R2 配置: Endpoint=${r2Config.endpoint}, Bucket=${r2Config.bucket}, PublicDomain=${r2Config.publicDomain}`);
    this.logger.log(`[后端抠图调试] 文件信息: 大小=${(fileBuffer.length / 1024 / 1024).toFixed(2)}MB, 类型=${contentType}, 扩展名=${ext}`);
    const uploadMagic = fileBuffer.length >= 8
      ? fileBuffer.slice(0, 8).toString('hex').toUpperCase()
      : 'too-small';
    this.logger.log(`[后端抠图调试] 上传前魔数校验: ${uploadMagic}`);

    const MAX_SIZE_MB = 10;
    if (fileBuffer.length > MAX_SIZE_MB * 1024 * 1024) {
      const sizeMb = (fileBuffer.length / 1024 / 1024).toFixed(2);
      this.logger.error(`[后端抠图调试] 图片过大，当前 ${sizeMb}MB，限制 ${MAX_SIZE_MB}MB`);
      throw new Error(`图片大小超过限制：当前 ${sizeMb}MB，限制 ${MAX_SIZE_MB}MB`);
    }

    const fileName = `${randomUUID()}.${ext}`;
    this.logger.log(`[后端抠图调试] R2 上传文件名: ${fileName}`);

    let publicUrl: string;
    const r2Start = Date.now();
    try {
      publicUrl = await r2UploadService.uploadImage(
        r2Config,
        fileBuffer,
        fileName,
        contentType,
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : '未知错误';
      const cost = Date.now() - r2Start;
      this.logger.error(`[后端抠图调试] R2 上传失败！耗时：${cost}ms，错误：${msg}`);
      if (msg.includes('aborted') || msg.includes('timeout')) {
        throw new Error('R2上传失败：请求超时');
      }
      throw new Error(`R2上传失败：${msg}`);
    }

    const r2Cost = Date.now() - r2Start;
    this.logger.log(`[后端抠图调试] R2上传成功，原始URL: ${publicUrl}，耗时：${r2Cost}ms`);

    try {
      const result = await this.removeBackgroundByUrl(config, publicUrl);
      const totalCost = Date.now() - startTime;
      this.logger.log(`[后端抠图调试] 整个抠图流程结束！总耗时：${totalCost}ms（R2上传 ${r2Cost}ms + Image Transform ${totalCost - r2Cost}ms）`);
      return result;
    } catch (err) {
      const totalCost = Date.now() - startTime;
      const msg = err instanceof Error ? err.message : '未知错误';
      this.logger.error(`[后端抠图调试] 整个抠图流程失败！总耗时：${totalCost}ms，原因：${msg}`);
      throw err;
    }
  }

  async testConnection(
    config: CloudflareImagesConfig,
  ): Promise<{ success: boolean; latencyMs: number; message: string }> {
    const testUrl = 'https://www.cloudflare.com/cdn-cgi/image/format=avif,width=100/images/logo-white.svg';
    const startTime = Date.now();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    try {
      const resp = await fetch(testUrl, {
        method: 'GET',
        signal: controller.signal,
      });

      const latencyMs = Date.now() - startTime;
      if (!resp.ok) {
        const errText = await resp.text().catch(() => '');
        return {
          success: false,
          latencyMs,
          message: `连接测试失败：HTTP ${resp.status} ${errText.slice(0, 100)}`,
        };
      }

      return {
        success: true,
        latencyMs,
        message: `Cloudflare Image Transform 服务可用 (${latencyMs}ms)`,
      };
    } catch (err) {
      const latencyMs = Date.now() - startTime;
      const msg = err instanceof Error ? err.message : '未知错误';
      return {
        success: false,
        latencyMs,
        message: `连接失败：${msg.slice(0, 100)}`,
      };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  async testConnectionWithR2(
    config: CloudflareImagesConfig,
    r2Config: R2Config,
    r2UploadService: R2UploadService,
  ): Promise<{
    success: boolean;
    latencyMs: number;
    message: string;
    steps?: {
      r2Upload: { success: boolean; message: string };
      r2Url?: { success: boolean; message: string };
      cfTransform?: { success: boolean; message: string };
    };
  }> {
    const startTime = Date.now();
    const testImage = this.buildTestImage();

    const steps = {
      r2Upload: { success: false, message: '未开始' },
    } as {
      r2Upload: { success: boolean; message: string; detail?: string; argumentName?: string };
      r2Url?: { success: boolean; message: string };
      cfTransform?: { success: boolean; message: string };
    };

    try {
      const testResult = await r2UploadService.testUpload(r2Config);
      steps.r2Upload = {
        success: testResult.uploadStep.success,
        message: testResult.uploadStep.message,
        detail: testResult.uploadStep.detail,
        argumentName: testResult.uploadStep.argumentName,
      };
      steps.r2Url = {
        success: testResult.urlStep.success,
        message: testResult.urlStep.message,
      };

      if (!testResult.overall.success) {
        const latencyMs = Date.now() - startTime;
        return {
          success: false,
          latencyMs,
          message: `R2 配置失败：${testResult.overall.message}`,
          steps,
        };
      }

      const cfStartTime = Date.now();
      const resultDataUrl = await this.removeBackgroundWithR2(
        config,
        r2Config,
        r2UploadService,
        testImage,
        'image/png',
        'png',
      );
      const cfDuration = Date.now() - cfStartTime;
      steps.cfTransform = {
        success: resultDataUrl.length > 0,
        message: resultDataUrl.length > 0
          ? `Cloudflare Image Transform 抠图成功 (${cfDuration}ms)`
          : '抠图返回为空',
      };

      const latencyMs = Date.now() - startTime;
      return {
        success: resultDataUrl.length > 0,
        latencyMs,
        message: resultDataUrl.length > 0
          ? `R2 + Image Transform 模式连接成功，总耗时 ${latencyMs}ms`
          : '抠图返回为空',
        steps,
      };
    } catch (err) {
      const latencyMs = Date.now() - startTime;
      const msg = err instanceof Error ? err.message : '未知错误';
      return {
        success: false,
        latencyMs,
        message: `连接失败：${msg.slice(0, 200)}`,
        steps,
      };
    }
  }

  private buildTransformUrl(imageUrl: string, options: string): string {
    const urlObj = new URL(imageUrl);
    const origin = urlObj.origin;
    return `${origin}/cdn-cgi/image/${options}/${imageUrl}`;
  }

  private buildAltTransformUrl(imageUrl: string, options: string): string {
    const urlObj = new URL(imageUrl);
    const origin = urlObj.origin;
    const pathname = urlObj.pathname.replace(/^\//, '');
    return `${origin}/cdn-cgi/image/${options}/${pathname}`;
  }

  private buildTestImage(): Buffer {
    const png = Buffer.from([
      0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
      0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
      0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x02,
      0x08, 0x02, 0x00, 0x00, 0x00, 0x57, 0xdd, 0x52,
      0xf8, 0x00, 0x00, 0x00, 0x1c, 0x49, 0x44, 0x41,
      0x54, 0x08, 0xd7, 0x63, 0x60, 0x60, 0x60, 0x60,
      0xf8, 0xff, 0xff, 0xff, 0x3f, 0x00, 0x05, 0xfe,
      0x02, 0xfe, 0xdc, 0xcc, 0x59, 0xe7, 0x00, 0x00,
      0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42,
      0x60, 0x82,
    ]);
    return png;
  }
}
