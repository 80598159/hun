import {
  Body,
  Controller,
  HttpException,
  HttpStatus,
  Post,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { AiService } from './ai.service';
import { AiApiConfigService } from '../admin/ai-api-config.service';
import { CloudflareImagesService } from './cloudflare-images.service';
import { AliyunImagesegService } from './aliyun-imageseg.service';
import { VolcengineVisualService } from './volcengine-visual.service';
import { R2UploadService } from './r2-upload.service';
import { Logger } from '@nestjs/common';
import type {
  AiFlowGenerateRequest,
  AiRequirementParseRequest,
  AiRiskDetectRequest,
  AiScriptGenerateRequest,
  RemoveBackgroundRequest,
  RemoveBackgroundResponse,
} from '@shared/api.interface';

@Controller('api/ai')
export class AiController {
  private readonly logger = new Logger(AiController.name);

  constructor(
    private readonly aiService: AiService,
    private readonly aiApiConfigService: AiApiConfigService,
    private readonly cloudflareImagesService: CloudflareImagesService,
    private readonly aliyunImagesegService: AliyunImagesegService,
    private readonly volcengineVisualService: VolcengineVisualService,
    private readonly r2UploadService: R2UploadService,
  ) {}

  @UseGuards(AppAuthGuard)
  @Post('generate-flow')
  async generateFlow(
    @Req() req: Request,
    @Body() body: AiFlowGenerateRequest,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new HttpException('未登录', HttpStatus.UNAUTHORIZED);
    }
    return this.aiService.generateFlow(userId, body.description);
  }

  @UseGuards(AppAuthGuard)
  @Post('generate-script')
  async generateScript(
    @Req() req: Request,
    @Body() body: AiScriptGenerateRequest,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new HttpException('未登录', HttpStatus.UNAUTHORIZED);
    }
    return this.aiService.generateScript(userId, body);
  }

  @UseGuards(AppAuthGuard)
  @Post('check-script-quota')
  async checkScriptQuota(@Req() req: Request) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new HttpException('未登录', HttpStatus.UNAUTHORIZED);
    }
    return this.aiService.checkScriptQuota(userId);
  }

  @UseGuards(AppAuthGuard)
  @Post('consume-script')
  async consumeScript(@Req() req: Request) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new HttpException('未登录', HttpStatus.UNAUTHORIZED);
    }
    return this.aiService.consumeScript(userId);
  }

  @UseGuards(AppAuthGuard)
  @Post('parse-requirement')
  async parseRequirement(
    @Req() req: Request,
    @Body() body: AiRequirementParseRequest,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new HttpException('未登录', HttpStatus.UNAUTHORIZED);
    }
    return this.aiService.parseRequirement(userId, body.text);
  }

  @UseGuards(AppAuthGuard)
  @Post('detect-risk')
  async detectRisk(
    @Req() req: Request,
    @Body() body: AiRiskDetectRequest,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new HttpException('未登录', HttpStatus.UNAUTHORIZED);
    }
      return this.aiService.detectRisk(userId, body.flowList, body.weddingInfo);
  }

  @UseGuards(AppAuthGuard)
  @Post('remove-background')
  async removeBackground(
    @Req() req: Request,
    @Body() body: RemoveBackgroundRequest,
  ): Promise<RemoveBackgroundResponse> {
    try {
      const bodySize = Buffer.byteLength(JSON.stringify(body || {}), 'utf8');
      this.logger.log(`[后端抠图调试] 收到请求，body 大小：${bodySize} bytes (${(bodySize / 1024 / 1024).toFixed(2)} MB)`);

      const { userId } = req.userContext;
      if (!userId) {
        return { success: false, message: '未登录' };
      }

      if (!body.imageDataUrl || !body.imageDataUrl.startsWith('data:image/')) {
        return { success: false, message: '无效的图片数据：缺少 data:image/ 前缀' };
      }

      const scene = body.scene || 'portrait';
      const outputMode = body.outputMode || 'transparent';

    const match = body.imageDataUrl.match(/^data:image\/([a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!match) {
      this.logger.warn(`[后端抠图调试] 图片格式不支持: ${body.imageDataUrl.slice(0, 50)}...`);
      return { success: false, message: '图片格式不支持' };
    }
    const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
    let base64 = match[2];
    base64 = base64.replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/');
    const pad = 4 - (base64.length % 4);
    if (pad !== 4) base64 += '='.repeat(pad);
    const buffer = Buffer.from(base64, 'base64');
    const fileName = `upload-${Date.now()}.${ext}`;

    const magicHex = buffer.length >= 8
      ? buffer.slice(0, 8).toString('hex').toUpperCase()
      : buffer.slice(0, buffer.length).toString('hex').toUpperCase();
    const isPng = buffer.length >= 4
      && buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47;
    const isJpeg = buffer.length >= 3
      && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;

    this.logger.log(`[后端抠图调试] 收到前端抠图请求`);
    this.logger.log(`[后端抠图调试] 图片信息: 格式=image/${match[1]}, base64长度=${match[2].length}字符, 解码后大小=${(buffer.length / 1024 / 1024).toFixed(2)}MB`);
    this.logger.log(`[后端抠图调试] 图片魔数: ${magicHex} (PNG=${isPng}, JPEG=${isJpeg})`);
    this.logger.log(`[后端抠图调试] 抠图参数: scene=${scene}, outputMode=${outputMode}`);

    if (buffer.length < 100) {
      this.logger.warn(`[后端抠图调试] 图片数据过小: ${buffer.length}字节`);
      return { success: false, message: '图片数据损坏或过小' };
    }

    if (!isPng && !isJpeg) {
      this.logger.error(`[后端抠图调试] 图片魔数校验失败！解码后的数据不是有效的 PNG/JPEG`);
      this.logger.error(`[后端抠图调试] 实际前20字节hex: ${buffer.slice(0, 20).toString('hex').toUpperCase()}`);
      const asciiPreview = buffer.slice(0, 30).toString('ascii').replace(/[\x00-\x1f\x7f]/g, '.');
      this.logger.error(`[后端抠图调试] 前30字节ASCII预览: ${asciiPreview}`);
      return { success: false, message: '图片数据损坏，不是有效的 PNG/JPEG 格式' };
    }

    const allConfigs = await this.aiApiConfigService.getActiveConfigsOrdered();
    const cutoutConfigs = allConfigs.filter(
      (c) => c.protocol === 'aliyun_imageseg' || c.protocol === 'volcengine_visual' || c.protocol === 'cloudflare_images',
    );

    this.logger.log(`[后端抠图调试] 可用抠图服务数量: ${cutoutConfigs.length}`);
    cutoutConfigs.forEach((c: { name: string; protocol: string }, i: number) => {
      this.logger.log(`[后端抠图调试]   服务${i + 1}: ${c.name} (${c.protocol})`);
    });

    let lastError = '';

    for (const cfg of cutoutConfigs) {
      try {
        let resultDataUrl = '';
        let serviceType: 'aliyun_imageseg' | 'volcengine_visual' | 'cloudflare_images' = 'cloudflare_images';

        if (cfg.protocol === 'aliyun_imageseg') {
          serviceType = 'aliyun_imageseg';
          const aliConfig = this.aliyunImagesegService.parseConfig(cfg.baseUrl, cfg.apiKey, cfg.appId);
          resultDataUrl = await this.aliyunImagesegService.removeBackground(aliConfig, buffer, {
            scene,
            outputMode,
            backgroundColor: body.backgroundColor,
          });
        } else if (cfg.protocol === 'volcengine_visual') {
          serviceType = 'volcengine_visual';
          const volcConfig = this.volcengineVisualService.parseConfig(cfg.baseUrl, cfg.apiKey, cfg.appId);
          resultDataUrl = await this.volcengineVisualService.removeBackground(volcConfig, buffer, {
            scene,
            outputMode,
            backgroundColor: body.backgroundColor,
            edgeFeathering: body.edgeFeathering,
            autoCrop: body.autoCrop,
          });
        } else {
          const cfConfig = this.cloudflareImagesService.parseConfig(cfg.baseUrl, cfg.apiKey);
          const hasR2 =
            cfg.r2Endpoint && cfg.r2Bucket && cfg.r2AccessKey && cfg.r2SecretKey && cfg.r2PublicDomain;
          if (!hasR2) {
            lastError = 'Cloudflare Images 配置缺少 R2 存储信息，无法进行抠图（Free 版仅支持 URL 拉取方式）';
            continue;
          }
          const contentType = `image/${match[1]}`;
          resultDataUrl = await this.cloudflareImagesService.removeBackgroundWithR2(
            cfConfig,
            {
              accessKeyId: cfg.r2AccessKey,
              secretAccessKey: cfg.r2SecretKey,
              endpoint: cfg.r2Endpoint,
              bucket: cfg.r2Bucket,
              publicDomain: cfg.r2PublicDomain,
            },
            this.r2UploadService,
            buffer,
            contentType,
            ext,
          );
          serviceType = 'cloudflare_images';
        }

        await this.aiApiConfigService.markSuccess(cfg.id);
        this.logger.log(`[后端抠图调试] 抠图成功！使用服务: ${cfg.name} (${cfg.protocol})`);
        return {
          success: true,
          imageDataUrl: resultDataUrl,
          serviceUsed: serviceType,
        };
      } catch (err) {
        const msg = err instanceof Error ? err.message : '抠图服务不可用';
        this.logger.error(`[后端抠图调试] 抠图服务 ${cfg.name}(${cfg.protocol}) 失败: ${msg}`);
        lastError = msg;
        continue;
      }
    }

    this.logger.error(`[后端抠图调试] 所有抠图服务均失败，最终错误: ${lastError}`);
    return {
      success: false,
      message: lastError || '所有云端抠图服务均不可用，请使用本地抠图',
    };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const stack = err instanceof Error ? err.stack : '';
      this.logger.error(`[后端抠图调试] 未捕获异常！错误信息: ${msg}`);
      if (stack) {
        this.logger.error(`[后端抠图调试] 错误堆栈:\n${stack}`);
      }
      return {
        success: false,
        message: msg || '服务器内部错误',
      };
    }
  }
}
