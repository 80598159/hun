import { Module, forwardRef } from '@nestjs/common';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';
import { LlmRouterService } from './llm-router.service';
import { AdminModule } from '../admin/admin.module';

@Module({
  imports: [AdminModule],
  controllers: [AiController],
  providers: [AiService, LlmRouterService],
  exports: [AiService, LlmRouterService],
})
export class AiModule {}
