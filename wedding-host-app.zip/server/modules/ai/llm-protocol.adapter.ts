import { Logger } from '@nestjs/common';

export type LlmProtocol = 'openai' | 'cloudflare_workers_ai' | 'cloudflare_images' | 'aliyun_imageseg' | 'volcengine_visual';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface LlmChatOptions {
  maxTokens?: number;
  temperature?: number;
  responseFormat?: 'json' | 'text';
  timeoutMs?: number;
}

interface LlmRequestSpec {
  url: string;
  headers: Record<string, string>;
  body: string;
}

interface LlmResponseParser {
  (data: unknown): string;
}

function buildOpenAiRequest(
  baseUrl: string,
  apiKey: string,
  modelName: string,
  messages: ChatMessage[],
  options: LlmChatOptions,
): LlmRequestSpec {
  const cleanedBase = baseUrl.replace(/\/$/, '');
  const url = `${cleanedBase}/chat/completions`;

  const requestBody: Record<string, unknown> = {
    model: modelName,
    messages,
  };

  if (options.maxTokens !== undefined) {
    requestBody.max_tokens = options.maxTokens;
  }
  if (options.temperature !== undefined) {
    requestBody.temperature = options.temperature;
  }
  if (options.responseFormat === 'json') {
    requestBody.response_format = { type: 'json_object' };
  }

  return {
    url,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(requestBody),
  };
}

function extractContentValue(content: unknown): string {
  if (typeof content === 'string') return content;
  if (content === null || content === undefined) return '';
  if (Array.isArray(content)) {
    const parts: string[] = [];
    for (const part of content) {
      if (typeof part === 'string') {
        parts.push(part);
      } else if (part && typeof part === 'object') {
        const p = part as { type?: string; text?: string }; 
        if (p.type === 'text' && typeof p.text === 'string') {
          parts.push(p.text);
        }
      }
    }
    return parts.join('');
  }
  return '';
}

function parseOpenAiResponse(data: unknown): string {
  const typed = data as {
    choices?: Array<{
      message?: { content?: unknown; reasoning_content?: string };
      text?: string;
      delta?: { content?: unknown };
    }>;
    output?: string;
    response?: string;
    content?: string;
    result?: string;
  };

  const choice0 = typed.choices?.[0];
  if (choice0) {
    const msgContent = extractContentValue(choice0.message?.content);
    if (msgContent) return msgContent;

    if (choice0.text && typeof choice0.text === 'string') return choice0.text;

    const deltaContent = extractContentValue(choice0.delta?.content);
    if (deltaContent) return deltaContent;

    const reasoning = choice0.message?.reasoning_content;
    if (reasoning && typeof reasoning === 'string') return reasoning;
  }

  if (typed.output && typeof typed.output === 'string') return typed.output;
  if (typed.response && typeof typed.response === 'string') return typed.response;
  if (typed.content && typeof typed.content === 'string') return typed.content;
  if (typed.result && typeof typed.result === 'string') return typed.result;

  return '';
}

function buildWorkersAiRequest(
  baseUrl: string,
  apiKey: string,
  modelName: string,
  messages: ChatMessage[],
  options: LlmChatOptions,
): LlmRequestSpec {
  const cleanedBase = baseUrl.replace(/\/$/, '');
  const url = `${cleanedBase}/${modelName}`;

  const requestBody: Record<string, unknown> = {
    messages,
  };

  if (options.maxTokens !== undefined) {
    requestBody.max_tokens = options.maxTokens;
  }
  if (options.temperature !== undefined) {
    requestBody.temperature = options.temperature;
  }
  if (options.responseFormat === 'json') {
    requestBody.response_format = { type: 'json_object' };
  }

  return {
    url,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(requestBody),
  };
}

function parseWorkersAiResponse(data: unknown): string {
  const typed = data as {
    result?: {
      response?: string | Record<string, unknown>;
      choices?: Array<{ message?: { content?: string } }>;
    };
    response?: string;
    choices?: Array<{ message?: { content?: string } }>;
  };

  if (typed?.result?.choices?.[0]?.message?.content) {
    const content = typed.result.choices[0].message.content;
    if (typeof content === 'string' && content.trim()) return content;
  }
  if (typed?.result?.response) {
    if (typeof typed.result.response === 'string') return typed.result.response;
    try {
      return JSON.stringify(typed.result.response);
    } catch {
      // fall through
    }
  }
  if (typed?.response && typeof typed.response === 'string') {
    return typed.response;
  }
  if (typed.choices?.[0]?.message?.content) {
    const content = typed.choices[0].message.content;
    if (typeof content === 'string') return content;
  }
  return '';
}

const BUILDERS: Record<LlmProtocol, (
  baseUrl: string,
  apiKey: string,
  modelName: string,
  messages: ChatMessage[],
  options: LlmChatOptions,
) => LlmRequestSpec> = {
  openai: buildOpenAiRequest,
  cloudflare_workers_ai: buildWorkersAiRequest,
  cloudflare_images: buildOpenAiRequest,
  aliyun_imageseg: buildOpenAiRequest,
  volcengine_visual: buildOpenAiRequest,
};

const PARSERS: Record<LlmProtocol, LlmResponseParser> = {
  openai: parseOpenAiResponse,
  cloudflare_workers_ai: parseWorkersAiResponse,
  cloudflare_images: parseOpenAiResponse,
  aliyun_imageseg: parseOpenAiResponse,
  volcengine_visual: parseOpenAiResponse,
};

export function buildLlmRequest(
  protocol: LlmProtocol,
  baseUrl: string,
  apiKey: string,
  modelName: string,
  messages: ChatMessage[],
  options: LlmChatOptions,
): LlmRequestSpec {
  const builder = BUILDERS[protocol];
  if (!builder) {
    const logger = new Logger('LlmProtocolAdapter');
    logger.warn(`Unknown protocol: ${protocol}, fallback to openai`);
    return buildOpenAiRequest(baseUrl, apiKey, modelName, messages, options);
  }
  return builder(baseUrl, apiKey, modelName, messages, options);
}

export function parseLlmResponse(protocol: LlmProtocol, data: unknown): string {
  const parser = PARSERS[protocol];
  if (!parser) {
    return parseOpenAiResponse(data);
  }
  return parser(data);
}

export function normalizeProtocol(raw: string | undefined | null): LlmProtocol {
  if (raw === 'cloudflare_workers_ai') return 'cloudflare_workers_ai';
  if (raw === 'cloudflare_images') return 'cloudflare_images';
  if (raw === 'aliyun_imageseg') return 'aliyun_imageseg';
  if (raw === 'volcengine_visual') return 'volcengine_visual';
  return 'openai';
}
