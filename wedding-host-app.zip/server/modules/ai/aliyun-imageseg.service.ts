import { Injectable, Logger } from '@nestjs/common';
import * as crypto from 'node:crypto';

interface AliyunImagesegConfig {
  accessKeyId: string;
  accessKeySecret: string;
  endpoint: string;
  regionId: string;
}

@Injectable()
export class AliyunImagesegService {
  private readonly logger = new Logger(AliyunImagesegService.name);

  parseConfig(baseUrl: string, apiKey: string, appId?: string): AliyunImagesegConfig {
    const parts = apiKey.split(':');
    const accessKeyId = parts[0] || '';
    const accessKeySecret = parts[1] || parts[0] || '';
    let endpoint = baseUrl.trim() || 'imageseg.cn-shanghai.aliyuncs.com';
    if (!endpoint.startsWith('http')) {
      endpoint = `https://${endpoint}`;
    }
    const regionMatch = endpoint.match(/imageseg\.([a-z0-9-]+)\.aliyuncs\.com/);
    const regionId = regionMatch ? regionMatch[1] : 'cn-shanghai';
    return { accessKeyId, accessKeySecret, endpoint, regionId };
  }

  private percentEncode(str: string): string {
    return encodeURIComponent(str)
      .replace(/\+/g, '%20')
      .replace(/\*/g, '%2A')
      .replace(/%7E/g, '~');
  }

  private sign(
    method: string,
    params: Record<string, string>,
    accessKeySecret: string,
  ): string {
    const sorted = Object.keys(params).sort();
    const canonicalized = sorted
      .map((key) => `${this.percentEncode(key)}=${this.percentEncode(params[key])}`)
      .join('&');
    const stringToSign = `${method}&${this.percentEncode('/')}&${this.percentEncode(canonicalized)}`;
    return crypto
      .createHmac('sha1', `${accessKeySecret}&`)
      .update(stringToSign, 'utf8')
      .digest('base64');
  }

  async testConnection(config: AliyunImagesegConfig): Promise<{ success: boolean; message: string }> {
    try {
      const timestamp = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
      const params: Record<string, string> = {
        Format: 'JSON',
        Version: '2019-12-30',
        SignatureMethod: 'HMAC-SHA1',
        SignatureVersion: '1.0',
        SignatureNonce: `${Date.now()}${Math.random().toString(36).slice(2, 10)}`,
        Timestamp: timestamp,
        AccessKeyId: config.accessKeyId,
        Action: 'SegmentBody',
        ImageURL: 'https://img.alicdn.com/tfs/TB1_uT8a5ERMeJjSspiXXb9pFXa-259-357.png',
        ReturnForm: 'png',
      };
      params.Signature = this.sign('GET', params, config.accessKeySecret);
      const url = `${config.endpoint}/?${Object.entries(params)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
        .join('&')}`;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);
      const resp = await fetch(url, { method: 'GET', signal: controller.signal });
      clearTimeout(timeoutId);

      if (!resp.ok) {
        const text = await resp.text().catch(() => '');
        return { success: false, message: `HTTP ${resp.status}: ${text.slice(0, 200)}` };
      }
      const data = await resp.json() as any;
      if (data.RequestId) {
        return { success: true, message: '连接成功，API可正常调用' };
      }
      return { success: false, message: data.Message || '连接失败，请检查AccessKey' };
    } catch (err: any) {
      return { success: false, message: err?.message || '连接异常' };
    }
  }

  async removeBackground(
    config: AliyunImagesegConfig,
    imageBuffer: Buffer,
    options: {
      scene: 'portrait' | 'product' | 'universal';
      outputMode: 'transparent' | 'color';
      backgroundColor?: string;
    },
  ): Promise<string> {
    const action = options.scene === 'portrait'
      ? 'SegmentBody'
      : options.scene === 'product'
      ? 'SegmentCommodity'
      : 'SegmentCommonImage';

    const base64Image = imageBuffer.toString('base64');

    const timestamp = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
    const params: Record<string, string> = {
      Format: 'JSON',
      Version: '2019-12-30',
      SignatureMethod: 'HMAC-SHA1',
      SignatureVersion: '1.0',
      SignatureNonce: `${Date.now()}${Math.random().toString(36).slice(2, 10)}`,
      Timestamp: timestamp,
      AccessKeyId: config.accessKeyId,
      Action: action,
      ReturnForm: options.outputMode === 'color' ? 'photo' : 'png',
    };

    if (options.outputMode === 'color' && options.backgroundColor) {
      const hex = options.backgroundColor.replace('#', '');
      const r = parseInt(hex.slice(0, 2), 16);
      const g = parseInt(hex.slice(2, 4), 16);
      const b = parseInt(hex.slice(4, 6), 16);
      params['Background.R'] = String(r);
      params['Background.G'] = String(g);
      params['Background.B'] = String(b);
    }

    params.Signature = this.sign('POST', params, config.accessKeySecret);

    const url = `${config.endpoint}/?${Object.entries(params)
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
      .join('&')}`;

    const body = JSON.stringify({ ImageURL: `data:image/png;base64,${base64Image}` });

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);
    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      throw new Error(`阿里云抠图失败 HTTP ${resp.status}: ${text.slice(0, 300)}`);
    }

    const data = await resp.json() as any;
    let resultUrl = '';
    if (data?.Data?.ImageURL) {
      resultUrl = data.Data.ImageURL;
    } else if (data?.ResultImageUrl) {
      resultUrl = data.ResultImageUrl;
    }

    if (!resultUrl) {
      throw new Error('阿里云抠图返回无结果：' + JSON.stringify(data).slice(0, 200));
    }

    const imgResp = await fetch(resultUrl, { signal: AbortSignal.timeout(15000) });
    if (!imgResp.ok) {
      throw new Error(`下载阿里云抠图结果失败 HTTP ${imgResp.status}`);
    }
    const imgBuffer = Buffer.from(await imgResp.arrayBuffer());
    const mimeType = 'image/png';
    return `data:${mimeType};base64,${imgBuffer.toString('base64')}`;
  }
}
