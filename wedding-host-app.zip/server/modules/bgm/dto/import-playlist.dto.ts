import { IsString, IsOptional, MaxLength, IsIn } from 'class-validator';
import type { ImportPlaylistRequest, BgmPurposeTag } from '@shared/api.interface';

const PURPOSE_TAGS: BgmPurposeTag[] = ['warmup', 'entrance', 'climax', 'exit', 'other'];

export class ImportPlaylistDto implements Omit<ImportPlaylistRequest, 'playlistId'> {
  @IsString()
  text!: string;

  @IsOptional()
  @IsString()
  @IsIn(PURPOSE_TAGS)
  defaultPurposeTag?: 'warmup' | 'entrance' | 'climax' | 'exit' | 'other';

  @IsOptional()
  @IsString()
  @MaxLength(100)
  defaultSegment?: string;
}
