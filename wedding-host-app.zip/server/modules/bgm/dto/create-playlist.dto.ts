import { IsString, IsOptional, MaxLength } from 'class-validator';
import type { CreatePlaylistRequest } from '@shared/api.interface';

export class CreatePlaylistDto implements CreatePlaylistRequest {
  @IsString()
  @MaxLength(200)
  name!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsString()
  @MaxLength(64)
  projectId?: string;
}
