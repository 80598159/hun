import { IsString, IsOptional, MaxLength } from 'class-validator';
import type { UpdatePlaylistRequest } from '@shared/api.interface';

export class UpdatePlaylistDto implements UpdatePlaylistRequest {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  name?: string;

  @IsOptional()
  @IsString()
  description?: string;
}
