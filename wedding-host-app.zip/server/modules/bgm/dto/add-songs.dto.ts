import {
  IsArray,
  IsString,
  IsOptional,
  ValidateNested,
  MaxLength,
  IsIn,
} from 'class-validator';
import { Type } from 'class-transformer';
import type { AddPlaylistSongsRequest, BgmPurposeTag } from '@shared/api.interface';

const PURPOSE_TAGS: BgmPurposeTag[] = ['warmup', 'entrance', 'climax', 'exit', 'other'];

class AddSongItemDto {
  @IsOptional()
  @IsString()
  @MaxLength(64)
  songId?: string;

  @IsString()
  @MaxLength(200)
  title!: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  artist?: string;

  @IsOptional()
  @IsString()
  @IsIn(PURPOSE_TAGS)
  purposeTag?: 'warmup' | 'entrance' | 'climax' | 'exit' | 'other';

  @IsOptional()
  @IsString()
  @MaxLength(100)
  segment?: string;
}

export class AddSongsDto implements AddPlaylistSongsRequest {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => AddSongItemDto)
  songs!: AddSongItemDto[];
}
