import { IsString, IsOptional, MaxLength, IsIn, IsInt, Min } from 'class-validator';
import type { UpdatePlaylistItemRequest, BgmPurposeTag } from '@shared/api.interface';

const PURPOSE_TAGS: BgmPurposeTag[] = ['warmup', 'entrance', 'climax', 'exit', 'other'];

export class UpdateItemDto implements UpdatePlaylistItemRequest {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  artist?: string;

  @IsOptional()
  @IsString()
  @IsIn(PURPOSE_TAGS)
  purposeTag?: 'warmup' | 'entrance' | 'climax' | 'exit' | 'other';

  @IsOptional()
  @IsString()
  @MaxLength(100)
  segment?: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  note?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  sortOrder?: number;
}
