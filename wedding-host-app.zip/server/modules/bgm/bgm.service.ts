import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  bgmLibrary,
  bgmPlaylists,
  bgmPlaylistItems,
} from '@server/database/schema';
import {
  eq,
  and,
  count,
  desc,
  asc,
  ilike,
  or,
  inArray,
  sql,
} from 'drizzle-orm';
import type {
  BgmSong,
  BgmCategory,
  BgmLibraryListResponse,
  BgmPlaylist,
  BgmPlaylistDetail,
  BgmPlaylistItem,
  BgmPurposeTag,
  ExportPlaylistResponse,
} from '@shared/api.interface';
import type { CreatePlaylistDto } from './dto/create-playlist.dto';
import type { UpdatePlaylistDto } from './dto/update-playlist.dto';
import type { AddSongsDto } from './dto/add-songs.dto';
import type { UpdateItemDto } from './dto/update-item.dto';
import type { ImportPlaylistDto } from './dto/import-playlist.dto';

const CATEGORIES: { key: BgmCategory; label: string }[] = [
  { key: 'prelude', label: '暖场迎宾' },
  { key: 'entrance', label: '新人入场' },
  { key: 'vows', label: '誓言' },
  { key: 'rings', label: '交换戒指' },
  { key: 'tea', label: '敬茶' },
  { key: 'speech', label: '致辞' },
  { key: 'exit', label: '退场' },
  { key: 'climax', label: '高潮' },
  { key: 'other', label: '其他' },
];

const SEGMENT_ORDER: string[] = [
  '暖场迎宾',
  '新人入场',
  '誓言',
  '交换戒指',
  '敬茶',
  '致辞',
  '退场',
  '高潮',
];

@Injectable()
export class BgmService {
  private readonly logger = new Logger(BgmService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ---------- 分类 ----------
  getCategories(): { key: BgmCategory; label: string }[] {
    return CATEGORIES;
  }

  // ---------- 音乐库 ----------
  async getLibrary(params: {
    userId: string;
    category?: string;
    keyword?: string;
    page: number;
    pageSize: number;
  }): Promise<BgmLibraryListResponse> {
    const { userId, category, keyword, page, pageSize } = params;

    const conditions = [
      or(eq(bgmLibrary.isSystem, true), eq(bgmLibrary.userId, userId)),
    ];

    if (category) {
      conditions.push(eq(bgmLibrary.category, category));
    }

    if (keyword) {
      conditions.push(
        or(
          ilike(bgmLibrary.title, `%${keyword}%`),
          ilike(bgmLibrary.artist, `%${keyword}%`),
        ),
      );
    }

    const where = and(...conditions);

    const [totalResult, itemsResult] = await Promise.all([
      this.db.select({ count: count() }).from(bgmLibrary).where(where),
      this.db
        .select()
        .from(bgmLibrary)
        .where(where)
        .orderBy(desc(bgmLibrary.isSystem), asc(bgmLibrary.id))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    const items: BgmSong[] = itemsResult.map((row) => ({
      id: row.id,
      title: row.title,
      artist: row.artist ?? '',
      category: row.category as BgmCategory,
      mood: row.mood ?? '',
      isSystem: row.isSystem ?? false,
    }));

    return { items, total, categories: this.getCategories() };
  }

  // ---------- 歌单列表 ----------
  async getPlaylists(userId: string): Promise<BgmPlaylist[]> {
    const result = await this.db
      .select({
        id: bgmPlaylists.id,
        name: bgmPlaylists.name,
        description: bgmPlaylists.description,
        projectId: bgmPlaylists.projectId,
        createdAt: bgmPlaylists.createdAt,
        songCount: sql<number>`
          coalesce(
            (SELECT count(*) FROM ${bgmPlaylistItems}
             WHERE ${bgmPlaylistItems.playlistId} = ${bgmPlaylists.id}),
            0
          )
        `,
      })
      .from(bgmPlaylists)
      .where(eq(bgmPlaylists.userId, userId))
      .orderBy(desc(bgmPlaylists.createdAt));

    return result.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.description ?? '',
      projectId: row.projectId ?? null,
      songCount: Number(row.songCount) || 0,
      createdAt: row.createdAt.toISOString(),
    }));
  }

  // ---------- 新建歌单 ----------
  async createPlaylist(
    dto: CreatePlaylistDto,
    userId: string,
  ): Promise<{ id: string }> {
    const result = await this.db
      .insert(bgmPlaylists)
      .values({
        userId,
        name: dto.name,
        description: dto.description ?? null,
        projectId: dto.projectId ?? null,
      })
      .returning({ id: bgmPlaylists.id });

    return { id: result[0].id };
  }

  // ---------- 歌单详情 ----------
  async getPlaylistDetail(
    playlistId: string,
    userId: string,
  ): Promise<BgmPlaylistDetail> {
    await this.ensurePlaylistOwner(playlistId, userId);

    const playlistResult = await this.db
      .select()
      .from(bgmPlaylists)
      .where(eq(bgmPlaylists.id, playlistId))
      .limit(1);

    const playlistRow = playlistResult[0];

    const itemsResult = await this.db
      .select()
      .from(bgmPlaylistItems)
      .where(eq(bgmPlaylistItems.playlistId, playlistId))
      .orderBy(asc(bgmPlaylistItems.sortOrder));

    const items: BgmPlaylistItem[] = itemsResult.map((row) => ({
      id: row.id,
      songId: row.songId ?? null,
      title: row.title,
      artist: row.artist ?? '',
      purposeTag: (row.purposeTag as BgmPurposeTag | null) ?? null,
      segment: row.segment ?? '',
      sortOrder: row.sortOrder,
      note: row.note ?? '',
    }));

    return {
      id: playlistRow.id,
      name: playlistRow.name,
      description: playlistRow.description ?? '',
      projectId: playlistRow.projectId ?? null,
      items,
    };
  }

  // ---------- 修改歌单 ----------
  async updatePlaylist(
    playlistId: string,
    dto: UpdatePlaylistDto,
    userId: string,
  ): Promise<{ success: true }> {
    await this.ensurePlaylistOwner(playlistId, userId);

    const patch: Partial<typeof bgmPlaylists.$inferInsert> = {};
    if (dto.name !== undefined) patch.name = dto.name;
    if (dto.description !== undefined)
      patch.description = dto.description ?? null;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(bgmPlaylists)
      .set(patch)
      .where(eq(bgmPlaylists.id, playlistId))
      .returning({ id: bgmPlaylists.id });

    if (updated.length === 0) {
      throw new NotFoundException('歌单不存在');
    }

    return { success: true };
  }

  // ---------- 删除歌单 ----------
  async deletePlaylist(
    playlistId: string,
    userId: string,
  ): Promise<{ success: true }> {
    await this.ensurePlaylistOwner(playlistId, userId);

    await this.db
      .delete(bgmPlaylists)
      .where(eq(bgmPlaylists.id, playlistId));

    return { success: true };
  }

  // ---------- 批量添加歌曲 ----------
  async addSongs(
    playlistId: string,
    dto: AddSongsDto,
    userId: string,
  ): Promise<{ addedCount: number }> {
    await this.ensurePlaylistOwner(playlistId, userId);

    if (!dto.songs || dto.songs.length === 0) {
      return { addedCount: 0 };
    }

    // 获取当前最大 sortOrder
    const maxResult = await this.db
      .select({
        max: sql<number>`coalesce(max(${bgmPlaylistItems.sortOrder}), -1)`,
      })
      .from(bgmPlaylistItems)
      .where(eq(bgmPlaylistItems.playlistId, playlistId));

    const maxSort = Number(maxResult[0]?.max) || -1;

    const values = dto.songs.map((song, index: number) => ({
      playlistId,
      songId: song.songId ?? null,
      title: song.title,
      artist: song.artist ?? null,
      purposeTag: song.purposeTag ?? null,
      segment: song.segment ?? null,
      sortOrder: maxSort + 1 + index,
      note: null,
    }));

    await this.db.insert(bgmPlaylistItems).values(values);

    return { addedCount: values.length };
  }

  // ---------- 修改歌单条目 ----------
  async updateItem(
    playlistId: string,
    itemId: string,
    dto: UpdateItemDto,
    userId: string,
  ): Promise<{ success: true }> {
    await this.ensureItemOwner(playlistId, itemId, userId);

    const patch: Partial<typeof bgmPlaylistItems.$inferInsert> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.artist !== undefined)
      patch.artist = dto.artist === '' ? null : dto.artist;
    if (dto.purposeTag !== undefined)
      patch.purposeTag = dto.purposeTag ?? null;
    if (dto.segment !== undefined)
      patch.segment = dto.segment === '' ? null : dto.segment;
    if (dto.note !== undefined)
      patch.note = dto.note === '' ? null : dto.note;
    if (dto.sortOrder !== undefined) patch.sortOrder = dto.sortOrder;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(bgmPlaylistItems)
      .set(patch)
      .where(eq(bgmPlaylistItems.id, itemId))
      .returning({ id: bgmPlaylistItems.id });

    if (updated.length === 0) {
      throw new NotFoundException('歌曲条目不存在');
    }

    return { success: true };
  }

  // ---------- 删除歌单条目 ----------
  async deleteItem(
    playlistId: string,
    itemId: string,
    userId: string,
  ): Promise<{ success: true }> {
    await this.ensureItemOwner(playlistId, itemId, userId);

    await this.db
      .delete(bgmPlaylistItems)
      .where(eq(bgmPlaylistItems.id, itemId));

    return { success: true };
  }

  // ---------- 文本导入 ----------
  async importSongs(
    playlistId: string,
    dto: ImportPlaylistDto,
    userId: string,
  ): Promise<{ addedCount: number; skippedCount: number }> {
    await this.ensurePlaylistOwner(playlistId, userId);

    const lines = dto.text.split('\n');
    const parsed: { title: string; artist: string | null }[] = [];
    let skippedCount = 0;

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      const dashIndex = trimmed.indexOf('-');
      if (dashIndex > 0) {
        const title = trimmed.slice(0, dashIndex).trim();
        const artist = trimmed.slice(dashIndex + 1).trim();
        if (title) {
          parsed.push({ title, artist: artist || null });
        } else {
          skippedCount += 1;
        }
      } else {
        if (trimmed) {
          parsed.push({ title: trimmed, artist: null });
        } else {
          skippedCount += 1;
        }
      }
    }

    if (parsed.length === 0) {
      return { addedCount: 0, skippedCount };
    }

    // 获取当前最大 sortOrder
    const maxResult = await this.db
      .select({
        max: sql<number>`coalesce(max(${bgmPlaylistItems.sortOrder}), -1)`,
      })
      .from(bgmPlaylistItems)
      .where(eq(bgmPlaylistItems.playlistId, playlistId));

    const maxSort = Number(maxResult[0]?.max) || -1;

    const values = parsed.map((item, index: number) => ({
      playlistId,
      songId: null,
      title: item.title,
      artist: item.artist,
      purposeTag: dto.defaultPurposeTag ?? null,
      segment: dto.defaultSegment ?? null,
      sortOrder: maxSort + 1 + index,
      note: null,
    }));

    await this.db.insert(bgmPlaylistItems).values(values);

    return { addedCount: values.length, skippedCount };
  }

  // ---------- 导出歌单 ----------
  async exportPlaylist(
    playlistId: string,
    userId: string,
  ): Promise<ExportPlaylistResponse> {
    const detail = await this.getPlaylistDetail(playlistId, userId);

    const purposeTagMap: Record<string, string> = {
      warmup: '暖场',
      entrance: '入场',
      climax: '高潮',
      exit: '退场',
      other: '其他',
    };

    // 按 segment 分组
    const groups = new Map<string, BgmPlaylistItem[]>();
    for (const item of detail.items) {
      const key = item.segment || '其他';
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(item);
    }

    // 按 SEGMENT_ORDER 排序，未列出的放最后
    const sortedKeys = Array.from(groups.keys()).sort((a, b) => {
      const aIdx = SEGMENT_ORDER.indexOf(a);
      const bIdx = SEGMENT_ORDER.indexOf(b);
      if (aIdx === -1 && bIdx === -1) return a.localeCompare(b);
      if (aIdx === -1) return 1;
      if (bIdx === -1) return -1;
      return aIdx - bIdx;
    });

    const lines: string[] = [];
    lines.push(`【婚礼音乐清单 · ${detail.name}】`);
    lines.push('');

    for (const key of sortedKeys) {
      lines.push(`「${key}」`);
      const groupItems = groups.get(key)!;
      groupItems.forEach((item, idx: number) => {
        const parts: string[] = [];
        parts.push(`${idx + 1}. ${item.title}`);
        if (item.artist) {
          parts.push(` - ${item.artist}`);
        }
        if (item.purposeTag) {
          parts.push(`  [${purposeTagMap[item.purposeTag] ?? item.purposeTag}]`);
        }
        if (item.note) {
          parts.push(`  备注${item.note}`);
        }
        lines.push(parts.join(''));
      });
      lines.push('');
    }

    lines.push(`共 ${detail.items.length} 首`);

    return {
      text: lines.join('\n'),
      title: `婚礼音乐清单 · ${detail.name}`,
    };
  }

  // ---------- 归属校验 ----------
  private async ensurePlaylistOwner(
    playlistId: string,
    userId: string,
  ): Promise<void> {
    const result = await this.db
      .select({ id: bgmPlaylists.id, userId: bgmPlaylists.userId })
      .from(bgmPlaylists)
      .where(eq(bgmPlaylists.id, playlistId))
      .limit(1);

    if (result.length === 0 || result[0].userId !== userId) {
      throw new NotFoundException('歌单不存在或无权限访问');
    }
  }

  private async ensureItemOwner(
    playlistId: string,
    itemId: string,
    userId: string,
  ): Promise<void> {
    const result = await this.db
      .select({
        itemId: bgmPlaylistItems.id,
        playlistUserId: bgmPlaylists.userId,
      })
      .from(bgmPlaylistItems)
      .innerJoin(
        bgmPlaylists,
        eq(bgmPlaylistItems.playlistId, bgmPlaylists.id),
      )
      .where(
        and(
          eq(bgmPlaylistItems.id, itemId),
          eq(bgmPlaylistItems.playlistId, playlistId),
        ),
      )
      .limit(1);

    if (result.length === 0 || result[0].playlistUserId !== userId) {
      throw new NotFoundException('歌曲条目不存在或无权限访问');
    }
  }
}
