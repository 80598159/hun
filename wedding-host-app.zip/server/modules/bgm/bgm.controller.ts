import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { BgmService } from './bgm.service';
import { CreatePlaylistDto } from './dto/create-playlist.dto';
import { UpdatePlaylistDto } from './dto/update-playlist.dto';
import { AddSongsDto } from './dto/add-songs.dto';
import { UpdateItemDto } from './dto/update-item.dto';
import { ImportPlaylistDto } from './dto/import-playlist.dto';
import type {
  BgmLibraryListResponse,
  BgmPlaylist,
  BgmPlaylistDetail,
  ExportPlaylistResponse,
} from '@shared/api.interface';

@Controller('api/bgm')
export class BgmController {
  constructor(private readonly bgmService: BgmService) {}

  // 1. BGM库列表
  @UseGuards(AppAuthGuard)
  @Get('library')
  async getLibrary(
    @Req() req: Request,
    @Query('category') category?: string,
    @Query('keyword') keyword?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<BgmLibraryListResponse> {
    const { userId } = req.userContext;
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = Math.min(
      pageSize ? parseInt(pageSize, 10) : 20,
      50,
    );
    return this.bgmService.getLibrary({
      userId,
      category,
      keyword,
      page: pageNum,
      pageSize: pageSizeNum,
    });
  }

  // 2. 我的歌单列表
  @UseGuards(AppAuthGuard)
  @Get('playlists')
  async getPlaylists(@Req() req: Request): Promise<BgmPlaylist[]> {
    const { userId } = req.userContext;
    return this.bgmService.getPlaylists(userId);
  }

  // 3. 新建歌单
  @UseGuards(AppAuthGuard)
  @Post('playlists')
  async createPlaylist(
    @Req() req: Request,
    @Body() dto: CreatePlaylistDto,
  ): Promise<{ id: string }> {
    const { userId } = req.userContext;
    return this.bgmService.createPlaylist(dto, userId);
  }

  // 4. 歌单详情
  @UseGuards(AppAuthGuard)
  @Get('playlists/:id')
  async getPlaylistDetail(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<BgmPlaylistDetail> {
    const { userId } = req.userContext;
    return this.bgmService.getPlaylistDetail(id, userId);
  }

  // 5. 修改歌单基本信息
  @UseGuards(AppAuthGuard)
  @Patch('playlists/:id')
  async updatePlaylist(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdatePlaylistDto,
  ): Promise<{ success: true }> {
    const { userId } = req.userContext;
    return this.bgmService.updatePlaylist(id, dto, userId);
  }

  // 6. 删除歌单
  @UseGuards(AppAuthGuard)
  @Delete('playlists/:id')
  async deletePlaylist(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: true }> {
    const { userId } = req.userContext;
    return this.bgmService.deletePlaylist(id, userId);
  }

  // 7. 批量添加歌曲到歌单
  @UseGuards(AppAuthGuard)
  @Post('playlists/:id/songs')
  async addSongs(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: AddSongsDto,
  ): Promise<{ addedCount: number }> {
    const { userId } = req.userContext;
    return this.bgmService.addSongs(id, dto, userId);
  }

  // 8. 修改歌单单条歌曲
  @UseGuards(AppAuthGuard)
  @Patch('playlists/:id/items/:itemId')
  async updateItem(
    @Req() req: Request,
    @Param('id') id: string,
    @Param('itemId') itemId: string,
    @Body() dto: UpdateItemDto,
  ): Promise<{ success: true }> {
    const { userId } = req.userContext;
    return this.bgmService.updateItem(id, itemId, dto, userId);
  }

  // 9. 移除歌单单条歌曲
  @UseGuards(AppAuthGuard)
  @Delete('playlists/:id/items/:itemId')
  async deleteItem(
    @Req() req: Request,
    @Param('id') id: string,
    @Param('itemId') itemId: string,
  ): Promise<{ success: true }> {
    const { userId } = req.userContext;
    return this.bgmService.deleteItem(id, itemId, userId);
  }

  // 10. 文本批量导入歌曲
  @UseGuards(AppAuthGuard)
  @Post('playlists/:id/import')
  async importSongs(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: ImportPlaylistDto,
  ): Promise<{ addedCount: number; skippedCount: number }> {
    const { userId } = req.userContext;
    return this.bgmService.importSongs(id, dto, userId);
  }

  // 11. 导出歌单为文本
  @UseGuards(AppAuthGuard)
  @Get('playlists/:id/export')
  async exportPlaylist(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<ExportPlaylistResponse> {
    const { userId } = req.userContext;
    return this.bgmService.exportPlaylist(id, userId);
  }
}
