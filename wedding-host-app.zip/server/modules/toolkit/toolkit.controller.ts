import { Controller, Get } from '@nestjs/common';
import { ToolkitService } from './toolkit.service';
import type { RehearsalChecklistGroup, EmergencyMemo } from './toolkit.service';

@Controller('api/toolkit')
export class ToolkitController {
  constructor(private readonly toolkitService: ToolkitService) {}

  @Get('rehearsal-checklist')
  getRehearsalChecklist(): RehearsalChecklistGroup[] {
    return this.toolkitService.getRehearsalChecklist();
  }

  @Get('emergency-memos')
  getEmergencyMemos(): EmergencyMemo[] {
    return this.toolkitService.getEmergencyMemos();
  }

  @Get('contract-template')
  getContractTemplate(): { title: string; content: string } {
    return this.toolkitService.getContractTemplate();
  }
}
