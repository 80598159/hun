import { Injectable, Inject, Logger, BadRequestException, UnauthorizedException, NotFoundException } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gt } from 'drizzle-orm';
import { aiQuotas, userProfiles, appSessions } from '@server/database/schema';
import { hashPassword, verifyPassword } from '@server/common/utils/password';
import * as crypto from 'crypto';
import type { AiQuota } from '@shared/api.interface';

export interface AuthMeResponse {
  userId: string;
  userName: string;
  nickname: string;
  avatarUrl: string;
  phone: string;
  city: string;
  experienceYears: number;
  bio: string;
  styleTags: string;
  isAdmin: boolean;
}

export interface AppLoginResult {
  token: string;
  userId: string;
  nickname: string;
  avatarUrl: string;
  isAdmin: boolean;
  expiresAt: Date;
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  /**
   * 获取当前用户信息，首次访问时自动初始化用户资料和AI额度
   */
  async getMe(userId: string, userName: string): Promise<AuthMeResponse> {
    // 初始化用户资料和AI额度记录
    await this.ensureUserRecords(userId);

    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);

    const displayName = profile?.nickname || userName || '婚礼主持人';

    return {
      userId,
      userName: userName || '',
      nickname: displayName,
      avatarUrl: profile?.avatarUrl || '',
      phone: profile?.phone || '',
      city: profile?.city || '',
      experienceYears: profile?.experienceYears ?? 0,
      bio: profile?.bio || '',
      styleTags: profile?.styleTags || '',
      isAdmin: profile?.isAdmin ?? false,
    };
  }

  /**
   * 账号密码登录
   */
  async login(username: string, password: string): Promise<AppLoginResult> {
    if (!username || !password) {
      throw new BadRequestException('账号和密码不能为空');
    }

    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.username, username))
      .limit(1);

    if (!profile || !profile.passwordHash) {
      throw new UnauthorizedException('账号或密码错误');
    }

    if (profile.status === 'disabled') {
      throw new UnauthorizedException('账号已被禁用');
    }

    const valid = verifyPassword(password, profile.passwordHash);
    if (!valid) {
      throw new UnauthorizedException('账号或密码错误');
    }

    await this.ensureUserRecords(profile.userId);
    return this.createSession(profile.userId);
  }

  /**
   * 创建会话 token
   */
  async createSession(userId: string): Promise<AppLoginResult> {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await this.db.insert(appSessions).values({
      userId,
      token,
      expiresAt,
    });

    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);

    return {
      token,
      userId,
      nickname: profile?.nickname || '婚礼主持人',
      avatarUrl: profile?.avatarUrl || '',
      isAdmin: profile?.isAdmin ?? false,
      expiresAt,
    };
  }

  /**
   * 账号密码注册
   */
  async register(
    username: string,
    password: string,
    nickname?: string,
  ): Promise<AppLoginResult> {
    if (!username || !password) {
      throw new BadRequestException('账号和密码不能为空');
    }

    const [existing] = await this.db
      .select({ id: userProfiles.id })
      .from(userProfiles)
      .where(eq(userProfiles.username, username))
      .limit(1);

    if (existing) {
      throw new BadRequestException('该账号已被注册');
    }

    const userId = `user_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const passwordHash = hashPassword(password);
    const displayName = nickname?.trim() || '婚礼主持人';

    await this.db.insert(userProfiles).values({
      userId,
      username,
      passwordHash,
      nickname: displayName,
      experienceYears: 0,
      status: 'active',
      isAdmin: false,
    });

    await this.ensureUserRecords(userId);
    return this.createSession(userId);
  }

  /**
   * 修改登录密码
   */
  async changePassword(
    userId: string,
    oldPassword: string,
    newPassword: string,
  ): Promise<{ success: boolean }> {
    if (!newPassword || newPassword.length < 6) {
      throw new BadRequestException('新密码长度不能少于6位');
    }

    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);

    if (!profile) {
      throw new NotFoundException('用户不存在');
    }

    if (!profile.passwordHash) {
      throw new BadRequestException('当前账号未设置密码，请先设置密码');
    }

    const valid = verifyPassword(oldPassword, profile.passwordHash);
    if (!valid) {
      throw new BadRequestException('原密码错误');
    }

    const newHash = hashPassword(newPassword);
    await this.db
      .update(userProfiles)
      .set({ passwordHash: newHash })
      .where(eq(userProfiles.userId, userId));

    await this.db
      .delete(appSessions)
      .where(eq(appSessions.userId, userId));

    return { success: true };
  }

  /**
   * 管理员设置/重置用户密码
   */
  async resetPassword(
    userId: string,
    newPassword: string,
  ): Promise<{ success: boolean }> {
    if (!newPassword || newPassword.length < 6) {
      throw new BadRequestException('密码长度不能少于6位');
    }

    const [profile] = await this.db
      .select({ id: userProfiles.id })
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);

    if (!profile) {
      throw new NotFoundException('用户不存在');
    }

    const newHash = hashPassword(newPassword);
    await this.db
      .update(userProfiles)
      .set({ passwordHash: newHash })
      .where(eq(userProfiles.userId, userId));

    await this.db
      .delete(appSessions)
      .where(eq(appSessions.userId, userId));

    return { success: true };
  }

  /**
   * 根据 token 校验登录态，有效则返回 userId
   */
  async verifyToken(token: string): Promise<{ userId: string; userName: string } | null> {
    if (!token) return null;

    const now = new Date();
    const [session] = await this.db
      .select()
      .from(appSessions)
      .where(and(eq(appSessions.token, token), gt(appSessions.expiresAt, now)))
      .limit(1);

    if (!session) return null;

    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, session.userId))
      .limit(1);

    if (!profile || profile.status === 'disabled') return null;

    return {
      userId: session.userId,
      userName: profile.username || '',
    };
  }

  /**
   * 退出登录（销毁当前 token）
   */
  async logout(token: string): Promise<{ success: boolean }> {
    if (token) {
      await this.db.delete(appSessions).where(eq(appSessions.token, token));
    }
    return { success: true };
  }

  /**
   * 获取当前用户AI额度，自动重置上月额度
   */
  async getQuota(userId: string): Promise<AiQuota> {
    await this.ensureUserRecords(userId);

    const [quota] = await this.db
      .select()
      .from(aiQuotas)
      .where(eq(aiQuotas.userId, userId))
      .limit(1);

    if (!quota) {
      throw new Error('AI额度记录不存在');
    }

    // 检查是否需要重置（resetDate 是上个月及以前）
    const now = new Date();
    const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const resetDate = new Date(quota.resetDate);

    if (resetDate < currentMonthStart) {
      // 重置当月计数和 reset_date 为当月1号
      const newResetDate = currentMonthStart.toISOString().split('T')[0];
      const [updated] = await this.db
        .update(aiQuotas)
        .set({
          flowGenerateCount: 0,
          scriptGenerateCount: 0,
          resetDate: newResetDate,
        })
        .where(eq(aiQuotas.userId, userId))
        .returning();

      return this.buildQuotaResponse(updated);
    }

    return this.buildQuotaResponse(quota);
  }

  /**
   * 确保用户资料和AI额度记录存在，不存在则创建
   */
  private async ensureUserRecords(userId: string): Promise<void> {
    try {
      // 检查并创建AI额度记录
      const [existingQuota] = await this.db
        .select({ id: aiQuotas.id })
        .from(aiQuotas)
        .where(eq(aiQuotas.userId, userId))
        .limit(1);

      if (!existingQuota) {
        const now = new Date();
        const resetDate = new Date(now.getFullYear(), now.getMonth(), 1)
          .toISOString()
          .split('T')[0];
        await this.db.insert(aiQuotas).values({
          userId,
          monthlyFlowQuota: 5,
          monthlyScriptQuota: 10,
          totalFlowQuota: 0,
          totalScriptQuota: 0,
          flowGenerateCount: 0,
          scriptGenerateCount: 0,
          resetDate,
        });
      }

      // 检查并创建用户资料记录
      const [existingProfile] = await this.db
        .select({ id: userProfiles.id })
        .from(userProfiles)
        .where(eq(userProfiles.userId, userId))
        .limit(1);

      if (!existingProfile) {
        await this.db.insert(userProfiles).values({
          userId,
          nickname: '婚礼主持人',
          experienceYears: 0,
        });
      }
    } catch (error) {
      // 并发初始化可能导致唯一键冲突，忽略即可
      const errorCode = this.extractErrorCode(error);
      if (errorCode === '23505') {
        this.logger.debug('用户记录已存在（并发初始化）');
        return;
      }
      this.logger.error('初始化用户记录失败', error);
      throw error;
    }
  }

  private buildQuotaResponse(quota: {
    flowGenerateCount: number;
    scriptGenerateCount: number;
    monthlyFlowQuota: number;
    monthlyScriptQuota: number;
    totalFlowQuota: number;
    totalScriptQuota: number;
    resetDate: string | Date;
  }): AiQuota {
    const remainingFlow =
      quota.monthlyFlowQuota + quota.totalFlowQuota - quota.flowGenerateCount;
    const remainingScript =
      quota.monthlyScriptQuota +
      quota.totalScriptQuota -
      quota.scriptGenerateCount;

    const resetDateStr =
      quota.resetDate instanceof Date
        ? quota.resetDate.toISOString().split('T')[0]
        : String(quota.resetDate);

    return {
      flowGenerateCount: quota.flowGenerateCount,
      scriptGenerateCount: quota.scriptGenerateCount,
      monthlyFlowQuota: quota.monthlyFlowQuota,
      monthlyScriptQuota: quota.monthlyScriptQuota,
      totalFlowQuota: quota.totalFlowQuota,
      totalScriptQuota: quota.totalScriptQuota,
      remainingFlow: Math.max(0, remainingFlow),
      remainingScript: Math.max(0, remainingScript),
      resetDate: resetDateStr,
    };
  }

  private extractErrorCode(error: unknown): string | undefined {
    let current: unknown = error;
    for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
      const { code, cause } = current as { code?: unknown; cause?: unknown };
      if (typeof code === 'string') return code;
      current = cause;
    }
    return undefined;
  }
}
