import {
  Controller,
  Get,
  Post,
  Body,
  Req,
  Headers,
  BadRequestException,
  UnauthorizedException,
} from '@nestjs/common';
import type { Request } from 'express';
import { AuthService } from './auth.service';
import type { AuthMeResponse, AppLoginResult } from './auth.service';
import type {
  AiQuota,
  AppLoginRequest,
  AppLoginResponse,
  AppRegisterRequest,
  ChangePasswordRequest,
} from '@shared/api.interface';

@Controller('api/auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(
    @Body() dto: AppLoginRequest,
  ): Promise<AppLoginResponse> {
    if (!dto.username || !dto.password) {
      throw new BadRequestException('账号和密码不能为空');
    }
    const result: AppLoginResult = await this.authService.login(
      dto.username,
      dto.password,
    );
    return {
      token: result.token,
      userId: result.userId,
      nickname: result.nickname,
      avatarUrl: result.avatarUrl,
      isAdmin: result.isAdmin,
      expiresAt: result.expiresAt.toISOString(),
    };
  }

  @Post('register')
  async register(
    @Body() dto: AppRegisterRequest,
  ): Promise<AppLoginResponse> {
    if (!dto.username || !dto.password) {
      throw new BadRequestException('账号和密码不能为空');
    }
    if (dto.username.length < 3) {
      throw new BadRequestException('账号长度不能少于3位');
    }
    if (dto.password.length < 6) {
      throw new BadRequestException('密码长度不能少于6位');
    }
    const result: AppLoginResult = await this.authService.register(
      dto.username,
      dto.password,
      dto.nickname,
    );
    return {
      token: result.token,
      userId: result.userId,
      nickname: result.nickname,
      avatarUrl: result.avatarUrl,
      isAdmin: result.isAdmin,
      expiresAt: result.expiresAt.toISOString(),
    };
  }

  @Post('change-password')
  async changePassword(
    @Headers('x-app-auth') token: string,
    @Body() dto: ChangePasswordRequest,
  ): Promise<{ success: boolean }> {
    const session = await this.authService.verifyToken(token || '');
    if (!session) {
      throw new UnauthorizedException('登录已失效，请重新登录');
    }
    return this.authService.changePassword(
      session.userId,
      dto.oldPassword,
      dto.newPassword,
    );
  }

  @Post('logout')
  async logout(
    @Headers('x-app-auth') token: string,
  ): Promise<{ success: boolean }> {
    return this.authService.logout(token || '');
  }

  @Get('me')
  async getMe(
    @Headers('x-app-auth') token: string,
  ): Promise<AuthMeResponse> {
    const session = await this.authService.verifyToken(token || '');
    if (!session) {
      throw new UnauthorizedException('登录已失效，请重新登录');
    }
    return this.authService.getMe(session.userId, session.userName);
  }

  @Get('quota')
  async getQuota(
    @Headers('x-app-auth') token: string,
  ): Promise<AiQuota> {
    const session = await this.authService.verifyToken(token || '');
    if (!session) {
      throw new UnauthorizedException('登录已失效，请重新登录');
    }
    return this.authService.getQuota(session.userId);
  }
}
