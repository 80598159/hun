import {
  BadRequestException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { asc, eq } from 'drizzle-orm';
import { systemConfigs } from '@server/database/schema';
import type {
  SystemConfigItem,
  SystemConfigListResponse,
  SystemConfigUpdateRequest,
} from '@shared/api.interface';

function toConfigItem(row: typeof systemConfigs.$inferSelect): SystemConfigItem {
  return {
    id: row.id,
    configKey: row.configKey,
    configValue: row.configValue,
    configType: (row.configType === 'number' || row.configType === 'boolean')
      ? row.configType
      : 'string',
    description: row.description || '',
    updatedAt: row.updatedAt.toISOString(),
  };
}

@Injectable()
export class SystemConfigService {
  private readonly logger = new Logger(SystemConfigService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async listConfigs(): Promise<SystemConfigListResponse> {
    const rows = await this.db
      .select()
      .from(systemConfigs)
      .orderBy(asc(systemConfigs.configKey));

    return {
      items: rows.map((row) => toConfigItem(row)),
    };
  }

  async updateConfig(
    configKey: string,
    dto: SystemConfigUpdateRequest,
  ): Promise<{ success: boolean }> {
    if (dto.configValue === undefined) {
      throw new BadRequestException('未提供可更新字段');
    }

    const patch: Partial<typeof systemConfigs.$inferInsert> = {
      configValue: dto.configValue,
    };
    if (dto.description !== undefined) {
      patch.description = dto.description;
    }

    const updated = await this.db
      .update(systemConfigs)
      .set(patch)
      .where(eq(systemConfigs.configKey, configKey))
      .returning({ configKey: systemConfigs.configKey });

    if (updated.length === 0) {
      throw new NotFoundException('系统配置不存在');
    }

    return { success: true };
  }
}
