import { Injectable, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { Inject } from '@nestjs/common';
import { aiApiConfigs } from '@server/database/schema';
import { eq, asc, sql } from 'drizzle-orm';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import {
  buildLlmRequest,
  parseLlmResponse,
  normalizeProtocol,
} from '../ai/llm-protocol.adapter';
import { CloudflareImagesService } from '../ai/cloudflare-images.service';
import { AliyunImagesegService } from '../ai/aliyun-imageseg.service';
import { VolcengineVisualService } from '../ai/volcengine-visual.service';
import { R2UploadService } from '../ai/r2-upload.service';
import type {
  AiApiConfigItem,
  AiApiConfigListResponse,
  AiApiConfigCreateRequest,
  AiApiConfigUpdateRequest,
  AiApiTestResponse,
} from '@shared/api.interface';

function maskApiKey(key: string): string {
  if (!key) return '';
  if (key.length <= 8) return '****';
  const prefix = key.slice(0, 4);
  const suffix = key.slice(-4);
  return `${prefix}****${suffix}`;
}

interface RawConfig {
  id: string;
  name: string;
  protocol: string;
  baseUrl: string;
  apiKey: string;
  modelName: string;
  appId: string | null;
  r2AccessKey: string | null;
  r2SecretKey: string | null;
  r2Bucket: string | null;
  r2Endpoint: string | null;
  r2PublicDomain: string | null;
  cfAccountId: string | null;
  status: string;
  priority: number;
  remark: string | null;
  lastCallStatus: string | null;
  lastCallAt: Date | null;
  lastError: string | null;
  failCount: number;
  createdAt: Date;
}

function toConfigItem(row: RawConfig): AiApiConfigItem {
  return {
    id: row.id,
    name: row.name,
    protocol: normalizeProtocol(row.protocol),
    baseUrl: row.baseUrl,
    apiKeyMasked: maskApiKey(row.apiKey),
    modelName: row.modelName,
    appId: row.appId ?? undefined,
    r2AccessKey: row.r2AccessKey ?? undefined,
    r2SecretKeyMasked: row.r2SecretKey ? maskApiKey(row.r2SecretKey) : undefined,
    r2Bucket: row.r2Bucket ?? undefined,
    r2Endpoint: row.r2Endpoint ?? undefined,
    r2PublicDomain: row.r2PublicDomain ?? undefined,
    cfAccountId: row.cfAccountId ?? undefined,
    status: (row.status === 'active' ? 'active' : 'inactive') as 'active' | 'inactive',
    priority: row.priority,
    remark: row.remark ?? '',
    lastCallStatus: row.lastCallStatus === 'success' || row.lastCallStatus === 'failed'
      ? row.lastCallStatus as 'success' | 'failed'
      : null,
    lastCallAt: row.lastCallAt ? row.lastCallAt.toISOString() : null,
    lastError: row.lastError,
    failCount: row.failCount,
    createdAt: row.createdAt.toISOString(),
  };
}

@Injectable()
export class AiApiConfigService {
  private readonly logger = new Logger(AiApiConfigService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly cloudflareImagesService: CloudflareImagesService,
    private readonly aliyunImagesegService: AliyunImagesegService,
    private readonly volcengineVisualService: VolcengineVisualService,
    private readonly r2UploadService: R2UploadService,
  ) {}

  async listConfigs(): Promise<AiApiConfigListResponse> {
    const rows = await this.db
      .select()
      .from(aiApiConfigs)
      .orderBy(asc(aiApiConfigs.priority), asc(aiApiConfigs.id));

    return {
      items: rows.map((row: RawConfig) => toConfigItem(row)),
    };
  }

  async createConfig(dto: AiApiConfigCreateRequest): Promise<{ id: string }> {
    if (!dto.name?.trim()) {
      throw new BadRequestException('接口名称不能为空');
    }
    if (!dto.baseUrl?.trim()) {
      throw new BadRequestException('接口地址不能为空');
    }
    if (!dto.apiKey?.trim()) {
      throw new BadRequestException('API Key 不能为空');
    }
    const protocol = normalizeProtocol(dto.protocol);
    if (protocol !== 'cloudflare_images' && protocol !== 'aliyun_imageseg' && protocol !== 'volcengine_visual' && !dto.modelName?.trim()) {
      throw new BadRequestException('模型名称不能为空');
    }

    const inserted = await this.db
      .insert(aiApiConfigs)
      .values({
        name: dto.name.trim(),
        protocol,
        baseUrl: dto.baseUrl.trim(),
        apiKey: dto.apiKey.trim(),
        modelName: dto.modelName?.trim() || 'remove-background',
        appId: dto.appId?.trim() || null,
        r2AccessKey: dto.r2AccessKey?.trim() || null,
        r2SecretKey: dto.r2SecretKey?.trim() || null,
        r2Bucket: dto.r2Bucket?.trim() || null,
        r2Endpoint: dto.r2Endpoint?.trim() || null,
        r2PublicDomain: dto.r2PublicDomain?.trim() || null,
        cfAccountId: dto.cfAccountId?.trim() || null,
        status: dto.status ?? 'active',
        priority: dto.priority ?? 100,
        remark: dto.remark ?? '',
      })
      .returning({ id: aiApiConfigs.id });

    return { id: inserted[0].id };
  }

  async updateConfig(id: string, dto: AiApiConfigUpdateRequest): Promise<{ success: boolean }> {
    const [existing] = await this.db
      .select()
      .from(aiApiConfigs)
      .where(eq(aiApiConfigs.id, id))
      .limit(1);

    if (!existing) {
      throw new NotFoundException('接口配置不存在');
    }

    const patch: Record<string, unknown> = {};
    if (dto.name !== undefined) patch.name = dto.name.trim();
    if (dto.protocol !== undefined) patch.protocol = normalizeProtocol(dto.protocol);
    if (dto.baseUrl !== undefined) patch.baseUrl = dto.baseUrl.trim();
    if (dto.apiKey !== undefined && dto.apiKey.trim() !== '') {
      patch.apiKey = dto.apiKey.trim();
    }
    if (dto.modelName !== undefined) patch.modelName = dto.modelName.trim();
    if (dto.appId !== undefined) patch.appId = dto.appId?.trim() || null;
    if (dto.r2AccessKey !== undefined) patch.r2AccessKey = dto.r2AccessKey?.trim() || null;
    if (dto.r2SecretKey !== undefined && dto.r2SecretKey.trim() !== '') {
      patch.r2SecretKey = dto.r2SecretKey.trim();
    }
    if (dto.r2Bucket !== undefined) patch.r2Bucket = dto.r2Bucket?.trim() || null;
    if (dto.r2Endpoint !== undefined) patch.r2Endpoint = dto.r2Endpoint?.trim() || null;
    if (dto.r2PublicDomain !== undefined) patch.r2PublicDomain = dto.r2PublicDomain?.trim() || null;
    if (dto.cfAccountId !== undefined) patch.cfAccountId = dto.cfAccountId?.trim() || null;
    if (dto.status !== undefined) patch.status = dto.status;
    if (dto.priority !== undefined) patch.priority = dto.priority;
    if (dto.remark !== undefined) patch.remark = dto.remark;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(aiApiConfigs)
      .set(patch)
      .where(eq(aiApiConfigs.id, id))
      .returning({ id: aiApiConfigs.id });

    if (updated.length === 0) {
      throw new NotFoundException('接口配置不存在');
    }

    return { success: true };
  }

  async deleteConfig(id: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(aiApiConfigs)
      .where(eq(aiApiConfigs.id, id))
      .returning({ id: aiApiConfigs.id });

    if (deleted.length === 0) {
      throw new NotFoundException('接口配置不存在');
    }

    return { success: true };
  }

  async toggleStatus(id: string, status: 'active' | 'inactive'): Promise<{ success: boolean }> {
    const updated = await this.db
      .update(aiApiConfigs)
      .set({ status })
      .where(eq(aiApiConfigs.id, id))
      .returning({ id: aiApiConfigs.id });

    if (updated.length === 0) {
      throw new NotFoundException('接口配置不存在');
    }

    return { success: true };
  }

  async testConfig(id: string): Promise<AiApiTestResponse> {
    const [config] = await this.db
      .select()
      .from(aiApiConfigs)
      .where(eq(aiApiConfigs.id, id))
      .limit(1);

    if (!config) {
      throw new NotFoundException('接口配置不存在');
    }

    const startTime = Date.now();
    try {
      const protocol = normalizeProtocol(config.protocol);

      if (protocol === 'cloudflare_images') {
        const cfConfig = this.cloudflareImagesService.parseConfig(
          config.baseUrl,
          config.apiKey,
        );
        const hasR2 =
          config.r2Endpoint && config.r2Bucket && config.r2AccessKey && config.r2SecretKey && config.r2PublicDomain;
        let result: { success: boolean; latencyMs: number; message: string };
        if (hasR2) {
          const r2Config = {
            accessKeyId: config.r2AccessKey,
            secretAccessKey: config.r2SecretKey,
            endpoint: config.r2Endpoint,
            bucket: config.r2Bucket,
            publicDomain: config.r2PublicDomain,
          };
          result = await this.cloudflareImagesService.testConnectionWithR2(cfConfig, r2Config, this.r2UploadService);
        } else {
          result = await this.cloudflareImagesService.testConnection(cfConfig);
        }

        await this.db
          .update(aiApiConfigs)
          .set({
            lastCallStatus: result.success ? 'success' : 'failed',
            lastCallAt: sql`CURRENT_TIMESTAMP`,
            lastError: result.success ? null : result.message.slice(0, 500),
            failCount: result.success
              ? aiApiConfigs.failCount
              : sql`${aiApiConfigs.failCount} + 1`,
          })
          .where(eq(aiApiConfigs.id, id));

        return {
          success: result.success,
          latencyMs: result.latencyMs,
          message: result.message,
          steps: 'steps' in result ? result.steps : undefined,
        };
      }

      if (protocol === 'aliyun_imageseg') {
        const aliConfig = this.aliyunImagesegService.parseConfig(
          config.baseUrl,
          config.apiKey,
          config.appId,
        );
        const result = await this.aliyunImagesegService.testConnection(aliConfig);
        const latencyMs = Date.now() - startTime;

        await this.db
          .update(aiApiConfigs)
          .set({
            lastCallStatus: result.success ? 'success' : 'failed',
            lastCallAt: sql`CURRENT_TIMESTAMP`,
            lastError: result.success ? null : result.message.slice(0, 500),
            failCount: result.success
              ? aiApiConfigs.failCount
              : sql`${aiApiConfigs.failCount} + 1`,
          })
          .where(eq(aiApiConfigs.id, id));

        return {
          success: result.success,
          latencyMs,
          message: result.message,
        };
      }

      if (protocol === 'volcengine_visual') {
        const volcConfig = this.volcengineVisualService.parseConfig(
          config.baseUrl,
          config.apiKey,
          config.appId,
        );
        const result = await this.volcengineVisualService.testConnection(volcConfig);
        const latencyMs = Date.now() - startTime;

        await this.db
          .update(aiApiConfigs)
          .set({
            lastCallStatus: result.success ? 'success' : 'failed',
            lastCallAt: sql`CURRENT_TIMESTAMP`,
            lastError: result.success ? null : result.message.slice(0, 500),
            failCount: result.success
              ? aiApiConfigs.failCount
              : sql`${aiApiConfigs.failCount} + 1`,
          })
          .where(eq(aiApiConfigs.id, id));

        return {
          success: result.success,
          latencyMs,
          message: result.message,
        };
      }

      const { url, headers, body } = buildLlmRequest(
        protocol,
        config.baseUrl,
        config.apiKey,
        config.modelName,
        [{ role: 'user', content: '你好' }],
        { maxTokens: 20 },
      );

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const response = await fetch(url, {
        method: 'POST',
        headers,
        body,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;

      if (response.ok) {
        let responseText = '';
        let content = '';
        let parseError: string | null = null;
        try {
          responseText = await response.text();
          const data = JSON.parse(responseText) as unknown;
          content = parseLlmResponse(protocol, data);
        } catch (parseErr) {
          const parseMsg = parseErr instanceof Error ? parseErr.message : '响应解析失败';
          parseError = `${parseMsg}（原始响应：${responseText.slice(0, 150)}）`;
        }

        await this.db
          .update(aiApiConfigs)
          .set({
            lastCallStatus: 'success',
            lastCallAt: sql`CURRENT_TIMESTAMP`,
            lastError: parseError,
          })
          .where(eq(aiApiConfigs.id, id));

        let message = `连接成功，响应耗时 ${latencyMs}ms`;
        if (parseError) {
          message = `连接成功（响应解析异常：${parseError.slice(0, 60)}）`;
        } else if (!content.trim()) {
          message = `连接成功（响应内容为空），耗时 ${latencyMs}ms`;
        }

        return {
          success: true,
          latencyMs,
          message,
        };
      }

      const errorBody = await response.text().catch(() => '');
      const errorMsg = `HTTP ${response.status}: ${errorBody.slice(0, 200)}`;

      await this.db
        .update(aiApiConfigs)
        .set({
          lastCallStatus: 'failed',
          lastCallAt: sql`CURRENT_TIMESTAMP`,
          lastError: errorMsg,
          failCount: sql`${aiApiConfigs.failCount} + 1`,
        })
        .where(eq(aiApiConfigs.id, id));

      return {
        success: false,
        latencyMs,
        message: `连接失败（${response.status}）`,
      };
    } catch (error: unknown) {
      const latencyMs = Date.now() - startTime;
      const errorMsg = error instanceof Error ? error.message : '未知错误';

      await this.db
        .update(aiApiConfigs)
        .set({
          lastCallStatus: 'failed',
          lastCallAt: sql`CURRENT_TIMESTAMP`,
          lastError: errorMsg.slice(0, 500),
          failCount: sql`${aiApiConfigs.failCount} + 1`,
        })
        .where(eq(aiApiConfigs.id, id));

      return {
        success: false,
        latencyMs,
        message: `连接失败：${errorMsg.slice(0, 100)}`,
      };
    }
  }

  async getActiveConfigsOrdered(): Promise<RawConfig[]> {
    const rows = await this.db
      .select()
      .from(aiApiConfigs)
      .where(eq(aiApiConfigs.status, 'active'))
      .orderBy(asc(aiApiConfigs.priority), asc(aiApiConfigs.id));
    return rows as RawConfig[];
  }

  async markSuccess(id: string): Promise<void> {
    await this.db
      .update(aiApiConfigs)
      .set({
        lastCallStatus: 'success',
        lastCallAt: sql`CURRENT_TIMESTAMP`,
        lastError: null,
      })
      .where(eq(aiApiConfigs.id, id));
  }

  async markFailure(id: string, errorMsg: string): Promise<void> {
    await this.db
      .update(aiApiConfigs)
      .set({
        lastCallStatus: 'failed',
        lastCallAt: sql`CURRENT_TIMESTAMP`,
        lastError: errorMsg.slice(0, 500),
        failCount: sql`${aiApiConfigs.failCount} + 1`,
      })
      .where(eq(aiApiConfigs.id, id));
  }
}
