import {
  Body,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { AdminService } from './admin.service';
import { AiApiConfigService } from './ai-api-config.service';
import { SystemConfigService } from './system-config.service';
import type {
  AdminAdjustQuotaRequest,
  AdminAuditListResponse,
  AdminCreateMerchantRequest,
  AdminCreateProductRequest,
  AdminCreateScriptRequest,
  AdminCreateUserRequest,
  AdminDashboardResponse,
  AdminLoginRequest,
  AdminLoginResponse,
  AdminMerchantListResponse,
  AdminOrderListResponse,
  AdminProductListResponse,
  AdminProjectListResponse,
  AdminScriptListResponse,
  AdminUpdateAuditRequest,
  AdminUpdateMerchantRequest,
  AdminUpdateOrderStatusRequest,
  AdminUpdateProductRequest,
  AdminUpdateScriptRequest,
  AdminUpdateUserRequest,
  AdminUserListResponse,
   AdminResetPasswordRequest,
   SystemConfigListResponse,
   SystemConfigUpdateRequest,
   AiApiConfigListResponse,
  AiApiConfigCreateRequest,
  AiApiConfigUpdateRequest,
  AiApiTestResponse,
} from '@shared/api.interface';

import * as crypto from 'crypto';

function computeAdminToken(): string {
  return crypto.createHash('md5').update('admin_123456').digest('hex');
}

function validateAdmin(req: Request): void {
  const token = req.headers['x-admin-token'];
  const expected = computeAdminToken();
  if (!token || token !== expected) {
    throw new ForbiddenException('管理员鉴权失败');
  }
}

@Controller('api/admin')
export class AdminController {
  constructor(
    private readonly adminService: AdminService,
    private readonly aiApiConfigService: AiApiConfigService,
    private readonly systemConfigService: SystemConfigService,
  ) {}

  // ===== 登录 =====
  @Post('login')
  async login(@Body() dto: AdminLoginRequest): Promise<AdminLoginResponse> {
    return this.adminService.login(dto);
  }

  // ===== 数据看板 =====
  @Get('dashboard')
  async getDashboard(@Req() req: Request): Promise<AdminDashboardResponse> {
    validateAdmin(req);
    return this.adminService.getDashboard();
  }

  // ===== 用户管理 =====
  @Get('users')
  async listUsers(
    @Req() req: Request,
    @Query('page') page = '1',
    @Query('pageSize') pageSize = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string,
  ): Promise<AdminUserListResponse> {
    validateAdmin(req);
    return this.adminService.listUsers({
      page: parseInt(page, 10),
      pageSize: parseInt(pageSize, 10),
      keyword,
      status,
    });
  }

  @Patch('users/:userId')
  async updateUser(
    @Req() req: Request,
    @Param('userId') userId: string,
    @Body() dto: AdminUpdateUserRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.updateUser(userId, dto);
  }

  @Patch('users/:userId/quota')
  async adjustQuota(
    @Req() req: Request,
    @Param('userId') userId: string,
    @Body() dto: AdminAdjustQuotaRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.adjustQuota(userId, dto);
  }

  @Post('users')
  async createUser(
    @Req() req: Request,
    @Body() dto: AdminCreateUserRequest,
  ): Promise<{ userId: string }> {
    validateAdmin(req);
    return this.adminService.createUser(dto);
  }

  @Delete('users/:userId')
  async deleteUser(
    @Req() req: Request,
    @Param('userId') userId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.deleteUser(userId);
  }

  @Post('users/:userId/reset-password')
  async resetPassword(
    @Req() req: Request,
    @Param('userId') userId: string,
    @Body() dto: AdminResetPasswordRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.resetPassword(userId, dto.password);
  }

  // ===== 婚礼方案管理 =====
  @Get('projects')
  async listProjects(
    @Req() req: Request,
    @Query('page') page = '1',
    @Query('pageSize') pageSize = '20',
    @Query('keyword') keyword?: string,
    @Query('userId') userIdFilter?: string,
  ): Promise<AdminProjectListResponse> {
    validateAdmin(req);
    return this.adminService.listProjects({
      page: parseInt(page, 10),
      pageSize: parseInt(pageSize, 10),
      keyword,
      userId: userIdFilter,
    });
  }

  @Delete('projects/:projectId')
  async deleteProject(
    @Req() req: Request,
    @Param('projectId') projectId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.deleteProject(projectId);
  }

  @Post('projects/:projectId/reset-poster-photo-count')
  async resetPosterPhotoCount(
    @Req() req: Request,
    @Param('projectId') projectId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.resetPosterPhotoCount(projectId);
  }

  // ===== 系统配置管理 =====
  @Get('system-configs')
  async listSystemConfigs(
    @Req() req: Request,
  ): Promise<SystemConfigListResponse> {
    validateAdmin(req);
    return this.systemConfigService.listConfigs();
  }

  @Patch('system-configs/:configKey')
  async updateSystemConfig(
    @Req() req: Request,
    @Param('configKey') configKey: string,
    @Body() dto: SystemConfigUpdateRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.systemConfigService.updateConfig(configKey, dto);
  }

  // ===== 台词库管理 =====
  @Get('scripts')
  async listScripts(
    @Req() req: Request,
    @Query('page') page = '1',
    @Query('pageSize') pageSize = '20',
    @Query('keyword') keyword?: string,
    @Query('category') category?: string,
    @Query('isSystem') isSystem?: string,
  ): Promise<AdminScriptListResponse> {
    validateAdmin(req);
    return this.adminService.listScripts({
      page: parseInt(page, 10),
      pageSize: parseInt(pageSize, 10),
      keyword,
      category,
      isSystem: isSystem === 'true' ? true : isSystem === 'false' ? false : undefined,
    });
  }

  @Post('scripts')
  async createScript(
    @Req() req: Request,
    @Body() dto: AdminCreateScriptRequest,
  ): Promise<{ id: string }> {
    validateAdmin(req);
    return this.adminService.createSystemScript(dto);
  }

  @Patch('scripts/:scriptId')
  async updateScript(
    @Req() req: Request,
    @Param('scriptId') scriptId: string,
    @Body() dto: AdminUpdateScriptRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.updateScript(scriptId, dto);
  }

  @Delete('scripts/:scriptId')
  async deleteScript(
    @Req() req: Request,
    @Param('scriptId') scriptId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.deleteScript(scriptId);
  }

  // ===== 商品管理 =====
  @Get('products')
  async listProducts(
    @Req() req: Request,
  ): Promise<AdminProductListResponse> {
    validateAdmin(req);
    return this.adminService.listProducts();
  }

  @Post('products')
  async createProduct(
    @Req() req: Request,
    @Body() dto: AdminCreateProductRequest,
  ): Promise<{ id: string }> {
    validateAdmin(req);
    return this.adminService.createProduct(dto);
  }

  @Patch('products/:productId')
  async updateProduct(
    @Req() req: Request,
    @Param('productId') productId: string,
    @Body() dto: AdminUpdateProductRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.updateProduct(productId, dto);
  }

  @Delete('products/:productId')
  async deleteProduct(
    @Req() req: Request,
    @Param('productId') productId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.deleteProduct(productId);
  }

  // ===== 订单管理 =====
  @Get('orders')
  async listOrders(
    @Req() req: Request,
    @Query('page') page = '1',
    @Query('pageSize') pageSize = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string,
  ): Promise<AdminOrderListResponse> {
    validateAdmin(req);
    return this.adminService.listOrders({
      page: parseInt(page, 10),
      pageSize: parseInt(pageSize, 10),
      keyword,
      status,
    });
  }

  @Patch('orders/:orderId/status')
  async updateOrderStatus(
    @Req() req: Request,
    @Param('orderId') orderId: string,
    @Body() dto: AdminUpdateOrderStatusRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.updateOrderStatus(orderId, dto.status);
  }

  // ===== 商家管理 =====
  @Get('merchants')
  async listMerchants(
    @Req() req: Request,
    @Query('page') page = '1',
    @Query('pageSize') pageSize = '20',
    @Query('keyword') keyword?: string,
    @Query('category') category?: string,
    @Query('isApproved') isApproved?: string,
    @Query('isActive') isActive?: string,
  ): Promise<AdminMerchantListResponse> {
    validateAdmin(req);
    return this.adminService.listMerchants({
      page: parseInt(page, 10),
      pageSize: parseInt(pageSize, 10),
      keyword,
      category,
      isApproved: isApproved === 'true' ? true : isApproved === 'false' ? false : undefined,
      isActive: isActive === 'true' ? true : isActive === 'false' ? false : undefined,
    });
  }

  @Post('merchants')
  async createMerchant(
    @Req() req: Request,
    @Body() dto: AdminCreateMerchantRequest,
  ): Promise<{ id: string }> {
    validateAdmin(req);
    return this.adminService.createMerchant(dto);
  }

  @Patch('merchants/:merchantId')
  async updateMerchant(
    @Req() req: Request,
    @Param('merchantId') merchantId: string,
    @Body() dto: AdminUpdateMerchantRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.updateMerchant(merchantId, dto);
  }

  @Delete('merchants/:merchantId')
  async deleteMerchant(
    @Req() req: Request,
    @Param('merchantId') merchantId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.deleteMerchant(merchantId);
  }

  // ===== 内容审核 =====
  @Get('audits')
  async listAudits(
    @Req() req: Request,
    @Query('page') page = '1',
    @Query('pageSize') pageSize = '20',
    @Query('keyword') keyword?: string,
    @Query('status') status?: string,
    @Query('riskLevel') riskLevel?: string,
  ): Promise<AdminAuditListResponse> {
    validateAdmin(req);
    return this.adminService.listAudits({
      page: parseInt(page, 10),
      pageSize: parseInt(pageSize, 10),
      keyword,
      status,
      riskLevel,
    });
  }

  @Patch('audits/:auditId')
  async updateAudit(
    @Req() req: Request,
    @Param('auditId') auditId: string,
    @Body() dto: AdminUpdateAuditRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.adminService.updateAudit(auditId, dto);
  }

  // ===== AI API 配置管理 =====
  @Get('ai-api-configs')
  async listAiApiConfigs(
    @Req() req: Request,
  ): Promise<AiApiConfigListResponse> {
    validateAdmin(req);
    return this.aiApiConfigService.listConfigs();
  }

  @Post('ai-api-configs')
  async createAiApiConfig(
    @Req() req: Request,
    @Body() dto: AiApiConfigCreateRequest,
  ): Promise<{ id: string }> {
    validateAdmin(req);
    return this.aiApiConfigService.createConfig(dto);
  }

  @Patch('ai-api-configs/:configId')
  async updateAiApiConfig(
    @Req() req: Request,
    @Param('configId') configId: string,
    @Body() dto: AiApiConfigUpdateRequest,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.aiApiConfigService.updateConfig(configId, dto);
  }

  @Delete('ai-api-configs/:configId')
  async deleteAiApiConfig(
    @Req() req: Request,
    @Param('configId') configId: string,
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.aiApiConfigService.deleteConfig(configId);
  }

  @Patch('ai-api-configs/:configId/status')
  async toggleAiApiConfigStatus(
    @Req() req: Request,
    @Param('configId') configId: string,
    @Body() body: { status: 'active' | 'inactive' },
  ): Promise<{ success: boolean }> {
    validateAdmin(req);
    return this.aiApiConfigService.toggleStatus(configId, body.status);
  }

  @Post('ai-api-configs/:configId/test')
  async testAiApiConfig(
    @Req() req: Request,
    @Param('configId') configId: string,
  ): Promise<AiApiTestResponse> {
    validateAdmin(req);
    return this.aiApiConfigService.testConfig(configId);
  }
}
