import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';
import { AiApiConfigService } from './ai-api-config.service';
import { SystemConfigService } from './system-config.service';
import { CloudflareImagesService } from '../ai/cloudflare-images.service';
import { AliyunImagesegService } from '../ai/aliyun-imageseg.service';
import { VolcengineVisualService } from '../ai/volcengine-visual.service';
import { R2UploadService } from '../ai/r2-upload.service';

@Module({
  controllers: [AdminController],
  providers: [AdminService, AiApiConfigService, SystemConfigService, CloudflareImagesService, AliyunImagesegService, VolcengineVisualService, R2UploadService],
  exports: [AiApiConfigService, CloudflareImagesService, AliyunImagesegService, VolcengineVisualService, R2UploadService],
})
export class AdminModule {}
