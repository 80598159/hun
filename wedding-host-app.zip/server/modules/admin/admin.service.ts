import * as crypto from 'crypto';
import { hashPassword } from '@server/common/utils/password';
import {
  BadRequestException,
  ForbiddenException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  and,
  count,
  desc,
  eq,
  ilike,
  inArray,
  or,
  sql,
  sum,
} from 'drizzle-orm';
import {
  aiQuotas,
  appSessions,
  contentAudits,
  mallMerchants,
  orders,
  products,
  schedules,
  scripts,
  userProfiles,
  weddingProjects,
  weddingSteps,
} from '@server/database/schema';
import type {
  AdminAdjustQuotaRequest,
  AdminAuditItem,
  AdminAuditListResponse,
  AdminCreateMerchantRequest,
  AdminCreateProductRequest,
  AdminCreateScriptRequest,
  AdminCreateUserRequest,
  AdminDashboardResponse,
  AdminDashboardStats,
  AdminLoginRequest,
  AdminLoginResponse,
  AdminMerchant,
  AdminMerchantListResponse,
  AdminOrderItem,
  AdminOrderListResponse,
  AdminOrderSummary,
  AdminProduct,
  AdminProductListResponse,
  AdminProjectItem,
  AdminProjectListResponse,
  AdminScriptItem,
  AdminScriptListResponse,
  AdminTrendPoint,
  AdminUpdateAuditRequest,
  AdminUpdateMerchantRequest,
  AdminUpdateProductRequest,
  AdminUpdateScriptRequest,
  AdminUpdateUserRequest,
  AdminUserItem,
  AdminUserListResponse,
} from '@shared/api.interface';

interface ListParams {
  page: number;
  pageSize: number;
  keyword?: string;
}

interface UserListParams extends ListParams {
  status?: string;
}

interface ProjectListParams extends ListParams {
  userId?: string;
}

interface ScriptListParams extends ListParams {
  category?: string;
  isSystem?: boolean;
}

interface OrderListParams extends ListParams {
  status?: string;
}

interface MerchantListParams extends ListParams {
  category?: string;
  isApproved?: boolean;
  isActive?: boolean;
}

interface AuditListParams extends ListParams {
  status?: string;
  riskLevel?: string;
}

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ===== 登录 =====
  async login(dto: AdminLoginRequest): Promise<AdminLoginResponse> {
    if (dto.username !== 'admin' || dto.password !== '123456') {
      throw new ForbiddenException('用户名或密码错误');
    }

const token = crypto.createHash('md5').update('admin_123456').digest('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    return {
      token,
      username: dto.username,
      expiresAt: expiresAt.toISOString(),
    };
  }

  // ===== 数据看板 =====
  async getDashboard(): Promise<AdminDashboardResponse> {
    const stats = await this.getDashboardStats();
    const [userTrend, aiTrend, revenueTrend, recentOrders] = await Promise.all([
      this.getUserTrend(),
      this.getAiTrend(),
      this.getRevenueTrend(),
      this.getRecentOrders(),
    ]);

    return {
      stats,
      userTrend,
      aiTrend,
      revenueTrend,
      recentOrders,
    };
  }

  private async getDashboardStats(): Promise<AdminDashboardStats> {
    const [
      [{ totalUsers }],
      [{ activeHosts }],
      [{ totalProjects }],
      aiResult,
      [{ totalRevenue }],
      [{ totalOrders }],
      [{ materialSales }],
      [{ merchantCount }],
      [{ pendingMerchants }],
      [{ pendingAudits }],
    ] = await Promise.all([
      this.db
        .select({ totalUsers: count() })
        .from(userProfiles),
      this.db
        .select({ activeHosts: count() })
        .from(userProfiles)
        .where(eq(userProfiles.status, 'active')),
      this.db
        .select({ totalProjects: count() })
        .from(weddingProjects),
      this.db
        .select({
          flowCount: sum(aiQuotas.flowGenerateCount),
          scriptCount: sum(aiQuotas.scriptGenerateCount),
        })
        .from(aiQuotas),
      this.db
        .select({ totalRevenue: sum(orders.amount) })
        .from(orders)
        .where(eq(orders.status, 'paid')),
      this.db
        .select({ totalOrders: count() })
        .from(orders),
      this.db
        .select({ materialSales: count() })
        .from(orders)
        .where(
          and(
            eq(orders.productType, 'poster_template'),
            eq(orders.status, 'paid'),
          ),
        ),
      this.db
        .select({ merchantCount: count() })
        .from(mallMerchants),
      this.db
        .select({ pendingMerchants: count() })
        .from(mallMerchants)
        .where(eq(mallMerchants.isApproved, false)),
      this.db
        .select({ pendingAudits: count() })
        .from(contentAudits)
        .where(eq(contentAudits.status, 'pending')),
    ]);

    const aiRow = aiResult[0];
    const totalAiCalls =
      Number(aiRow?.flowCount ?? 0) + Number(aiRow?.scriptCount ?? 0);

    return {
      totalUsers: Number(totalUsers),
      activeHosts: Number(activeHosts),
      totalProjects: Number(totalProjects),
      totalAiCalls,
      totalRevenue: Number(totalRevenue ?? 0),
      totalOrders: Number(totalOrders),
      materialSales: Number(materialSales),
      merchantCount: Number(merchantCount),
      pendingMerchants: Number(pendingMerchants),
      pendingAudits: Number(pendingAudits),
    };
  }

  private getUserTrendSql(): string {
    return `
      SELECT
        dates.day::date AS date,
        COALESCE(COUNT(up.user_id), 0) AS value
      FROM
        generate_series(
          CURRENT_DATE - INTERVAL '6 days',
          CURRENT_DATE,
          INTERVAL '1 day'
        ) AS dates(day)
      LEFT JOIN
        user_profiles up ON DATE(up._created_at) = dates.day::date
      GROUP BY
        dates.day
      ORDER BY
        dates.day
    `;
  }

  private async getUserTrend(): Promise<AdminTrendPoint[]> {
    const result = await this.db.execute(sql.raw(this.getUserTrendSql()));
    return this.rowsToTrendPoints(result as unknown as { date: string; value: string | number }[]);
  }

  private getRevenueTrendSql(): string {
    return `
      SELECT
        dates.day::date AS date,
        COALESCE(SUM(o.amount::numeric), 0) AS value
      FROM
        generate_series(
          CURRENT_DATE - INTERVAL '6 days',
          CURRENT_DATE,
          INTERVAL '1 day'
        ) AS dates(day)
      LEFT JOIN
        orders o ON DATE(o.paid_at) = dates.day::date
        AND o.status = 'paid'
      GROUP BY
        dates.day
      ORDER BY
        dates.day
    `;
  }

  private async getRevenueTrend(): Promise<AdminTrendPoint[]> {
    const result = await this.db.execute(sql.raw(this.getRevenueTrendSql()));
    return this.rowsToTrendPoints(result as unknown as { date: string; value: string | number }[]);
  }

  private async getAiTrend(): Promise<AdminTrendPoint[]> {
    // 没有调用记录表，用0填充近7天
    const points: AdminTrendPoint[] = [];
    for (let i = 6; i >= 0; i -= 1) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      points.push({
        date: d.toISOString().split('T')[0],
        value: 0,
      });
    }
    return points;
  }

  private rowsToTrendPoints(
    rows: { date: string; value: string | number }[],
  ): AdminTrendPoint[] {
    return rows.map((row: { date: string; value: string | number }) => ({
      date: String(row.date).split('T')[0],
      value: Number(row.value),
    }));
  }

  private async getRecentOrders(): Promise<AdminOrderItem[]> {
    const result = await this.db
      .select({
        id: orders.id,
        userId: orders.userId,
        userNickname: userProfiles.nickname,
        productType: orders.productType,
        productName: orders.productName,
        amount: orders.amount,
        status: orders.status,
        paidAt: orders.paidAt,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .leftJoin(userProfiles, eq(orders.userId, userProfiles.userId))
      .orderBy(desc(orders.createdAt))
      .limit(5);

    return result.map((row) => ({
      id: row.id,
      userId: row.userId,
      userNickname: row.userNickname || '未知用户',
      productType: row.productType,
      productName: row.productName,
      amount: Number(row.amount),
      status: row.status ?? 'pending',
      paidAt: row.paidAt ? row.paidAt.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
    }));
  }

  // ===== 用户管理 =====
  async listUsers(params: UserListParams): Promise<AdminUserListResponse> {
    const { page, pageSize, keyword, status } = params;
    const offset = (page - 1) * pageSize;

    const whereConditions = [];
    if (keyword) {
      whereConditions.push(
        or(
          ilike(userProfiles.nickname, `%${keyword}%`),
          ilike(userProfiles.userId, `%${keyword}%`),
          ilike(userProfiles.username, `%${keyword}%`),
        ),
      );
    }
    if (status) {
      whereConditions.push(eq(userProfiles.status, status));
    }
    const where = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const baseQuery = this.db.select().from(userProfiles);
    const query = where ? baseQuery.where(where) : baseQuery;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(userProfiles)
        .where(where ?? undefined),
      query
        .orderBy(desc(userProfiles.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    if (rows.length === 0) {
      return { items: [], total, page, pageSize };
    }

    const userIds = rows.map((row) => row.userId);

    // 批量查 ai_quotas
    const quotaRows = await this.db
      .select()
      .from(aiQuotas)
      .where(inArray(aiQuotas.userId, userIds));
    const quotaMap = new Map<string, typeof quotaRows[number]>();
    for (const q of quotaRows) {
      quotaMap.set(q.userId, q);
    }

    // 批量统计 projectCount
    const projectCountRows = await this.db
      .select({
        userId: weddingProjects.userId,
        count: count(),
      })
      .from(weddingProjects)
      .where(inArray(weddingProjects.userId, userIds))
      .groupBy(weddingProjects.userId);
    const projectCountMap = new Map<string, number>();
    for (const p of projectCountRows) {
      projectCountMap.set(p.userId, Number(p.count));
    }

    const items: AdminUserItem[] = rows.map((row) => {
      const q = quotaMap.get(row.userId);
      const remainingFlow = q
        ? (q.monthlyFlowQuota ?? 0) + (q.totalFlowQuota ?? 0) - (q.flowGenerateCount ?? 0)
        : 0;
      const remainingScript = q
        ? (q.monthlyScriptQuota ?? 0) + (q.totalScriptQuota ?? 0) - (q.scriptGenerateCount ?? 0)
        : 0;

      return {
        userId: row.userId,
        nickname: row.nickname || '',
        avatarUrl: row.avatarUrl || '',
        phone: row.phone || '',
        city: row.city || '',
        experienceYears: row.experienceYears ?? 0,
        status: row.status,
        isAdmin: row.isAdmin,
        createdAt: row.createdAt.toISOString(),
        remainingFlow: Math.max(0, remainingFlow),
        remainingScript: Math.max(0, remainingScript),
        monthlyFlowQuota: q?.monthlyFlowQuota ?? 0,
        monthlyScriptQuota: q?.monthlyScriptQuota ?? 0,
        totalFlowQuota: q?.totalFlowQuota ?? 0,
        totalScriptQuota: q?.totalScriptQuota ?? 0,
        projectCount: projectCountMap.get(row.userId) ?? 0,
      };
    });

    return { items, total, page, pageSize };
  }

  async createUser(
    dto: AdminCreateUserRequest,
  ): Promise<{ userId: string }> {
    if (!dto.username || dto.username.length < 3) {
      throw new BadRequestException('账号长度至少3位');
    }
    if (!dto.password || dto.password.length < 6) {
      throw new BadRequestException('密码长度至少6位');
    }
    if (!dto.nickname || dto.nickname.trim().length === 0) {
      throw new BadRequestException('昵称不能为空');
    }

    // 检查 username 唯一性
    const existing = await this.db
      .select({ userId: userProfiles.userId })
      .from(userProfiles)
      .where(eq(userProfiles.username, dto.username))
      .limit(1);
    if (existing.length > 0) {
      throw new BadRequestException('该账号已被使用');
    }

    const userId = `user_${crypto.randomBytes(4).toString('hex')}`;
    const passwordHash = hashPassword(dto.password);

    await this.db.transaction(async (tx) => {
      await tx.insert(userProfiles).values({
        userId,
        username: dto.username,
        passwordHash,
        nickname: dto.nickname.trim(),
        status: 'active',
        isAdmin: false,
      });

      await tx.insert(aiQuotas).values({
        userId,
        monthlyFlowQuota: 5,
        monthlyScriptQuota: 10,
        totalFlowQuota: 0,
        totalScriptQuota: 0,
        resetDate: new Date().toISOString().split('T')[0],
      });
    });

    return { userId };
  }

  async deleteUser(userId: string): Promise<{ success: boolean }> {
    // 检查用户是否存在
    const user = await this.db
      .select({ id: userProfiles.id })
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);
    if (user.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    await this.db.transaction(async (tx) => {
      // 删除 app_sessions
      await tx.delete(appSessions).where(eq(appSessions.userId, userId));
      // 删除 content_audits
      await tx.delete(contentAudits).where(eq(contentAudits.userId, userId));
      // 删除 orders
      await tx.delete(orders).where(eq(orders.userId, userId));
      // 删除 ai_quotas
      await tx.delete(aiQuotas).where(eq(aiQuotas.userId, userId));
      // 删除 scripts
      await tx.delete(scripts).where(eq(scripts.userId, userId));
      // 删除 schedules
      await tx.delete(schedules).where(eq(schedules.userId, userId));
      // 删除 wedding_steps（外键 CASCADE 自动删 wedding_steps，手动删更稳妥）
      // 先查该用户的所有 projectIds，再删 steps，最后删 projects
      const projectRows = await tx
        .select({ id: weddingProjects.id })
        .from(weddingProjects)
        .where(eq(weddingProjects.userId, userId));
      const projectIds = projectRows.map((p) => p.id);
      if (projectIds.length > 0) {
        await tx
          .delete(weddingSteps)
          .where(inArray(weddingSteps.projectId, projectIds));
      }
      // 删除 wedding_projects
      await tx
        .delete(weddingProjects)
        .where(eq(weddingProjects.userId, userId));
      // 最后删 user_profiles
      await tx.delete(userProfiles).where(eq(userProfiles.userId, userId));
    });

    return { success: true };
  }

  async resetPassword(
    userId: string,
    password: string,
  ): Promise<{ success: boolean }> {
    if (!password || password.length < 6) {
      throw new BadRequestException('密码长度至少6位');
    }

    const user = await this.db
      .select({ id: userProfiles.id })
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);
    if (user.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    const passwordHash = hashPassword(password);

    await this.db.transaction(async (tx) => {
      await tx
        .update(userProfiles)
        .set({ passwordHash })
        .where(eq(userProfiles.userId, userId));
      // 清除所有会话
      await tx.delete(appSessions).where(eq(appSessions.userId, userId));
    });

    return { success: true };
  }

  async updateUser(
    userId: string,
    dto: AdminUpdateUserRequest,
  ): Promise<{ success: boolean }> {
    const patch: Record<string, unknown> = {};
    if (dto.status !== undefined) patch.status = dto.status;
    if (dto.isAdmin !== undefined) patch.isAdmin = dto.isAdmin;
    if (dto.nickname !== undefined) patch.nickname = dto.nickname;
    if (dto.avatarUrl !== undefined) patch.avatarUrl = dto.avatarUrl;
    if (dto.city !== undefined) patch.city = dto.city;
    if (dto.phone !== undefined) patch.phone = dto.phone;
    if (dto.experienceYears !== undefined) patch.experienceYears = dto.experienceYears;
    if (dto.bio !== undefined) patch.bio = dto.bio;
    if (dto.styleTags !== undefined) patch.styleTags = dto.styleTags;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(userProfiles)
      .set(patch)
      .where(eq(userProfiles.userId, userId))
      .returning({ id: userProfiles.id });

    if (updated.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return { success: true };
  }

  async adjustQuota(
    userId: string,
    dto: AdminAdjustQuotaRequest,
  ): Promise<{ success: boolean }> {
    const patch: Record<string, unknown> = {};
    if (dto.monthlyFlowQuota !== undefined) patch.monthlyFlowQuota = dto.monthlyFlowQuota;
    if (dto.monthlyScriptQuota !== undefined) patch.monthlyScriptQuota = dto.monthlyScriptQuota;
    if (dto.totalFlowQuota !== undefined) patch.totalFlowQuota = dto.totalFlowQuota;
    if (dto.totalScriptQuota !== undefined) patch.totalScriptQuota = dto.totalScriptQuota;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const [existing] = await this.db
      .select({ id: aiQuotas.id })
      .from(aiQuotas)
      .where(eq(aiQuotas.userId, userId))
      .limit(1);

    if (!existing) {
      // 不存在则创建
      await this.db.insert(aiQuotas).values({
        userId,
        monthlyFlowQuota: dto.monthlyFlowQuota ?? 5,
        monthlyScriptQuota: dto.monthlyScriptQuota ?? 10,
        totalFlowQuota: dto.totalFlowQuota ?? 0,
        totalScriptQuota: dto.totalScriptQuota ?? 0,
      });
    } else {
      await this.db
        .update(aiQuotas)
        .set(patch)
        .where(eq(aiQuotas.userId, userId));
    }

    return { success: true };
  }

  // ===== 婚礼方案管理 =====
  async listProjects(params: ProjectListParams): Promise<AdminProjectListResponse> {
    const { page, pageSize, keyword, userId } = params;
    const offset = (page - 1) * pageSize;

    const whereConditions = [];
    if (keyword) {
      whereConditions.push(
        or(
          ilike(weddingProjects.title, `%${keyword}%`),
          ilike(weddingProjects.hotelName, `%${keyword}%`),
        ),
      );
    }
    if (userId) {
      whereConditions.push(eq(weddingProjects.userId, userId));
    }
    const where = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const baseQuery = this.db
      .select({
        id: weddingProjects.id,
        userId: weddingProjects.userId,
        title: weddingProjects.title,
        groomName: weddingProjects.groomName,
        brideName: weddingProjects.brideName,
        weddingDate: weddingProjects.weddingDate,
        timeType: weddingProjects.timeType,
        hotelName: weddingProjects.hotelName,
        planner: weddingProjects.planner,
        supervisor: weddingProjects.supervisor,
        videographer: weddingProjects.videographer,
        photographer: weddingProjects.photographer,
        soundController: weddingProjects.soundController,
        specialNotes: weddingProjects.specialNotes,
        status: weddingProjects.status,
        isArchived: weddingProjects.isArchived,
        posterTemplate: weddingProjects.posterTemplate,
        scheduleId: weddingProjects.scheduleId,
        posterPhotoUpdateCount: weddingProjects.posterPhotoUpdateCount,
        createdAt: weddingProjects.createdAt,
        updatedAt: weddingProjects.updatedAt,
        userNickname: userProfiles.nickname,
      })
      .from(weddingProjects)
      .leftJoin(userProfiles, eq(weddingProjects.userId, userProfiles.userId));

    const query = where ? baseQuery.where(where) : baseQuery;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(weddingProjects)
        .where(where ?? undefined),
      query
        .orderBy(desc(weddingProjects.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    if (rows.length === 0) {
      return { items: [], total, page, pageSize };
    }

    const projectIds = rows.map((row) => row.id);
    const stepCountRows = await this.db
      .select({
        projectId: weddingSteps.projectId,
        count: count(),
      })
      .from(weddingSteps)
      .where(inArray(weddingSteps.projectId, projectIds))
      .groupBy(weddingSteps.projectId);
    const stepCountMap = new Map<string, number>();
    for (const s of stepCountRows) {
      stepCountMap.set(s.projectId, Number(s.count));
    }

    const items: AdminProjectItem[] = rows.map((row) => ({
      id: row.id,
      title: row.title,
      groomName: row.groomName || '',
      brideName: row.brideName || '',
      weddingDate: row.weddingDate
        ? new Date(row.weddingDate).toISOString().split('T')[0]
        : null,
      timeType: (row.timeType ?? 'dinner') as 'lunch' | 'dinner',
      hotelName: row.hotelName || '',
      planner: row.planner || '',
      supervisor: row.supervisor || '',
      videographer: row.videographer || '',
      photographer: row.photographer || '',
      soundController: row.soundController || '',
      specialNotes: row.specialNotes || '',
      status: row.status ?? 'active',
      isArchived: row.isArchived ?? false,
      posterTemplate: row.posterTemplate ?? 'classic',
      scheduleId: row.scheduleId ?? null,
      posterPhotoUpdateCount: row.posterPhotoUpdateCount ?? 0,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      userNickname: row.userNickname || '未知用户',
      stepCount: stepCountMap.get(row.id) ?? 0,
    }));

    return { items, total, page, pageSize };
  }

  async deleteProject(projectId: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(weddingProjects)
      .where(eq(weddingProjects.id, projectId))
      .returning({ id: weddingProjects.id });

    if (deleted.length === 0) {
      throw new NotFoundException('方案不存在');
    }

    return { success: true };
  }

  async resetPosterPhotoCount(projectId: string): Promise<{ success: boolean }> {
    const updated = await this.db
      .update(weddingProjects)
      .set({ posterPhotoUpdateCount: 0 })
      .where(eq(weddingProjects.id, projectId))
      .returning({ id: weddingProjects.id });

    if (updated.length === 0) {
      throw new NotFoundException('方案不存在');
    }

    return { success: true };
  }

  // ===== 台词库管理 =====
  async listScripts(params: ScriptListParams): Promise<AdminScriptListResponse> {
    const { page, pageSize, keyword, category, isSystem } = params;
    const offset = (page - 1) * pageSize;

    const whereConditions = [];
    if (keyword) {
      whereConditions.push(ilike(scripts.title, `%${keyword}%`));
    }
    if (category) {
      whereConditions.push(eq(scripts.category, category));
    }
    if (isSystem !== undefined) {
      whereConditions.push(eq(scripts.isSystem, isSystem));
    }
    const where = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const baseQuery = this.db
      .select({
        id: scripts.id,
        userId: scripts.userId,
        category: scripts.category,
        title: scripts.title,
        content: scripts.content,
        isSystem: scripts.isSystem,
        isFavorite: scripts.isFavorite,
        styleTags: scripts.styleTags,
        createdAt: scripts.createdAt,
        userNickname: userProfiles.nickname,
      })
      .from(scripts)
      .leftJoin(userProfiles, eq(scripts.userId, userProfiles.userId));

    const query = where ? baseQuery.where(where) : baseQuery;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(scripts)
        .where(where ?? undefined),
      query
        .orderBy(desc(scripts.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    const items: AdminScriptItem[] = rows.map((row) => ({
      id: row.id,
      category: row.category,
      title: row.title,
      content: row.content,
      isSystem: row.isSystem ?? false,
      isFavorite: row.isFavorite ?? false,
      styleTags: row.styleTags || '',
      userNickname: row.isSystem ? '系统预置' : row.userNickname || '未知用户',
      createdAt: row.createdAt.toISOString(),
    }));

    return { items, total, page, pageSize };
  }

  async createSystemScript(dto: AdminCreateScriptRequest): Promise<{ id: string }> {
    const [created] = await this.db
      .insert(scripts)
      .values({
        userId: 'system',
        category: dto.category,
        title: dto.title,
        content: dto.content,
        styleTags: dto.styleTags,
        isSystem: true,
      })
      .returning({ id: scripts.id });

    return { id: created.id };
  }

  async updateScript(
    scriptId: string,
    dto: AdminUpdateScriptRequest,
  ): Promise<{ success: boolean }> {
    const patch: Record<string, unknown> = {};
    if (dto.category !== undefined) patch.category = dto.category;
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.content !== undefined) patch.content = dto.content;
    if (dto.styleTags !== undefined) patch.styleTags = dto.styleTags;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(scripts)
      .set(patch)
      .where(eq(scripts.id, scriptId))
      .returning({ id: scripts.id });

    if (updated.length === 0) {
      throw new NotFoundException('台词不存在');
    }

    return { success: true };
  }

  async deleteScript(scriptId: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(scripts)
      .where(eq(scripts.id, scriptId))
      .returning({ id: scripts.id });

    if (deleted.length === 0) {
      throw new NotFoundException('台词不存在');
    }

    return { success: true };
  }

  // ===== 商品管理 =====
  async listProducts(): Promise<AdminProductListResponse> {
    const rows = await this.db
      .select()
      .from(products)
      .orderBy(products.sortOrder, desc(products.createdAt));

    if (rows.length === 0) {
      return { items: [], total: 0 };
    }

    const productNames = rows.map((row) => row.name);
    const salesRows = await this.db
      .select({
        productName: orders.productName,
        count: count(),
      })
      .from(orders)
      .where(
        and(
          inArray(orders.productName, productNames),
          eq(orders.status, 'paid'),
        ),
      )
      .groupBy(orders.productName);
    const salesMap = new Map<string, number>();
    for (const s of salesRows) {
      salesMap.set(s.productName, Number(s.count));
    }

    const items: AdminProduct[] = rows.map((row) => ({
      id: row.id,
      type: row.type,
      name: row.name,
      description: row.description || '',
      price: Number(row.price),
      originalPrice: row.originalPrice != null ? Number(row.originalPrice) : null,
      flowQuota: row.flowQuota ?? 0,
      scriptQuota: row.scriptQuota ?? 0,
      posterTemplate: row.posterTemplate || '',
      isActive: row.isActive,
      sortOrder: row.sortOrder,
      createdAt: row.createdAt.toISOString(),
      salesCount: salesMap.get(row.name) ?? 0,
    }));

    return { items, total: items.length };
  }

  async createProduct(dto: AdminCreateProductRequest): Promise<{ id: string }> {
    const [created] = await this.db
      .insert(products)
      .values({
        type: dto.type,
        name: dto.name,
        description: dto.description,
        price: String(dto.price),
        originalPrice: dto.originalPrice != null ? String(dto.originalPrice) : null,
        flowQuota: dto.flowQuota ?? 0,
        scriptQuota: dto.scriptQuota ?? 0,
        posterTemplate: dto.posterTemplate,
        sortOrder: dto.sortOrder ?? 0,
      })
      .returning({ id: products.id });

    return { id: created.id };
  }

  async updateProduct(
    productId: string,
    dto: AdminUpdateProductRequest,
  ): Promise<{ success: boolean }> {
    const patch: Record<string, unknown> = {};
    if (dto.type !== undefined) patch.type = dto.type;
    if (dto.name !== undefined) patch.name = dto.name;
    if (dto.description !== undefined) patch.description = dto.description;
    if (dto.price !== undefined) patch.price = String(dto.price);
    if (dto.originalPrice !== undefined) {
      patch.originalPrice =
        dto.originalPrice != null ? String(dto.originalPrice) : null;
    }
    if (dto.flowQuota !== undefined) patch.flowQuota = dto.flowQuota;
    if (dto.scriptQuota !== undefined) patch.scriptQuota = dto.scriptQuota;
    if (dto.posterTemplate !== undefined) patch.posterTemplate = dto.posterTemplate;
    if (dto.isActive !== undefined) patch.isActive = dto.isActive;
    if (dto.sortOrder !== undefined) patch.sortOrder = dto.sortOrder;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(products)
      .set(patch)
      .where(eq(products.id, productId))
      .returning({ id: products.id });

    if (updated.length === 0) {
      throw new NotFoundException('商品不存在');
    }

    return { success: true };
  }

  async deleteProduct(productId: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(products)
      .where(eq(products.id, productId))
      .returning({ id: products.id });

    if (deleted.length === 0) {
      throw new NotFoundException('商品不存在');
    }

    return { success: true };
  }

  // ===== 订单管理 =====
  async listOrders(params: OrderListParams): Promise<AdminOrderListResponse> {
    const { page, pageSize, keyword, status } = params;
    const offset = (page - 1) * pageSize;

    const whereConditions = [];
    if (keyword) {
      whereConditions.push(
        or(
          ilike(orders.productName, `%${keyword}%`),
          ilike(userProfiles.nickname, `%${keyword}%`),
        ),
      );
    }
    if (status) {
      whereConditions.push(eq(orders.status, status));
    }
    const where = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const baseQuery = this.db
      .select({
        id: orders.id,
        userId: orders.userId,
        userNickname: userProfiles.nickname,
        productType: orders.productType,
        productName: orders.productName,
        amount: orders.amount,
        status: orders.status,
        paidAt: orders.paidAt,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .leftJoin(userProfiles, eq(orders.userId, userProfiles.userId));

    const query = where ? baseQuery.where(where) : baseQuery;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(orders)
        .leftJoin(userProfiles, eq(orders.userId, userProfiles.userId))
        .where(where ?? undefined),
      query
        .orderBy(desc(orders.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    const items: AdminOrderItem[] = rows.map((row) => ({
      id: row.id,
      userId: row.userId,
      userNickname: row.userNickname || '未知用户',
      productType: row.productType,
      productName: row.productName,
      amount: Number(row.amount),
      status: row.status ?? 'pending',
      paidAt: row.paidAt ? row.paidAt.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
    }));

    // 计算 summary（全局统计，不受分页影响，但受 keyword/status 过滤影响）
    const summary = await this.getOrderSummary(where);

    return { items, total, page, pageSize, summary };
  }

  private async getOrderSummary(
    where: ReturnType<typeof and> | undefined,
  ): Promise<AdminOrderSummary> {
    const allOrders = await this.db
      .select({
        status: orders.status,
        amount: orders.amount,
      })
      .from(orders)
      .leftJoin(userProfiles, eq(orders.userId, userProfiles.userId))
      .where(where ?? undefined);

    let totalAmount = 0;
    let paidAmount = 0;
    let refundAmount = 0;
    let paidCount = 0;

    for (const o of allOrders) {
      const amt = Number(o.amount);
      totalAmount += amt;
      if (o.status === 'paid') {
        paidAmount += amt;
        paidCount += 1;
      } else if (o.status === 'refunded') {
        refundAmount += amt;
      }
    }

    return { totalAmount, paidAmount, refundAmount, paidCount };
  }

  async updateOrderStatus(
    orderId: string,
    newStatus: 'pending' | 'paid' | 'refunded' | 'cancelled',
  ): Promise<{ success: boolean }> {
    const [existing] = await this.db
      .select()
      .from(orders)
      .where(eq(orders.id, orderId))
      .limit(1);

    if (!existing) {
      throw new NotFoundException('订单不存在');
    }

    const oldStatus = existing.status ?? 'pending';
    if (oldStatus === newStatus) {
      return { success: true };
    }

    const flowQuota = existing.flowQuota ?? 0;
    const scriptQuota = existing.scriptQuota ?? 0;
    const userId = existing.userId;

    await this.db.transaction(async (tx) => {
      const patch: Record<string, unknown> = { status: newStatus };

      const wasPaid = oldStatus === 'paid';
      const becomesPaid = newStatus === 'paid';

      if (!wasPaid && becomesPaid) {
        // 变为 paid：加额度
        patch.paidAt = new Date();
        if (flowQuota > 0 || scriptQuota > 0) {
          const [quota] = await tx
            .select()
            .from(aiQuotas)
            .where(eq(aiQuotas.userId, userId))
            .limit(1);

          if (quota) {
            await tx
              .update(aiQuotas)
              .set({
                totalFlowQuota: (quota.totalFlowQuota ?? 0) + flowQuota,
                totalScriptQuota: (quota.totalScriptQuota ?? 0) + scriptQuota,
              })
              .where(eq(aiQuotas.id, quota.id));
          } else {
            await tx.insert(aiQuotas).values({
              userId,
              totalFlowQuota: flowQuota,
              totalScriptQuota: scriptQuota,
            });
          }
        }
      } else if (wasPaid && (newStatus === 'refunded' || newStatus === 'cancelled')) {
        // 从 paid 变为 refunded/cancelled：扣额度
        if (flowQuota > 0 || scriptQuota > 0) {
          const [quota] = await tx
            .select()
            .from(aiQuotas)
            .where(eq(aiQuotas.userId, userId))
            .limit(1);

          if (quota) {
            await tx
              .update(aiQuotas)
              .set({
                totalFlowQuota: Math.max(
                  0,
                  (quota.totalFlowQuota ?? 0) - flowQuota,
                ),
                totalScriptQuota: Math.max(
                  0,
                  (quota.totalScriptQuota ?? 0) - scriptQuota,
                ),
              })
              .where(eq(aiQuotas.id, quota.id));
          }
        }
      }

      await tx
        .update(orders)
        .set(patch)
        .where(eq(orders.id, orderId));
    });

    this.logger.log(
      `订单状态更新：orderId=${orderId}, ${oldStatus} -> ${newStatus}`,
    );

    return { success: true };
  }

  // ===== 商家管理 =====
  async listMerchants(
    params: MerchantListParams,
  ): Promise<AdminMerchantListResponse> {
    const { page, pageSize, keyword, category, isApproved, isActive } = params;
    const offset = (page - 1) * pageSize;

    const whereConditions = [];
    if (keyword) {
      whereConditions.push(
        or(
          ilike(mallMerchants.name, `%${keyword}%`),
          ilike(mallMerchants.contactPerson, `%${keyword}%`),
        ),
      );
    }
    if (category) {
      whereConditions.push(eq(mallMerchants.category, category));
    }
    if (isApproved !== undefined) {
      whereConditions.push(eq(mallMerchants.isApproved, isApproved));
    }
    if (isActive !== undefined) {
      whereConditions.push(eq(mallMerchants.isActive, isActive));
    }
    const where = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const baseQuery = this.db.select().from(mallMerchants);
    const query = where ? baseQuery.where(where) : baseQuery;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(mallMerchants)
        .where(where ?? undefined),
      query
        .orderBy(mallMerchants.sortOrder, desc(mallMerchants.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    const items: AdminMerchant[] = rows.map((row) => ({
      id: row.id,
      name: row.name,
      category: row.category,
      logoUrl: row.logoUrl || '',
      coverUrl: row.coverUrl || '',
      contactPerson: row.contactPerson || '',
      contactPhone: row.contactPhone || '',
      address: row.address || '',
      description: row.description || '',
      rating: Number(row.rating ?? 0),
      isApproved: row.isApproved,
      isActive: row.isActive,
      sortOrder: row.sortOrder,
      isAd: row.isAd,
      createdAt: row.createdAt.toISOString(),
    }));

    return { items, total, page, pageSize };
  }

  async createMerchant(dto: AdminCreateMerchantRequest): Promise<{ id: string }> {
    const [created] = await this.db
      .insert(mallMerchants)
      .values({
        name: dto.name,
        category: dto.category,
        contactPerson: dto.contactPerson,
        contactPhone: dto.contactPhone,
        address: dto.address,
        description: dto.description,
        coverUrl: dto.coverUrl,
        rating: dto.rating != null ? String(dto.rating) : '5.0',
        sortOrder: dto.sortOrder ?? 0,
        isAd: dto.isAd ?? false,
      })
      .returning({ id: mallMerchants.id });

    return { id: created.id };
  }

  async updateMerchant(
    merchantId: string,
    dto: AdminUpdateMerchantRequest,
  ): Promise<{ success: boolean }> {
    const patch: Record<string, unknown> = {};
    if (dto.name !== undefined) patch.name = dto.name;
    if (dto.category !== undefined) patch.category = dto.category;
    if (dto.contactPerson !== undefined) patch.contactPerson = dto.contactPerson;
    if (dto.contactPhone !== undefined) patch.contactPhone = dto.contactPhone;
    if (dto.address !== undefined) patch.address = dto.address;
    if (dto.description !== undefined) patch.description = dto.description;
    if (dto.coverUrl !== undefined) patch.coverUrl = dto.coverUrl;
    if (dto.rating !== undefined) patch.rating = String(dto.rating);
    if (dto.isApproved !== undefined) patch.isApproved = dto.isApproved;
    if (dto.isActive !== undefined) patch.isActive = dto.isActive;
    if (dto.sortOrder !== undefined) patch.sortOrder = dto.sortOrder;
    if (dto.isAd !== undefined) patch.isAd = dto.isAd;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(mallMerchants)
      .set(patch)
      .where(eq(mallMerchants.id, merchantId))
      .returning({ id: mallMerchants.id });

    if (updated.length === 0) {
      throw new NotFoundException('商家不存在');
    }

    return { success: true };
  }

  async deleteMerchant(merchantId: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(mallMerchants)
      .where(eq(mallMerchants.id, merchantId))
      .returning({ id: mallMerchants.id });

    if (deleted.length === 0) {
      throw new NotFoundException('商家不存在');
    }

    return { success: true };
  }

  // ===== 内容审核 =====
  async listAudits(params: AuditListParams): Promise<AdminAuditListResponse> {
    const { page, pageSize, keyword, status, riskLevel } = params;
    const offset = (page - 1) * pageSize;

    const whereConditions = [];
    if (keyword) {
      whereConditions.push(
        or(
          ilike(contentAudits.content, `%${keyword}%`),
          ilike(userProfiles.nickname, `%${keyword}%`),
        ),
      );
    }
    if (status) {
      whereConditions.push(eq(contentAudits.status, status));
    }
    if (riskLevel) {
      whereConditions.push(eq(contentAudits.riskLevel, riskLevel));
    }
    const where = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const baseQuery = this.db
      .select({
        id: contentAudits.id,
        userId: contentAudits.userId,
        userNickname: userProfiles.nickname,
        contentType: contentAudits.contentType,
        content: contentAudits.content,
        riskLevel: contentAudits.riskLevel,
        status: contentAudits.status,
        flaggedWords: contentAudits.flaggedWords,
        aiGenerated: contentAudits.aiGenerated,
        remark: contentAudits.remark,
        createdAt: contentAudits.createdAt,
      })
      .from(contentAudits)
      .leftJoin(userProfiles, eq(contentAudits.userId, userProfiles.userId));

    const query = where ? baseQuery.where(where) : baseQuery;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(contentAudits)
        .leftJoin(userProfiles, eq(contentAudits.userId, userProfiles.userId))
        .where(where ?? undefined),
      query
        .orderBy(desc(contentAudits.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    const items: AdminAuditItem[] = rows.map((row) => ({
      id: row.id,
      userId: row.userId,
      userNickname: row.userNickname || '未知用户',
      contentType: row.contentType,
      content: row.content,
      riskLevel: row.riskLevel,
      status: row.status,
      flaggedWords: row.flaggedWords || '',
      aiGenerated: row.aiGenerated,
      remark: row.remark || '',
      createdAt: row.createdAt.toISOString(),
    }));

    return { items, total, page, pageSize };
  }

  async updateAudit(
    auditId: string,
    dto: AdminUpdateAuditRequest,
  ): Promise<{ success: boolean }> {
    const patch: Record<string, unknown> = {};
    if (dto.status !== undefined) patch.status = dto.status;
    if (dto.riskLevel !== undefined) patch.riskLevel = dto.riskLevel;
    if (dto.remark !== undefined) patch.remark = dto.remark;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(contentAudits)
      .set(patch)
      .where(eq(contentAudits.id, auditId))
      .returning({ id: contentAudits.id });

    if (updated.length === 0) {
      throw new NotFoundException('审核记录不存在');
    }

    return { success: true };
  }
}
