import { IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';
import type { UpdatePosterPhotoRequest } from '@shared/api.interface';

export class UpdatePosterPhotoDto implements UpdatePosterPhotoRequest {
  @IsString()
  @MaxLength(500)
  posterPhotoUrl!: string;

  @IsOptional()
  @IsString()
  @IsUUID()
  projectId?: string;
}
