import { Controller, Get, Put, Post, Body, Req, Query } from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { UserService } from './user.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { UpdatePosterPhotoDto } from './dto/update-poster-photo.dto';
import { FavoritesQueryDto } from './dto/favorites-query.dto';
import { OrdersQueryDto } from './dto/orders-query.dto';
import type {
  UserProfileData,
  ScriptListResponse,
  UpdatePosterPhotoResponse,
} from '@shared/api.interface';

interface OrderListResponse {
  items: {
    id: string;
    productType: string;
    productName: string;
    amount: number;
    status: string;
    flowQuota: number;
    scriptQuota: number;
    paidAt: string | null;
    createdAt: string;
  }[];
  total: number;
}

@Controller('api/user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @UseGuards(AppAuthGuard)
  @Get('profile')
  async getProfile(@Req() req: Request): Promise<UserProfileData> {
    const { userId } = req.userContext;
    return this.userService.getProfile(userId);
  }

  @UseGuards(AppAuthGuard)
  @Put('profile')
  async updateProfile(
    @Req() req: Request,
    @Body() dto: UpdateProfileDto,
  ): Promise<UserProfileData> {
    const { userId } = req.userContext;
    return this.userService.updateProfile(userId, dto);
  }

  @UseGuards(AppAuthGuard)
  @Post('poster-photo')
  async updatePosterPhoto(
    @Req() req: Request,
    @Body() dto: UpdatePosterPhotoDto,
  ): Promise<UpdatePosterPhotoResponse> {
    const { userId } = req.userContext;
    const result = await this.userService.updatePosterPhoto(
      userId,
      dto.posterPhotoUrl,
      dto.projectId,
    );
    return {
      success: true,
      posterPhotoUrl: result.profile.posterPhotoUrl,
      remainingUpdates: result.remainingUpdates,
      totalLimit: result.totalLimit,
    };
  }

  @UseGuards(AppAuthGuard)
  @Get('orders')
  async getOrders(
    @Req() req: Request,
    @Query() query: OrdersQueryDto,
  ): Promise<OrderListResponse> {
    const { userId } = req.userContext;
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 10;
    return this.userService.getOrders(userId, page, pageSize);
  }

  @UseGuards(AppAuthGuard)
  @Get('favorites')
  async getFavorites(
    @Req() req: Request,
    @Query() query: FavoritesQueryDto,
  ): Promise<ScriptListResponse> {
    const { userId } = req.userContext;
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 10;
    return this.userService.getFavorites(userId, page, pageSize);
  }
}
