import { Injectable, Inject, Logger, NotFoundException, ConflictException } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, count, desc, sql } from 'drizzle-orm';
import { userProfiles, orders, scripts, systemConfigs, weddingProjects } from '@server/database/schema';
import type { UserProfileData, Order, ScriptListResponse } from '@shared/api.interface';

interface OrderListResponse {
  items: Order[];
  total: number;
}

@Injectable()
export class UserService {
  private readonly logger = new Logger(UserService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  /**
   * 获取用户个人资料
   */
  async getProfile(userId: string): Promise<UserProfileData> {
    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);

    if (!profile) {
      // 返回默认资料
      return {
        nickname: '婚礼主持人',
        avatarUrl: '',
        phone: '',
        city: '',
        experienceYears: 0,
        bio: '',
        styleTags: '',
        posterPhotoUrl: '',
      };
    }

    return {
      nickname: profile.nickname || '',
      avatarUrl: profile.avatarUrl || '',
      phone: profile.phone || '',
      city: profile.city || '',
      experienceYears: profile.experienceYears ?? 0,
      bio: profile.bio || '',
      styleTags: profile.styleTags || '',
      posterPhotoUrl: profile.posterPhotoUrl || '',
    };
  }

  /**
   * 更新用户个人资料
   */
  async updateProfile(
    userId: string,
    data: Partial<UserProfileData>,
  ): Promise<UserProfileData> {
    const patch: Partial<typeof userProfiles.$inferInsert> = {};
    if (data.nickname !== undefined) patch.nickname = data.nickname;
    if (data.avatarUrl !== undefined) patch.avatarUrl = data.avatarUrl;
    if (data.phone !== undefined) patch.phone = data.phone;
    if (data.city !== undefined) patch.city = data.city;
    if (data.experienceYears !== undefined)
      patch.experienceYears = data.experienceYears;
    if (data.bio !== undefined) patch.bio = data.bio;
    if (data.styleTags !== undefined) patch.styleTags = data.styleTags;

    if (Object.keys(patch).length === 0) {
      return this.getProfile(userId);
    }

    // 使用 upsert 逻辑：先尝试更新，无匹配则插入
    const [updated] = await this.db
      .update(userProfiles)
      .set(patch)
      .where(eq(userProfiles.userId, userId))
      .returning();

    if (!updated) {
      // 记录不存在，创建新记录
      const [created] = await this.db
        .insert(userProfiles)
        .values({
          userId,
          nickname: patch.nickname || '婚礼主持人',
          avatarUrl: patch.avatarUrl,
          phone: patch.phone,
          city: patch.city,
          experienceYears: patch.experienceYears ?? 0,
          bio: patch.bio,
          styleTags: patch.styleTags,
        })
        .returning();

      if (!created) {
        throw new NotFoundException('用户资料创建失败');
      }

      return {
        nickname: created.nickname || '',
        avatarUrl: created.avatarUrl || '',
        phone: created.phone || '',
        city: created.city || '',
        experienceYears: created.experienceYears ?? 0,
        bio: created.bio || '',
        styleTags: created.styleTags || '',
        posterPhotoUrl: created.posterPhotoUrl || '',
      };
    }

    return {
      nickname: updated.nickname || '',
      avatarUrl: updated.avatarUrl || '',
      phone: updated.phone || '',
      city: updated.city || '',
      experienceYears: updated.experienceYears ?? 0,
      bio: updated.bio || '',
      styleTags: updated.styleTags || '',
      posterPhotoUrl: updated.posterPhotoUrl || '',
    };
  }

  /**
   * 更新海报形象照（每方案次数限制）
   */
  async updatePosterPhoto(
    userId: string,
    posterPhotoUrl: string,
    projectId?: string,
  ): Promise<{ profile: UserProfileData; remainingUpdates: number; totalLimit: number }> {
    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId))
      .limit(1);

    // 如果是删除（空字符串），不消耗方案次数
    let totalLimit = 0;
    let remainingUpdates = -1;

    // 方案级次数限制：仅在提供 projectId 且设置新照片时检查
    if (projectId && posterPhotoUrl) {
      const [configRow] = await this.db
        .select({ configValue: systemConfigs.configValue })
        .from(systemConfigs)
        .where(eq(systemConfigs.configKey, 'poster_photo_update_limit_per_project'))
        .limit(1);

      const limitValue: number = configRow?.configValue
        ? parseInt(configRow.configValue, 10) || 0
        : 0;
      totalLimit = limitValue;

      // 校验方案归属及当前次数
      const [project] = await this.db
        .select({ posterPhotoUpdateCount: weddingProjects.posterPhotoUpdateCount })
        .from(weddingProjects)
        .where(and(
          eq(weddingProjects.id, projectId),
          eq(weddingProjects.userId, userId),
        ))
        .limit(1);

      if (!project) {
        throw new NotFoundException('方案不存在或无权限');
      }

      const currentCount: number = project.posterPhotoUpdateCount ?? 0;
      if (limitValue > 0 && currentCount >= limitValue) {
        throw new ConflictException(
          `本方案已达到形象照更换次数上限（${currentCount}/${limitValue}次）`,
        );
      }

      remainingUpdates = limitValue > 0 ? limitValue - currentCount - 1 : -1;
    }

    const patch: Partial<typeof userProfiles.$inferInsert> = {
      posterPhotoUrl,
    };

    // 先尝试更新，无匹配则插入
    const [updated] = await this.db
      .update(userProfiles)
      .set(patch)
      .where(eq(userProfiles.userId, userId))
      .returning();

    let finalProfile: UserProfileData;

    if (!updated) {
      const [created] = await this.db
        .insert(userProfiles)
        .values({
          userId,
          nickname: '婚礼主持人',
          posterPhotoUrl,
        })
        .returning();

      if (!created) {
        throw new NotFoundException('用户资料创建失败');
      }

      finalProfile = {
        nickname: created.nickname || '',
        avatarUrl: created.avatarUrl || '',
        phone: created.phone || '',
        city: created.city || '',
        experienceYears: created.experienceYears ?? 0,
        bio: created.bio || '',
        styleTags: created.styleTags || '',
        posterPhotoUrl: created.posterPhotoUrl || '',
      };
    } else {
      finalProfile = {
        nickname: updated.nickname || '',
        avatarUrl: updated.avatarUrl || '',
        phone: updated.phone || '',
        city: updated.city || '',
        experienceYears: updated.experienceYears ?? 0,
        bio: updated.bio || '',
        styleTags: updated.styleTags || '',
        posterPhotoUrl: updated.posterPhotoUrl || '',
      };
    }

    // 方案级次数 +1（仅在提供 projectId 且设置新照片时）
    if (projectId && posterPhotoUrl) {
      await this.db
        .update(weddingProjects)
        .set({ posterPhotoUpdateCount: sql`${weddingProjects.posterPhotoUpdateCount} + 1` })
        .where(eq(weddingProjects.id, projectId));
    }

    return { profile: finalProfile, remainingUpdates, totalLimit };
  }

  /**
   * 获取用户订单列表
   */
  async getOrders(
    userId: string,
    page: number,
    pageSize: number,
  ): Promise<OrderListResponse> {
    const offset = (page - 1) * pageSize;

    const [countResult] = await this.db
      .select({ count: count() })
      .from(orders)
      .where(eq(orders.userId, userId));

    const total = Number(countResult?.count ?? 0);

    if (total === 0) {
      return { items: [], total: 0 };
    }

    const orderList = await this.db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt))
      .limit(pageSize)
      .offset(offset);

    const items: Order[] = orderList.map((order) => ({
      id: order.id,
      productType: order.productType,
      productName: order.productName,
      amount: Number(order.amount),
      status: order.status || 'pending',
      flowQuota: order.flowQuota ?? 0,
      scriptQuota: order.scriptQuota ?? 0,
      paidAt: order.paidAt ? order.paidAt.toISOString() : null,
      createdAt: order.createdAt.toISOString(),
    }));

    return { items, total };
  }

  /**
   * 获取用户收藏的台词列表
   */
  async getFavorites(
    userId: string,
    page: number,
    pageSize: number,
  ): Promise<ScriptListResponse> {
    const offset = (page - 1) * pageSize;

    const [countResult] = await this.db
      .select({ count: count() })
      .from(scripts)
      .where(and(eq(scripts.userId, userId), eq(scripts.isFavorite, true)));

    const total = Number(countResult?.count ?? 0);

    if (total === 0) {
      return { items: [], total: 0 };
    }

    const scriptList = await this.db
      .select()
      .from(scripts)
      .where(and(eq(scripts.userId, userId), eq(scripts.isFavorite, true)))
      .orderBy(desc(scripts.createdAt))
      .limit(pageSize)
      .offset(offset);

    const items = scriptList.map((script) => ({
      id: script.id,
      category: script.category,
      title: script.title,
      content: script.content,
      isSystem: script.isSystem ?? false,
      isFavorite: script.isFavorite ?? false,
      styleTags: script.styleTags || '',
    }));

    return { items, total };
  }
}
