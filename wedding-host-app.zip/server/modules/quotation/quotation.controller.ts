import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { QuotationService } from './quotation.service';
import { CreateQuotationDto } from './dto/create-quotation.dto';
import { UpdateQuotationDto } from './dto/update-quotation.dto';
import type {
  ExportQuotationResponse,
  Quotation,
  QuotationListResponse,
} from '@shared/api.interface';

@UseGuards(AppAuthGuard)
@Controller('api/quotations')
export class QuotationController {
  constructor(private readonly quotationService: QuotationService) {}

  @Get()
  async getList(
    @Req() req: Request,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
    @Query('isTemplate') isTemplate?: string,
  ): Promise<QuotationListResponse> {
    const { userId } = req.userContext;
    const pageNum = page ? parseInt(page, 10) : 1;
    let pageSizeNum = pageSize ? parseInt(pageSize, 10) : 20;
    if (pageSizeNum > 50) pageSizeNum = 50;
    if (pageSizeNum < 1) pageSizeNum = 20;
    const isTemplateBool =
      isTemplate === 'true' ? true : isTemplate === 'false' ? false : undefined;
    return this.quotationService.getList(
      userId,
      pageNum,
      pageSizeNum,
      isTemplateBool,
    );
  }

  @Get(':id/export')
  async export(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<ExportQuotationResponse> {
    const { userId } = req.userContext;
    return this.quotationService.export(id, userId);
  }

  @Get(':id')
  async getDetail(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<Quotation> {
    const { userId } = req.userContext;
    return this.quotationService.getDetail(id, userId);
  }

  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateQuotationDto,
  ): Promise<{ id: string }> {
    const { userId } = req.userContext;
    return this.quotationService.create(dto, userId);
  }

  @Post(':id/duplicate')
  async duplicate(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ id: string }> {
    const { userId } = req.userContext;
    return this.quotationService.duplicate(id, userId);
  }

  @Patch(':id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateQuotationDto,
  ): Promise<{ success: boolean }> {
    const { userId } = req.userContext;
    return this.quotationService.update(id, dto, userId);
  }

  @Delete(':id')
  async delete(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<{ success: boolean }> {
    const { userId } = req.userContext;
    return this.quotationService.delete(id, userId);
  }
}
