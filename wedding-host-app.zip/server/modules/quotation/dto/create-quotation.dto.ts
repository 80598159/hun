import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import type { CreateQuotationRequest } from '@shared/api.interface';

export class QuotationItemDto {
  @IsString()
  id!: string;

  @IsString()
  name!: string;

  @IsString()
  unitPrice!: string;

  @IsNumber()
  quantity!: number;

  @IsString()
  unit!: string;
}

export class CreateQuotationDto implements CreateQuotationRequest {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  clientName?: string;

  @IsOptional()
  @IsString()
  weddingDate?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  hotelName?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => QuotationItemDto)
  items?: QuotationItemDto[];

  @IsOptional()
  @IsString()
  deposit?: string;

  @IsOptional()
  @IsString()
  finalPayment?: string;

  @IsOptional()
  @IsString()
  remark?: string;

  @IsOptional()
  @IsBoolean()
  isTemplate?: boolean;
}
