import {
  BadRequestException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { and, desc, eq, count } from 'drizzle-orm';
import { quotations } from '@server/database/schema';
import type {
  ExportQuotationResponse,
  Quotation,
  QuotationItem,
  QuotationListResponse,
} from '@shared/api.interface';
import type { CreateQuotationDto } from './dto/create-quotation.dto';
import type { UpdateQuotationDto } from './dto/update-quotation.dto';

@Injectable()
export class QuotationService {
  private readonly logger = new Logger(QuotationService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getList(
    userId: string,
    page: number,
    pageSize: number,
    isTemplate?: boolean,
  ): Promise<QuotationListResponse> {
    const conditions = [eq(quotations.userId, userId)];
    if (isTemplate !== undefined) {
      conditions.push(eq(quotations.isTemplate, isTemplate));
    }

    const offset = (page - 1) * pageSize;

    const [rows, countResult] = await Promise.all([
      this.db
        .select()
        .from(quotations)
        .where(and(...conditions))
        .orderBy(desc(quotations.createdAt))
        .limit(pageSize)
        .offset(offset),
      this.db
        .select({ count: count() })
        .from(quotations)
        .where(and(...conditions)),
    ]);

    const total = Number(countResult[0]?.count ?? 0);

    return {
      items: rows.map((row) => this.mapToQuotation(row)),
      total,
    };
  }

  async getDetail(id: string, userId: string): Promise<Quotation> {
    await this.ensureOwner(id, userId);

    const result = await this.db
      .select()
      .from(quotations)
      .where(eq(quotations.id, id))
      .limit(1);

    return this.mapToQuotation(result[0]);
  }

  async create(
    dto: CreateQuotationDto,
    userId: string,
  ): Promise<{ id: string }> {
    const result = await this.db
      .insert(quotations)
      .values({
        userId,
        title: dto.title ?? '婚礼主持服务报价单',
        clientName: dto.clientName ?? null,
        weddingDate: dto.weddingDate ?? null,
        hotelName: dto.hotelName ?? null,
        items: (dto.items ?? []) as unknown as Record<string, unknown>[],
        deposit: dto.deposit ?? '0',
        finalPayment: dto.finalPayment ?? '0',
        remark: dto.remark ?? null,
        isTemplate: dto.isTemplate ?? false,
      })
      .returning({ id: quotations.id });

    return { id: result[0].id };
  }

  async update(
    id: string,
    dto: UpdateQuotationDto,
    userId: string,
  ): Promise<{ success: boolean }> {
    await this.ensureOwner(id, userId);

    const patch: Partial<typeof quotations.$inferInsert> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.clientName !== undefined) patch.clientName = dto.clientName;
    if (dto.weddingDate !== undefined) patch.weddingDate = dto.weddingDate;
    if (dto.hotelName !== undefined) patch.hotelName = dto.hotelName;
    if (dto.items !== undefined) {
      patch.items = dto.items as unknown as Record<string, unknown>[];
    }
    if (dto.deposit !== undefined) patch.deposit = dto.deposit;
    if (dto.finalPayment !== undefined) patch.finalPayment = dto.finalPayment;
    if (dto.remark !== undefined) patch.remark = dto.remark;
    if (dto.isTemplate !== undefined) patch.isTemplate = dto.isTemplate;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(quotations)
      .set(patch)
      .where(eq(quotations.id, id))
      .returning({ id: quotations.id });

    if (updated.length === 0) {
      throw new NotFoundException('报价单不存在');
    }

    return { success: true };
  }

  async delete(id: string, userId: string): Promise<{ success: boolean }> {
    await this.ensureOwner(id, userId);

    const deleted = await this.db
      .delete(quotations)
      .where(eq(quotations.id, id))
      .returning({ id: quotations.id });

    if (deleted.length === 0) {
      throw new NotFoundException('报价单不存在');
    }

    return { success: true };
  }

  async export(id: string, userId: string): Promise<ExportQuotationResponse> {
    const quotation = await this.getDetail(id, userId);

    const lines: string[] = [];
    lines.push(`【${quotation.title}】`);
    lines.push('');

    if (quotation.clientName) {
      lines.push(`客户姓名：${quotation.clientName}`);
    }
    if (quotation.weddingDate) {
      lines.push(`婚礼日期：${quotation.weddingDate}`);
    }
    if (quotation.hotelName) {
      lines.push(`婚礼酒店：${quotation.hotelName}`);
    }
    if (quotation.clientName || quotation.weddingDate || quotation.hotelName) {
      lines.push('');
    }

    // 表头
    const headerName = '服务项目';
    const headerPrice = '单价';
    const headerQty = '数量';
    const headerSub = '小计';

    const col1Width = 24;
    const col2Width = 12;
    const col3Width = 8;
    const col4Width = 12;
    const totalWidth = col1Width + col2Width + col3Width + col4Width;

    lines.push(
      this.padEnd(headerName, col1Width) +
        this.padEnd(headerPrice, col2Width) +
        this.padEnd(headerQty, col3Width) +
        headerSub,
    );
    lines.push('─'.repeat(totalWidth));

    const items = quotation.items ?? [];
    for (const item of items) {
      const subTotal = Number(item.unitPrice) * item.quantity;
      const unitPriceStr = `¥${this.formatNumber(item.unitPrice)}`;
      const qtyStr = `${item.quantity}${item.unit}`;
      const subStr = `¥${this.formatNumber(subTotal.toString())}`;

      lines.push(
        this.padEnd(item.name, col1Width) +
          this.padEnd(unitPriceStr, col2Width) +
          this.padEnd(qtyStr, col3Width) +
          subStr,
      );
    }

    if (items.length === 0) {
      lines.push(this.padEnd('暂无服务项目', totalWidth));
    }

    lines.push('─'.repeat(totalWidth));

    const total = this.calcTotal(quotation.items);
    lines.push(`合计：¥${this.formatNumber(total)}`);
    lines.push(`定金：¥${this.formatNumber(quotation.deposit)}`);

    const finalPayNum = Number(quotation.finalPayment);
    if (finalPayNum > 0) {
      lines.push(`尾款：¥${this.formatNumber(quotation.finalPayment)}`);
    }

    if (quotation.remark) {
      lines.push('');
      lines.push('备注：');
      lines.push(quotation.remark);
    }

    lines.push('');
    lines.push('最终以双方签订合同为准。');

    return {
      title: quotation.title,
      text: lines.join('\n'),
    };
  }

  async duplicate(
    id: string,
    userId: string,
  ): Promise<{ id: string }> {
    const source = await this.getDetail(id, userId);

    const newTitle = `${source.title}副本`;

    const result = await this.db
      .insert(quotations)
      .values({
        userId,
        title: newTitle,
        clientName: source.clientName || null,
        weddingDate: source.weddingDate,
        hotelName: source.hotelName || null,
        items: source.items as unknown as Record<string, unknown>[],
        deposit: source.deposit,
        finalPayment: source.finalPayment,
        remark: source.remark || null,
        isTemplate: false,
      })
      .returning({ id: quotations.id });

    return { id: result[0].id };
  }

  private async ensureOwner(id: string, userId: string): Promise<void> {
    const result = await this.db
      .select({ id: quotations.id, userId: quotations.userId })
      .from(quotations)
      .where(eq(quotations.id, id))
      .limit(1);

    if (result.length === 0) {
      throw new NotFoundException('报价单不存在');
    }

    if (result[0].userId !== userId) {
      throw new NotFoundException('报价单不存在');
    }
  }

  private mapToQuotation(row: typeof quotations.$inferSelect): Quotation {
    const items = (row.items as unknown as QuotationItem[]) ?? [];
    const total = this.calcTotal(items);

    return {
      id: row.id,
      title: row.title,
      clientName: row.clientName ?? '',
      weddingDate: row.weddingDate ? String(row.weddingDate) : null,
      hotelName: row.hotelName ?? '',
      items,
      deposit: String(row.deposit),
      finalPayment: String(row.finalPayment),
      total,
      remark: row.remark ?? '',
      isTemplate: row.isTemplate,
      createdAt: row.createdAt.toISOString(),
    };
  }

  private calcTotal(items: QuotationItem[]): string {
    const sum = items.reduce((acc: number, item: QuotationItem) => {
      return acc + Number(item.unitPrice) * item.quantity;
    }, 0);
    return sum.toString();
  }

  private formatNumber(value: string | number): string {
    const num = typeof value === 'string' ? Number(value) : value;
    return num.toLocaleString('zh-CN', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }

  private padEnd(str: string, len: number): string {
    let count = 0;
    for (const ch of str) {
      // CJK characters take 2 columns
      if (ch.charCodeAt(0) > 127) {
        count += 2;
      } else {
        count += 1;
      }
    }
    if (count >= len) return str;
    return str + ' '.repeat(len - count);
  }
}
