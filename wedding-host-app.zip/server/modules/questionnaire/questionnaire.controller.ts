import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { UseGuards } from '@nestjs/common';
import { AppAuthGuard } from '@server/common/guards/app-auth.guard';
import { QuestionnaireService } from './questionnaire.service';
import type {
  QuestionnaireCreateRequest,
  QuestionnaireUpdateFieldsRequest,
  QuestionnaireAnswerSubmitRequest,
  QuestionnaireApplyToProjectRequest,
} from '@shared/api.interface';

@Controller('api/questionnaires')
export class QuestionnaireController {
  constructor(private readonly questionnaireService: QuestionnaireService) {}

  // ========== 匿名接口（静态路由在前） ==========

  @Get('by-code/:shareCode')
  getByShareCode(@Param('shareCode') shareCode: string) {
    return this.questionnaireService.getByShareCode(shareCode);
  }

  @Post('submit')
  submitAnswer(@Body() dto: QuestionnaireAnswerSubmitRequest) {
    return this.questionnaireService.submitAnswer(dto);
  }

  // ========== 登录态接口 ==========

  @UseGuards(AppAuthGuard)
  @Get()
  list(@Req() req: Request) {
    const { userId } = req.userContext;
    return this.questionnaireService.list(userId);
  }

  @UseGuards(AppAuthGuard)
  @Post()
  create(@Req() req: Request, @Body() dto: QuestionnaireCreateRequest) {
    const { userId } = req.userContext;
    return this.questionnaireService.create(dto, userId);
  }

  @UseGuards(AppAuthGuard)
  @Post('apply-to-project')
  applyToProject(
    @Req() req: Request,
    @Body() dto: QuestionnaireApplyToProjectRequest,
  ) {
    const { userId } = req.userContext;
    return this.questionnaireService.applyToProject(dto, userId);
  }

  @UseGuards(AppAuthGuard)
  @Get(':id')
  get(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.questionnaireService.get(id, userId);
  }

  @UseGuards(AppAuthGuard)
  @Patch(':id/fields')
  updateFields(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: QuestionnaireUpdateFieldsRequest,
  ) {
    const { userId } = req.userContext;
    return this.questionnaireService.updateFields(id, dto.fields, userId);
  }

  @UseGuards(AppAuthGuard)
  @Patch(':id/status')
  updateStatus(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: { status: 'draft' | 'published' | 'closed' },
  ) {
    const { userId } = req.userContext;
    return this.questionnaireService.updateStatus(id, dto.status, userId);
  }

  @UseGuards(AppAuthGuard)
  @Delete(':id')
  delete(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.questionnaireService.delete(id, userId);
  }

  @UseGuards(AppAuthGuard)
  @Get(':id/answers')
  getAnswers(@Req() req: Request, @Param('id') id: string) {
    const { userId } = req.userContext;
    return this.questionnaireService.getAnswers(id, userId);
  }
}
