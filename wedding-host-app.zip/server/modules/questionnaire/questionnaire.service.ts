import {
  Injectable,
  Inject,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, asc, desc, inArray } from 'drizzle-orm';
import { randomBytes } from 'node:crypto';
import {
  questionnaires,
  questionnaireFields,
  questionnaireAnswers,
  weddingProjects,
} from '@server/database/schema';
import type {
  Questionnaire,
  QuestionnaireField,
  QuestionnaireAnswer,
  QuestionnaireListResponse,
  QuestionnaireDetailResponse,
  QuestionnaireAnswerListResponse,
  QuestionnaireCreateRequest,
  QuestionnaireUpdateFieldsRequest,
  QuestionnaireAnswerSubmitRequest,
  QuestionnaireApplyToProjectRequest,
  WeddingProject,
} from '@shared/api.interface';

type FieldType = 'text' | 'textarea' | 'tel' | 'date';

const DEFAULT_FIELDS: Array<{
  fieldKey: string;
  label: string;
  fieldType: FieldType;
  required: boolean;
}> = [
  { fieldKey: 'groom_name', label: '新郎姓名', fieldType: 'text', required: true },
  { fieldKey: 'bride_name', label: '新娘姓名', fieldType: 'text', required: true },
  { fieldKey: 'groom_phone', label: '新郎联系方式', fieldType: 'tel', required: true },
  { fieldKey: 'bride_phone', label: '新娘联系方式', fieldType: 'tel', required: true },
  { fieldKey: 'wedding_date', label: '婚期', fieldType: 'date', required: true },
  { fieldKey: 'hotel_address', label: '酒店地址', fieldType: 'text', required: true },
  { fieldKey: 'time_type', label: '婚礼时段（午宴/晚宴）', fieldType: 'text', required: false },
  { fieldKey: 'groom_parents', label: '新郎父母姓名及称谓', fieldType: 'textarea', required: false },
  { fieldKey: 'bride_parents', label: '新娘父母姓名及称谓', fieldType: 'textarea', required: false },
  { fieldKey: 'special_customs', label: '特殊环节或习俗', fieldType: 'textarea', required: false },
  { fieldKey: 'love_story', label: '爱情故事或婚礼经历', fieldType: 'textarea', required: false },
  { fieldKey: 'taboos', label: '禁忌或注意事项', fieldType: 'textarea', required: false },
];

const STATUS_VALUES = ['draft', 'published', 'closed'] as const;
type QuestionnaireStatus = (typeof STATUS_VALUES)[number];

@Injectable()
export class QuestionnaireService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ========== 问卷管理（登录态） ==========

  async list(userId: string): Promise<QuestionnaireListResponse> {
    const qs = await this.db
      .select()
      .from(questionnaires)
      .where(eq(questionnaires.userId, userId))
      .orderBy(desc(questionnaires.createdAt));

    if (qs.length === 0) {
      return { items: [] };
    }

    const ids = qs.map((q) => q.id);
    const allFields = await this.db
      .select()
      .from(questionnaireFields)
      .where(inArray(questionnaireFields.questionnaireId, ids))
      .orderBy(asc(questionnaireFields.sortOrder));

    const fieldsByQ = new Map<string, typeof allFields>();
    for (const f of allFields) {
      if (!fieldsByQ.has(f.questionnaireId)) {
        fieldsByQ.set(f.questionnaireId, []);
      }
      fieldsByQ.get(f.questionnaireId)!.push(f);
    }

    return {
      items: qs.map((q) => this.mapQuestionnaire(q, fieldsByQ.get(q.id) ?? [])),
    };
  }

  async get(id: string, userId: string): Promise<QuestionnaireDetailResponse> {
    const q = await this.findById(id);
    if (!q) {
      throw new NotFoundException('问卷不存在');
    }
    if (q.userId !== userId) {
      throw new ForbiddenException('无权访问该问卷');
    }

    const fields = await this.db
      .select()
      .from(questionnaireFields)
      .where(eq(questionnaireFields.questionnaireId, id))
      .orderBy(asc(questionnaireFields.sortOrder));

    return { questionnaire: this.mapQuestionnaire(q, fields) };
  }

  async create(
    dto: QuestionnaireCreateRequest,
    userId: string,
  ): Promise<QuestionnaireDetailResponse> {
    if (!dto.projectId) {
      throw new BadRequestException('项目ID不能为空');
    }

    const shareCode = this.generateShareCode();

    const result = await this.db.transaction(async (tx) => {
      const [q] = await tx
        .insert(questionnaires)
        .values({
          projectId: dto.projectId,
          userId,
          title: dto.title || '新人信息采集问卷',
          shareCode,
          status: 'draft',
        })
        .returning();

      const fieldValues = DEFAULT_FIELDS.map((f, idx) => ({
        questionnaireId: q.id,
        fieldKey: f.fieldKey,
        label: f.label,
        fieldType: f.fieldType,
        sortOrder: idx,
        required: f.required,
      }));

      const insertedFields = await tx
        .insert(questionnaireFields)
        .values(fieldValues)
        .returning();

      return { q, fields: insertedFields };
    });

    return { questionnaire: this.mapQuestionnaire(result.q, result.fields) };
  }

  async updateFields(
    id: string,
    fields: QuestionnaireUpdateFieldsRequest['fields'],
    userId: string,
  ): Promise<QuestionnaireDetailResponse> {
    const q = await this.findById(id);
    if (!q) {
      throw new NotFoundException('问卷不存在');
    }
    if (q.userId !== userId) {
      throw new ForbiddenException('无权操作该问卷');
    }
    if (!Array.isArray(fields)) {
      throw new BadRequestException('字段数据格式错误');
    }

    const result = await this.db.transaction(async (tx) => {
      await tx
        .delete(questionnaireFields)
        .where(eq(questionnaireFields.questionnaireId, id));

      if (fields.length === 0) {
        return [];
      }

      const fieldValues = fields.map((f, idx) => ({
        questionnaireId: id,
        fieldKey: f.fieldKey,
        label: f.label,
        fieldType: f.fieldType,
        placeholder: f.placeholder ?? null,
        sortOrder: f.sortOrder ?? idx,
        required: f.required ?? true,
      }));

      const inserted = await tx
        .insert(questionnaireFields)
        .values(fieldValues)
        .returning();

      await tx
        .update(questionnaires)
        .set({ updatedAt: new Date() })
        .where(eq(questionnaires.id, id));

      return inserted;
    });

    const refreshed = await this.findById(id);
    return { questionnaire: this.mapQuestionnaire(refreshed!, result) };
  }

  async updateStatus(
    id: string,
    status: QuestionnaireStatus,
    userId: string,
  ): Promise<QuestionnaireDetailResponse> {
    if (!STATUS_VALUES.includes(status)) {
      throw new BadRequestException('状态值非法');
    }

    const q = await this.findById(id);
    if (!q) {
      throw new NotFoundException('问卷不存在');
    }
    if (q.userId !== userId) {
      throw new ForbiddenException('无权操作该问卷');
    }

    const [updated] = await this.db
      .update(questionnaires)
      .set({ status, updatedAt: new Date() })
      .where(eq(questionnaires.id, id))
      .returning();

    const fields = await this.db
      .select()
      .from(questionnaireFields)
      .where(eq(questionnaireFields.questionnaireId, id))
      .orderBy(asc(questionnaireFields.sortOrder));

    return { questionnaire: this.mapQuestionnaire(updated, fields) };
  }

  async delete(id: string, userId: string): Promise<void> {
    const q = await this.findById(id);
    if (!q) {
      throw new NotFoundException('问卷不存在');
    }
    if (q.userId !== userId) {
      throw new ForbiddenException('无权操作该问卷');
    }

    await this.db.delete(questionnaires).where(eq(questionnaires.id, id));
  }

  // ========== 匿名访问 ==========

  async getByShareCode(
    shareCode: string,
  ): Promise<QuestionnaireDetailResponse> {
    const [q] = await this.db
      .select()
      .from(questionnaires)
      .where(eq(questionnaires.shareCode, shareCode))
      .limit(1);

    if (!q) {
      throw new NotFoundException('问卷不存在');
    }

    if (q.status === 'draft' || q.status === 'closed') {
      throw new BadRequestException('问卷不可填写');
    }

    const fields = await this.db
      .select()
      .from(questionnaireFields)
      .where(eq(questionnaireFields.questionnaireId, q.id))
      .orderBy(asc(questionnaireFields.sortOrder));

    // 匿名访问不返回 userId 等敏感信息
    return {
      questionnaire: {
        ...this.mapQuestionnaire(q, fields),
        userId: '',
      },
    };
  }

  async submitAnswer(
    dto: QuestionnaireAnswerSubmitRequest,
  ): Promise<{ answerId: string }> {
    if (!dto.shareCode) {
      throw new BadRequestException('分享码不能为空');
    }
    if (!dto.answerData || typeof dto.answerData !== 'object') {
      throw new BadRequestException('答案数据格式错误');
    }

    const [q] = await this.db
      .select()
      .from(questionnaires)
      .where(eq(questionnaires.shareCode, dto.shareCode))
      .limit(1);

    if (!q) {
      throw new NotFoundException('问卷不存在');
    }

    if (q.status === 'draft' || q.status === 'closed') {
      throw new BadRequestException('问卷不可提交');
    }

    const [answer] = await this.db
      .insert(questionnaireAnswers)
      .values({
        questionnaireId: q.id,
        projectId: q.projectId,
        answerData: dto.answerData,
        submittedAt: new Date(),
        submitterName: dto.submitterName ?? null,
      })
      .returning({ id: questionnaireAnswers.id });

    return { answerId: answer.id };
  }

  // ========== 答案管理（登录态） ==========

  async getAnswers(
    questionnaireId: string,
    userId: string,
  ): Promise<QuestionnaireAnswerListResponse> {
    const q = await this.findById(questionnaireId);
    if (!q) {
      throw new NotFoundException('问卷不存在');
    }
    if (q.userId !== userId) {
      throw new ForbiddenException('无权访问该问卷');
    }

    const answers = await this.db
      .select()
      .from(questionnaireAnswers)
      .where(eq(questionnaireAnswers.questionnaireId, questionnaireId))
      .orderBy(desc(questionnaireAnswers.submittedAt));

    return {
      items: answers.map((a) => this.mapAnswer(a)),
    };
  }

  async applyToProject(
    dto: QuestionnaireApplyToProjectRequest,
    userId: string,
  ): Promise<{ success: boolean; project: WeddingProject }> {
    const answer = await this.findAnswerById(dto.answerId);
    if (!answer) {
      throw new NotFoundException('答案不存在');
    }

    const q = await this.findById(answer.questionnaireId);
    if (!q || q.userId !== userId) {
      throw new ForbiddenException('无权操作该答案');
    }

    const [project] = await this.db
      .select()
      .from(weddingProjects)
      .where(eq(weddingProjects.id, dto.projectId))
      .limit(1);

    if (!project) {
      throw new NotFoundException('项目不存在');
    }
    if (project.userId !== userId) {
      throw new ForbiddenException('无权操作该项目');
    }

    const patch: Partial<typeof weddingProjects.$inferInsert> = {};

    const data = answer.answerData as { [key: string]: string };

    if (data.groom_name !== undefined && data.groom_name !== '') {
      patch.groomName = data.groom_name;
    }
    if (data.bride_name !== undefined && data.bride_name !== '') {
      patch.brideName = data.bride_name;
    }
    if (data.wedding_date !== undefined && data.wedding_date !== '') {
      patch.weddingDate = data.wedding_date;
    }
    if (data.hotel_address !== undefined && data.hotel_address !== '') {
      patch.hotelName = data.hotel_address;
    }
    if (data.time_type !== undefined && data.time_type !== '') {
      const raw = data.time_type.toLowerCase();
      if (raw.includes('午')) {
        patch.timeType = 'lunch';
      } else if (raw.includes('晚')) {
        patch.timeType = 'dinner';
      }
    }

    if (Object.keys(patch).length > 0) {
      patch.updatedAt = new Date();
      const [updated] = await this.db
        .update(weddingProjects)
        .set(patch)
        .where(eq(weddingProjects.id, dto.projectId))
        .returning();

      return { success: true, project: this.mapProject(updated) };
    }

    return { success: true, project: this.mapProject(project) };
  }

  // ========== helpers ==========

  private async findById(id: string) {
    const [q] = await this.db
      .select()
      .from(questionnaires)
      .where(eq(questionnaires.id, id))
      .limit(1);
    return q ?? null;
  }

  private async findAnswerById(id: string) {
    const [a] = await this.db
      .select()
      .from(questionnaireAnswers)
      .where(eq(questionnaireAnswers.id, id))
      .limit(1);
    return a ?? null;
  }

  private generateShareCode(): string {
    return randomBytes(4).toString('hex').toUpperCase();
  }

  private mapQuestionnaire(
    q: typeof questionnaires.$inferSelect,
    fields: Array<typeof questionnaireFields.$inferSelect>,
  ): Questionnaire {
    return {
      id: q.id,
      projectId: q.projectId,
      userId: q.userId,
      title: q.title,
      shareCode: q.shareCode,
      status: q.status as QuestionnaireStatus,
      createdAt: q.createdAt.toISOString(),
      updatedAt: q.updatedAt.toISOString(),
      fields: fields.map((f) => this.mapField(f)),
    };
  }

  private mapField(
    f: typeof questionnaireFields.$inferSelect,
  ): QuestionnaireField {
    return {
      id: f.id,
      fieldKey: f.fieldKey,
      label: f.label,
      fieldType: f.fieldType as FieldType,
      placeholder: f.placeholder ?? undefined,
      sortOrder: f.sortOrder,
      required: f.required,
    };
  }

  private mapAnswer(
    a: typeof questionnaireAnswers.$inferSelect,
  ): QuestionnaireAnswer {
    return {
      id: a.id,
      questionnaireId: a.questionnaireId,
      projectId: a.projectId,
      answerData: (a.answerData as { [key: string]: string }) ?? {},
      submittedAt: a.submittedAt ? a.submittedAt.toISOString() : null,
      submitterName: a.submitterName ?? null,
      createdAt: a.createdAt.toISOString(),
    };
  }

  private mapProject(p: typeof weddingProjects.$inferSelect): WeddingProject {
    return {
      id: p.id,
      title: p.title,
      groomName: p.groomName ?? '',
      brideName: p.brideName ?? '',
      weddingDate: p.weddingDate ? new Date(p.weddingDate).toISOString().split('T')[0] : null,
      timeType: p.timeType as 'lunch' | 'dinner',
      hotelName: p.hotelName ?? '',
      planner: p.planner ?? '',
      supervisor: p.supervisor ?? '',
      videographer: p.videographer ?? '',
      photographer: p.photographer ?? '',
      soundController: p.soundController ?? '',
      specialNotes: p.specialNotes ?? '',
      status: p.status ?? '',
      isArchived: p.isArchived ?? false,
      posterTemplate: p.posterTemplate ?? 'classic',
      scheduleId: p.scheduleId ?? null,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    };
  }
}
