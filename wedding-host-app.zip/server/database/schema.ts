/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { boolean, date, foreignKey, index, integer, jsonb, numeric, pgTable, text, uniqueIndex, uuid, varchar, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const systemConfigs = pgTable("system_configs", {
  id: uuid("id").primaryKey().defaultRandom(),
  configKey: varchar("config_key", { length: 100 }).notNull().unique(),
  configValue: text("config_value").notNull(),
  configType: varchar("config_type", { length: 20 }).notNull().default('string'),
  description: varchar("description", { length: 255 }).notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("system_configs_config_key_key").on(table.configKey),
]);

export const questionnaireAnswers = pgTable("questionnaire_answers", {
  id: uuid("id").primaryKey().defaultRandom(),
  questionnaireId: uuid("questionnaire_id").notNull(),
  projectId: uuid("project_id").notNull(),
  /**
   * @type { [key: string]: string }
   */
  answerData: jsonb("answer_data").notNull().default('{}'),
  submittedAt: customTimestamptz("submitted_at", { precision: 3 }),
  submitterName: varchar("submitter_name", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_questionnaire_answers_qid").on(table.questionnaireId),
  index("idx_questionnaire_answers_pid").on(table.projectId),
  foreignKey({
    columns: [table.questionnaireId],
    foreignColumns: [questionnaires.id],
    name: "questionnaire_answers_questionnaire_id_fkey",
  }).onDelete("cascade"),
]);

export const questionnaireFields = pgTable("questionnaire_fields", {
  id: uuid("id").primaryKey().defaultRandom(),
  questionnaireId: uuid("questionnaire_id").notNull(),
  fieldKey: varchar("field_key", { length: 50 }).notNull(),
  label: varchar("label", { length: 100 }).notNull(),
  fieldType: varchar("field_type", { length: 20 }).notNull().default('text'),
  placeholder: varchar("placeholder", { length: 200 }),
  sortOrder: integer("sort_order").notNull().default(0),
  required: boolean("required").notNull().default(true),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_questionnaire_fields_qid").on(table.questionnaireId),
  foreignKey({
    columns: [table.questionnaireId],
    foreignColumns: [questionnaires.id],
    name: "questionnaire_fields_questionnaire_id_fkey",
  }).onDelete("cascade"),
]);

export const questionnaires = pgTable("questionnaires", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  title: varchar("title", { length: 200 }).notNull().default('新人信息采集问卷'),
  shareCode: varchar("share_code", { length: 32 }).notNull().unique(),
  status: varchar("status", { length: 20 }).notNull().default('draft'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("questionnaires_share_code_key").on(table.shareCode),
  index("idx_questionnaires_user_id").on(table.userId),
  index("idx_questionnaires_project_id").on(table.projectId),
  index("idx_questionnaires_share_code").on(table.shareCode),
]);

export const aiApiConfigs = pgTable("ai_api_configs", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 100 }).notNull(),
  baseUrl: varchar("base_url", { length: 500 }).notNull(),
  apiKey: varchar("api_key", { length: 500 }).notNull(),
  modelName: varchar("model_name", { length: 100 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default('active'),
  priority: integer("priority").notNull().default(100),
  remark: text("remark"),
  lastCallStatus: varchar("last_call_status", { length: 20 }),
  lastCallAt: customTimestamptz("last_call_at", { precision: 3 }),
  lastError: text("last_error"),
  failCount: integer("fail_count").notNull().default(0),
  protocol: varchar("protocol", { length: 30 }).notNull().default('openai'),
  appId: varchar("app_id", { length: 200 }),
  r2AccessKey: varchar("r2_access_key", { length: 200 }),
  r2SecretKey: varchar("r2_secret_key", { length: 200 }),
  r2Bucket: varchar("r2_bucket", { length: 200 }),
  r2Endpoint: varchar("r2_endpoint", { length: 500 }),
  r2PublicDomain: varchar("r2_public_domain", { length: 500 }),
  cfAccountId: varchar("cf_account_id", { length: 200 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_ai_api_configs_priority").on(table.priority),
  index("idx_ai_api_configs_status").on(table.status),
]);

export const weddingShareLinks = pgTable("wedding_share_links", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull(),
  shareCode: varchar("share_code", { length: 32 }).notNull().unique(),
  createdBy: varchar("created_by", { length: 64 }).notNull(),
  expiresAt: customTimestamptz("expires_at", { precision: 3 }),
  isActive: boolean("is_active").notNull().default(true),
  joinCount: integer("join_count").notNull().default(0),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("wedding_share_links_share_code_key").on(table.shareCode),
  index("idx_wedding_share_links_code").on(table.shareCode),
  index("idx_wedding_share_links_project").on(table.projectId),
  foreignKey({
    columns: [table.projectId],
    foreignColumns: [weddingProjects.id],
    name: "wedding_share_links_project_id_fkey",
  }).onDelete("cascade"),
]);

export const weddingCollaborators = pgTable("wedding_collaborators", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  role: varchar("role", { length: 20 }).notNull().default('collaborator'),
  invitedBy: varchar("invited_by", { length: 64 }),
  joinedAt: customTimestamptz("joined_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("wedding_collaborators_project_id_user_id_key").on(table.projectId, table.userId),
  index("idx_wedding_collaborators_project").on(table.projectId),
  index("idx_wedding_collaborators_user").on(table.userId),
  foreignKey({
    columns: [table.projectId],
    foreignColumns: [weddingProjects.id],
    name: "wedding_collaborators_project_id_fkey",
  }).onDelete("cascade"),
]);

export const quotations = pgTable("quotations", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  title: varchar("title", { length: 200 }).notNull().default('婚礼主持服务报价单'),
  clientName: varchar("client_name", { length: 200 }),
  weddingDate: date("wedding_date"),
  hotelName: varchar("hotel_name", { length: 200 }),
  /**
   * @type { id: string; name: string; unitPrice: string; quantity: number; unit: string; }[]
   */
  items: jsonb("items").notNull().default('[]'),
  deposit: numeric("deposit").notNull().default('0'),
  finalPayment: numeric("final_payment").notNull().default('0'),
  remark: text("remark"),
  isTemplate: boolean("is_template").notNull().default(false),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_quotations_user_id").on(table.userId),
  index("idx_quotations_template").on(table.isTemplate),
]);

export const bgmPlaylistItems = pgTable("bgm_playlist_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  playlistId: uuid("playlist_id").notNull(),
  songId: uuid("song_id"),
  title: varchar("title", { length: 200 }).notNull(),
  artist: varchar("artist", { length: 200 }),
  purposeTag: varchar("purpose_tag", { length: 50 }),
  segment: varchar("segment", { length: 100 }),
  sortOrder: integer("sort_order").notNull().default(0),
  note: varchar("note", { length: 500 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_bgm_playlist_items_playlist_id").on(table.playlistId),
  index("idx_bgm_playlist_items_sort").on(table.playlistId, table.sortOrder),
  foreignKey({
    columns: [table.playlistId],
    foreignColumns: [bgmPlaylists.id],
    name: "bgm_playlist_items_playlist_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.songId],
    foreignColumns: [bgmLibrary.id],
    name: "bgm_playlist_items_song_id_fkey",
  }).onDelete("set null"),
]);

export const bgmPlaylists = pgTable("bgm_playlists", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  projectId: uuid("project_id"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_bgm_playlists_user_id").on(table.userId),
  index("idx_bgm_playlists_project_id").on(table.projectId),
]);

export const bgmLibrary = pgTable("bgm_library", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 200 }).notNull(),
  artist: varchar("artist", { length: 200 }),
  category: varchar("category", { length: 50 }).notNull(),
  mood: varchar("mood", { length: 50 }),
  isSystem: boolean("is_system").notNull().default(false),
  userId: varchar("user_id", { length: 64 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_bgm_library_category").on(table.category),
  index("idx_bgm_library_user_id").on(table.userId),
]);

export const appSessions = pgTable("app_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  token: varchar("token", { length: 128 }).notNull().unique(),
  expiresAt: customTimestamptz("expires_at", { precision: 3 }).notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("app_sessions_token_key").on(table.token),
  index("idx_app_sessions_user_id").on(table.userId),
  index("idx_app_sessions_expires_at").on(table.expiresAt),
]);

export const contentAudits = pgTable("content_audits", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  contentType: varchar("content_type", { length: 30 }).notNull(),
  content: text("content").notNull(),
  riskLevel: varchar("risk_level", { length: 20 }).notNull().default('low'),
  status: varchar("status", { length: 20 }).notNull().default('pending'),
  flaggedWords: varchar("flagged_words", { length: 255 }),
  aiGenerated: boolean("ai_generated").notNull().default(false),
  remark: text("remark"),
  relatedId: uuid("related_id"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_content_audits_user_id").on(table.userId),
  index("idx_content_audits_status").on(table.status),
]);

export const mallMerchants = pgTable("mall_merchants", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 200 }).notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  logoUrl: varchar("logo_url", { length: 500 }),
  coverUrl: varchar("cover_url", { length: 500 }),
  contactPerson: varchar("contact_person", { length: 100 }),
  contactPhone: varchar("contact_phone", { length: 50 }),
  address: varchar("address", { length: 300 }),
  description: text("description"),
  rating: numeric("rating").default('5.0'),
  isApproved: boolean("is_approved").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  isAd: boolean("is_ad").notNull().default(false),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_mall_merchants_category").on(table.category),
  index("idx_mall_merchants_active").on(table.isActive),
]);

export const products = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  type: varchar("type", { length: 30 }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  price: numeric("price").notNull().default('0'),
  originalPrice: numeric("original_price"),
  flowQuota: integer("flow_quota").notNull().default(0),
  scriptQuota: integer("script_quota").notNull().default(0),
  posterTemplate: varchar("poster_template", { length: 50 }),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_products_type").on(table.type),
  index("idx_products_active").on(table.isActive),
]);

export const userProfiles = pgTable("user_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull().unique(),
  nickname: varchar("nickname", { length: 100 }),
  avatarUrl: varchar("avatar_url", { length: 500 }),
  phone: varchar("phone", { length: 20 }),
  city: varchar("city", { length: 100 }),
  experienceYears: integer("experience_years").default(0),
  isAdmin: boolean("is_admin").notNull().default(false),
  status: varchar("status", { length: 20 }).notNull().default('active'),
  username: varchar("username", { length: 64 }).unique(),
  passwordHash: varchar("password_hash", { length: 255 }),
  bio: text("bio"),
  styleTags: varchar("style_tags", { length: 255 }),
  posterPhotoUrl: varchar("poster_photo_url", { length: 500 }),
  posterPhotoChangedAt: date("poster_photo_changed_at"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("user_profiles_user_id_key").on(table.userId),
  uniqueIndex("user_profiles_username_key").on(table.username),
]);

export const orders = pgTable("orders", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  productType: varchar("product_type", { length: 50 }).notNull(),
  productName: varchar("product_name", { length: 100 }).notNull(),
  amount: numeric("amount").notNull().default('0'),
  status: varchar("status", { length: 20 }).default('pending'),
  flowQuota: integer("flow_quota").default(0),
  scriptQuota: integer("script_quota").default(0),
  paidAt: customTimestamptz("paid_at", { precision: 3 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_orders_user_id").on(table.userId),
]);

export const aiQuotas = pgTable("ai_quotas", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull().unique(),
  flowGenerateCount: integer("flow_generate_count").default(0),
  scriptGenerateCount: integer("script_generate_count").default(0),
  monthlyFlowQuota: integer("monthly_flow_quota").default(5),
  monthlyScriptQuota: integer("monthly_script_quota").default(10),
  totalFlowQuota: integer("total_flow_quota").default(0),
  totalScriptQuota: integer("total_script_quota").default(0),
  resetDate: date("reset_date").notNull().default('CURRENT_DATE'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("ai_quotas_user_id_key").on(table.userId),
]);

export const schedules = pgTable("schedules", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  weddingDate: date("wedding_date").notNull(),
  timeType: varchar("time_type", { length: 20 }).default('dinner'),
  hotelName: varchar("hotel_name", { length: 200 }),
  coupleName: varchar("couple_name", { length: 200 }),
  notes: text("notes"),
  projectId: uuid("project_id"),
  source: varchar("source", { length: 20 }).notNull().default('manual'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_schedules_user_id").on(table.userId),
  index("idx_schedules_date").on(table.weddingDate),
  index("idx_schedules_project_id").on(table.projectId),
]);

export const scripts = pgTable("scripts", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  content: text("content").notNull(),
  isSystem: boolean("is_system").default(false),
  isFavorite: boolean("is_favorite").default(false),
  styleTags: varchar("style_tags", { length: 255 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_scripts_user_id").on(table.userId),
  index("idx_scripts_category").on(table.category),
]);

export const weddingSteps = pgTable("wedding_steps", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull(),
  stepName: varchar("step_name", { length: 100 }).notNull(),
  duration: integer("duration").notNull().default(5),
  bgmSuggest: varchar("bgm_suggest", { length: 200 }),
  hostTip: text("host_tip"),
  sortOrder: integer("sort_order").notNull().default(0),
  isCustom: boolean("is_custom").default(false),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_wedding_steps_project_id").on(table.projectId),
  foreignKey({
    columns: [table.projectId],
    foreignColumns: [weddingProjects.id],
    name: "wedding_steps_project_id_fkey",
  }).onDelete("cascade"),
]);

export const weddingProjects = pgTable("wedding_projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  title: varchar("title", { length: 200 }).notNull().default('新婚礼方案'),
  groomName: varchar("groom_name", { length: 100 }),
  brideName: varchar("bride_name", { length: 100 }),
  weddingDate: date("wedding_date"),
  timeType: varchar("time_type", { length: 20 }).default('dinner'),
  hotelName: varchar("hotel_name", { length: 200 }),
  planner: varchar("planner", { length: 100 }),
  supervisor: varchar("supervisor", { length: 100 }),
  videographer: varchar("videographer", { length: 100 }),
  photographer: varchar("photographer", { length: 100 }),
  soundController: varchar("sound_controller", { length: 100 }),
  specialNotes: text("special_notes"),
  status: varchar("status", { length: 20 }).default('active'),
  isArchived: boolean("is_archived").default(false),
  posterTemplate: varchar("poster_template", { length: 50 }).default('classic'),
  scheduleId: uuid("schedule_id"),
  posterPhotoUpdateCount: integer("poster_photo_update_count").notNull().default(0),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_wedding_projects_user_id").on(table.userId),
  index("idx_wedding_projects_schedule_id").on(table.scheduleId),
]);

// table aliases
export const aiApiConfigsTable = aiApiConfigs;
export const aiQuotasTable = aiQuotas;
export const appSessionsTable = appSessions;
export const bgmLibraryTable = bgmLibrary;
export const bgmPlaylistItemsTable = bgmPlaylistItems;
export const bgmPlaylistsTable = bgmPlaylists;
export const contentAuditsTable = contentAudits;
export const mallMerchantsTable = mallMerchants;
export const ordersTable = orders;
export const productsTable = products;
export const questionnaireAnswersTable = questionnaireAnswers;
export const questionnaireFieldsTable = questionnaireFields;
export const questionnairesTable = questionnaires;
export const quotationsTable = quotations;
export const schedulesTable = schedules;
export const scriptsTable = scripts;
export const systemConfigsTable = systemConfigs;
export const userProfilesTable = userProfiles;
export const weddingCollaboratorsTable = weddingCollaborators;
export const weddingProjectsTable = weddingProjects;
export const weddingShareLinksTable = weddingShareLinks;
export const weddingStepsTable = weddingSteps;
