import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gt } from 'drizzle-orm';
import { appSessions, userProfiles } from '@server/database/schema';

@Injectable()
export class AppAuthGuard implements CanActivate {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();

    const token =
      req.headers['x-app-auth']?.toString() ||
      (req.headers['authorization']?.startsWith('Bearer ')
        ? req.headers['authorization'].slice(7)
        : null);

    if (!token) {
      throw new UnauthorizedException('请先登录');
    }

    const now = new Date();
    const [session] = await this.db
      .select()
      .from(appSessions)
      .where(and(eq(appSessions.token, token), gt(appSessions.expiresAt, now)))
      .limit(1);

    if (!session) {
      throw new UnauthorizedException('登录已失效，请重新登录');
    }

    const [profile] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, session.userId))
      .limit(1);

    if (!profile || profile.status === 'disabled') {
      throw new UnauthorizedException('账号已被禁用');
    }

    req.userContext = {
      userId: profile.userId,
      userName: profile.nickname || '婚礼主持人',
    };

    return true;
  }
}
