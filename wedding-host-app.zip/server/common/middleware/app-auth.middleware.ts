import { Injectable, NestMiddleware, Inject, Logger } from '@nestjs/common';
import type { Request, Response, NextFunction } from 'express';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gt } from 'drizzle-orm';
import { appSessions, userProfiles } from '@server/database/schema';

@Injectable()
export class AppAuthMiddleware implements NestMiddleware {
  private readonly logger = new Logger(AppAuthMiddleware.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async use(req: Request, _res: Response, next: NextFunction): Promise<void> {
    try {
      const token =
        req.headers['x-app-auth']?.toString() ||
        (req.headers['authorization']?.startsWith('Bearer ')
          ? req.headers['authorization'].slice(7)
          : null);

      if (!token) {
        next();
        return;
      }

      const now = new Date();
      const [session] = await this.db
        .select()
        .from(appSessions)
        .where(and(eq(appSessions.token, token), gt(appSessions.expiresAt, now)))
        .limit(1);

      if (!session) {
        next();
        return;
      }

      const [profile] = await this.db
        .select()
        .from(userProfiles)
        .where(eq(userProfiles.userId, session.userId))
        .limit(1);

      if (!profile || profile.status === 'disabled') {
        next();
        return;
      }

      const existingUserId = req.userContext?.userId;

      if (!existingUserId) {
        req.userContext = {
          userId: profile.userId,
          userName: profile.nickname || '婚礼主持人',
        };
      }

      next();
    } catch (error) {
      this.logger.error('自定义认证中间件异常', error);
      next();
    }
  }
}
