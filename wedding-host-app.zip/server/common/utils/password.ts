import { pbkdf2Sync, randomBytes } from 'crypto';

const ITERATIONS = 10000;
const KEY_LEN = 64;
const SALT_LEN = 16;
const DIGEST = 'sha256';

export function hashPassword(password: string): string {
  const salt = randomBytes(SALT_LEN).toString('hex');
  const derivedKey = pbkdf2Sync(password, salt, ITERATIONS, KEY_LEN, DIGEST).toString('hex');
  return `pbkdf2_sha256\$${ITERATIONS}\$${salt}\$${derivedKey}`;
}

export function verifyPassword(password: string, hash: string): boolean {
  if (!hash || !hash.startsWith('pbkdf2_sha256$')) {
    return false;
  }
  const parts = hash.split('$');
  if (parts.length !== 4) return false;
  const [, iterationsStr, salt, derivedKey] = parts;
  const iterations = parseInt(iterationsStr, 10);
  if (Number.isNaN(iterations) || iterations <= 0) return false;
  const candidate = pbkdf2Sync(password, salt, iterations, KEY_LEN, DIGEST).toString('hex');
  return candidate === derivedKey;
}
