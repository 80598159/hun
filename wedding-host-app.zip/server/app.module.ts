import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ViewModule } from './modules/view/view.module';
import { AuthModule } from './modules/auth/auth.module';
import { UserModule } from './modules/user/user.module';
import { WeddingModule } from './modules/wedding/wedding.module';
import { ScriptModule } from './modules/script/script.module';
import { ScheduleModule } from './modules/schedule/schedule.module';
import { ToolkitModule } from './modules/toolkit/toolkit.module';
import { AiModule } from './modules/ai/ai.module';
import { ShopModule } from './modules/shop/shop.module';
import { AdminModule } from './modules/admin/admin.module';
import { BgmModule } from './modules/bgm/bgm.module';
import { QuotationModule } from './modules/quotation/quotation.module';
import { QuestionnaireModule } from './modules/questionnaire/questionnaire.module';

@Module({
  imports: [
    // 平台 Module，提供平台能力
    PlatformModule.forRoot(),
    // ====== @route-section: business-modules START ======
    // Place all business modules here.Do NOT add fallback modules here.
    AuthModule,
    UserModule,
    WeddingModule,
    ScriptModule,
    ScheduleModule,
    ToolkitModule,
    AiModule,
    ShopModule,
    AdminModule,
    BgmModule,
    QuotationModule,
    QuestionnaireModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    // ViewModule is the fallback route module, must be registered last.
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
